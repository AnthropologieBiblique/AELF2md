---
aliases : 
- 1 Pierre 2
- 1 Pierre 2
- 1 P 2
- 1 Peter 2
tags : 
- Bible/1P/2
- français
cssclass : français
---

# 1 Pierre 2

###### 01
Rejetez donc toute méchanceté, toute ruse, les hypocrisies, les jalousies et toutes les médisances ;
###### 02
comme des enfants nouveau-nés, soyez avides du lait non dénaturé de la Parole qui vous fera grandir pour arriver au salut,
###### 03
puisque vous avez goûté combien le Seigneur est bon.
###### 04
Approchez-vous de lui : il est la pierre vivante rejetée par les hommes, mais choisie et précieuse devant Dieu.
###### 05
Vous aussi, comme pierres vivantes, entrez dans la construction de la demeure spirituelle, pour devenir le sacerdoce saint et présenter des sacrifices spirituels, agréables à Dieu, par Jésus Christ.
###### 06
En effet, il y a ceci dans l’Écriture :
Je vais poser en Sion une pierre angulaire,
une pierre choisie, précieuse ;
celui qui met en elle sa foi
ne saurait connaître la honte.
###### 07
Ainsi donc, honneur à vous les croyants, mais, pour ceux qui refusent de croire, il est écrit : La pierre qu’ont rejetée les bâtisseurs est devenue la pierre d’angle,
###### 08
une pierre d’achoppement, un rocher sur lequel on trébuche. Ils achoppent, ceux qui refusent d’obéir à la Parole, et c’est bien ce qui devait leur arriver.
###### 09
Mais vous, vous êtes une descendance choisie, un sacerdoce royal, une nation sainte, un peuple destiné au salut, pour que vous annonciez les merveilles de celui qui vous a appelés des ténèbres à son admirable lumière.
###### 10
Autrefois vous n’étiez pas un peuple, mais maintenant vous êtes le peuple de Dieu ; vous n’aviez pas obtenu miséricorde, mais maintenant vous avez obtenu miséricorde.
###### 11
Bien-aimés, puisque vous êtes comme des étrangers résidents ou de passage, je vous exhorte à vous abstenir des convoitises nées de la chair, qui combattent contre l’âme.
###### 12
Ayez une belle conduite parmi les gens des nations ; ainsi, sur le point même où ils disent du mal de vous en vous traitant de malfaiteurs, ils ouvriront les yeux devant vos belles actions et rendront gloire à Dieu, le jour de sa visite.
###### 13
Soyez soumis à toute institution humaine à cause du Seigneur, soit à l’empereur, qui est le souverain,
###### 14
soit aux gouverneurs, qui sont ses délégués pour punir les malfaiteurs et reconnaître les mérites des gens de bien.
###### 15
Car la volonté de Dieu, c’est qu’en faisant le bien, vous fermiez la bouche aux insensés qui parlent sans savoir.
###### 16
Soyez des hommes libres, sans toutefois utiliser la liberté pour voiler votre méchanceté : mais soyez plutôt les esclaves de Dieu.
###### 17
Honorez tout le monde, aimez la communauté des frères, craignez Dieu, honorez l’empereur.
###### 18
Vous les domestiques, soyez soumis en tout respect à vos maîtres, non seulement à ceux qui sont bons et bienveillants, mais aussi à ceux qui sont difficiles.
###### 19
En effet, c’est une grâce de supporter, par motif de conscience devant Dieu, des peines que l’on souffre injustement.
###### 20
En effet, si vous supportez des coups pour avoir commis une faute, quel honneur en attendre ? Mais si vous supportez la souffrance pour avoir fait le bien, c’est une grâce aux yeux de Dieu.
###### 21
C’est bien à cela que vous avez été appelés, car
c’est pour vous que le Christ,
lui aussi, a souffert ;
il vous a laissé un modèle
afin que vous suiviez ses traces.
###### 22
Lui n’a pas commis de péché ;
dans sa bouche,
on n’a pas trouvé de mensonge.
###### 23
Insulté, il ne rendait pas l’insulte,
dans la souffrance, il ne menaçait pas,
mais il s’abandonnait
à Celui qui juge avec justice.
###### 24
Lui-même a porté nos péchés,
dans son corps, sur le bois,
afin que, morts à nos péchés,
nous vivions pour la justice.
Par ses blessures, nous sommes guéris.
###### 25
Car vous étiez errants
comme des brebis ;
mais à présent vous êtes retournés
vers votre berger, le gardien de vos âmes.
