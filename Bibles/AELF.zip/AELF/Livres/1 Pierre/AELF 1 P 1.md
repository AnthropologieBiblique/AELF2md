---
aliases : 
- 1 Pierre 1
- 1 Pierre 1
- 1 P 1
- 1 Peter 1
tags : 
- Bible/1P/1
- français
cssclass : français
---

# 1 Pierre 1

###### 01
PIERRE, APOTRE DE JESUS CHRIST,
à ceux qui sont choisis par Dieu,
qui séjournent comme étrangers en diaspora
dans les régions du Pont, de Galatie, de Cappadoce,
dans la province d’Asie et en Bithynie,
###### 02
qui sont désignés d’avance par Dieu le Père,
et sanctifiés par l’Esprit,
pour entrer dans l’obéissance
et pour être purifiés par le sang de Jésus Christ.
Que la grâce et la paix
vous soient accordées en abondance.
###### 03
Béni soit Dieu, le Père de notre Seigneur Jésus Christ : dans sa grande miséricorde, il nous a fait renaître pour une vivante espérance grâce à la résurrection de Jésus Christ d’entre les morts,
###### 04
pour un héritage qui ne connaîtra ni corruption, ni souillure, ni flétrissure. Cet héritage vous est réservé dans les cieux,
###### 05
à vous que la puissance de Dieu garde par la foi, pour un salut prêt à se révéler dans les derniers temps.
###### 06
Aussi vous exultez de joie, même s’il faut que vous soyez affligés, pour un peu de temps encore, par toutes sortes d’épreuves ;
###### 07
elles vérifieront la valeur de votre foi qui a bien plus de prix que l’or – cet or voué à disparaître et pourtant vérifié par le feu –, afin que votre foi reçoive louange, gloire et honneur quand se révélera Jésus Christ.
###### 08
Lui, vous l’aimez sans l’avoir vu ; en lui, sans le voir encore, vous mettez votre foi, vous exultez d’une joie inexprimable et remplie de gloire,
###### 09
car vous allez obtenir le salut des âmes qui est l’aboutissement de votre foi.
###### 10
Sur le salut, les prophètes ont fait porter leurs interrogations et leurs recherches, eux qui ont prophétisé pour annoncer la grâce qui vous est destinée.
###### 11
Ils cherchaient quel temps et quelles circonstances voulait indiquer l’Esprit du Christ, présent en eux, quand il attestait par avance les souffrances du Christ et la gloire qui s’ensuivrait.
###### 12
Il leur fut révélé que ce n’était pas pour eux-mêmes, mais pour vous, qu’ils étaient au service de ce message, annoncé maintenant par ceux qui vous ont évangélisés dans l’Esprit Saint envoyé du ciel ; même des anges désirent se pencher pour scruter ce message.
###### 13
C’est pourquoi, après avoir disposé votre intelligence pour le service, restez sobres, mettez toute votre espérance dans la grâce que vous apporte la révélation de Jésus Christ.
###### 14
Comme des enfants qui obéissent, cessez de vous conformer aux convoitises d’autrefois, quand vous étiez dans l’ignorance,
###### 15
mais, à l’exemple du Dieu saint qui vous a appelés, devenez saints, vous aussi, dans toute votre conduite,
###### 16
puisqu’il est écrit : Vous serez saints, car moi, je suis saint.
###### 17
Si vous invoquez comme Père celui qui juge impartialement chacun selon son œuvre, vivez donc dans la crainte de Dieu, pendant le temps où vous résidez ici-bas en étrangers.
###### 18
Vous le savez : ce n’est pas par des biens corruptibles, l’argent ou l’or, que vous avez été rachetés de la conduite superficielle héritée de vos pères ;
###### 19
mais c’est par un sang précieux, celui d’un agneau sans défaut et sans tache, le Christ.
###### 20
Dès avant la fondation du monde, Dieu l’avait désigné d’avance et il l’a manifesté à la fin des temps à cause de vous.
###### 21
C’est bien par lui que vous croyez en Dieu, qui l’a ressuscité d’entre les morts et qui lui a donné la gloire ; ainsi vous mettez votre foi et votre espérance en Dieu.
###### 22
En obéissant à la vérité, vous avez purifié vos âmes pour vous aimer sincèrement comme des frères ; aussi, d’un cœur pur, aimez-vous intensément les uns les autres,
###### 23
car Dieu vous a fait renaître, non pas d’une semence périssable, mais d’une semence impérissable : sa parole vivante qui demeure.
###### 24
C’est pourquoi il est écrit :
Toute chair est comme l’herbe,
toute sa gloire, comme l’herbe en fleur ;
l’herbe se dessèche et la fleur tombe,
###### 25
mais la parole du Seigneur demeure pour toujours.
Or, cette parole est celle de la Bonne Nouvelle qui vous a été annoncée.
