---
aliases : 
- 1 Pierre 3
- 1 Pierre 3
- 1 P 3
- 1 Peter 3
tags : 
- Bible/1P/3
- français
cssclass : français
---

# 1 Pierre 3

###### 01
Vous les femmes, soyez soumises à votre mari, pour que, même si certains refusent d’obéir à la parole de Dieu, ils soient gagnés par la conduite de leur femme et non par des paroles,
###### 02
en ouvrant les yeux devant votre attitude pure et pleine de respect.
###### 03
Que votre parure ne soit pas extérieure – coiffure élaborée, bijoux d’or, vêtements recherchés –
###### 04
mais qu’elle soit une qualité d’humanité au plus intime de votre cœur, parure impérissable d’un esprit doux et paisible : voilà ce qui a grande valeur devant Dieu.
###### 05
C’est cela qui faisait la parure des saintes femmes de jadis, elles qui espéraient en Dieu, soumises chacune à leur mari,
###### 06
comme Sara qui obéissait à Abraham, en l’appelant seigneur. Vous êtes devenues les filles de Sara en faisant le bien, sans vous laisser troubler par aucune crainte.
###### 07
De même, vous les maris, sachez comprendre, dans la vie commune, que la femme est un être plus délicat ; accordez-lui l’honneur qui lui revient, puisqu’elle hérite, au même titre que vous, de la grâce de la vie. Ainsi, rien ne fera obstacle à vos prières.
###### 08
Vous tous, enfin, vivez en parfait accord, dans la sympathie, l’amour fraternel, la compassion et l’esprit d’humilité.
###### 09
Ne rendez pas le mal pour le mal, ni l’insulte pour l’insulte ; au contraire, invoquez sur les autres la bénédiction, car c’est à cela que vous avez été appelés, afin de recevoir en héritage cette bénédiction.
###### 10
En effet, comme il est écrit :
Celui qui veut aimer la vie
et connaître des jours heureux,
qu’il garde sa langue du mal
et ses lèvres des paroles perfides ;
###### 11
qu’il se détourne du mal et qu’il fasse le bien,
qu’il recherche la paix, et qu’il la poursuive.
###### 12
Car le Seigneur regarde les justes,
il écoute, attentif à leur demande.
Mais le Seigneur affronte les méchants.
###### 13
Qui donc vous fera du mal, si vous cherchez le bien avec ardeur ?
###### 14
Mais s’il vous arrivait de souffrir pour la justice, heureux seriez-vous ! Comme dit l’Écriture : N’ayez aucune crainte de ces gens-là, ne vous laissez pas troubler.
###### 15
Honorez dans vos cœurs la sainteté du Seigneur, le Christ. Soyez prêts à tout moment à présenter une défense devant quiconque vous demande de rendre raison de l’espérance qui est en vous ;
###### 16
mais faites-le avec douceur et respect. Ayez une conscience droite, afin que vos adversaires soient pris de honte sur le point même où ils disent du mal de vous pour la bonne conduite que vous avez dans le Christ.
###### 17
Car mieux vaudrait souffrir en faisant le bien, si c’était la volonté de Dieu, plutôt qu’en faisant le mal.
###### 18
Car le Christ, lui aussi,
a souffert pour les péchés, une seule fois,
lui, le juste, pour les injustes,
afin de vous introduire devant Dieu ;
il a été mis à mort dans la chair,
mais vivifié dans l’Esprit.
###### 19
C’est en lui qu’il est parti proclamer son message
aux esprits qui étaient en captivité.
###### 20
Ceux-ci, jadis, avaient refusé d’obéir, au temps où se prolongeait la patience de Dieu, quand Noé construisit l’arche, dans laquelle un petit nombre, en tout huit personnes, furent sauvées à travers l’eau.
###### 21
C’était une figure du baptême qui vous sauve maintenant : le baptême ne purifie pas de souillures extérieures, mais il est l’engagement envers Dieu d’une conscience droite et il sauve par la résurrection de Jésus Christ,
###### 22
lui qui est à la droite de Dieu, après s’en être allé au ciel, lui à qui sont soumis les anges, ainsi que les Souverainetés et les Puissances.
