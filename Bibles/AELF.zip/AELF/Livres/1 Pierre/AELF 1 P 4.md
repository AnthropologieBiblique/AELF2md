---
aliases : 
- 1 Pierre 4
- 1 Pierre 4
- 1 P 4
- 1 Peter 4
tags : 
- Bible/1P/4
- français
cssclass : français
---

# 1 Pierre 4

###### 01
Puisque le Christ a donc souffert dans la chair, vous aussi, armez-vous de la même pensée, à savoir : quiconque a souffert dans la chair en a fini avec le péché ;
###### 02
alors, vous vivrez le temps qui reste à passer dans la chair, non plus selon les convoitises humaines mais selon la volonté de Dieu.
###### 03
Il a assez duré, le temps passé à faire ce que veulent les gens des nations, quand vous vous laissiez aller aux débauches, aux convoitises, à l’ivrognerie, aux orgies, aux beuveries et aux cultes interdits des idoles.
###### 04
À ce propos, ils trouvent étrange que vous ne couriez plus avec eux vers les mêmes débordements d’inconduite, et ils vous couvrent d’injures.
###### 05
Ils auront des comptes à rendre à Celui qui se tient prêt à juger les vivants et les morts.
###### 06
C’est pour cela que l’Évangile a été annoncé aussi aux morts, afin que, jugés selon les hommes dans la chair, ils vivent selon Dieu dans l’Esprit.
###### 07
La fin de toutes choses est proche. Soyez donc raisonnables et sobres en vue de la prière.
###### 08
Avant tout, ayez entre vous une charité intense, car la charité couvre une multitude de péchés.
###### 09
Pratiquez l’hospitalité les uns envers les autres sans récriminer.
###### 10
Ce que chacun de vous a reçu comme don de la grâce, mettez-le au service des autres, en bons gérants de la grâce de Dieu qui est si diverse :
###### 11
si quelqu’un parle, qu’il le fasse comme pour des paroles de Dieu ; celui qui assure le service, qu’il s’en acquitte comme avec la force procurée par Dieu. Ainsi, en tout, Dieu sera glorifié par Jésus Christ, à qui appartiennent la gloire et la souveraineté pour les siècles des siècles. Amen.
###### 12
Bien-aimés, ne trouvez pas étrange le brasier allumé parmi vous pour vous mettre à l’épreuve ; ce qui vous arrive n’a rien d’étrange.
###### 13
Dans la mesure où vous communiez aux souffrances du Christ, réjouissez-vous, afin d’être dans la joie et l’allégresse quand sa gloire se révélera.
###### 14
Si l’on vous insulte pour le nom du Christ, heureux êtes-vous, parce que l’Esprit de gloire, l’Esprit de Dieu, repose sur vous.
###### 15
Que personne d’entre vous, en effet, n’ait à souffrir comme meurtrier, voleur, malfaiteur, ou comme agitateur.
###### 16
Mais si c’est comme chrétien, qu’il n’ait pas de honte, et qu’il rende gloire à Dieu pour ce nom-là.
###### 17
Car voici le temps du jugement : il commence par la famille de Dieu. Or, s’il vient d’abord sur nous, quelle sera la fin de ceux qui refusent d’obéir à l’Évangile de Dieu ?
###### 18
Et, si le juste est sauvé à grand-peine, l’impie, le pécheur, où va-t-il se montrer ?
###### 19
Ainsi, ceux qui souffrent en faisant la volonté de Dieu, qu’ils confient leurs âmes au Créateur fidèle, en faisant le bien.
