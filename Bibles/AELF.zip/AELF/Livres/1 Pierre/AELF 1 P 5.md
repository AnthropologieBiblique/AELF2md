---
aliases : 
- 1 Pierre 5
- 1 Pierre 5
- 1 P 5
- 1 Peter 5
tags : 
- Bible/1P/5
- français
cssclass : français
---

# 1 Pierre 5

###### 01
Quant aux anciens en fonction parmi vous, je les exhorte, moi qui suis ancien comme eux et témoin des souffrances du Christ, communiant à la gloire qui va se révéler :
###### 02
soyez les pasteurs du troupeau de Dieu qui se trouve chez vous ; veillez sur lui, non par contrainte mais de plein gré, selon Dieu ; non par cupidité mais par dévouement ;
###### 03
non pas en commandant en maîtres à ceux qui vous sont confiés, mais en devenant les modèles du troupeau.
###### 04
Et, quand se manifestera le Chef des pasteurs, vous recevrez la couronne de gloire qui ne se flétrit pas.
###### 05
De même, vous les jeunes gens, soyez soumis aux anciens.
Et vous tous, les uns envers les autres, prenez l’humilité comme tenue de service. En effet, Dieu s’oppose aux orgueilleux, aux humbles il accorde sa grâce.
###### 06
Abaissez-vous donc sous la main puissante de Dieu, pour qu’il vous élève en temps voulu.
###### 07
Déchargez-vous sur lui de tous vos soucis, puisqu’il prend soin de vous.
###### 08
Soyez sobres, veillez : votre adversaire, le diable, comme un lion rugissant, rôde, cherchant qui dévorer.
###### 09
Résistez-lui avec la force de la foi, car vous savez que tous vos frères, de par le monde, sont en butte aux mêmes souffrances.
###### 10
Après que vous aurez souffert un peu de temps, le Dieu de toute grâce, lui qui, dans le Christ Jésus, vous a appelés à sa gloire éternelle, vous rétablira lui-même, vous affermira, vous fortifiera, vous rendra inébranlables.
###### 11
À lui la souveraineté pour les siècles. Amen.
###### 12
Par Silvain, que je considère comme un frère digne de confiance, je vous écris ces quelques mots pour vous exhorter, et pour attester que c’est vraiment dans la grâce de Dieu que vous tenez ferme.
###### 13
La communauté qui est à Babylone, choisie comme vous par Dieu, vous salue, ainsi que Marc, mon fils.
###### 14
Saluez-vous les uns les autres par un baiser fraternel.
Paix à vous tous, qui êtes dans le Christ.
