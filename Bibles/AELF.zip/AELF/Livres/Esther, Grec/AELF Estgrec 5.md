---
aliases : 
- Esther, Grec 5
- Esther, Grec 5
- Estgrec 5
- Esther, Greek 5
tags : 
- Bible/Estgrec/5
- français
cssclass : français
---

# Esther, Grec 5

###### 01
Au troisième jour, lorsqu’elle eut cessé de prier, Esther quitta ses vêtements de suppliante et revêtit des habits d’apparat.
###### 1A
Ainsi dans tout son éclat, ayant invoqué le Dieu qui protège et qui sauve, elle prit avec elle ses deux servantes : sur l’une d’elles, elle s’appuyait mollement ; l’autre l’accompagnait en portant sa traîne.
###### 1B
Elle-même était rougissante, au comble de sa beauté ; son visage était radieux, comme épanoui par l’amour, mais son cœur était serré par la peur.
###### 1C
Franchissant toutes les portes, elle se trouva devant le roi. Il était assis sur son trône royal, revêtu de l’habit avec lequel il paraissait en public, rutilant d’or et de pierres précieuses : il était redoutable.
###### 1D
Il leva son visage rayonnant de gloire et, au comble de la colère, il la fixa. La reine s’effondra. Prise de faiblesse, elle changea de couleur et se pencha vers la tête de la servante qui la précédait.
###### 1E
Dieu changea le cœur du roi et l’inclina à la douceur. Saisi d’angoisse, il s’élança de son trône et la prit dans ses bras jusqu’à ce qu’elle se remît. Il la réconfortait par des paroles apaisantes :
###### 1F
« Qu’y a-t-il, Esther ? Je suis ton frère. Rassure-toi ! Tu ne mourras pas : notre décret ne vaut que pour le commun des gens. Viens avec moi ! »
###### 02
Levant son sceptre d’or, il le posa sur le cou d’Esther, puis il l’embrassa en disant : « Parle-moi ».
###### 2A
« Seigneur, lui dit-elle, je t’ai vu pareil à un ange de Dieu. Mon cœur a été troublé, j’ai eu peur de ta gloire. Car tu es admirable, Seigneur, et ton visage est merveilleux. »
###### 2B
Tandis qu’elle parlait, elle tomba de faiblesse. Le roi était bouleversé, et toute sa suite la réconfortait.
###### 03
Le roi lui demanda : « Qu’y a-t-il, reine Esther ? Quelle est ta requête ? Quand ce serait la moitié du royaume, cela te serait accordé. »
###### 04
Esther dit : « S’il plaît au roi, que le roi vienne aujourd’hui avec Amane au banquet que je lui ai préparé. »
###### 05
Le roi dit alors : « Allez vite chercher Amane, pour répondre à l’invitation d’Esther ! »
Le roi et Amane vinrent au banquet préparé par Esther.
###### 06
Au cours du banquet, le roi dit de nouveau à Esther : « Quelle est ta demande ? Cela te sera accordé. Quelle est ta requête ? Quand ce serait la moitié du royaume, ce sera réalisé. »
###### 07
Esther répondit : « Ma demande ? Ma requête ?
###### 08
Si j’ai trouvé grâce aux yeux du roi, s’il lui plaît d’exaucer ma demande et de réaliser ma requête, que le roi vienne encore demain avec Amane au banquet que je préparerai pour eux, et je me conformerai à la parole du roi. »
###### 09
Ce jour-là, Amane sortit joyeux et le cœur content. Mais lorsque, à la porte du roi, il vit Mardochée qui ne se levait pas et ne se dérangeait pas à sa vue, il fut rempli de fureur contre Mardochée.
###### 10
Mais il se domina et rentra chez lui. Il envoya chercher ses amis et sa femme Zéresh,
###### 11
et, longuement, il leur parla de ses somptueuses richesses, de la multitude de ses fils, de tout ce dont le roi l’avait comblé, pour l’élever et le mettre au-dessus de ses princes et de ses serviteurs.
###### 12
Amane ajouta : « La reine Esther n’a fait venir que moi, avec le roi, au banquet qu’elle a préparé ; bien plus, elle vient de m’inviter encore demain avec le roi.
###### 13
Mais tout cela est sans intérêt pour moi, tant que je verrai Mardochée, le Juif, assis à la porte du roi. »
###### 14
Sa femme Zéresh et tous ses amis lui dirent alors : « Que l’on dresse une potence de cinquante coudées et, demain matin, demande au roi qu’on y pende Mardochée. Puis va te réjouir au banquet du roi ! » Le conseil plut à Amane, et il fit préparer la potence.
