---
aliases : 
- Esther, Grec 7
- Esther, Grec 7
- Estgrec 7
- Esther, Greek 7
tags : 
- Bible/Estgrec/7
- français
cssclass : français
---

# Esther, Grec 7

###### 01
Le roi se rendit avec Amane au banquet de la reine Esther.
###### 02
Le deuxième jour, au cours du banquet, le roi dit encore à Esther : « Quelle est ta demande, ô reine Esther ? Cela te sera accordé. Quelle est ta requête ? Quand ce serait la moitié du royaume, ce sera réalisé. »
###### 03
La reine Esther répondit : « Si j’ai trouvé grâce à tes yeux, ô roi, et s’il plaît au roi, accorde-moi la vie – voilà ma demande. Accorde la vie à mon peuple – voilà ma requête.
###### 04
Car nous avons été vendus, moi et mon peuple, pour être exterminés, tués, anéantis. Si nous avions été seulement vendus comme esclaves ou servantes, je me serais tue ; car ce mauvais traitement n’aurait pas justifié que l’on dérange le roi. »
###### 05
Le roi Assuérus prit la parole et demanda à la reine Esther : « De qui s’agit-il ? Quel est l’homme qui a osé agir ainsi ? »
###### 06
Esther répondit : « L’adversaire, l’ennemi, c’est Amane, c’est ce misérable. »
Devant le roi et la reine, Amane fut terrifié.
###### 07
Plein de fureur, le roi se leva, quitta la salle du banquet pour gagner le jardin du palais, tandis qu’Amane se tenait près de la reine Esther et lui demandait grâce pour sa vie, voyant bien que le roi avait décidé sa perte.
###### 08
Quand le roi revint du jardin du palais dans la salle du banquet, Amane était effondré sur le divan où se trouvait Esther. « Quoi ! dit le roi. Va-t-il encore faire violence à la reine chez moi, dans ma maison ? » Le roi prononça un ordre, et on voila le visage d’Amane.
###### 09
Harbona, l’un des eunuques, dit devant le roi : « Il y a justement, dans la maison d’Amane, une potence de cinquante coudées, qu’Amane avait dressée pour Mardochée, l’homme qui a parlé pour le bien du roi. » Le roi dit : « Qu’on l’y pende ! »
###### 10
On pendit Amane à la potence qu’il avait préparée pour Mardochée, et la fureur du roi s’apaisa.
