---
aliases : 
- Esther, Grec 6
- Esther, Grec 6
- Estgrec 6
- Esther, Greek 6
tags : 
- Bible/Estgrec/6
- français
cssclass : français
---

# Esther, Grec 6

###### 01
Or, cette nuit-là, comme le sommeil le fuyait, le roi se fit apporter le livre des Mémoires, les Chroniques, pour s’en faire donner lecture.
###### 02
On y trouva écrit ce que Mardochée avait révélé sur les eunuques du roi, Bigtane et Tèresh, deux des gardiens du seuil, qui avaient cherché à porter la main sur le roi Assuérus.
###### 03
Le roi demanda : « Quels honneurs et quelle distinction ont récompensé Mardochée pour cette révélation ? » Les jeunes serviteurs du roi lui dirent : « Rien n’a été fait pour le récompenser. »
###### 04
Le roi leur demanda alors : « Qui est dans la cour ? » C’était juste le moment où Amane arrivait dans la cour extérieure du palais royal pour demander au roi de faire pendre Mardochée à la potence qu’il avait fait préparer pour lui.
###### 05
Les jeunes serviteurs du roi lui répondirent : « C’est Amane qui se tient dans la cour. » Le roi ordonna : « Qu’il entre ! »
###### 06
Dès qu’il fut entré, le roi lui dit : « Comment faut-il traiter un homme que le roi désire honorer ? » Amane se dit : « Qui le roi désirerait-il honorer plus que moi ? »
###### 07
Il répondit donc au roi : « Le roi désire-t-il honorer quelqu’un ?
###### 08
Qu’on apporte un vêtement royal, parmi ceux que le roi a déjà portés, un cheval que le roi a monté et un bandeau royal qui a déjà orné sa tête.
###### 09
Que l’on confie vêtement et cheval à l’un des plus nobles des princes du roi. On revêtira alors l’homme que le roi désire honorer, on le conduira à cheval sur la place de la ville, et devant lui on criera : “Voilà comment on traite l’homme que le roi désire honorer !” »
###### 10
Le roi dit à Amane : « Vite, prends le vêtement et le cheval ! Ce que tu as dit, fais-le pour Mardochée, le Juif, qui est assis à la porte du roi. Et surtout, ne néglige rien de ce que tu as dit. »
###### 11
Et Amane, prenant vêtement et cheval, revêtit Mardochée, le conduisit à cheval sur la place de la ville, en criant devant lui : « Voilà comment on traite l’homme que le roi désire honorer ! »
###### 12
Puis Mardochée revint à la porte du roi tandis qu’Amane se précipitait chez lui, consterné, la tête voilée.
###### 13
Amane raconta à sa femme Zéresh et à tous ses amis ce qui lui était arrivé. Ses conseillers et sa femme lui dirent : « Ce Mardochée, devant qui tu commences à capituler, s’il appartient bien à la race des Juifs, tu ne pourras rien contre lui, tu capituleras totalement devant lui. »
###### 14
Comme ils lui parlaient encore, les eunuques du roi arrivèrent et conduisirent aussitôt Amane au banquet qu’avait préparé Esther.
