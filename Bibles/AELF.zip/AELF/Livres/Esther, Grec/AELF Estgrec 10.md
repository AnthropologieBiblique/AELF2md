---
aliases : 
- Esther, Grec 10
- Esther, Grec 10
- Estgrec 10
- Esther, Greek 10
tags : 
- Bible/Estgrec/10
- français
cssclass : français
---

# Esther, Grec 10

###### 01
Le roi Assuérus perçut un impôt sur le continent et les îles de la mer.
###### 02
Tous ses actes de puissance et de vaillance, et les détails de la haute situation que le roi avait accordée à Mardochée ne sont-ils pas écrits dans le livre des Chroniques des rois de Médie et de Perse ?
###### 03
Car Mardochée le Juif était le second personnage du royaume après le roi Assuérus ; il était grand aux yeux des Juifs, et aimé de la multitude de ses frères. Il recherchait le bien de son peuple et se préoccupait du bonheur de toute sa race.
###### 3A
Et Mardochée dit : « C’est grâce à Dieu que tout cela est arrivé.
###### 3B
Je me souviens en effet du songe que j’ai eu à ce sujet, rien n’a été omis :
###### 3C
ni la petite source qui est devenue un fleuve, ni la lumière, ni le soleil, ni l’eau abondante. Esther est ce fleuve, elle que le roi a épousée, et qu’il a faite reine ;
###### 3D
les deux dragons, c’est moi et Amane.
###### 3E
Les nations sont celles qui se sont rassemblées pour effacer le nom des Juifs.
###### 3F
Ma nation, c’est Israël, ceux qui crièrent vers Dieu et furent sauvés. Oui, le Seigneur a sauvé son peuple, le Seigneur nous a arrachés à tous ces maux, Dieu a accompli des signes et de grands prodiges, comme il n’y en eut jamais parmi les nations.
###### 3G
C’est pourquoi il a réservé deux sorts, l’un pour le peuple de Dieu, l’autre pour toutes les nations.
###### 3H
Ces deux sorts ont trouvé accomplissement à l’heure, au temps et au jour que Dieu avait fixés pour toutes les nations :
###### 3I
Dieu s’est souvenu de son peuple, il a rendu justice à son héritage.
###### 3K
Ces quatorzième et quinzième jours du mois nommé Adar seront désormais des jours de rassemblement, de joie et d’allégresse devant Dieu, pour toutes les générations et à jamais, en Israël son peuple. »
###### 3L
La quatrième année du règne de Ptolémée et de Cléopâtre, Dosithée, qui se déclarait prêtre et lévite, ainsi que son fils Ptolémée, apportèrent la présente lettre concernant la fête de Pourim. Ils la déclaraient authentique et traduite par Lysimaque, fils de Ptolémée, un des habitants de Jérusalem.
