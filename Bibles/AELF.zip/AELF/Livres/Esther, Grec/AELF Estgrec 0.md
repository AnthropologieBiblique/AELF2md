---
aliases : 
- Esther, Grec 0
- Esther, Grec 0
- Estgrec 0
- Esther, Greek 0
tags : 
- Bible/Estgrec/0
- français
cssclass : français
---

# Esther, Grec 0

###### 1A
LA DEUXIEME ANNEE du règne du grand roi Assuérus, le premier jour du mois de Nissane, Mardochée, fils de Jaïre, fils de Shiméï, fils de Qish, de la tribu de Benjamin, fit un songe.
###### 1B
C’était un Juif qui habitait la ville de Suse, un personnage important, ayant une fonction à la cour.
###### 1C
Il faisait partie des captifs que Nabucodonosor, roi de Babylone, avait déportés de Jérusalem avec le roi de Juda, Jékonias.
###### 1D
Voici le songe : cris et tumulte, le tonnerre gronde et le sol tremble, toute la terre est bouleversée.
###### 1E
Et voilà que deux énormes dragons s’avancent, prêts l’un et l’autre au combat, et ils poussent un hurlement.
###### 1F
À ce bruit, toutes les nations se préparent à la guerre contre le peuple des justes.
###### 1G
Jour de ténèbres et d’obscurité ! Souffrance, détresse, angoisse, grand bouleversement sur la terre !
###### 1H
Bouleversé de terreur devant les maux qui l’attendent, le peuple juste tout entier se prépare à périr et crie vers Dieu ;
###### 1I
à son cri, comme d’une petite source, naît un grand fleuve, une eau abondante.
###### 1K
La lumière se lève avec le soleil ; les humbles sont exaltés et dévorent les superbes.
###### 1L
À son réveil, Mardochée, ayant vu ce songe et pensant y découvrir le dessein de Dieu, le retint dans son cœur et, jusqu’à la nuit, s’efforça de toutes les manières d’en pénétrer le sens.
