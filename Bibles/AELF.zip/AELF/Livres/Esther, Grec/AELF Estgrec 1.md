---
aliases : 
- Esther, Grec 1
- Esther, Grec 1
- Estgrec 1
- Esther, Greek 1
tags : 
- Bible/Estgrec/1
- français
cssclass : français
---

# Esther, Grec 1

###### 01
C’ETAIT AU TEMPS D’ASSUERUS – cet Assuérus qui régnait sur cent vingt-sept provinces, depuis l’Inde jusqu’à l’Éthiopie.
###### 02
En ces jours-là, comme le roi Assuérus siégeait sur son trône royal, qui est à Suse-la-Citadelle,
###### 03
la troisième année de son règne, il donna en sa présence un banquet pour tous ses princes et ses serviteurs, les chefs de l’armée de Perse et de Médie, les nobles et les gouverneurs des provinces.
###### 04
Il voulait leur montrer la richesse de sa gloire royale et la splendeur de sa grande magnificence, pendant de longs jours – cent quatre-vingts jours durant.
###### 05
Après cette période, pour toute la population de Suse-la-Citadelle, pour les gens importants comme pour les humbles, le roi donna un banquet de sept jours dans la cour du jardin du palais royal.
###### 06
Des tentures blanches et violettes étaient attachées par des cordelières de lin et de pourpre à des anneaux d’argent et à des colonnes de marbre blanc. Pour le banquet, des lits d’or et d’argent étaient posés sur un pavement de porphyre, de marbre blanc, de nacre et de marbre noir.
###### 07
On servait à boire dans des vases d’or de différentes formes, et le vin du roi était versé avec une libéralité royale.
###### 08
La règle était de boire sans contrainte, car le roi avait ordonné à tous les maîtres d’hôtel de servir selon le bon plaisir de chacun.
###### 09
La reine Vasti avait également organisé un banquet pour les femmes dans le palais du roi Assuérus.
###### 10
Le septième jour, alors que le roi avait le cœur joyeux sous l’effet du vin, il donna l’ordre à Mehoumane, à Bizzeta, à Harbona, à Bigta, à Abagta, à Zétar, à Karkas – les sept eunuques qui étaient au service du roi Assuérus –
###### 11
de faire venir devant le roi la reine Vasti, portant sa couronne royale, pour montrer sa beauté aux peuples et aux princes, car elle était agréable à voir.
###### 12
Mais la reine Vasti refusa de venir selon l’ordre du roi transmis par les eunuques. Le roi en fut très irrité et sa colère s’enflamma.
###### 13
Le roi s’adressa alors aux sages qui avaient la connaissance des temps, – car toute affaire royale devait aller devant les spécialistes de la loi et du droit.
###### 14
Les plus proches étaient Karshena, Shétar, Admata, Tarshish, Mérès, Marsena, Memoukane, les sept chefs de Perse et de Médie qui voyaient la face du roi et siégeaient au premier rang du royaume. Il leur dit :
###### 15
« Que faire, conformément à la loi, pour punir la reine Vasti de n’avoir pas obéi à l’ordre d’Assuérus transmis par les eunuques ? »
###### 16
Memoukane prit la parole en présence du roi et de ses princes : « Ce n’est pas seulement contre le roi que la reine Vasti a mal agi, mais contre tous les princes et contre tous les peuples dans toutes les provinces du roi Assuérus.
###### 17
Car son attitude sera connue de toutes les femmes et leur fera mépriser leurs maris, quand on leur dira : “Le roi Assuérus avait ordonné de faire venir la reine Vasti en sa présence, et elle n’est pas venue !”
###### 18
Et dès aujourd’hui, les princesses de Perse et de Médie qui auront entendu parler de l’attitude de la reine vont se mettre à répliquer à tous les princes du roi. Ce ne seront que mépris et colère !
###### 19
Si le roi le trouve bon, qu’il publie une ordonnance royale qui sera inscrite dans les lois de Perse et de Médie, et sera irrévocable : selon cette ordonnance, Vasti ne paraîtra plus en présence du roi Assuérus qui donnera son titre de reine à une autre, meilleure qu’elle.
###### 20
Et le décret que le roi aura publié sera connu dans tout son royaume – et il est grand ! Alors, toutes les femmes auront du respect pour leurs maris, du plus important au plus humble. »
###### 21
La proposition plut au roi et aux princes, et le roi agit selon les conseils de Memoukane.
###### 22
Il envoya des lettres dans toutes ses provinces, pour chaque province selon son écriture, et pour chaque peuple selon sa langue, afin que tout homme, parlant la langue de son peuple, fût maître dans sa maison.
