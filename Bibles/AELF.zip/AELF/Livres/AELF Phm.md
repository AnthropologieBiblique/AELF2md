---
aliases : 
- Philémon
- Philémon
- Phm
- Philemon
tags : 
- Bible/Phm
- français
cssclass : français
---

# Philémon

[[AELF Phm 1|Philémon 1]]
