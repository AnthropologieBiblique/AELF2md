---
aliases : 
- Michée 7
- Michée 7
- Mi 7
- Micah 7
tags : 
- Bible/Mi/7
- français
cssclass : français
---

# Michée 7

###### 01
Hélas pour moi !
Je suis comme au temps des récoltes d’été,
comme au grappillage des vendanges :
plus une grappe à manger,
plus de ces figues précoces que j’aime tant !
###### 02
Les fidèles ont disparu du pays :
plus un seul homme juste !
Tous cherchent l’occasion de verser le sang,
chacun tend un piège à son frère.
###### 03
Leurs mains sont habiles pour faire le mal :
le chef se fait payer, le juge également,
et le grand fait savoir ce qu’il désire ;
ensemble ils intriguent.
###### 04
Le meilleur d’entre eux est pareil à un buisson de ronces,
le plus juste est pire qu’une haie d’épines.
Au jour annoncé par les guetteurs, le châtiment arrive ;
c’est alors qu’ils seront confondus.
###### 05
Ne mets pas ta foi dans ton ami,
ne te confie pas à ton familier ;
devant celle qui repose entre tes bras,
garde les portes de ta bouche.
###### 06
Car le fils insulte son père,
la fille se dresse contre sa mère,
la belle-fille contre sa belle-mère,
chacun a pour ennemis les gens de sa maison.
###### 07
« Moi, Jérusalem, je veux guetter le Seigneur,
attendre Dieu mon Sauveur ;
lui, mon Dieu, m’entendra.
###### 08
Ne te réjouis pas de mon malheur, ô mon ennemie ;
oui, je suis tombée, mais je me relève ;
j’habite dans les ténèbres,
mais le Seigneur est ma lumière.
###### 09
Puisque j’ai péché contre le Seigneur,
je dois endurer sa colère
jusqu’à ce qu’il prenne ma cause en main
et rétablisse mon droit.
Il me fera sortir à la lumière,
et je contemplerai sa justice.
###### 10
Mon ennemie verra tout cela,
elle sera couverte de honte,
elle qui me disait :
“Où est-il, le Seigneur, ton Dieu ?”
Mes yeux la contempleront
tandis qu’elle sera piétinée
comme la boue des rues. »
###### 11
Au jour où l’on rebâtira ton enclos,
ce jour-là on repoussera tes frontières,
###### 12
ce jour-là on viendra jusqu’à toi,
depuis Assour jusqu’à l’Égypte,
depuis l’Égypte jusqu’au Fleuve,
et de la mer à la mer, de la montagne à la montagne.
###### 13
Le reste de la terre deviendra un lieu désolé
à cause de ses habitants,
tel sera le fruit de leur conduite.
###### 14
Seigneur, avec ta houlette,
sois le pasteur de ton peuple,
du troupeau qui t’appartient,
qui demeure isolé dans le maquis,
entouré de vergers.
Qu’il retrouve son pâturage à Bashane et Galaad,
comme aux jours d’autrefois !
###### 15
Comme aux jours où tu sortis d’Égypte,
tu lui feras voir des merveilles !
###### 16
Les nations verront, et elles seront confondues
en dépit de toute leur puissance.
Elles mettront la main sur leur bouche,
leurs oreilles deviendront sourdes.
###### 17
Elles lécheront la poussière comme le serpent,
comme les bêtes qui rampent sur la terre.
Elles trembleront en sortant de leurs forteresses,
elles viendront vers le Seigneur, notre Dieu,
elles seront terrifiées, elles auront peur de toi.
###### 18
Qui est Dieu comme toi, pour enlever le crime,
pour passer sur la révolte
comme tu le fais à l’égard du reste, ton héritage :
un Dieu qui ne s’obstine pas pour toujours dans sa colère
mais se plaît à manifester sa faveur ?
###### 19
De nouveau, tu nous montreras ta miséricorde,
tu fouleras aux pieds nos crimes,
tu jetteras au fond de la mer tous nos péchés !
###### 20
Ainsi tu accordes à Jacob ta fidélité,
à Abraham ta faveur,
comme tu l’as juré à nos pères
depuis les jours d’autrefois.
