---
aliases : 
- Michée 3
- Michée 3
- Mi 3
- Micah 3
tags : 
- Bible/Mi/3
- français
cssclass : français
---

# Michée 3

###### 01
Et je dis :
Écoutez donc, chefs de Jacob
et dirigeants de la maison d’Israël !
N’est-ce pas à vous de connaître le droit ?
###### 02
Vous qui haïssez le bien et aimez le mal,
vous qui leur arrachez la peau,
et la chair de dessus leurs os.
###### 03
Ceux qui ont dévoré la chair de mon peuple,
qui lui ont arraché la peau et brisé les os,
qui l’ont découpé comme viande en la marmite,
comme chair à l’intérieur du chaudron,
###### 04
ceux-là pourront bien crier vers le Seigneur,
il ne leur répondra pas.
Il leur cachera sa face en ce temps-là,
à cause du mal qu’ils ont commis.
###### 05
Ainsi parle le Seigneur
contre les prophètes qui égarent mon peuple :
Ont-ils quelque chose à se mettre sous la dent ?
Ils annoncent la paix.
À qui ne leur met rien dans la bouche,
ils déclarent la guerre.
###### 06
C’est pourquoi ce sera pour vous la nuit,
et pas de vision ;
ce sera pour vous les ténèbres,
et pas de divination.
Le soleil se couchera pour les prophètes,
pour eux le jour s’obscurcira.
###### 07
Les voyants seront alors couverts de honte
et les devins, remplis de confusion ;
tous, ils mettront la main sur leurs lèvres,
car il n’y aura pas de réponse de Dieu.
###### 08
Moi, au contraire, je suis rempli de force
– celle du souffle du Seigneur –,
je suis rempli de jugement et de courage,
pour dénoncer à Jacob sa révolte,
à Israël son péché.
###### 09
Écoutez donc ceci, chefs de la maison de Jacob,
dirigeants de la maison d’Israël,
vous qui avez la justice en abomination,
qui tordez tout ce qui est droit,
###### 10
bâtissant Sion dans le sang
et Jérusalem dans la perfidie !
###### 11
Ses chefs jugent pour un cadeau,
ses prêtres enseignent pour un salaire,
ses prophètes pratiquent la divination pour de l’argent.
Et ils s’appuient sur le Seigneur en disant :
« Le Seigneur n’est-il pas au milieu de nous ?
Aucun malheur ne peut nous atteindre ! »
###### 12
C’est pourquoi, à cause de vous,
Sion sera un champ qu’on laboure,
Jérusalem, un monceau de décombres,
et la montagne du Temple, des lieux sacrés envahis par la forêt.
