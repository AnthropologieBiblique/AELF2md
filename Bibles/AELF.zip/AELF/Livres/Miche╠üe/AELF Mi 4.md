---
aliases : 
- Michée 4
- Michée 4
- Mi 4
- Micah 4
tags : 
- Bible/Mi/4
- français
cssclass : français
---

# Michée 4

###### 01
Il arrivera dans les derniers jours
que la montagne de la Maison du Seigneur
se tiendra plus haut que les monts,
elle s’élèvera au-dessus des collines.
Vers elle afflueront des peuples
###### 02
et viendront des nations nombreuses.
Elles diront : « Venez !
montons à la montagne du Seigneur,
à la maison du Dieu de Jacob !
Qu’il nous enseigne ses chemins,
et nous irons par ses sentiers. »
Oui, la loi sortira de Sion,
et de Jérusalem, la parole du Seigneur.
###### 03
Il sera le juge entre des peuples nombreux
et, jusqu’aux lointains, l’arbitre de nations puissantes.
De leurs épées, ils forgeront des socs,
et de leurs lances, des faucilles.
Jamais nation contre nation
ne lèvera l’épée ;
ils n’apprendront plus la guerre.
###### 04
Chacun pourra s’asseoir sous sa vigne et son figuier,
et personne pour l’inquiéter.
La bouche du Seigneur de l’univers a parlé !
###### 05
Oui, tous les peuples marchent,
chacun au nom de son dieu ;
mais nous, nous marchons
au nom du Seigneur, notre Dieu,
pour toujours et à jamais.
###### 06
Ce jour-là – oracle du Seigneur –,
je rassemblerai les brebis boiteuses,
je réunirai les égarées,
et celles que j’avais maltraitées.
###### 07
Des boiteuses je ferai le reste d’Israël,
de celles qui sont mises à l’écart, une nation puissante.
Le Seigneur régnera sur eux
à la montagne de Sion,
dès maintenant et à jamais.
###### 08
Et toi, Tour du Troupeau,
Ophel de la fille de Sion,
à toi va revenir la souveraineté d’antan,
la royauté de la fille de Jérusalem.
###### 09
Maintenant pourquoi pousses-tu de tels cris ?
N’y a-t-il donc pas de Roi chez toi ?
A-t-il péri, ton Conseiller,
pour que les douleurs t’aient saisie
comme la femme qui enfante ?
###### 10
Oui, tords-toi de douleur, fille de Sion,
et mets-toi en travail comme celle qui enfante,
car maintenant il te faut sortir de la cité,
camper dans les champs.
Puis, tu iras jusqu’à Babel,
c’est là que tu seras délivrée ;
c’est là que le Seigneur te rachètera
de la main de tes ennemis.
###### 11
Maintenant se sont rassemblées contre toi
des nations nombreuses, et elles disent :
« Qu’on profane Sion !
Que nos yeux se repaissent d’un tel spectacle ! »
###### 12
Mais elles ne connaissent pas les pensées du Seigneur ;
elles ne comprennent pas son projet :
il les a rassemblées comme les gerbes sur l’aire à grain.
###### 13
Lève-toi, fille de Sion, piétine-les !
Je te ferai des cornes de fer,
je te ferai des sabots de bronze.
Tu vas broyer des peuples nombreux.
Le fruit de leurs rapines, tu le voueras par anathème au Seigneur,
et leurs richesses, au Maître de toute la terre.
###### 14
Maintenant, rassemble tes troupes.
Contre nous on a mis le siège.
À coups de bâton, on frappe à la joue
le juge d’Israël.
