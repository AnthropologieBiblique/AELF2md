---
aliases : 
- Michée 5
- Michée 5
- Mi 5
- Micah 5
tags : 
- Bible/Mi/5
- français
cssclass : français
---

# Michée 5

###### 01
Et toi, Bethléem Éphrata,
le plus petit des clans de Juda,
c’est de toi que sortira pour moi
celui qui doit gouverner Israël.
Ses origines remontent aux temps anciens,
aux jours d’autrefois.
###### 02
Mais Dieu livrera son peuple
jusqu’au jour où enfantera...
celle qui doit enfanter,
et ceux de ses frères qui resteront
rejoindront les fils d’Israël.
###### 03
Il se dressera et il sera leur berger
par la puissance du Seigneur,
par la majesté du nom du Seigneur, son Dieu.
Ils habiteront en sécurité, car désormais
il sera grand jusqu’aux lointains de la terre,
###### 04
et lui-même, il sera la paix !
Alors, si Assour envahissait notre pays,
s’il foulait au pied nos palais,
nous susciterions contre lui sept pasteurs,
et huit meneurs d’hommes.
###### 05
Ils seraient les bergers de la terre d’Assour avec l’épée,
de la terre de Nimrod avec le glaive.
Car lui nous délivrerait d’Assour,
si Assour venait à entrer sur notre terre,
à fouler notre territoire.
###### 06
Alors, le reste de Jacob sera,
au milieu des peuples nombreux,
comme une rosée venant du Seigneur,
comme une ondée sur l’herbe
qui n’espère rien de l’homme
et n’attend rien des fils d’homme.
###### 07
Alors, le reste de Jacob sera,
au milieu des peuples nombreux,
comme un lion parmi les bêtes de la forêt,
comme un lionceau parmi les troupeaux de moutons :
chaque fois qu’il passe, il piétine,
il déchire, et personne qui délivre !
###### 08
Seigneur, que ta main se lève sur tes adversaires,
et que tous tes ennemis soient supprimés !
###### 09
Voici ce qui arrivera ce jour-là – oracle du Seigneur –,
je supprimerai de chez toi les chevaux
et je ferai disparaître tes chars.
###### 10
Je supprimerai les villes de ton pays
et je démolirai toutes tes forteresses.
###### 11
Je supprimerai de ta main tes sorcelleries ;
il n’y aura plus chez toi de magiciens.
###### 12
Je supprimerai de chez toi tes statues et tes stèles,
et tu ne te prosterneras plus devant l’œuvre de tes mains.
###### 13
Je supprimerai de chez toi tes poteaux sacrés
et j’exterminerai tes villes.
###### 14
Avec colère, avec fureur, j’exercerai ma vengeance
sur les nations qui n’ont pas écouté.
