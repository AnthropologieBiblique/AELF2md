---
aliases : 
- Michée 1
- Michée 1
- Mi 1
- Micah 1
tags : 
- Bible/Mi/1
- français
cssclass : français
---

# Michée 1

###### 01
PAROLE DU SEIGNEUR qui fut adressée à Michée de Moréshèth, au temps de Yotam, d’Acaz et d’Ézékias, rois de Juda – ce qu’il a vu au sujet de Samarie et de Jérusalem.
###### 02
Vous, tous les peuples, écoutez !
Sois attentive, terre et toute ta richesse !
Dieu, le Seigneur, va témoigner contre vous,
le Seigneur, du haut de son temple saint.
###### 03
Voici que le Seigneur sort du lieu où il demeure ;
il descend, il foule les sommets de la terre.
###### 04
Les montagnes fondent sous ses pas,
les vallées se fendent,
comme la cire en présence du feu,
comme l’eau qui coule sur une pente.
###### 05
Tout cela, à cause de la révolte de Jacob,
à cause des péchés de la maison d’Israël.
Qui donc est la révolte de Jacob ?
N’est-ce pas Samarie ?
Qui donc est le lieu sacré de Juda ?
N’est-ce pas Jérusalem ?
###### 06
« Je ferai de Samarie un champ de décombres,
une terre où planter des vignes.
Je ferai rouler ses pierres au fond du ravin ;
ses fondations, je les mettrai à nu.
###### 07
Toutes ses statues seront brisées,
tous les cadeaux qu’elle a reçus seront brûlés.
Toutes ses idoles, je les réduirai à rien :
elles avaient été amassées avec les gains de prostituée,
gains de prostituée elles redeviendront. »
###### 08
C’est pourquoi je vais me lamenter, moi, Michée, et hurler,
je vais marcher déchaussé et nu.
Je ferai une lamentation, comme les chacals,
je pousserai des cris de deuil, comme les autruches.
###### 09
Car le coup porté par le Seigneur est sans remède,
il atteint jusqu’à Juda,
il frappe jusqu’à la porte de mon peuple,
jusqu’à Jérusalem !
###### 10
Dans Gath, ne le publiez pas,
ne faites pas entendre vos pleurs !
Mais à Beth-Léafra,
roulez-vous dans la poussière !
###### 11
Va-t’en, honteuse et nue,
habitante de Shafir !
Elle ne sortira plus,
l’habitante de Saanane !
Lamente-toi, Beth-ha-Ésel :
tout appui t’est retiré.
###### 12
L’habitante de Maroth est privée de bonheur.
Car le Seigneur fait descendre le malheur
jusqu’aux portes de Jérusalem.
###### 13
Attelle au char le coursier,
habitante de Lakish,
– ce fut bien là l’origine du péché pour la fille de Sion, comme ce fut l’occasion des révoltes d’Israël.
###### 14
On donnera donc des cadeaux d’adieu
pour Morésheth-Gath,
et les ateliers de Beth-Akzib
ne seront que déception pour les rois d’Israël.
###### 15
Je ferai de nouveau venir contre toi le conquérant,
habitante de Maréshah !
Jusqu’à Adoullam s’en ira
la gloire d’Israël.
###### 16
Arrache tes cheveux,
rase-toi le crâne, fille de Sion,
à cause des fils qui faisaient ta joie !
Que ta tête devienne chauve comme celle du vautour,
car ils sont exilés loin de toi !
