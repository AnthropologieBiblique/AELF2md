---
aliases : 
- Michée 6
- Michée 6
- Mi 6
- Micah 6
tags : 
- Bible/Mi/6
- français
cssclass : français
---

# Michée 6

###### 01
Écoutez donc ce que dit le Seigneur :
Lève-toi ! Engage un procès avec les montagnes,
et que les collines entendent ta voix.
###### 02
Montagnes, écoutez le procès du Seigneur,
vous aussi, fondements inébranlables de la terre.
Car le Seigneur est en procès avec son peuple,
il plaide contre Israël :
###### 03
Mon peuple, que t’ai-je fait ?
En quoi t’ai-je fatigué ? Réponds-moi.
###### 04
Est-ce parce que je t’ai fait monter du pays d’Égypte,
que je t’ai racheté de la maison d’esclavage,
et que je t’ai donné comme guides
Moïse, Aaron et Miryam ?
###### 05
Ô mon peuple, souviens-toi, je te prie,
du projet de Balac, roi de Moab,
et de ce que lui répondit Balaam, fils de Béor.
Souviens-toi du passage de Shittim jusqu’à Guilgal
pour que tu reconnaisses les justes actions du Seigneur.
###### 06
« Comment dois-je me présenter devant le Seigneur ?,
demande le peuple.
Comment m’incliner devant le Très-Haut ?
Dois-je me présenter avec de jeunes taureaux
pour les offrir en holocaustes ?
###### 07
Prendra-t-il plaisir à recevoir des milliers de béliers,
à voir des flots d’huile répandus sur l’autel ?
Donnerai-je mon fils aîné pour prix de ma révolte,
le fruit de mes entrailles pour mon propre péché ?
###### 08
– Homme, répond le prophète,
on t’a fait connaître ce qui est bien,
ce que le Seigneur réclame de toi :
rien d’autre que respecter le droit,
aimer la fidélité,
et t’appliquer à marcher avec ton Dieu. »
###### 09
La voix du Seigneur appelle la cité :
« Écoutez...
###### 10
Puis-je supporter une mesure fausse,
des biens acquis par fraude
et un boisseau honteusement réduit ?
###### 11
Puis-je tenir pour innocents
ceux qui utilisent des balances fausses,
et des sacoches de poids truqués ?
###### 12
Les riches sont pleins de violence.
Les habitants profèrent le mensonge,
leur langage n’est que tromperie.
###### 13
Moi-même j’ai commencé à te frapper,
à te dévaster à cause de tes péchés.
###### 14
Toi, tu mangeras, mais tu ne seras pas rassasiée,
chez toi viendra la famine.
Tu mettras de côté, mais tu ne pourras rien garder
et ce que tu aurais gardé, je le livrerai à l’épée.
###### 15
Toi, tu sèmeras, mais tu ne moissonneras pas ;
tu presseras l’olive, mais tu ne t’enduiras pas d’huile,
tu presseras le raisin, mais tu ne boiras pas de vin.
###### 16
Les prescriptions d’Omri ont été observées,
ainsi que toutes les pratiques de la maison d’Acab.
Vous avez marché selon leurs conseils.
C’est pour cela que je te livrerai à la dévastation
et tes habitants à la raillerie.
Le mépris des peuples pèsera sur vous. »
