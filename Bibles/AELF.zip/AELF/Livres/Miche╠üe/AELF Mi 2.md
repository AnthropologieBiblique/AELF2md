---
aliases : 
- Michée 2
- Michée 2
- Mi 2
- Micah 2
tags : 
- Bible/Mi/2
- français
cssclass : français
---

# Michée 2

###### 01
Malheur à ceux qui préparent leur mauvais coup
et, du fond de leur lit, élaborent le mal !
Au point du jour, ils l’exécutent
car c’est en leur pouvoir.
###### 02
S’ils convoitent des champs, ils s’en emparent ;
des maisons, ils les prennent ;
ils saisissent le maître et sa maison,
l’homme et son héritage.
###### 03
C’est pourquoi, ainsi parle le Seigneur :
Moi, je prépare contre cette engeance un malheur
où ils enfonceront jusqu’au cou ;
vous ne marcherez plus la tête haute,
car ce sera un temps de malheur.
###### 04
Ce jour-là, on proférera sur vous une satire,
et l’on entonnera une lamentation ; on dira :
« Nous sommes entièrement dévastés !
On livre à d’autres la part de mon peuple !
Hélas ! Elle m’échappe !
Nos champs sont partagés
entre des infidèles ! »
###### 05
Plus personne, en effet, ne t’assurera une part
dans l’assemblée du Seigneur.
###### 06
Mes ennemis déblatèrent contre moi.
Ils disent : « Ne déblatérez pas.
Cessez de déblatérer en répétant :
“Jamais le déshonneur ne s’éloignera.”
###### 07
Peut-on dire cela, maison de Jacob ?
La patience du Seigneur est-elle à bout ?
Est-ce là sa manière d’agir ?
Ses paroles ne sont-elles pas bienveillantes ?
N’accompagnent-elles pas celui qui marche droit ? »
###### 08
Hier, mon peuple faisait face à l’ennemi ;
mais vous, vous arrachez leur manteau
à ceux qui avancent avec confiance, au retour du combat.
###### 09
Les femmes de mon peuple, vous les chassez
des maisons qu’elles aimaient ;
à leurs enfants, vous enlevez pour toujours
la gloire de m’appartenir.
###### 10
Levez-vous, allez ! Ce n’est plus le temps du repos !
À cause de votre impureté, vous serez détruits
et la destruction sera cruelle.
###### 11
Qu’un homme coure après le vent
et que par son mensonge il vous dupe en disant :
« En échange de vin et de boisson forte,
je vais déblatérer à ton profit »,
celui-là sera un homme
qui déblatère pour ce peuple !
###### 12
Mais moi, je veux te rassembler tout entier, Jacob,
je veux réunir le reste d’Israël !
Je les mettrai ensemble comme des brebis de Bosra,
comme un troupeau au milieu de son pâturage ;
et de cette foule humaine s’élèvera une rumeur.
###### 13
Celui qui ouvre les brèches est monté ;
devant eux il a ouvert la brèche.
Ils ont passé la porte,
ils sont sortis par elle ;
leur roi, devant eux, est passé :
le Seigneur est à leur tête.
