---
aliases : 
- 3 Jean 1
- 3 Jean 1
- 3 Jn 1
- 3 John 1
tags : 
- Bible/3Jn/1
- français
cssclass : français
---

# 3 Jean 1

###### 01
MOI, L’ANCIEN, à Gaïos, le bien-aimé, que j’aime en vérité.
###### 02
Bien-aimé, je prie pour qu’en toutes choses tu ailles bien et que tu sois en bonne santé, comme c’est déjà le cas pour ton âme.
###### 03
J’ai eu beaucoup de joie quand des frères sont venus et qu’ils ont rendu témoignage à la vérité qui est en toi : ils ont dit comment tu marches dans la vérité.
###### 04
Rien ne me donne plus de joie que d’apprendre que mes enfants marchent dans la vérité.
###### 05
Bien-aimé, tu agis fidèlement dans ce que tu fais pour les frères, et particulièrement pour des étrangers.
###### 06
En présence de l’Église, ils ont rendu témoignage à ta charité ; tu feras bien de faciliter leur voyage d’une manière digne de Dieu.
###### 07
Car c’est pour son nom qu’ils se sont mis en route sans rien recevoir des païens.
###### 08
Nous devons donc apporter notre soutien à de tels hommes pour être des collaborateurs de la vérité.
###### 09
J’ai écrit une lettre à l’Église ; mais Diotréphès, qui aime tant être le premier d’entre eux, ne nous accueille pas.
###### 10
Alors si je viens, je dénoncerai les œuvres qu’il accomplit : il se répand en paroles méchantes contre nous ; non content de cela, il n’accueille pas les frères ; et ceux qui voudraient le faire, il les en empêche et les chasse de l’Église.
###### 11
Bien-aimé, n’imite pas le mal, mais le bien. Celui qui fait le bien vient de Dieu ; celui qui fait le mal n’a pas vu Dieu.
###### 12
Quant à Démétrios, il fait l’objet d’un bon témoignage de la part de tous et de la vérité elle-même ; nous aussi, nous lui rendons témoignage, et tu sais que notre témoignage est vrai.
###### 13
J’aurais bien des choses à t’écrire, mais je ne veux pas le faire avec l’encre et la plume.
###### 14
J’espère te voir bientôt, et nous nous parlerons de vive voix.
###### 15
La paix soit avec toi ! Les amis te saluent. Et toi, salue les amis, chacun par son nom.
