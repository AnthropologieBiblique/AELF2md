---
aliases : 
- 2 Jean
- 2 Jean
- 2 Jn
- 2 John
tags : 
- Bible/2Jn
- français
cssclass : français
---

# 2 Jean

[[AELF 2 Jn 1|2 Jean 1]]
