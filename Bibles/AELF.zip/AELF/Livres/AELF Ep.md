---
aliases : 
- Éphésiens
- Éphésiens
- Ep
- Ephesians
tags : 
- Bible/Ep
- français
cssclass : français
---

# Éphésiens

[[AELF Ep 1|Éphésiens 1]]
[[AELF Ep 2|Éphésiens 2]]
[[AELF Ep 3|Éphésiens 3]]
[[AELF Ep 4|Éphésiens 4]]
[[AELF Ep 5|Éphésiens 5]]
[[AELF Ep 6|Éphésiens 6]]
