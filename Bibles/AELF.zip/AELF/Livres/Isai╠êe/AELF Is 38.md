---
aliases : 
- Isaïe 38
- Isaïe 38
- Is 38
- Isaiah 38
tags : 
- Bible/Is/38
- français
cssclass : français
---

# Isaïe 38

###### 01
En ces jours-là, le roi Ézékias souffrait d’une maladie mortelle. Le prophète Isaïe, fils d’Amots, vint lui dire : « Ainsi parle le Seigneur : Prends des dispositions pour ta maison, car tu vas mourir, tu ne guériras pas. »
###### 02
Ézékias se tourna vers le mur et fit cette prière au Seigneur :
###### 03
« Ah ! Seigneur, souviens-toi ! J’ai marché en ta présence, dans la loyauté et d’un cœur sans partage, et j’ai fait ce qui est bien à tes yeux. » Puis le roi Ézékias fondit en larmes.
###### 04
La parole du Seigneur fut adressée à Isaïe :
###### 05
« Va dire à Ézékias : Ainsi parle le Seigneur, Dieu de David ton ancêtre : J’ai entendu ta prière, j’ai vu tes larmes. Je vais ajouter quinze années à ta vie.
###### 06
Je te délivrerai, toi et cette ville, de la main du roi d’Assour, je protégerai cette ville.
###### 07
Voici le signe que le Seigneur te donne pour montrer qu’il accomplira sa promesse :
###### 08
Je vais faire reculer de dix degrés l’ombre qui est déjà descendue sur le cadran solaire d’Acaz. » Et le soleil remonta sur le cadran les dix degrés qu’il avait déjà descendus.
###### 09
Cantique d’Ézékias, roi de Juda, lorsqu’il tomba malade et survécut à sa maladie.
###### 10
Je disais : Au milieu de mes jours,
je m’en vais ;
j’ai ma place entre les morts
pour la fin de mes années.
###### 11
Je disais : Je ne verrai pas le Seigneur
sur la terre des vivants,
plus un visage d’homme
parmi les habitants du monde !
###### 12
Ma demeure m’est enlevée, arrachée,
comme une tente de berger.
Tel un tisserand, j’ai dévidé ma vie :
le fil est tranché.
Du jour à la nuit, tu m’achèves ;
###### 13
j’ai crié jusqu’au matin.
Comme un lion, il a broyé tous mes os.
Du jour à la nuit, tu m’achèves.
###### 14
Comme l’hirondelle, je crie ;
je gémis comme la colombe.
À regarder là-haut, mes yeux faiblissent :
Seigneur, je défaille ! Sois mon soutien !
[
###### 15
Que lui dirai-je pour qu’il me réponde,
à lui qui agit ?
J’irais, errant au long de mes années
avec mon amertume ?
###### 16
« Le Seigneur est auprès d’eux : ils vivront !
Tout ce qui vit en eux vit de son esprit ! »
Oui, tu me guériras, tu me feras vivre :
###### 17
voici que mon amertume se change en paix.]
Et toi, tu t’es attaché à mon âme,
tu me tires du néant de l’abîme.
Tu as jeté, loin derrière toi,
tous mes péchés.
###### 18
La mort ne peut te rendre grâce,
ni le séjour des morts, te louer.
Ils n’espèrent plus ta fidélité,
ceux qui descendent dans la fosse.
###### 19
Le vivant, le vivant, lui, te rend grâce,
comme moi, aujourd’hui.
Et le père à ses enfants
montrera ta fidélité.
###### 20
Seigneur, viens me sauver !
Et nous jouerons sur nos cithares,
tous les jours de notre vie,
auprès de la Maison du Seigneur.
###### 21
Puis Isaïe dit : « Qu’on apporte un gâteau de figues ; qu’on l’applique sur l’ulcère, et le roi vivra. »
###### 22
Ézékias dit : « À quel signe reconnaîtrai-je que je pourrai monter à la Maison du Seigneur ? »
