---
aliases : 
- Isaïe 59
- Isaïe 59
- Is 59
- Isaiah 59
tags : 
- Bible/Is/59
- français
cssclass : français
---

# Isaïe 59

###### 01
Non, le bras du Seigneur n’est pas trop court pour sauver,
ni son oreille, trop dure pour entendre.
###### 02
Mais ce sont vos crimes qui font la séparation
entre vous et votre Dieu :
vos péchés vous cachent son visage
et l’empêchent de vous entendre.
###### 03
Car vos mains sont souillées par le sang,
vos doigts, par le crime ;
vos lèvres ont proféré le mensonge,
votre langue murmure la perfidie.
###### 04
Nul ne porte plainte à juste titre,
nul ne plaide de bonne foi.
On s’appuie sur le néant, on dit des paroles creuses,
on conçoit la peine, on enfante le méfait.
###### 05
Ce sont des œufs de serpent qu’ils font éclore,
et des toiles d’araignée qu’ils tissent.
Qui mange de leurs œufs mourra ;
que l’on en brise un, une vipère en sort !
###### 06
De leurs toiles ne sera fait aucun vêtement :
rien qui permette de s’en couvrir.
Leurs œuvres sont des œuvres malfaisantes,
leurs mains ne font que violence.
###### 07
Ils courent au mal d’un pied rapide,
ils ont hâte de verser le sang innocent.
Leurs pensées sont des pensées malfaisantes ;
sur leurs parcours, ravage et ruine !
###### 08
Ils ne connaissent pas le chemin de la paix,
sur leur passage ne se trouve pas le droit,
ils rendent leurs sentiers tortueux.
Qui prend ce chemin ne connaît pas la paix.
###### 09
Voilà pourquoi le droit reste loin de nous,
et pourquoi la justice n’arrive pas jusqu’à nous.
Nous attendons la lumière, et voici les ténèbres ;
la clarté, et nous marchons dans l’obscurité.
###### 10
Nous tâtonnons comme des aveugles le long d’un mur,
nous tâtonnons comme des gens qui ont perdu la vue.
En plein midi nous trébuchons comme au crépuscule ;
en pleine santé, nous voilà comme des morts.
###### 11
Nous grognons tous comme des ours,
nous gémissons sans trêve comme des colombes.
Nous attendons le droit : il n’y en a pas ;
le salut : il reste loin de nous !
###### 12
Car nos révoltes se multiplient devant toi,
nos péchés ont témoigné contre nous.
Oui, notre révolte nous tient,
et nos crimes, nous les connaissons :
###### 13
se révolter, renier le Seigneur,
abandonner notre Dieu,
prêcher l’oppression, la rébellion,
concevoir le mensonge et le ruminer dans son cœur.
###### 14
Le jugement a été repoussé,
la justice se tient à l’écart,
car la vérité a trébuché sur la place,
et la droiture ne peut y accéder.
###### 15
La vérité est portée disparue ;
qui se détourne du mal se fait dépouiller.
Le Seigneur l’a vu, et c’est mal à ses yeux :
il n’y a plus de droit.
###### 16
Il a vu qu’il n’y avait personne,
il s’est désolé que personne n’intervienne.
Alors c’est son bras qui l’a sauvé,
sa justice elle-même fut son appui.
###### 17
Il a revêtu la justice comme cuirasse,
et mis, sur sa tête, le casque du salut ;
il a revêtu les vêtements de la vengeance,
il s’est drapé de son ardeur jalouse comme d’un manteau.
###### 18
Il rendra à chacun selon ses œuvres :
fureur pour ses adversaires,
représailles pour ses ennemis ;
il rendra aux îles lointaines ce qui leur est dû.
###### 19
Et l’on craindra depuis l’occident le nom du Seigneur,
et depuis l’orient, sa gloire,
car il viendra comme un cours d’eau encaissé,
que précipite le souffle du Seigneur.
###### 20
Alors il viendra en rédempteur pour Sion,
pour ceux de Jacob revenus de leur révolte,
– oracle du Seigneur.
###### 21
Quant à moi, dit le Seigneur,
voici mon alliance avec eux :
Mon esprit qui repose sur toi
et mes paroles que j’ai mises dans ta bouche
ne quitteront plus ta bouche,
ni celle de tes descendants,
ni celle des descendants de tes descendants,
– dit le Seigneur –
dès maintenant et pour toujours.
