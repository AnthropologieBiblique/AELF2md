---
aliases : 
- Isaïe 19
- Isaïe 19
- Is 19
- Isaiah 19
tags : 
- Bible/Is/19
- français
cssclass : français
---

# Isaïe 19

###### 01
Proclamation sur l’Égypte.
Voici le Seigneur :
il chevauche une nuée légère,
il entre en Égypte ;
les idoles d’Égypte vacillent devant lui,
l’Égypte voit fondre son courage.
###### 02
J’exciterai l’Égypte contre l’Égypte,
on se battra frère contre frère,
ami contre ami, ville contre ville,
royaume contre royaume.
###### 03
L’Égypte en perdra l’esprit,
je brouillerai son projet ;
ils consulteront idoles et sorciers,
nécromanciens et devins.
###### 04
Je livrerai l’Égypte aux mains d’un maître implacable,
un roi tout-puissant régnera sur eux,
– oracle du Maître et Seigneur de l’univers.
###### 05
Les eaux s’épuiseront avant d’atteindre la mer,
le fleuve tarira, s’asséchera,
###### 06
ses canaux empesteront,
le delta du Nil baissera, s’asséchera,
cannes et roseaux flétriront.
###### 07
Les joncs des bords du Nil jusqu’à l’embouchure,
les plantations seront desséchés, emportés :
il n’en restera rien.
###### 08
Les pêcheurs se lamenteront :
ils seront en deuil,
tous ceux qui jettent l’hameçon dans le Nil ;
ils dépériront,
ceux qui tendent le filet sur les eaux.
###### 09
Ils seront déçus, ceux qui travaillent le lin :
cardeuses et tisserands deviendront livides.
###### 10
Les artisans seront accablés,
les salariés, désespérés.
###### 11
Qu’ils sont stupides, les princes de Tanis !
Les plus sages conseillers de Pharaon
forment un conseil d’incapables.
Comment pouvez-vous dire à Pharaon :
« Je suis un fils de sage,
un descendant des rois de jadis » ?
###### 12
Où sont-ils, tes sages, où sont-ils ?
Qu’ils t’instruisent donc,
et l’on saura ce que le Seigneur de l’univers
a décidé contre l’Égypte.
###### 13
Ils déraisonnent, les princes de Tanis,
ils délirent, les princes de Memphis ;
ils font vaciller l’Égypte,
eux qui sont la pierre d’angle de ses tribus.
###### 14
Le Seigneur a insufflé au milieu d’elle un esprit de vertige :
ils font vaciller l’Égypte en tout ce qu’elle fait,
comme vacille un ivrogne en vomissant.
###### 15
Plus rien ne se fera en Égypte,
que ce soit par le grand ou par le petit,
le palmier ou le roseau.
###### 16
Ce jour-là,
l’Égypte, comme les femmes,
sera tremblante et terrifiée
quand le Seigneur de l’univers lui-même
élèvera la main contre elle.
###### 17
Le pays de Juda sera objet d’effroi pour l’Égypte :
chaque fois qu’on l’évoquera, elle sera terrifiée
à cause du projet que le Seigneur de l’univers
a lui-même formé contre elle.
###### 18
Ce jour-là, il y aura au pays d’Égypte
cinq villes pour parler la langue de Canaan
et prêter serment au Seigneur de l’univers ;
l’une d’elles se nomme « Ville-du-Soleil ».
###### 19
Ce jour-là, il y aura un autel pour le Seigneur
au centre du pays d’Égypte,
et près de sa frontière une stèle pour le Seigneur.
###### 20
Ce sera un signe, un témoin, pour le Seigneur de l’univers
dans le pays d’Égypte :
quand ils crieront vers le Seigneur
devant ceux qui les oppriment,
il leur enverra un sauveur, un défenseur
qui les délivrera.
###### 21
Le Seigneur se fera connaître de l’Égypte
et l’Égypte connaîtra le Seigneur, ce jour-là ;
elle le servira par des sacrifices et des offrandes,
elle fera des vœux au Seigneur et les accomplira.
###### 22
Le Seigneur frappera l’Égypte,
il frappera et guérira.
Elle reviendra au Seigneur
qui l’écoutera et la guérira.
###### 23
Ce jour-là, il y aura une route
pour relier l’Égypte et Assour.
Assour viendra en Égypte,
et l’Égypte en Assour ;
et l’Égypte avec Assour servira le Seigneur.
###### 24
Ce jour-là, entre l’Égypte et Assour,
Israël viendra en troisième,
bénédiction au milieu de la terre,
###### 25
que bénira le Seigneur Dieu de l’univers en disant :
« Bénis soient l’Égypte, mon peuple,
Assour, l’ouvrage de mes mains,
et Israël, mon héritage. »
