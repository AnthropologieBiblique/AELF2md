---
aliases : 
- Isaïe 7
- Isaïe 7
- Is 7
- Isaiah 7
tags : 
- Bible/Is/7
- français
cssclass : français
---

# Isaïe 7

###### 01
Au temps d’Acaz, fils de Yotam, fils d’Ozias, roi de Juda, Recine, roi d’Aram, et Pékah, fils de Remalyahou, roi d’Israël, montèrent contre Jérusalem pour l’attaquer, mais ils ne purent lui donner l’assaut.
###### 02
On informa la maison de David que les Araméens avaient pris position en Éphraïm. Alors le cœur du roi et le cœur de son peuple furent secoués comme les arbres de la forêt sont secoués par le vent.
###### 03
Le Seigneur dit alors à Isaïe : « Avec ton fils Shear-Yashoub (c’est-à-dire : Un-reste-reviendra), va trouver Acaz, au bout du canal du réservoir supérieur, sur la route du Champ-du-Foulon.
###### 04
Tu lui diras :
“Garde ton calme, ne crains pas,
ne va pas perdre cœur
devant ces deux bouts de tisons fumants,
à cause de la colère brûlante du roi d’Aram
et du roi d’Israël,
###### 05
Oui, Aram a décidé ta perte,
en accord avec Éphraïm et son roi.
Ils se sont dit :
###### 06
Marchons contre le royaume de Juda,
pour l’intimider,
et nous le forcerons à se rendre ;
alors, nous lui imposerons comme roi le fils de Tabéel.
###### 07
Ainsi parle le Seigneur Dieu :
Cela ne durera pas, ne sera pas,
###### 08
que la capitale d’Aram soit Damas,
et Recine, le chef de Damas,
###### 09
que la capitale d’Éphraïm soit Samarie,
et le fils de Remalyahou, chef de Samarie.
– Dans soixante-cinq ans, Éphraïm, écrasé,
cessera d’être un peuple.
Mais vous, si vous ne croyez pas,
vous ne pourrez pas tenir.” »
###### 10
Le Seigneur parla encore ainsi au roi Acaz :
###### 11
« Demande pour toi un signe de la part du Seigneur ton Dieu, au fond du séjour des morts ou sur les sommets, là-haut. »
###### 12
Acaz répondit : « Non, je n’en demanderai pas, je ne mettrai pas le Seigneur à l’épreuve. »
###### 13
Isaïe dit alors :
« Écoutez, maison de David !
Il ne vous suffit donc pas de fatiguer les hommes :
il faut encore que vous fatiguiez mon Dieu !
###### 14
C’est pourquoi le Seigneur lui-même
vous donnera un signe :
Voici que la vierge est enceinte,
elle enfantera un fils,
qu’elle appellera Emmanuel
(c’est-à-dire : Dieu-avec-nous).
###### 15
De crème et de miel il se nourrira,
jusqu’à ce qu’il sache rejeter le mal et choisir le bien.
###### 16
Avant que cet enfant sache rejeter le mal
et choisir le bien,
la terre dont les deux rois te font trembler
sera laissée à l’abandon.
###### 17
Le Seigneur fera venir sur toi,
sur ton peuple et la maison de ton père,
des jours tels qu’il n’en est pas venu
depuis la séparation d’Éphraïm et de Juda.
###### 18
Il arrivera, en ce jour-là,
que le Seigneur sifflera les mouches
depuis les embouchures des fleuves d’Égypte
et les guêpes du pays d’Assour.
###### 19
Elles viendront et toutes se poseront
dans le fond des ravins et les fentes des rochers,
sur toutes les broussailles et tous les pacages.
###### 20
Ce jour-là, le Seigneur rasera
avec un rasoir loué au-delà de l’Euphrate,
– c’est le roi d’Assour –,
il rasera de la tête aux pieds ;
il coupera même la barbe.
###### 21
Il arrivera, en ce jour-là,
que chacun élèvera une vache et deux chèvres ;
###### 22
il y aura tant de lait
qu’on en mangera la crème ;
tous ceux qui resteront au cœur du pays
se nourriront de crème et de miel.
###### 23
Il arrivera, en ce jour-là, que tout lieu
planté de mille vignes
et valant mille pièces d’argent
ne sera que des épines et des ronces.
###### 24
On y viendra avec un arc et des flèches ;
oui, tout le pays ne sera que des épines et des ronces.
###### 25
Sur tous les coteaux bêchés et sarclés,
on ne viendra plus par crainte des épines et des ronces ;
on lâchera sur eux le gros bétail,
et les moutons viendront les piétiner.
