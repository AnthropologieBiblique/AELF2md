---
aliases : 
- Isaïe 28
- Isaïe 28
- Is 28
- Isaiah 28
tags : 
- Bible/Is/28
- français
cssclass : français
---

# Isaïe 28

###### 01
Malheur ! Samarie,
insolente couronne des buveurs d’Éphraïm,
fleur qui se fane, splendide parure,
dominant une vallée plantureuse !
Vous êtes assommés par le vin !
###### 02
Voici au service du Seigneur un homme fort et vigoureux,
comme un orage de grêle, une tempête dévastatrice,
un orage d’eaux puissantes, torrentielles :
de sa main il va tout mettre à terre.
###### 03
Elle sera foulée aux pieds,
l’insolente couronne des buveurs d’Éphraïm.
###### 04
La fleur qui se fane, splendide parure,
dominant la vallée plantureuse,
sera comme une figue précoce avant l’été :
sitôt vue, sitôt cueillie,
sitôt avalée.
###### 05
Ce jour-là, le Seigneur de l’univers
deviendra prestigieuse couronne,
diadème de splendeur,
pour le reste de son peuple ;
###### 06
il deviendra esprit de jugement
pour qui siège au jugement,
et vaillance de ceux qui repoussent l’assaut
devant la porte.
###### 07
En voici d’autres que le vin égare,
que la boisson forte fait divaguer :
prêtre et prophète, la boisson les égare,
ils sont troublés par le vin,
ils divaguent sous l’effet de la boisson,
s’égarent dans leurs visions
et s’embrouillent dans leurs sentences.
###### 08
Leurs tables sont couvertes d’infectes vomissures :
plus un endroit propre.
###### 09
Ils disent : « À qui veut-il faire la leçon ?
À qui veut-il faire entendre le message ?
À des enfants à peine sevrés,
qui ne prennent plus le sein ?
###### 10
Écoutez-le : “Fais-ci, fais-ça ;
par-ci, par-là ;
un peu ci, un peu là !” »
###### 11
Eh bien, oui : c’est dans une langue ridicule,
dans un jargon étrange,
qu’il parlera à ce peuple.
###### 12
Il leur avait dit : « C’est le repos !
Laissez l’accablé se reposer !
C’est le répit ! »,
mais ils n’ont pas voulu écouter.
###### 13
Voici donc ce que leur dira le Seigneur :
« Fais-ci, fais-ça ;
par-ci, par-là ;
un peu ci, un peu là ! »,
afin qu’en marchant ils trébuchent et tombent à la renverse,
soient brisés, pris au piège et capturés.
###### 14
C’est pourquoi, écoutez la parole du Seigneur,
vous, les moqueurs,
vous qui gouvernez ce peuple
qui est à Jérusalem.
###### 15
Vous dites : « Nous avons conclu
une alliance avec la mort ;
avec le séjour des morts
nous avons fait un pacte ;
quand passera le flot torrentiel,
il ne nous atteindra pas ;
car nous faisons du mensonge notre abri,
dans la tromperie nous sommes cachés. »
###### 16
Voilà pourquoi, ainsi parle le Seigneur Dieu :
Moi, dans Sion, je pose une pierre,
une pierre à toute épreuve,
choisie pour être une pierre d’angle,
une véritable pierre de fondement.
Celui qui croit ne s’inquiétera pas.
###### 17
Je prendrai le droit comme cordeau,
et la justice comme fil à plomb.
Mais la grêle balaiera l’abri de mensonge
et les eaux submergeront le refuge caché.
###### 18
Votre alliance avec la mort se rompra,
votre pacte avec le séjour des morts ne tiendra pas.
Quand passera le flot torrentiel,
vous serez broyés.
###### 19
Chaque fois qu’il passera,
il vous prendra ;
il passera matin après matin,
et le jour et la nuit ;
ne restera que l’épouvante
d’en apprendre la nouvelle.
###### 20
Car : « Trop court est le lit pour se coucher,
et trop étroite, la couverture pour s’y blottir. »
###### 21
Oui, comme sur le mont Peracim,
le Seigneur se dressera ;
comme dans la vallée de Gabaon,
il frémira d’indignation,
pour accomplir son œuvre,
– étrange est son œuvre –,
pour se mettre à son travail,
– insolite est son travail.
###### 22
Et maintenant, ne vous moquez pas
de peur que vos liens ne se resserrent :
c’est la destruction,
j’ai entendu qu’elle a été décidée
par le Seigneur, Dieu de l’univers,
contre tout le pays.
###### 23
Tendez l’oreille, écoutez ma voix ;
soyez attentifs, écoutez ma parole :
###### 24
pour semer, faut-il que, tout le jour,
le laboureur laboure sa terre, la retourne et la herse ?
###### 25
Ne va-t-il pas aplanir le sol,
pour répandre la nigelle, jeter le cumin,
semer en pleine terre le blé, l’orge, le millet,
et l’épeautre en bordure ?
###### 26
Son Dieu lui enseigne cette pratique ;
il l’a instruit :
###### 27
on n’écrase pas la nigelle au traîneau,
la roue du chariot ne passe pas sur le cumin ;
mais on bat la nigelle avec le fléau,
et le cumin avec le bâton.
###### 28
Va-t-on broyer le froment ?
On ne l’écrase pas sans fin :
on le foule sous les roues du chariot,
mais il n’est pas broyé.
###### 29
Même cela vient du Seigneur de l’univers :
il conçoit des merveilles, il réussit de grandes choses.
