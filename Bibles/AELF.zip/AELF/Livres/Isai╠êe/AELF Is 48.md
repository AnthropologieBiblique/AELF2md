---
aliases : 
- Isaïe 48
- Isaïe 48
- Is 48
- Isaiah 48
tags : 
- Bible/Is/48
- français
cssclass : français
---

# Isaïe 48

###### 01
Écoutez ceci, maison de Jacob,
vous qui portez le nom d’Israël,
vous qui êtes issus de Juda,
vous qui prêtez serment par le nom du Seigneur,
qui faites mémoire du Dieu d’Israël,
mais sans loyauté ni justice.
###### 02
Car ils s’appellent « ceux de la Ville sainte »,
et ils s’appuient sur le Dieu d’Israël :
« Seigneur de l’univers » est son nom.
###### 03
Les événements passés,
je les avais annoncés d’avance ;
ils étaient sortis de ma bouche,
et je les avais fait entendre ;
soudain j’ai agi, et ils sont arrivés.
###### 04
Sachant que tu es dur,
que ta nuque est une barre de fer,
et que ton front est de bronze,
###### 05
je t’ai annoncé d’avance les événements ;
avant qu’ils n’arrivent,
je te les ai fait entendre,
pour que tu n’ailles pas dire :
« C’est ma figurine qui en est l’auteur,
c’est mon idole, ma statue de métal fondu
qui les a ordonnés. »
###### 06
Tu as entendu tout cela : regarde-le ;
et tu ne l’annoncerais pas ?
Maintenant, je te fais entendre des choses nouvelles,
secrètes, inconnues de toi.
###### 07
C’est maintenant qu’elles sont créées
et non depuis longtemps ;
avant ce jour, tu ne les avais pas entendues ;
ainsi tu ne pouvais pas dire :
« Mais oui, je les connaissais ! »
###### 08
Eh bien non, tu n’as rien entendu,
non, tu ne savais rien,
non, autrefois tu n’avais pas ouvert l’oreille ;
je sais bien que tu as trahi encore et encore,
toi que l’on nomme « Rebelle-dès-le-sein-maternel ».
###### 09
À cause de mon nom, je suspends ma colère,
pour mon honneur, je patiente avec toi,
afin de ne pas t’exterminer.
###### 10
Ce n’est pas comme de l’argent que je t’ai épuré,
mais je t’ai éprouvé au creuset du malheur.
###### 11
C’est à cause de moi, de moi seul que je le fais :
Comment ! Mon nom serait-il profané ?
Ma gloire, je ne la donnerai pas à un autre.
###### 12
Écoute-moi, Jacob,
toi, Israël, que j’ai appelé !
Moi, Je suis :
je suis le Premier,
et je suis le Dernier.
###### 13
C’est ma main qui a fondé la terre,
ma droite a déployé les cieux.
Je les appelle :
ensemble ils se présentent.
###### 14
Tous, réunissez-vous, écoutez !
Qui parmi eux a annoncé cela ?
Celui que le Seigneur aime
accomplit sa volonté contre Babylone,
il sera son bras contre les Chaldéens.
###### 15
C’est moi, oui, c’est moi qui ai parlé,
qui l’ai appelé ;
je l’ai fait venir,
il mènera son entreprise à bien !
###### 16
Approchez-vous de moi, écoutez ceci :
depuis le commencement,
je n’ai jamais parlé en secret ;
depuis le temps où cela s’est passé,
Je suis là.
Et maintenant, le Seigneur Dieu,
avec son esprit, m’envoie.
###### 17
Ainsi parle le Seigneur, ton rédempteur,
Saint d’Israël :
Je suis le Seigneur ton Dieu,
je te donne un enseignement utile,
je te guide sur le chemin où tu marches.
###### 18
Si seulement tu avais prêté attention à mes commandements,
ta paix serait comme un fleuve,
ta justice, comme les flots de la mer.
###### 19
Ta postérité serait comme le sable,
comme les grains de sable, ta descendance ;
son nom ne serait ni retranché
ni effacé devant moi.
###### 20
Sortez de Babylone ! Vite, quittez les Chaldéens !
Avec des cris de joie,
annoncez, faites-le entendre,
propagez-le jusqu’aux extrémités de la terre !
Dites : « Le Seigneur a racheté son serviteur Jacob. »
###### 21
Ils n’ont pas eu soif dans les lieux arides
où il les a conduits.
Il a fait sourdre pour eux les eaux du rocher,
il a fendu le rocher : les eaux ont ruisselé !
###### 22
Pas de paix pour les méchants,
– dit le Seigneur.
