---
aliases : 
- Isaïe 47
- Isaïe 47
- Is 47
- Isaiah 47
tags : 
- Bible/Is/47
- français
cssclass : français
---

# Isaïe 47

###### 01
Descends, assieds-toi dans la poussière,
vierge, fille de Babylone !
Assieds-toi par terre, tu n’as plus de trône,
fille des Chaldéens,
car on ne t’appellera plus
« la délicate, la raffinée ».
###### 02
Prends la meule, mouds la farine,
relève ton voile, retrousse ta robe,
découvre tes jambes, traverse les cours d’eau :
###### 03
que soit découverte ta nudité,
que l’on voie ta honte.
J’exercerai ma vengeance,
personne ne m’en empêchera.
###### 04
– Notre rédempteur se nomme le Seigneur de l’univers,
le Saint d’Israël.
###### 05
Assieds-toi donc sans un mot,
enfonce-toi dans les ténèbres,
fille des Chaldéens,
car on ne t’appellera plus
« Souveraine des royaumes ».
###### 06
J’étais irrité contre mon peuple :
j’avais profané mon héritage
et je les avais livrés entre tes mains.
Tu ne leur as montré aucune compassion.
Sur le vieillard, tu as durement appesanti ton joug.
###### 07
Tu disais : « Je serai pour toujours,
perpétuellement souveraine. »
Tu n’as pas pris à cœur ces choses-là,
ni songé à cette fin.
###### 08
Maintenant, écoute donc, voluptueuse,
toi qui trônais avec assurance
et disais en ton cœur :
« Moi, et rien que moi !
Je ne serai jamais veuve
ni ne connaîtrai la privation d’enfants. »
###### 09
Eh bien, ces deux malheurs fondront sur toi
d’un seul coup, en un jour :
privation d’enfants et veuvage ;
tous ces malheurs fondent sur toi,
malgré le nombre de tes sorcelleries,
malgré la puissance de ta magie.
###### 10
Tu tirais assurance de ta malice ;
tu disais : « Personne ne me voit ! »
C’est ta sagesse et ta science qui t’ont égarée.
En ton cœur tu disais :
« Moi, et rien que moi ! »
###### 11
Un malheur va fondre sur toi,
sans que tu puisses le conjurer ;
un désastre te frappera,
sans que tu puisses y échapper ;
soudain fondra sur toi une tourmente
que tu ne connais pas.
###### 12
Reste donc avec ta magie
et tes nombreuses sorcelleries
pour lesquelles tu t’es fatiguée dès ta jeunesse :
peut-être pourras-tu en tirer profit,
et peut-être te rendras-tu redoutable !
###### 13
Tu t’es épuisée à force de consultations.
Qu’ils se lèvent donc et qu’ils te sauvent,
ceux qui scrutent le ciel,
qui observent les étoiles
et, à chaque nouvelle lune,
font connaître ce qui t’arrivera !
###### 14
Voici qu’ils sont comme de la paille :
le feu les brûlera,
ils ne pourront échapper à l’étreinte des flammes ;
ce ne seront pas des braises pour se chauffer,
ni la flambée devant laquelle on s’assied !
###### 15
Voilà comment te serviront ceux pour qui tu t’es fatiguée,
ceux qui trafiquèrent avec toi depuis ta jeunesse ;
chacun s’est fourvoyé de son côté,
et pas un qui te sauve.
