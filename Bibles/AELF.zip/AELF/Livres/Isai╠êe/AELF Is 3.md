---
aliases : 
- Isaïe 3
- Isaïe 3
- Is 3
- Isaiah 3
tags : 
- Bible/Is/3
- français
cssclass : français
---

# Isaïe 3

###### 01
Voici que le Maître et Seigneur de l’univers
va retirer de Jérusalem et de Juda
réserves et ressources,
toute réserve de pain,
toute réserve d’eau,
###### 02
le héros et l’homme de guerre,
le juge et le prophète,
le devin et l’ancien,
###### 03
l’officier, le notable,
le conseiller, l’expert en magie,
et le charmeur habile.
###### 04
Je leur donne pour princes des gamins
dont le caprice les gouvernera.
###### 05
Les gens seront des tyrans les uns pour les autres,
chacun pour son prochain ;
le gamin s’en prendra à l’ancien,
et le vaurien, au vénérable.
###### 06
Un individu se saisira de son frère
dans la maison paternelle, en disant :
« Tu as un manteau : tu seras notre chef !
Ce pays en ruines, gouverne-le ! » ;
###### 07
ce jour-là, l’autre répliquera :
« Je ne suis pas un guérisseur !
Il n’y a, dans ma maison, ni pain ni manteau,
ne me faites pas chef du peuple ! »
###### 08
Oui, Jérusalem trébuche
et Juda s’écroule,
parce que leurs paroles et leurs actes
envers le Seigneur
sont des insultes au regard de sa gloire.
###### 09
Leur partialité témoigne contre eux ;
comme Sodome, ils étalent leur péché,
ils n’en cachent rien.
Hélas pour eux !
Ils font leur propre malheur.
###### 10
Dites : « Qu’il est bon pour le juste
de se nourrir du fruit de ses actes !
###### 11
Quel malheur, hélas, pour le méchant
d’être traité selon l’œuvre de ses mains ! »
###### 12
Ô mon peuple ! Un nourrisson le tyrannise !
Des femmes le gouvernent !
Ô mon peuple, tes guides te fourvoient ;
ils brouillent le tracé de tes chemins.
###### 13
Le Seigneur s’est levé pour accuser,
il est debout pour juger les peuples.
###### 14
Le Seigneur entre en jugement
avec les anciens du peuple et ses princes :
« C’est vous qui dévastez la vigne ;
les biens volés au pauvre emplissent vos maisons.
###### 15
De quel droit écrasez-vous mon peuple,
piétinez-vous le visage du pauvre ? »
– oracle du Seigneur, Dieu de l’univers.
###### 16
Le Seigneur le déclare :
Parce que les filles de Sion sont orgueilleuses,
qu’elles marchent la poitrine haute
et les yeux provocants,
qu’elles avancent à petits pas
en faisant sonner les anneaux de leurs pieds,
###### 17
le Seigneur rendra chauve
le crâne des filles de Sion,
le Seigneur dénudera leur front.
###### 18
Ce jour-là, le Seigneur ôtera leurs parures :
grelots et médaillons,
pendentifs
###### 19
et boucles d’oreilles,
bracelets et voilettes,
###### 20
diadèmes et chaînes de chevilles,
cordelières, porte-bonheur et amulettes,
###### 21
bagues et anneaux de narines,
###### 22
robes de fête et mantilles,
châles et petits sacs,
###### 23
miroirs, linges fins, turbans et capes légères.
###### 24
Au lieu de parfum, la puanteur ;
au lieu de ceinture, une corde ;
au lieu de coiffure bouclée, un crâne tondu ;
au lieu d’une robe d’apparat, un pagne en toile à sac ;
une marque au fer rouge au lieu de la beauté.
###### 25
Tes hommes tomberont sous l’épée,
et ton élite, dans le combat.
###### 26
Elles gémiront, elles se lamenteront, les portes de la ville,
qui sera désertée, assise par terre.
