---
aliases : 
- Isaïe 39
- Isaïe 39
- Is 39
- Isaiah 39
tags : 
- Bible/Is/39
- français
cssclass : français
---

# Isaïe 39

###### 01
En ce temps-là, Mérodak-Baladane, fils de Baladane, roi de Babylone, envoya des lettres et un présent à Ézékias ; il avait appris qu’Ézékias avait été malade et avait retrouvé des forces.
###### 02
Ézékias s’en réjouit et montra aux envoyés ses entrepôts, l’argent et l’or, les aromates et l’huile parfumée, ainsi que tout son arsenal et tout ce qui se trouvait dans ses trésors. Il n’y eut rien qu’Ézékias ne leur ait montré dans sa maison et dans tout son royaume.
###### 03
Le prophète Isaïe vint alors trouver le roi Ézékias et lui demanda : « Qu’ont-ils dit, ces gens-là, et d’où venaient-ils ? » Ézékias répondit : « Ils venaient d’un pays lointain, de Babylone. »
###### 04
Il demanda : « Et qu’ont-ils vu dans ta maison ? » Ézékias dit : « Tout ce qui se trouve dans ma maison, ils l’ont vu. Il n’y a rien, dans mes trésors, que je ne leur aie montré. »
###### 05
Alors Isaïe dit à Ézékias : « Écoute la parole du Seigneur de l’univers :
###### 06
Voici venir des jours, où tout ce qui est dans ta maison, ce que tes pères ont amassé jusqu’à aujourd’hui, sera emporté à Babylone ; il n’en restera rien – dit le Seigneur.
###### 07
On prendra plusieurs de tes fils, issus de toi, engendrés par toi ; ils seront eunuques dans le palais du roi de Babylone. »
###### 08
Ézékias dit à Isaïe : « C’est une bonne chose que tu me dis de la part du Seigneur. » Il se disait : « Il y aura la paix et la stabilité pendant ma vie ! »
