---
aliases : 
- Isaïe 32
- Isaïe 32
- Is 32
- Isaiah 32
tags : 
- Bible/Is/32
- français
cssclass : français
---

# Isaïe 32

###### 01
Voici un roi qui règne avec justice,
des princes qui gouvernent selon le droit :
###### 02
chacun sera comme un abri contre le vent,
un refuge contre l’orage,
comme un ruisseau sur une terre desséchée,
l’ombre d’un grand rocher dans un pays torride.
###### 03
Les yeux qui regardent ne seront plus aveuglés,
les oreilles qui écoutent seront attentives ;
###### 04
le cœur frivole réfléchira pour comprendre
et la langue des bègues parlera vite et clairement.
###### 05
Le fou ne sera plus déclaré noble,
l’escroc ne sera pas dit honorable.
###### 06
Qui est fou ne dit que des folies
et son cœur fait le mal :
il commet l’impiété,
il blasphème le Seigneur ;
il laisse l’affamé le ventre creux
et l’assoiffé sans rien à boire.
###### 07
Quant à l’escroc, elles sont odieuses, ses escroqueries :
il conçoit des mauvais coups
pour perdre les humbles par des mensonges,
quand le malheureux plaide son bon droit.
###### 08
Qui est noble conçoit de nobles projets :
il se lève, lui, pour de nobles causes.
###### 09
Femmes insouciantes, debout !
Écoutez ma voix !
Filles présomptueuses,
prêtez l’oreille à ma parole :
###### 10
Dans un an révolu,
vous tremblerez, présomptueuses,
car la vendange sera perdue,
on ne rentrera pas de récolte.
###### 11
Alarmez-vous, insouciantes !
tremblez, présomptueuses !
Dévêtez-vous, dénudez-vous
avec un pagne autour des reins.
###### 12
Frappez-vous la poitrine :
faites le deuil sur la campagne riante
sur les vignes fertiles,
###### 13
sur la terre de mon peuple,
où poussent la broussaille et l’épine,
et sur les maisons joyeuses
de la cité en liesse !
###### 14
Oui, le palais sera abandonné,
la ville bruyante sera désertée.
L’Ophel et la Tour de guet
deviendront à jamais des repaires,
joie des ânes sauvages
et pâture des troupeaux,
###### 15
jusqu’à ce que soit répandu sur nous
l’esprit qui vient d’en haut.
Alors le désert deviendra un verger,
et le verger sera pareil à une forêt.
###### 16
Le droit habitera le désert,
la justice résidera dans le verger.
###### 17
L’œuvre de la justice sera la paix,
et la pratique de la justice, le calme et la sécurité
pour toujours.
###### 18
Mon peuple habitera un séjour de paix,
des demeures protégées,
des lieux sûrs de repos.
###### 19
– Mais la forêt s’écroulera sous la grêle
et la ville sera entièrement démolie.
###### 20
Heureux vous qui sèmerez près de tous les cours d’eau,
et laisserez aller le bœuf et l’âne.
