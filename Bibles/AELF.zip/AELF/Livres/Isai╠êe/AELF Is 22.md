---
aliases : 
- Isaïe 22
- Isaïe 22
- Is 22
- Isaiah 22
tags : 
- Bible/Is/22
- français
cssclass : français
---

# Isaïe 22

###### 01
Proclamation sur le Val de la Vision.
Ville de Jérusalem, qu’as-tu donc
à monter tout entière sur les terrasses,
###### 02
ville en fête, pleine de cris,
cité joyeuse ?
Tes morts ne sont pas morts par l’épée,
ils n’ont pas été tués dans un combat.
###### 03
Tes chefs ont pris la fuite comme un seul homme ;
sans même avoir tiré de l’arc, ils sont faits prisonniers.
Si loin qu’ils aient fui, on les a tous retrouvés :
ils sont prisonniers ensemble.
###### 04
C’est pourquoi je dis :
« Détournez de moi vos regards,
je pleure amèrement !
Ne cherchez pas à me consoler
du désastre subi par la fille de mon peuple. »
###### 05
Oui, c’est un jour d’affolement,
d’effarement, d’effondrement,
envoyé par le Seigneur, Dieu de l’univers.
Dans le Val de la Vision,
on sape la muraille,
des cris s’élèvent vers la montagne.
###### 06
Élam lève le carquois,
il amène des chars et des cavaliers ;
Qir brandit son bouclier.
###### 07
Les plus belles de tes vallées
sont remplies de chars,
les cavaliers sont rangés devant tes portes.
###### 08
Et Juda, lui, est privé de ses défenses !
En regardant, ce jour-là,
vers l’arsenal du palais royal,
###### 09
vous avez vu comme elles sont nombreuses,
les brèches de la Cité de David.
Vous avez recueilli les eaux
dans le réservoir inférieur.
###### 10
Vous avez recensé les maisons de Jérusalem,
démoli des maisons pour renforcer le rempart.
###### 11
Vous avez creusé un bassin entre les deux remparts
pour les eaux de l’ancien réservoir.
Mais vous n’avez pas regardé vers Celui qui est à l’œuvre ;
Celui qui façonne tout depuis longtemps, vous ne l’avez pas vu.
###### 12
Ce jour-là, le Seigneur, Dieu de l’univers,
appelait à pleurer, à se lamenter,
à se raser la tête, à se vêtir de toile à sac.
###### 13
Et voilà qu’on se réjouit, on fait la fête ;
on tue le bœuf, on égorge le mouton ;
on mange de la viande, on boit du vin :
« Mangeons et buvons, car demain nous mourrons ! »
###### 14
Mais le Seigneur de l’univers
m’a fait entendre cette révélation :
« J’en fais serment : cette faute ne vous sera jamais remise,
jusque dans la mort ».
Il l’a dit, le Seigneur, Dieu de l’univers.
###### 15
Ainsi parle le Seigneur, Dieu de l’univers :
« Va trouver ce ministre,
Shebna, le maître du palais, et dis-lui :
###### 16
Ici, quel est ton bien ? Qui sont les tiens, ici,
pour t’y faire creuser un tombeau,
toi qui te creuses un tombeau sur une hauteur,
et te fais tailler une demeure dans le roc ?
###### 17
Voici que le Seigneur va te rejeter,
il va te rejeter, grand homme,
t’empaqueter comme un paquet,
###### 18
t’enrouler, t’envoyer rouler comme une boule
vers un pays aux vastes étendues.
C’est là-bas que tu vas mourir,
là-bas, dans tes chars prestigieux,
toi, le déshonneur de la maison de ton maître.
###### 19
Je vais te chasser de ton poste,
t’expulser de ta place.
###### 20
Et, ce jour-là, j’appellerai mon serviteur,
Éliakim, fils d’Helcias.
###### 21
Je le revêtirai de ta tunique,
je le ceindrai de ton écharpe,
je lui remettrai tes pouvoirs :
il sera un père pour les habitants de Jérusalem
et pour la maison de Juda.
###### 22
Je mettrai sur son épaule la clef de la maison de David :
s’il ouvre, personne ne fermera ;
s’il ferme, personne n’ouvrira.
###### 23
Je le planterai comme une cheville
dans un endroit solide ;
il sera un trône de gloire
pour la maison de son père.
###### 24
Le poids de la gloire de la maison de son père
y sera suspendu :
les rameaux et les pousses,
et même tous les petits récipients,
depuis les coupes jusqu’aux vases de toute sorte.
###### 25
Ce jour-là – oracle du Seigneur de l’univers –,
la cheville plantée dans un endroit solide lâchera,
elle cédera, elle tombera,
et la charge qui pesait sur elle sera détruite.
Le Seigneur a parlé. »
