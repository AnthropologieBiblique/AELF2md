---
aliases : 
- Isaïe 6
- Isaïe 6
- Is 6
- Isaiah 6
tags : 
- Bible/Is/6
- français
cssclass : français
---

# Isaïe 6

###### 01
L’année de la mort du roi Ozias, je vis le Seigneur qui siégeait sur un trône très élevé ; les pans de son manteau remplissaient le Temple.
###### 02
Des séraphins se tenaient au-dessus de lui. Ils avaient chacun six ailes : deux pour se couvrir le visage, deux pour se couvrir les pieds, et deux pour voler.
###### 03
Ils se criaient l’un à l’autre : « Saint ! Saint ! Saint, le Seigneur de l’univers ! Toute la terre est remplie de sa gloire. »
###### 04
Les pivots des portes se mirent à trembler à la voix de celui qui criait, et le Temple se remplissait de fumée.
###### 05
Je dis alors : « Malheur à moi ! je suis perdu, car je suis un homme aux lèvres impures, j’habite au milieu d’un peuple aux lèvres impures : et mes yeux ont vu le Roi, le Seigneur de l’univers ! »
###### 06
L’un des séraphins vola vers moi, tenant un charbon brûlant qu’il avait pris avec des pinces sur l’autel.
###### 07
Il l’approcha de ma bouche et dit : « Ceci a touché tes lèvres, et maintenant ta faute est enlevée, ton péché est pardonné. »
###### 08
J’entendis alors la voix du Seigneur qui disait : « Qui enverrai-je ? qui sera notre messager ? » Et j’ai répondu : « Me voici : envoie-moi ! »
###### 09
Il me dit :
« Va dire à ce peuple :
Écoutez bien, mais sans comprendre ;
regardez bien, mais sans reconnaître.
###### 10
Alourdis le cœur de ce peuple,
rends-le dur d’oreille,
aveugle ses yeux,
de peur que ses yeux ne voient,
que ses oreilles n’entendent,
que son cœur ne comprenne,
qu’il ne se convertisse
et ne soit guéri. »
###### 11
Et je dis :
« Jusqu’à quand, Seigneur ? »
Il répondit :
« Jusqu’à ce que les villes
soient ravagées, dépeuplées,
les maisons, sans habitants,
et la terre, désolée, ravagée,
###### 12
jusqu’à ce que le Seigneur
en ait éloigné les habitants,
et que se multiplient dans le pays
les terres abandonnées.
###### 13
Et s’il en reste un dixième,
à son tour, il sera détruit,
comme le chêne et le térébinthe abattus
dont il ne reste que la souche.
– Cette souche est une semence sainte. »
