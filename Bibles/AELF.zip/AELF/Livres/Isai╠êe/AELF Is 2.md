---
aliases : 
- Isaïe 2
- Isaïe 2
- Is 2
- Isaiah 2
tags : 
- Bible/Is/2
- français
cssclass : français
---

# Isaïe 2

###### 01
Parole d’Isaïe, fils d’Amots, – ce qu’il a vu au sujet de Juda et de Jérusalem.
###### 02
Il arrivera dans les derniers jours
que la montagne de la Maison du Seigneur se tiendra plus haut que les monts, *
s’élèvera au-dessus des collines.
Vers elle afflueront toutes les nations
###### 03
et viendront des peuples nombreux.
Ils diront : « Venez !
montons à la montagne du Seigneur, *
à la Maison du Dieu de Jacob !
Qu’il nous enseigne ses chemins,
et nous irons par ses sentiers. »
Oui, la loi sortira de Sion,
et de Jérusalem, la parole du Seigneur.
###### 04
Il sera juge entre les nations
et l’arbitre de peuples nombreux.
De leurs épées, ils forgeront des socs,
et de leurs lances, des faucilles.
Jamais nation contre nation
ne lèvera l’épée ;
ils n’apprendront plus la guerre.
###### 05
Venez, maison de Jacob !
Marchons à la lumière du Seigneur.
###### 06
Oui, tu as délaissé ton peuple,
la maison de Jacob,
car ils sont remplis des superstitions de l’Orient,
ils exercent la divination comme les Philistins,
ils applaudissent aux pratiques étrangères.
###### 07
Le pays est rempli d’or et d’argent,
on ne peut compter ses trésors !
Le pays est rempli de chevaux,
on ne peut compter ses chars !
###### 08
Le pays est rempli de faux dieux :
les gens se prosternent devant l’ouvrage de leurs mains,
devant ce que leurs doigts ont fabriqué.
###### 09
L’être humain sera humilié,
l’homme sera abaissé,
tu ne saurais lui pardonner.
###### 10
Entre dans les rochers,
cache-toi dans la poussière,
épouvanté, loin du Seigneur,
loin de l’éclat de sa majesté.
###### 11
Les regards arrogants des humains seront abaissés,
et la prétention des hommes sera humiliée.
Seul le Seigneur sera exalté
en ce jour-là.
###### 12
Oui, pour le Seigneur de l’univers, il y aura un jour
contre tout orgueil et toute prétention,
contre tout ce qui s’élève et sera abaissé,
###### 13
contre tous les cèdres du Liban, prétentieux et altiers,
contre tous les chênes du Bashane,
###### 14
contre toute haute montagne,
et toute colline élevée,
###### 15
contre toutes les tours arrogantes,
et tout rempart fortifié,
###### 16
contre tout vaisseau de Tarsis,
et tout navire de grand prix.
###### 17
L’arrogance des humains sera humiliée ;
la prétention des hommes sera abaissée.
Seul le Seigneur sera exalté
en ce jour-là.
###### 18
Et les faux dieux, tous à la fois, disparaîtront.
###### 19
Entrez dans les cavernes des rochers,
dans les grottes souterraines,
épouvantés, loin du Seigneur,
loin de l’éclat de sa majesté,
quand il se dressera pour terrifier la terre.
###### 20
Ce jour-là, les hommes jetteront
les faux dieux d’or et d’argent
qu’ils s’étaient fabriqués pour les adorer ;
ils les jetteront aux taupes et aux chauves-souris.
###### 21
Eux, ils entreront dans les creux des rochers
et dans les fentes des falaises,
épouvantés, loin du Seigneur,
loin de l’éclat de sa majesté,
quand il se dressera pour terrifier la terre.
###### 22
Cessez de vous appuyer sur l’être humain :
sa vie tient à un souffle ;
et quelle est sa valeur ?
