---
aliases : 
- Isaïe 18
- Isaïe 18
- Is 18
- Isaiah 18
tags : 
- Bible/Is/18
- français
cssclass : français
---

# Isaïe 18

###### 01
Malheureux, le pays des bruissements d’ailes,
au-delà des fleuves d’Éthiopie :
###### 02
il envoie par mer des ambassades
dans des barques de papyrus à la surface des eaux.
Partez, rapides messagers,
vers une race élancée, à la peau luisante,
peuple redouté ici et là-bas,
nation barbare et tyrannique,
où des cours d’eau sillonnent la terre.
###### 03
Vous tous, habitants du monde,
vous qui peuplez la terre,
quand l’étendard sera levé sur les montagnes,
regardez !
quand sonnera le cor,
écoutez !
###### 04
Car le Seigneur m’a déclaré :
Je demeure tranquille ;
là où je me tiens, je regarde
dans la chaleur éblouissante du plein midi,
comme un nuage de rosée dans la chaleur de la récolte.
###### 05
Avant la récolte, quand la floraison s’achève
et que la fleur se change en fruits mûrissants,
on coupe les branches à la serpe,
on enlève et jette les rameaux.
###### 06
Tout sera abandonné aux rapaces des montagnes
et aux bêtes du pays :
les rapaces y passeront l’été,
et toutes les bêtes du pays, l’hiver.
###### 07
C’est alors qu’un présent sera porté
au Seigneur de l’univers
par le peuple élancé, à la peau luisante,
peuple redouté ici et là-bas,
nation barbare et tyrannique,
où des cours d’eau sillonnent la terre ;
ce présent sera porté
au lieu où réside le nom du Seigneur, Dieu de l’univers :
la montagne de Sion.
