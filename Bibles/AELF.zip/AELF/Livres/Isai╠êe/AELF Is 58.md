---
aliases : 
- Isaïe 58
- Isaïe 58
- Is 58
- Isaiah 58
tags : 
- Bible/Is/58
- français
cssclass : français
---

# Isaïe 58

###### 01
Crie à pleine gorge ! Ne te retiens pas !
Que s’élève ta voix comme le cor !
Dénonce à mon peuple sa révolte,
à la maison de Jacob ses péchés.
###### 02
Ils viennent me consulter jour après jour,
ils veulent connaître mes chemins.
Comme une nation qui pratiquerait la justice
et n’abandonnerait pas le droit de son Dieu,
ils me demandent des ordonnances justes,
ils voudraient que Dieu soit proche :
###### 03
« Quand nous jeûnons,
pourquoi ne le vois-tu pas ?
Quand nous faisons pénitence,
pourquoi ne le sais-tu pas ? »
Oui, mais le jour où vous jeûnez,
vous savez bien faire vos affaires,
et vous traitez durement ceux qui peinent pour vous.
###### 04
Votre jeûne se passe en disputes et querelles,
en coups de poing sauvages.
Ce n’est pas en jeûnant comme vous le faites aujourd’hui
que vous ferez entendre là-haut votre voix.
###### 05
Est-ce là le jeûne qui me plaît,
un jour où l’homme se rabaisse ?
S’agit-il de courber la tête comme un roseau,
de coucher sur le sac et la cendre ?
Appelles-tu cela un jeûne,
un jour agréable au Seigneur ?
###### 06
Le jeûne qui me plaît, n’est-ce pas ceci :
faire tomber les chaînes injustes,
délier les attaches du joug,
rendre la liberté aux opprimés,
briser tous les jougs ?
###### 07
N’est-ce pas partager ton pain avec celui qui a faim,
accueillir chez toi les pauvres sans abri,
couvrir celui que tu verras sans vêtement,
ne pas te dérober à ton semblable ?
###### 08
Alors ta lumière jaillira comme l’aurore,
et tes forces reviendront vite.
Devant toi marchera ta justice,
et la gloire du Seigneur fermera la marche.
###### 09
Alors, si tu appelles, le Seigneur répondra ;
si tu cries, il dira : « Me voici. »
Si tu fais disparaître de chez toi
le joug, le geste accusateur, la parole malfaisante,
###### 10
si tu donnes à celui qui a faim ce que toi, tu désires,
et si tu combles les désirs du malheureux,
ta lumière se lèvera dans les ténèbres
et ton obscurité sera lumière de midi.
###### 11
Le Seigneur sera toujours ton guide.
En plein désert, il comblera tes désirs
et te rendra vigueur.
Tu seras comme un jardin bien irrigué,
comme une source où les eaux ne manquent jamais.
###### 12
Tu rebâtiras les ruines anciennes,
tu restaureras les fondations séculaires.
On t’appellera : « Celui qui répare les brèches »,
« Celui qui remet en service les chemins ».
###### 13
Si tu t’abstiens de voyager le jour du sabbat,
de traiter tes affaires pendant mon jour saint,
si tu nommes « délices » le sabbat
et déclares « glorieux » le jour saint du Seigneur,
si tu le glorifies, en évitant
démarches, affaires et pourparlers,
###### 14
alors tu trouveras tes délices dans le Seigneur ;
je te ferai chevaucher sur les hauteurs du pays,
je te donnerai pour vivre l’héritage de Jacob ton père.
Oui, la bouche du Seigneur a parlé.
