---
aliases : 
- Isaïe 29
- Isaïe 29
- Is 29
- Isaiah 29
tags : 
- Bible/Is/29
- français
cssclass : français
---

# Isaïe 29

###### 01
Malheur ! Ariel, Ariel,
cité où campa David !
Ajoutez une année à l’année,
que s’accomplisse le cycle des fêtes,
###### 02
et j’opprimerai Ariel :
il ne sera que plaintes et complaintes,
il ne sera pour moi qu’un ariel, un brasier d’autel.
###### 03
Contre toi, tout autour, je dresserai le camp,
j’érigerai contre toi des remblais,
j’élèverai contre toi des fortifications.
###### 04
Tu seras si abaissée que ta parole semblera venir de terre,
de la poussière elle montera assourdie,
comme celle d’un revenant ta voix viendra de la terre,
et de la poussière ta parole ne sera que chuchotement.
###### 05
Mais la foule de tes ennemis n’est que poudre fine,
la foule des tyrans n’est que paille au vent.
Tout à coup, en un instant,
###### 06
le Seigneur de l’univers interviendra
dans le tonnerre, avec tremblement et fracas,
dans l’ouragan et la tempête,
dans la flamme d’un feu dévorant.
###### 07
Comme disparaît un songe, une vision de nuit,
telle est la foule de toutes les nations
mobilisées contre Ariel,
tous ceux qui l’assiègent dans sa forteresse,
et qui l’oppriment.
###### 08
Comme un affamé rêve qu’il mange
et s’éveille le ventre creux,
comme un assoiffé rêve qu’il boit
et s’éveille épuisé, le gosier sec,
ainsi en sera-t-il de la foule de toutes les nations
mobilisées contre le mont Sion.
###### 09
Soyez stupéfiés, stupéfaits,
aveuglés, et aveugles ;
enivrés sans vin,
titubants sans avoir bu.
###### 10
Car le Seigneur a répandu sur vous
un esprit de torpeur ;
il a fermé les yeux, que sont vos prophètes ;
il a voilé les têtes, que sont vos voyants.
###### 11
Toute vision est devenue pour vous
comme les mots d’un livre scellé.
On le donne à qui sait lire,
en lui disant : « Lis donc ceci » ;
mais il répond : « Je ne peux pas : le livre est scellé ! »
###### 12
On le donne alors à qui ne sait pas lire,
en lui disant : « Lis donc ceci » ;
mais il répond : « Je ne sais pas lire. »
###### 13
Le Seigneur dit :
Parce que ce peuple s’approche de moi
en me glorifiant de la bouche et des lèvres,
alors que son cœur est loin de moi,
parce que la crainte qu’ils ont de moi
n’est que précepte enseigné par les hommes,
###### 14
eh bien ! j’émerveillerai encore ce peuple
par des merveilles de merveilles,
et la sagesse de leurs sages se perdra
et l’intelligence des intelligents disparaîtra.
###### 15
Malheur ! Dans un profond secret, loin du Seigneur
ils cachent leur projet,
et leur ouvrage est fait dans l’obscurité ;
ils se disent : « Qui nous voit ? Qui nous reconnaît ? »
###### 16
C’est le monde à l’envers !
L’argile se prend-elle pour le potier ?
L’ouvrage va-t-il dire de son fabricant :
« Il ne m’a pas fabriqué »,
et le pot va-t-il dire du potier :
« Il n’y connaît rien » ?
###### 17
Ne le savez-vous pas ?
Encore un peu, très peu de temps,
et le Liban se changera en verger,
et le verger sera pareil à une forêt.
###### 18
Les sourds, en ce jour-là,
entendront les paroles du livre.
Quant aux aveugles, sortant de l’obscurité et des ténèbres,
leurs yeux verront.
###### 19
Les humbles se réjouiront de plus en plus
dans le Seigneur,
les malheureux exulteront
en Dieu, le Saint d’Israël.
###### 20
Car ce sera la fin des tyrans,
l’extermination des moqueurs,
et seront supprimés tous ceux qui s’empressent à mal faire,
###### 21
ceux qui font condamner quelqu’un par leur témoignage,
qui faussent les débats du tribunal
et sans raison font débouter l’innocent.
###### 22
C’est pourquoi le Seigneur, lui qui a libéré Abraham,
parle ainsi à la maison de Jacob :
« Désormais Jacob n’aura plus de honte,
son visage ne pâlira plus ;
###### 23
car, quand il verra chez lui ses enfants,
l’œuvre de mes mains,
il sanctifiera mon nom,
il sanctifiera le Dieu Saint de Jacob,
il tremblera devant le Dieu d’Israël.
###### 24
Les esprits égarés découvriront l’intelligence,
et les récalcitrants accepteront qu’on les instruise. »
