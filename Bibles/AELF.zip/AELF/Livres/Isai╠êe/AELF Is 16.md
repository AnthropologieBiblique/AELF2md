---
aliases : 
- Isaïe 16
- Isaïe 16
- Is 16
- Isaiah 16
tags : 
- Bible/Is/16
- français
cssclass : français
---

# Isaïe 16

###### 01
Envoyez au maître du pays un agneau,
depuis La Roche au désert,
vers la montagne de la fille de Sion.
###### 02
Des oiseaux qui s’enfuient,
une nichée dispersée,
telles seront les filles de Moab,
aux gués de l’Arnon.
###### 03
Moab dit à Juda :
« Fais des plans ! Prends une décision !
En plein midi, fais-nous une ombre comme la nuit,
cache les expulsés, ne trahis pas les fugitifs !
###### 04
Que les expulsés de Moab trouvent chez toi un asile,
sois un abri pour eux face au dévastateur.
Quand l’oppression aura disparu,
quand la dévastation aura pris fin,
quand sera parti du pays celui qui le foulait,
###### 05
un trône s’établira sur la fidélité ;
et, pour la maison de David,
siégera sur ce trône avec loyauté
le juge qui cherche le droit
et fait prompte justice. »
###### 06
Nous avons appris l’orgueil de Moab,
son immense orgueil,
son orgueil arrogant, démesuré,
ses bavardages qui ne sont rien.
###### 07
C’est pourquoi Moab hurle sur Moab,
il n’est que hurlement.
Pour les gâteaux de raisin de Qir-Harèseth,
vous gémissez, tout abattus.
###### 08
Car ils dépérissent, les vignobles de Heshbone,
la vigne de Sibma
dont les maîtres des nations
ont saccagé les grappes rouges ;
ses sarments allaient jusqu’à Yazèr,
ils se perdaient dans le désert ;
ses rejetons s’étendaient
au-delà de la mer.
###### 09
C’est pourquoi avec Yazèr je pleure
la vigne de Sibma ;
je t’arrose de mes larmes, Heshbone,
et toi, Élalé,
car sur tes récoltes et tes moissons,
une clameur s’est abattue.
###### 10
Joie et liesse
disparaissent des vergers ;
dans les vignes,
plus de chants de jubilation ;
au pressoir le fouleur ne foule plus le raisin :
j’ai fait cesser les clameurs.
###### 11
C’est pourquoi, comme une cithare,
mes entrailles gémissent sur Moab,
et mon cœur, sur Qir-Hérès.
###### 12
On verra Moab s’épuiser sur le lieu sacré,
entrer au sanctuaire pour prier,
et ne rien obtenir.
###### 13
Telle est la parole que le Seigneur prononça sur Moab, autrefois.
###### 14
Et maintenant le Seigneur déclare :
D’ici trois ans, jour pour jour,
la gloire de Moab ne comptera plus ;
malgré toute sa multitude,
il en restera très peu, un reste insignifiant.
