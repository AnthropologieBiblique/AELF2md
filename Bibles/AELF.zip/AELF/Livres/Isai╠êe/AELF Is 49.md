---
aliases : 
- Isaïe 49
- Isaïe 49
- Is 49
- Isaiah 49
tags : 
- Bible/Is/49
- français
cssclass : français
---

# Isaïe 49

###### 01
Écoutez-moi, îles lointaines !
Peuples éloignés, soyez attentifs !
J’étais encore dans le sein maternel
quand le Seigneur m’a appelé ;
j’étais encore dans les entrailles de ma mère
quand il a prononcé mon nom.
###### 02
Il a fait de ma bouche une épée tranchante,
il m’a protégé par l’ombre de sa main ;
il a fait de moi une flèche acérée,
il m’a caché dans son carquois.
###### 03
Il m’a dit :
« Tu es mon serviteur, Israël,
en toi je manifesterai ma splendeur. »
###### 04
Et moi, je disais :
« Je me suis fatigué pour rien,
c’est pour le néant, c’est en pure perte
que j’ai usé mes forces. »
Et pourtant, mon droit subsistait auprès du Seigneur,
ma récompense, auprès de mon Dieu.
###### 05
Maintenant le Seigneur parle,
lui qui m’a façonné dès le sein de ma mère
pour que je sois son serviteur,
que je lui ramène Jacob,
que je lui rassemble Israël.
Oui, j’ai de la valeur aux yeux du Seigneur,
c’est mon Dieu qui est ma force.
###### 06
Et il dit :
« C’est trop peu que tu sois mon serviteur
pour relever les tribus de Jacob,
ramener les rescapés d’Israël :
je fais de toi la lumière des nations,
pour que mon salut parvienne
jusqu’aux extrémités de la terre. »
###### 07
Ainsi parle le Seigneur,
rédempteur et saint d’Israël,
au serviteur méprisé, détesté par les nations,
esclave des puissants :
Les rois verront, ils se lèveront,
les grands se prosterneront,
à cause du Seigneur qui est fidèle,
du Saint d’Israël qui t’a choisi.
###### 08
Ainsi parle le Seigneur :
Au temps favorable, je t’ai exaucé,
au jour du salut, je t’ai secouru.
Je t’ai façonné, établi,
pour que tu sois l’alliance du peuple,
pour relever le pays,
restituer les héritages dévastés
###### 09
et dire aux prisonniers : « Sortez ! »,
aux captifs des ténèbres : « Montrez-vous ! »
Au long des routes, ils pourront paître ;
sur les hauteurs dénudées seront leurs pâturages.
###### 10
Ils n’auront ni faim ni soif ;
le vent brûlant et le soleil ne les frapperont plus.
Lui, plein de compassion, les guidera,
les conduira vers les eaux vives.
###### 11
De toutes mes montagnes, je ferai un chemin,
et ma route sera rehaussée.
###### 12
Les voici : ils viennent de loin,
les uns du nord et du couchant,
les autres des terres du sud.
###### 13
Cieux, criez de joie ! Terre, exulte !
Montagnes, éclatez en cris de joie !
Car le Seigneur console son peuple ;
de ses pauvres, il a compassion.
###### 14
Jérusalem disait :
« Le Seigneur m’a abandonnée,
mon Seigneur m’a oubliée. »
###### 15
Une femme peut-elle oublier son nourrisson,
ne plus avoir de tendresse pour le fils de ses entrailles ?
Même si elle l’oubliait,
moi, je ne t’oublierai pas.
###### 16
Car je t’ai gravée sur les paumes de mes mains,
j’ai toujours tes remparts devant les yeux.
###### 17
Ils accourent, tes bâtisseurs ;
tes démolisseurs, tes dévastateurs, ils s’éloignent de toi.
###### 18
Lève les yeux alentour et regarde :
tous, ils se rassemblent et viennent vers toi.
Par ma vie – oracle du Seigneur –,
tous, ils seront comme une parure que tu revêtiras,
autour de toi, comme la ceinture d’une jeune mariée.
###### 19
Car tes ruines, tes décombres, ton pays dévasté
sont désormais trop étroits pour tes habitants,
et ceux qui te dévoraient s’éloigneront.
###### 20
Les fils dont tu étais privée
te diront de nouveau à l’oreille :
« L’espace est trop étroit pour moi,
fais-moi place, que je m’installe. »
###### 21
Et tu diras en ton cœur :
« Qui me les a enfantés, ceux-là ?
Privée d’enfants, j’étais stérile,
j’étais bannie, rejetée,
et ceux-là, qui les a élevés ?
Quand moi, je restais seule,
ceux-là, où donc étaient-ils ? »
###### 22
Ainsi parle le Seigneur Dieu :
Voici : de ma main levée, je ferai signe aux nations,
je dresserai mon étendard vers les peuples.
Ils ramèneront tes fils dans leurs bras,
tes filles seront portées sur les épaules.
###### 23
Tu auras pour tuteurs des rois,
et des princesses pour nourrices.
Face contre terre, ils se prosterneront devant toi,
ils lècheront la poussière de tes pieds.
Tu sauras que Je suis le Seigneur.
Ceux qui espèrent en moi ne seront pas confondus.
###### 24
Peut-on reprendre au guerrier sa prise,
le captif d’un tyran peut-il s’échapper ?
###### 25
Ainsi parle le Seigneur :
Oui, même le captif du guerrier lui sera repris,
la prise du tyran lui échappera.
Tes adversaires, moi, je m’en ferai l’adversaire,
tes fils, moi, je les sauverai.
###### 26
À ceux qui t’exploitent je ferai manger leur propre chair ;
ils s’enivreront de leur sang comme d’un vin nouveau,
et tout être de chair saura
que moi, le Seigneur, je suis ton Sauveur,
ton rédempteur, Force de Jacob.
