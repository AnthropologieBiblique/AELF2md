---
aliases : 
- Joël 2
- Joël 2
- Jl 2
- Joel 2
tags : 
- Bible/Jl/2
- français
cssclass : français
---

# Joël 2

###### 01
Sonnez du cor dans Sion,
faites retentir la clameur sur ma montagne sainte !
Qu’ils tremblent, tous les habitants du pays,
car voici venir le jour du Seigneur,
il est tout proche.
###### 02
Jour de ténèbres et d’obscurité,
jour de nuages et de sombres nuées.
Comme la nuit qui envahit les montagnes,
voici un peuple nombreux et fort ;
il n’y en a jamais eu de pareil
et il n’y en aura plus dans les générations à venir.
###### 03
Devant lui, un feu dévore ;
derrière lui, une flamme consume.
Devant lui, le pays, comme un jardin d’Éden ;
derrière lui, un désert désolé.
Il n’y a rien qui lui échappe.
###### 04
Son aspect est l’aspect des chevaux ;
comme des coursiers, ils s’élancent.
###### 05
C’est comme le bruit des chars
bondissant aux sommets des montagnes ;
comme le bruit des flammes,
un feu qui dévore le chaume ;
comme un peuple puissant
rangé en bataille.
###### 06
Devant lui frémissent des peuples,
tous les visages ont perdu leur éclat.
###### 07
Comme des braves ils courent ;
tels des guerriers, ils escaladent le rempart.
Chacun va son chemin,
ils ne quittent pas leur voie.
###### 08
Ils ne se bousculent pas l’un l’autre,
chaque homme va sa route.
Ils foncent à travers les projectiles,
sans rompre les rangs.
###### 09
Ils se ruent dans la ville,
ils courent sur le rempart,
ils escaladent les maisons,
ils pénètrent par les fenêtres
comme des voleurs.
###### 10
Devant lui, la terre tremble,
le ciel est ébranlé ;
le soleil et la lune se sont obscurcis
et les étoiles ont retiré leur clarté.
###### 11
Le Seigneur a donné de la voix
devant son armée :
ils sont nombreux, ses bataillons ;
il est puissant, l’exécuteur de sa parole ;
il est grand, le jour du Seigneur, et très redoutable :
qui peut l’affronter ?
###### 12
Et maintenant – oracle du Seigneur –
revenez à moi de tout votre cœur,
dans le jeûne, les larmes et le deuil !
###### 13
Déchirez vos cœurs et non pas vos vêtements,
et revenez au Seigneur votre Dieu,
car il est tendre et miséricordieux,
lent à la colère et plein d’amour,
renonçant au châtiment.
###### 14
Qui sait ? Il pourrait revenir,
il pourrait renoncer au châtiment,
et laisser derrière lui sa bénédiction :
alors, vous pourrez présenter offrandes et libations
au Seigneur votre Dieu.
###### 15
Sonnez du cor dans Sion :
prescrivez un jeûne sacré, annoncez une fête solennelle,
###### 16
réunissez le peuple, tenez une assemblée sainte,
rassemblez les anciens,
réunissez petits enfants et nourrissons !
Que le jeune époux sorte de sa maison,
que la jeune mariée quitte sa chambre !
###### 17
Entre le portail et l’autel,
les prêtres, serviteurs du Seigneur,
iront pleurer et diront :
« Pitié, Seigneur, pour ton peuple,
n’expose pas ceux qui t’appartiennent
à l’insulte et aux moqueries des païens !
Faudra-t-il qu’on dise :
“Où donc est leur Dieu ?” »
###### 18
Et le Seigneur s’est ému en faveur de son pays,
il a eu pitié de son peuple.
###### 19
Le Seigneur a répondu à son peuple, en disant :
« Voici que je vous envoie
le froment, le vin nouveau et l’huile fraîche.
Vous en serez rassasiés,
jamais plus je ne ferai de vous l’opprobre des nations.
###### 20
Celui qui vient du nord, je l’éloignerai de chez vous,
je le chasserai vers un pays aride et désolé :
son avant-garde vers la mer orientale,
son arrière-garde vers la mer occidentale ;
sa puanteur s’élève,
son infection s’élèvera. »
Oui, il a fait de grandes choses !
###### 21
Ô terre, ne crains plus !
exulte et réjouis-toi !
Car le Seigneur a fait de grandes choses.
###### 22
Ne craignez plus, bêtes des champs :
les pâturages du désert ont reverdi,
les arbres ont produit leurs fruits,
la vigne et le figuier ont donné leurs richesses.
###### 23
Fils de Sion, exultez,
réjouissez-vous dans le Seigneur votre Dieu !
Car il vous a donné la pluie avec générosité,
il a fait tomber pour vous les averses,
celles de l’automne et celles du printemps,
dès qu’il le fallait.
###### 24
Les granges seront pleines de blé,
les cuves déborderont de vin nouveau et d’huile fraîche.
###### 25
Je vous rétribuerai pour les années
dévorées par la sauterelle,
par le criquet, le grillon, la chenille,
ma grande armée envoyée contre vous.
###### 26
Vous mangerez à votre faim, vous serez rassasiés,
et vous célébrerez le nom du Seigneur votre Dieu
car il a fait pour vous des merveilles.
Mon peuple ne connaîtra plus jamais la honte.
###### 27
Et vous saurez que moi, je suis au milieu d’Israël,
que Je suis le Seigneur votre Dieu,
il n’y en a pas d’autre.
Mon peuple ne connaîtra plus jamais la honte.
