---
aliases : 
- Joël 4
- Joël 4
- Jl 4
- Joel 4
tags : 
- Bible/Jl/4
- français
cssclass : français
---

# Joël 4

###### 01
Oui, voici qu’en ces jours et en ce temps,
où je ramènerai les captifs de Juda et de Jérusalem,
###### 02
j’assemblerai toutes les nations
et je les ferai descendre vers la Vallée de Josaphat
(dont le nom signifie « Le Seigneur juge »).
Là-bas, j’entrerai en jugement avec elles
au sujet d’Israël, mon peuple et mon héritage,
car elles l’ont dispersé parmi les nations,
elles ont partagé ma terre.
###### 03
Elles ont tiré au sort mon peuple,
troqué le garçon contre la prostituée,
vendu la fille pour du vin qu’elles ont bu.
###### 04
Et vous aussi, qu’êtes-vous pour moi, Tyr et Sidon,
et tous les districts de Philistie ?
Useriez-vous de représailles envers moi ?
Mais si vous usez de représailles envers moi,
bien vite, je retournerai sur vos têtes vos représailles.
###### 05
Mon argent et mon or,
c’est vous qui les avez pris ;
mes trésors les plus beaux,
vous les avez emportés dans vos temples.
###### 06
Les fils de Juda et ceux de Jérusalem,
vous les avez vendus aux fils de Yavane (c’est-à-dire aux Grecs)
pour les éloigner de leur territoire :
###### 07
voici que moi je vais les éveiller
du lieu où vous les avez vendus,
et je retournerai sur vos têtes vos représailles.
###### 08
Je vendrai vos fils et vos filles,
par la main des fils de Juda ;
ils les vendront aux Sabéens, nation lointaine.
Oui, le Seigneur a parlé.
###### 09
Criez ceci parmi les nations,
sanctifiez-vous pour faire la guerre,
éveillez les guerriers ;
qu’ils s’avancent, qu’ils montent,
tous les hommes de guerre !
###### 10
De vos socs, forgez des épées,
et de vos serpes, des javelots ;
que le faible dise : « Je suis un brave ! »
###### 11
Hâtez-vous et venez,
toutes les nations d’alentour,
assemblez-vous ici.
Seigneur, fais descendre tes braves !
###### 12
Que les nations se réveillent,
qu’elles montent jusqu’à la vallée de Josaphat
(dont le nom signifie « Le Seigneur juge »),
car c’est là que je vais siéger
pour juger tous les peuples qui vous entourent.
###### 13
Lancez la faucille :
la moisson est mûre ;
venez fouler la vendange :
le pressoir est rempli et les cuves débordent
de tout le mal qu’ils ont fait !
###### 14
Voici des multitudes et encore des multitudes
dans la vallée du Jugement ;
il est tout proche, le jour du Seigneur
dans la vallée du Jugement !
###### 15
Le soleil et la lune se sont obscurcis,
les étoiles ont retiré leur clarté.
###### 16
De Sion, le Seigneur fait entendre un rugissement,
de Jérusalem, il donne de la voix.
Le ciel et la terre sont ébranlés,
mais le Seigneur est un refuge pour son peuple,
une forteresse pour les fils d’Israël.
###### 17
Vous saurez que je suis le Seigneur votre Dieu,
qui demeure à Sion, sa montagne sainte.
Jérusalem sera un lieu saint,
les étrangers n’y passeront plus.
###### 18
Ce jour-là, le vin nouveau ruissellera sur les montagnes,
le lait coulera sur les collines.
Tous les torrents de Juda seront pleins d’eau,
une source jaillira de la Maison du Seigneur
et arrosera le ravin des Acacias.
###### 19
L’Égypte sera vouée à la désolation,
Édom sera un désert désolé,
car ils ont multiplié les violences contre les fils de Juda,
ils ont répandu leur sang innocent dans le pays.
###### 20
Mais il y aura toujours des habitants en Juda,
ainsi qu’à Jérusalem, de génération en génération.
###### 21
Je vengerai leur sang,
que je n’avais pas encore vengé.
Et le Seigneur aura sa demeure à Sion.
