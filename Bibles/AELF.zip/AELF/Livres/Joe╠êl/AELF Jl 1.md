---
aliases : 
- Joël 1
- Joël 1
- Jl 1
- Joel 1
tags : 
- Bible/Jl/1
- français
cssclass : français
---

# Joël 1

###### 01
PAROLE DU SEIGNEUR adressée à Joël, fils de Petouël.
###### 02
Écoutez ceci, les anciens,
prêtez l’oreille, tous les habitants du pays !
Cela s’est-il passé de votre temps,
ou même du temps de vos pères ?
###### 03
Cela, racontez-le à vos fils,
et vos fils à leurs fils,
et leurs fils à la génération qui suivra.
###### 04
Ce que laisse la chenille,
la sauterelle le dévore ;
ce que laisse la sauterelle,
le criquet le dévore ;
ce que laisse le criquet,
le grillon le dévore.
###### 05
Réveillez-vous, ivrognes, et pleurez ;
tous les buveurs, lamentez-vous sur le vin nouveau,
car il est retiré de votre bouche.
###### 06
Oui, une nation est montée contre mon pays,
elle est puissante et innombrable.
Ses dents sont les dents d’un lion,
elle a les mâchoires d’une lionne.
###### 07
Elle a fait de ma vigne un désert ;
mon figuier, elle l’a réduit en pièces,
l’a écorcé, abattu ;
ses rameaux ont blanchi.
###### 08
Soupire, comme une vierge vêtue de toile à sac,
pleurant l’époux de sa jeunesse.
###### 09
On a retiré offrandes et libations
de la Maison du Seigneur.
Ils sont en deuil, les prêtres
au service du Seigneur.
###### 10
Les champs sont ravagés,
la terre est en deuil.
Le froment est ravagé,
le vin nouveau fait défaut,
l’huile fraîche est tarie.
###### 11
Soyez consternés, laboureurs,
vignerons, lamentez-vous,
à cause du blé et de l’orge,
car la moisson des champs est perdue.
###### 12
La vigne a séché, le figuier est flétri ;
le grenadier comme le dattier et le pommier,
tous les arbres des champs ont séché.
Et la joie a disparu de chez les hommes.
###### 13
Prêtres, mettez un vêtement de deuil, et pleurez !
Serviteurs de l’autel, faites entendre des lamentations !
Venez, serviteurs de mon Dieu,
passez la nuit vêtus de toile à sac !
Car la maison de votre Dieu
ne reçoit plus ni offrandes ni libations.
###### 14
Prescrivez un jeûne sacré,
annoncez une fête solennelle,
réunissez les anciens et tous les habitants du pays
dans la Maison du Seigneur votre Dieu.
Criez vers le Seigneur :
###### 15
« Ah ! jour de malheur ! »
Le jour du Seigneur est proche,
il vient du Puissant comme un fléau.
###### 16
N’est-ce pas sous nos yeux
que la nourriture est retirée,
que la joie et la jubilation
s’éloignent de la Maison du Seigneur ?
###### 17
Les graines se dessèchent dans la terre ;
les silos sont en ruine, les greniers démolis :
le froment a séché.
###### 18
Comme il gémit, le bétail !
Les troupeaux de bœufs sont inquiets,
car ils n’ont plus de pâture.
Même les troupeaux de brebis sont touchés.
###### 19
Vers toi, Seigneur, je crie !
Car un feu dévore les pâturages du désert,
une flamme consume tous les arbres des champs.
###### 20
Les bêtes sauvages soupirent aussi vers toi,
car les cours d’eau sont à sec,
un feu dévore les pâturages du désert.
