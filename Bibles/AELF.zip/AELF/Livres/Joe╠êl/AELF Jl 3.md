---
aliases : 
- Joël 3
- Joël 3
- Jl 3
- Joel 3
tags : 
- Bible/Jl/3
- français
cssclass : français
---

# Joël 3

###### 01
Alors, après cela, je répandrai mon esprit
sur tout être de chair,
vos fils et vos filles prophétiseront,
vos anciens seront instruits par des songes,
et vos jeunes gens par des visions.
###### 02
Même sur les serviteurs et sur les servantes
je répandrai mon esprit en ces jours-là.
###### 03
Je ferai des prodiges au ciel et sur la terre :
du sang, du feu, des nuages de fumée.
###### 04
Le soleil sera changé en ténèbres,
et la lune sera changée en sang,
avant que vienne le jour du Seigneur,
jour grand et redoutable.
###### 05
Alors, quiconque invoquera le nom du Seigneur
sera sauvé.
Car sur la montagne de Sion et à Jérusalem
il y aura des rescapés,
selon la parole du Seigneur,
les survivants que le Seigneur convoque.
