---
aliases : 
- Apocalypse 18
- Apocalypse 18
- Ap 18
- Revelation 18
tags : 
- Bible/Ap/18
- français
cssclass : français
---

# Apocalypse 18

###### 01
Après cela, j’ai vu descendre du ciel un autre ange, ayant un grand pouvoir, et la terre fut illuminée de sa gloire.
###### 02
Il s’écria d’une voix puissante :
« Elle est tombée, elle est tombée,
Babylone la Grande !
La voilà devenue tanière de démons,
repaire de tous les esprits impurs,
repaire de tous les oiseaux impurs,
repaire de toutes les bêtes impures et répugnantes !
###### 03
Car toutes les nations ont bu du vin de sa fureur,
de sa prostitution ;
les rois de la terre se sont prostitués avec elle,
et les marchands de la terre se sont enrichis
de son luxe insolent. »
###### 04
Et j’entendis une autre voix venant du ciel qui disait :
« Sortez de la ville, vous mon peuple,
pour ne pas prendre part à ses péchés
et ne rien subir des fléaux qui l’affligent.
###### 05
Car ses péchés se sont amoncelés jusqu’au ciel,
et, de ses injustices, Dieu s’est souvenu.
###### 06
Traitez-la comme elle vous a traités,
rendez-lui au double selon ses actes ;
dans la coupe qu’elle a préparée,
préparez-lui le double.
###### 07
À la mesure de la gloire et du luxe qu’elle a étalés,
donnez-lui torture et deuil.
Car elle dit dans son cœur :
“Je trône, je suis reine,
je ne suis pas veuve,
je ne verrai jamais le deuil.”
###### 08
C’est pourquoi
des fléaux, en un seul jour, viendront sur elle :
mort, deuil, famine,
et elle sera brûlée au feu,
car il est fort, le Seigneur Dieu qui l’a jugée. »
###### 09
Alors, ils pleureront et se lamenteront sur elle, les rois de la terre qui se sont prostitués avec elle et qui ont partagé son luxe, quand ils verront la fumée de son incendie.
###### 10
Ils se tiendront à distance par peur de ses tortures, et ils diront :
« Malheur ! Malheur !
la grande ville,
Babylone, ville puissante :
en une heure, ton jugement est arrivé ! »
###### 11
Et les marchands de la terre pleurent et prennent le deuil à cause d’elle, puisque personne n’achète plus leur cargaison :
###### 12
cargaison d’or, d’argent, de pierres précieuses et de perles, de lin fin, de pourpre, de soie et d’écarlate ; toutes sortes de bois odorants, d’objets en ivoire, en bois très précieux, en bronze, en fer et en marbre ;
###### 13
cannelle, épices, parfums, baume et encens, vin, huile, fleur de farine et blé, bestiaux et moutons, chevaux et chariots, esclaves et marchandise humaine.
###### 14
« Les fruits mûrs de tes convoitises
sont partis loin de toi,
tout ce qui était brillance et splendeur est perdu pour toi,
et cela plus jamais ne se retrouvera. »
###### 15
Les marchands qu’elle avait ainsi enrichis se tiendront à distance par peur de ses tortures, dans les pleurs et le deuil.
###### 16
Ils diront :
« Malheur ! Malheur ! La grande ville,
vêtue de lin fin, de pourpre et d’écarlate,
toute parée d’or, de pierres précieuses et de perles,
###### 17
car, en une heure, tant de richesses furent dévastées ! »
Tous les capitaines de navires et ceux qui font le cabotage, les marins et tous les travailleurs de la mer se tenaient à distance,
###### 18
et ils criaient en voyant la fumée de son incendie. Ils disaient : « Quelle ville fut comparable à la grande ville ? »
###### 19
Et jetant de la poussière sur leur tête, ils criaient dans les pleurs et le deuil. Ils disaient :
« Malheur ! Malheur ! La grande ville,
dont l’opulence enrichissait
tous ceux qui avaient des bateaux sur la mer :
en une heure, elle a été dévastée ! »
###### 20
Ciel, sois dans la joie à cause d’elle,
ainsi que vous, les saints, les apôtres et les prophètes,
car Dieu, en la jugeant, vous a rendu justice.
###### 21
Alors un ange plein de force prit une pierre pareille à une grande meule, et la précipita dans la mer, en disant :
« Ainsi, d’un coup, sera précipitée
Babylone, la grande ville,
on ne la retrouvera jamais plus.
###### 22
La voix des joueurs de cithares et des musiciens,
des joueurs de flûte et de trompette,
chez toi ne s’entendra jamais plus.
Aucun artisan d’aucun métier
chez toi ne se trouvera jamais plus,
et la voix de la meule
chez toi ne s’entendra jamais plus.
###### 23
La lumière de la lampe
chez toi ne brillera jamais plus.
La voix du jeune époux et de son épouse
chez toi ne s’entendra jamais plus.
Pourtant, tes marchands étaient les magnats de la terre,
et tes sortilèges égaraient toutes les nations !
###### 24
Mais c’est chez toi qu’on a trouvé le sang
des prophètes et des saints,
et de tous ceux qui furent immolés sur la terre. »
