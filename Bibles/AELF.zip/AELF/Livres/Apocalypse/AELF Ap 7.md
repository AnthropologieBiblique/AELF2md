---
aliases : 
- Apocalypse 7
- Apocalypse 7
- Ap 7
- Revelation 7
tags : 
- Bible/Ap/7
- français
cssclass : français
---

# Apocalypse 7

###### 01
Après cela, j’ai vu quatre anges debout aux quatre coins de la terre, maîtrisant les quatre vents de la terre, pour empêcher le vent de souffler sur la terre, sur la mer et sur tous les arbres.
###### 02
Puis j’ai vu un autre ange qui montait du côté où le soleil se lève, avec le sceau qui imprime la marque du Dieu vivant ; d’une voix forte, il cria aux quatre anges qui avaient reçu le pouvoir de faire du mal à la terre et à la mer :
###### 03
« Ne faites pas de mal à la terre, ni à la mer, ni aux arbres, avant que nous ayons marqué du sceau le front des serviteurs de notre Dieu. »
###### 04
Et j’entendis le nombre de ceux qui étaient marqués du sceau : ils étaient cent quarante-quatre mille, de toutes les tribus des fils d’Israël.
###### 05
De la tribu de Juda, douze mille marqués du sceau ;
de la tribu de Roubène, douze mille ;
de la tribu de Gad, douze mille ;
###### 06
de la tribu d’Aser, douze mille ;
de la tribu de Nephtali, douze mille ;
de la tribu de Manassé, douze mille ;
###### 07
de la tribu de Siméon, douze mille ;
de la tribu de Lévi, douze mille ;
de la tribu d’Issakar, douze mille ;
###### 08
de la tribu de Zabulon, douze mille ;
de la tribu de Joseph, douze mille ;
de la tribu de Benjamin, douze mille marqués du sceau.
###### 09
Après cela, j’ai vu : et voici une foule immense, que nul ne pouvait dénombrer, une foule de toutes nations, tribus, peuples et langues. Ils se tenaient debout devant le Trône et devant l’Agneau, vêtus de robes blanches, avec des palmes à la main.
###### 10
Et ils s’écriaient d’une voix forte :
« Le salut appartient à notre Dieu
qui siège sur le Trône
et à l’Agneau ! »
###### 11
Tous les anges se tenaient debout autour du Trône, autour des Anciens et des quatre Vivants ; se jetant devant le Trône, face contre terre, ils se prosternèrent devant Dieu.
###### 12
Et ils disaient :
« Amen !
Louange, gloire, sagesse et action de grâce,
honneur, puissance et force
à notre Dieu, pour les siècles des siècles ! Amen ! »
###### 13
L’un des Anciens prit alors la parole et me dit : « Ces gens vêtus de robes blanches, qui sont-ils, et d’où viennent-ils ? »
###### 14
Je lui répondis : « Mon seigneur, toi, tu le sais. » Il me dit :
« Ceux-là viennent de la grande épreuve ;
ils ont lavé leurs robes,
ils les ont blanchies par le sang de l’Agneau.
###### 15
C’est pourquoi ils sont devant le trône de Dieu,
et le servent, jour et nuit, dans son sanctuaire.
Celui qui siège sur le Trône
établira sa demeure chez eux.
###### 16
Ils n’auront plus faim, ils n’auront plus soif,
ni le soleil ni la chaleur ne les accablera,
###### 17
puisque l’Agneau qui se tient au milieu du Trône
sera leur pasteur
pour les conduire aux sources des eaux de la vie.
Et Dieu essuiera toute larme de leurs yeux. »
