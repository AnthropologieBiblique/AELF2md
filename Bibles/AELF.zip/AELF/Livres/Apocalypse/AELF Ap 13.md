---
aliases : 
- Apocalypse 13
- Apocalypse 13
- Ap 13
- Revelation 13
tags : 
- Bible/Ap/13
- français
cssclass : français
---

# Apocalypse 13

###### 01
Alors, j’ai vu monter de la mer une Bête ayant dix cornes et sept têtes, avec un diadème sur chacune des dix cornes et, sur les têtes, des noms blasphématoires.
###### 02
Et la Bête que j’ai vue ressemblait à une panthère ; ses pattes étaient comme celles d’un ours, et sa gueule, comme celle d’un lion. Le Dragon lui donna sa puissance et son trône, et un grand pouvoir.
###### 03
L’une de ses têtes était comme blessée à mort, mais sa plaie mortelle fut guérie.
Émerveillée, la terre entière suivit la Bête,
###### 04
et l’on se prosterna devant le Dragon parce qu’il avait donné le pouvoir à la Bête. Et, devant elle, on se prosterna aussi, en disant : « Qui est comparable à la Bête, et qui peut lui faire la guerre ? »
###### 05
Il lui fut donné une bouche qui disait des énormités, des blasphèmes, et il lui fut donné pouvoir d’agir pendant quarante-deux mois.
###### 06
Elle ouvrit la bouche pour proférer des blasphèmes contre Dieu, pour blasphémer contre son nom et sa demeure, contre ceux qui demeurent au ciel.
###### 07
Il lui fut donné de faire la guerre aux saints et de les vaincre, il lui fut donné pouvoir sur toute tribu, peuple, langue et nation.
###### 08
Ils se prosterneront devant elle, tous ceux qui habitent sur la terre, et dont le nom n’est pas inscrit dans le livre de vie de l’Agneau immolé, depuis la fondation du monde.
###### 09
Si quelqu’un a des oreilles, qu’il entende.
###### 10
Si quelqu’un doit aller en captivité,
il ira en captivité ;
si quelqu’un doit être tué par l’épée,
il sera tué par l’épée.
C’est ici qu’on reconnaît la persévérance et la foi des saints.
###### 11
Puis, j’ai vu monter de la terre une autre Bête ; elle avait deux cornes comme un agneau, et elle parlait comme un dragon.
###### 12
Elle exerce tout le pouvoir de la première Bête en sa présence, amenant la terre et tous ceux qui l’habitent à se prosterner devant la première Bête, dont la plaie mortelle a été guérie.
###### 13
Elle produit de grands signes, jusqu’à faire descendre le feu du ciel sur la terre aux yeux des hommes :
###### 14
elle égare les habitants de la terre par les signes qu’il lui a été donné de produire en présence de la Bête ; elle dit aux habitants de la terre de dresser une image en l’honneur de la première Bête qui porte une plaie faite par l’épée mais qui a repris vie.
###### 15
Il lui a été donné d’animer l’image de la Bête, au point que cette image se mette à parler, et fasse tuer tous ceux qui ne se prosternent pas devant elle.
###### 16
À tous, petits et grands, riches et pauvres, hommes libres et esclaves, elle fait mettre une marque sur la main droite ou sur le front,
###### 17
afin que personne ne puisse acheter ou vendre, s’il ne porte cette marque-là : le nom de la Bête ou le chiffre de son nom.
###### 18
C’est ici qu’on reconnaît la sagesse. Celui qui a l’intelligence, qu’il se mette à calculer le chiffre de la Bête, car c’est un chiffre d’homme, et ce chiffre est six cent soixante-six.
