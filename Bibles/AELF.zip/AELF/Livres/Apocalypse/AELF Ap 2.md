---
aliases : 
- Apocalypse 2
- Apocalypse 2
- Ap 2
- Revelation 2
tags : 
- Bible/Ap/2
- français
cssclass : français
---

# Apocalypse 2

###### 01
À l’ange de l’Église qui est à Éphèse, écris :
Ainsi parle celui qui tient les sept étoiles dans sa main droite, qui marche au milieu des sept chandeliers d’or :
###### 02
Je connais tes actions, ta peine, ta persévérance, je sais que tu ne peux supporter les malfaisants ; tu as mis à l’épreuve ceux qui se disent apôtres et ne le sont pas ; tu as découvert qu’ils étaient menteurs.
###### 03
Tu ne manques pas de persévérance, et tu as tant supporté pour mon nom, sans ménager ta peine.
###### 04
Mais j’ai contre toi que ton premier amour, tu l’as abandonné.
###### 05
Eh bien, rappelle-toi d’où tu es tombé, convertis-toi, reviens à tes premières actions. Sinon je vais venir à toi et je délogerai ton chandelier de sa place, si tu ne t’es pas converti.
###### 06
Pourtant, tu as cela pour toi que tu détestes les agissements des Nicolaïtes – et je les déteste, moi aussi.
###### 07
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises. Au vainqueur, je donnerai de goûter à l’arbre de la vie qui est dans le paradis de Dieu.
###### 08
À l’ange de l’Église qui est à Smyrne, écris :
Ainsi parle celui qui est le Premier et le Dernier, celui qui était mort et qui est entré dans la vie :
###### 09
Je sais ta détresse et ta pauvreté ; pourtant tu es riche ! Je connais les propos blasphématoires de ceux qui se disent Juifs et ne le sont pas : ils sont une synagogue de Satan.
###### 10
Sois sans aucune crainte pour ce que tu vas souffrir. Voici que le diable va jeter en prison certains des vôtres pour vous mettre à l’épreuve, et vous serez dans la détresse pendant dix jours. Sois fidèle jusqu’à la mort, et je te donnerai la couronne de la vie.
###### 11
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises. Le vainqueur ne pourra être atteint par la seconde mort.
###### 12
À l’ange de l’Église qui est à Pergame, écris :
Ainsi parle celui qui a le glaive acéré à deux tranchants :
###### 13
Je sais où tu habites : c’est là que Satan a son trône ; mais tu tiens ferme à mon nom, et tu n’as pas renié ma foi, même dans les jours où Antipas, mon témoin fidèle, a été mis à mort chez vous, là où Satan habite.
###### 14
Mais j’ai quelque chose contre toi : tu as là des gens qui tiennent ferme à la doctrine de Balaam ; celui-ci enseignait à Balak comment faire trébucher les fils d’Israël, pour qu’ils mangent des viandes offertes aux idoles et qu’ils se prostituent.
###### 15
De même, tu as, toi aussi, des gens qui tiennent ferme à la doctrine des Nicolaïtes.
###### 16
Eh bien, convertis-toi : sinon je vais venir à toi sans tarder ; avec le glaive de ma bouche je les combattrai.
###### 17
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises. Au vainqueur je donnerai de la manne cachée, je lui donnerai un caillou blanc, et, inscrit sur ce caillou, un nom nouveau que nul ne sait, sauf celui qui le reçoit.
###### 18
À l’ange de l’Église qui est à Thyatire, écris :
Ainsi parle le Fils de Dieu, celui qui a les yeux comme une flamme ardente et des pieds qui semblent de bronze précieux :
###### 19
Je connais tes actions, je sais ton amour, ta foi, ton engagement, ta persévérance, et tes dernières actions surpassent les premières.
###### 20
Mais j’ai contre toi que tu laisses faire Jézabel, cette femme qui se dit prophétesse, et qui égare mes serviteurs en leur enseignant à se prostituer et à manger des viandes offertes aux idoles.
###### 21
Je lui ai donné du temps pour se convertir, mais elle ne veut pas se convertir de sa prostitution.
###### 22
Voici que je vais la jeter sur un lit de grande détresse, elle et ses compagnons d’adultère, à moins que, renonçant aux agissements de cette femme, ils ne se convertissent ;
###### 23
et ses enfants, je vais les frapper de mort. Toutes les Églises reconnaîtront que moi, je suis celui qui scrute les reins et les cœurs, et je donnerai à chacun de vous selon ses œuvres.
###### 24
Mais vous, les autres de Thyatire, qui ne partagez pas cette doctrine et n’avez pas connu les « profondeurs de Satan » – comme ils disent –, je vous déclare que je ne vous impose pas d’autre fardeau ;
###### 25
tenez fermement, du moins, ce que vous avez, jusqu’à ce que je vienne.
###### 26
Le vainqueur, celui qui reste fidèle jusqu'à la fin à ma façon d’agir, je lui donnerai autorité sur les nations,
###### 27
et il les conduira avec un sceptre de fer, comme des vases de potier que l’on brise.
###### 28
Il sera comme moi qui ai reçu autorité de mon Père, et je lui donnerai l’étoile du matin.
###### 29
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises.
