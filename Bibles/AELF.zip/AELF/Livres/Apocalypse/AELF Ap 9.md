---
aliases : 
- Apocalypse 9
- Apocalypse 9
- Ap 9
- Revelation 9
tags : 
- Bible/Ap/9
- français
cssclass : français
---

# Apocalypse 9

###### 01
Le cinquième ange sonna de la trompette, et j’ai vu une étoile qui était tombée du ciel sur la terre : c’est à elle que fut donnée la clé du puits de l’abîme.
###### 02
Elle ouvrit le puits de l’abîme, et du puits monta une fumée comme celle d’une grande fournaise ; le soleil et l’air furent obscurcis par la fumée du puits.
###### 03
Et de la fumée sortirent vers la terre des sauterelles ; un pouvoir leur fut donné, pareil au pouvoir des scorpions de la terre.
###### 04
Il leur fut dit de ne pas faire de mal à l’herbe de la terre, ni à la verdure, ni à aucun arbre, mais seulement aux hommes, ceux qui n’ont pas sur le front la marque du sceau de Dieu.
###### 05
Il leur fut donné, non pas de les tuer, mais de les tourmenter pendant cinq mois d’un tourment comme celui qu’inflige le scorpion quand il pique un homme.
###### 06
En ces jours-là, les hommes chercheront la mort et ne la trouveront pas ; ils désireront mourir et la mort les fuira.
###### 07
Ces sortes de sauterelles ressemblent à des chevaux équipés pour la guerre ; elles ont comme des couronnes d’or sur la tête, et un visage comme un visage humain.
###### 08
Elles ont des cheveux comme des cheveux de femmes, leurs dents sont comme celles des lions.
###### 09
Elles ont des poitrails comme des cuirasses de fer, et le bruit de leurs ailes est comme celui de chars à plusieurs chevaux courant au combat.
###### 10
Elles ont des queues comme des scorpions, et des dards venimeux. Dans leur queue se trouve le pouvoir de faire du mal aux hommes pendant cinq mois.
###### 11
Elles ont comme roi l’ange de l’abîme ; il se nomme en hébreu Abaddôn et en grec Apollyôn (c’est-à-dire : Destructeur).
###### 12
Le premier « Malheur ! » est passé ; voici que deux « Malheur ! » vont encore arriver.
###### 13
Le sixième ange sonna de la trompette, et j’entendis une voix venant des quatre cornes de l’autel d’or qui est devant Dieu ;
###### 14
elle disait au sixième ange qui avait la trompette : « Libère les quatre anges qui sont enchaînés au bord de l’Euphrate, le grand fleuve. »
###### 15
Alors furent libérés les quatre anges qui étaient prêts pour cette heure, ce jour, ce mois, cette année, afin de tuer le tiers de l’humanité.
###### 16
Les troupes de cavalerie comptaient deux myriades de myriades : j’ai entendu ce nombre.
###### 17
Ainsi, dans ma vision, j’ai vu les chevaux et ceux qui les montaient : ils ont des cuirasses couleur de feu, d’hyacinthe et de soufre ; les têtes des chevaux sont comme des têtes de lion ; de leurs bouches sortent du feu, de la fumée et du soufre.
###### 18
Le tiers de l’humanité fut tué par ces trois fléaux, le feu, la fumée et le soufre qui sortaient de leurs bouches.
###### 19
Car le pouvoir des chevaux se trouve dans leurs bouches, et aussi dans leurs queues. En effet, celles-ci sont semblables à des serpents, et elles ont des têtes qui font du mal.
###### 20
Et le reste des hommes, ceux qui n’avaient pas été tués par ces fléaux, ne se sont pas convertis, ne renonçant pas aux œuvres de leurs mains ; ils n’ont pas cessé de se prosterner devant les démons, les idoles d’or, d’argent, de bronze, de pierre et de bois, qui ne peuvent pas voir, ni entendre, ni marcher.
###### 21
Ils ne se sont pas convertis, ne renonçant ni à leurs meurtres, ni à leurs sortilèges, ni à leur débauche, ni à leurs vols.
