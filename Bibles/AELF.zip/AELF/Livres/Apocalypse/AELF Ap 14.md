---
aliases : 
- Apocalypse 14
- Apocalypse 14
- Ap 14
- Revelation 14
tags : 
- Bible/Ap/14
- français
cssclass : français
---

# Apocalypse 14

###### 01
Alors j’ai vu : et voici que l’Agneau se tenait debout sur la montagne de Sion, et avec lui les cent quarante-quatre mille qui portent, inscrits sur leur front, le nom de l’Agneau et celui de son Père.
###### 02
Et j’ai entendu une voix venant du ciel comme la voix des grandes eaux ou celle d’un fort coup de tonnerre ; mais cette voix que j’entendais était aussi comme celle des joueurs de cithare qui chantent et s’accompagnent sur leur cithare.
###### 03
Ils chantent un cantique nouveau devant le Trône, et devant les quatre Vivants et les Anciens. Personne ne pouvait apprendre ce cantique sinon les cent quarante-quatre mille, ceux qui ont été rachetés et retirés de la terre.
###### 04
Ceux-là ne se sont pas souillés avec des femmes ;
ils sont vierges, en effet.
Ceux-là suivent l’Agneau partout où il va ;
ils ont été pris d’entre les hommes,
achetés comme prémices pour Dieu et pour l’Agneau.
###### 05
Dans leur bouche, on n’a pas trouvé de mensonge ;
ils sont sans tache.
###### 06
Puis j’ai vu un autre ange volant en plein ciel ; il avait un évangile éternel à proclamer, bonne nouvelle pour ceux qui résident sur la terre, pour toute nation, tribu, langue et peuple.
###### 07
Il disait d’une voix forte :
« Craignez Dieu et rendez-lui gloire,
car elle est venue, l’heure où il doit juger ;
prosternez-vous devant celui qui a fait le ciel,
la terre, la mer, et les sources des eaux. »
###### 08
Un autre ange, le deuxième, vint à sa suite. Il disait :
« Elle est tombée, elle est tombée, Babylone la Grande,
elle qui abreuvait toutes les nations
du vin de la fureur de sa prostitution. »
###### 09
Un autre ange, le troisième, vint à leur suite. Il disait d’une voix forte :
« Si quelqu’un se prosterne devant la Bête et son image,
s’il en reçoit la marque sur le front ou sur la main,
###### 10
lui aussi boira du vin de la fureur de Dieu,
versé sans mélange dans la coupe de sa colère ;
il sera torturé par le feu et le soufre
devant les anges saints et devant l’Agneau.
###### 11
Et la fumée de ces tortures
monte pour les siècles des siècles.
Ils n’ont de repos ni le jour ni la nuit,
ceux qui se prosternent devant la Bête et son image,
et quiconque reçoit la marque de son nom. »
###### 12
C’est ici qu’on reconnaît la persévérance des saints, ceux-là qui gardent les commandements de Dieu et la foi de Jésus.
###### 13
Alors j’ai entendu une voix qui venait du ciel. Elle disait :
« Écris :
Heureux, dès à présent,
les morts qui meurent dans le Seigneur.
Oui, dit l’Esprit,
qu’ils se reposent de leurs peines,
car leurs actes les suivent ! »
###### 14
Alors j’ai vu : et voici une nuée blanche, et sur cette nuée, quelqu’un siégeait, qui semblait un Fils d’homme. Il avait sur la tête une couronne d’or et, à la main, une faucille aiguisée.
###### 15
Un autre ange sortit du Sanctuaire. Il cria d’une voix forte à celui qui siégeait sur la nuée :
« Lance ta faucille et moissonne :
elle est venue, l’heure de la moisson,
car la moisson de la terre se dessèche. »
###### 16
Alors, celui qui siégeait sur la nuée jeta la faucille sur la terre, et la terre fut moissonnée.
###### 17
Puis un autre ange sortit du Sanctuaire qui est dans le ciel ; il avait, lui aussi, une faucille aiguisée.
###### 18
Un autre ange encore sortit, venant de l’autel ; il avait pouvoir sur le feu. Il interpella d’une voix forte celui qui avait la faucille aiguisée : « Lance ta faucille aiguisée, et vendange les grappes de la vigne sur la terre, car les raisins sont mûrs. »
###### 19
L’ange, alors, jeta la faucille sur la terre, il vendangea la vigne de la terre et jeta la vendange dans la cuve immense de la fureur de Dieu.
###### 20
On se mit à fouler hors de la ville, et de la cuve sortit du sang, jusqu’à hauteur du mors des chevaux, sur une distance de mille six cents stades.
