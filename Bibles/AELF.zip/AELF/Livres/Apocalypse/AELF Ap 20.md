---
aliases : 
- Apocalypse 20
- Apocalypse 20
- Ap 20
- Revelation 20
tags : 
- Bible/Ap/20
- français
cssclass : français
---

# Apocalypse 20

###### 01
Alors j’ai vu un ange qui descendait du ciel ; il tenait à la main la clé de l’abîme et une énorme chaîne.
###### 02
Il s’empara du Dragon, le serpent des origines, qui est le Diable, le Satan, et il l’enchaîna pour une durée de mille ans.
###### 03
Il le précipita dans l’abîme, qu’il referma sur lui ; puis il mit les scellés pour que le Dragon n’égare plus les nations, jusqu’à ce que les mille ans arrivent à leur terme. Après cela, il faut qu’il soit relâché pour un peu de temps.
###### 04
Puis j’ai vu des trônes : à ceux qui vinrent y siéger fut donné le pouvoir de juger. Et j’ai vu les âmes de ceux qui ont été décapités à cause du témoignage pour Jésus, et à cause de la parole de Dieu, eux qui ne se sont pas prosternés devant la Bête et son image, et qui n’ont pas reçu sa marque sur le front ou sur la main. Ils revinrent à la vie, et ils régnèrent avec le Christ pendant mille ans.
###### 05
Le reste des morts ne revint pas à la vie tant que les mille ans ne furent pas arrivés à leur terme.
Telle est la première résurrection.
###### 06
Heureux et saints, ceux qui ont part à la première résurrection ! Sur eux, la seconde mort n’a pas de pouvoir : ils seront prêtres de Dieu et du Christ, et régneront avec lui pendant les mille ans.
###### 07
Et quand les mille ans seront arrivés à leur terme, Satan sera relâché de sa prison,
###### 08
il sortira pour égarer les gens des nations qui sont aux quatre coins de la terre, Gog et Magog, afin de les rassembler pour la guerre ; ils sont aussi nombreux que le sable de la mer.
###### 09
Ils montèrent, couvrant l’étendue de la terre, ils encerclèrent le camp des saints et la Ville bien-aimée, mais un feu descendit du ciel et les dévora.
###### 10
Et le diable qui les égarait fut jeté dans l’étang de feu et de soufre, où sont aussi la Bête et le faux prophète ; ils y seront torturés jour et nuit pour les siècles des siècles.
###### 11
Puis j’ai vu un grand trône blanc et celui qui siégeait sur ce trône. Devant sa face, le ciel et la terre s’enfuirent : nulle place pour eux !
###### 12
J’ai vu aussi les morts, les grands et les petits, debout devant le Trône. On ouvrit des livres, puis un autre encore : le livre de la vie. D’après ce qui était écrit dans les livres, les morts furent jugés selon leurs actes.
###### 13
La mer rendit les morts qu’elle retenait ; la Mort et le séjour des morts rendirent aussi ceux qu’ils retenaient, et ils furent jugés, chacun selon ses actes.
###### 14
Puis la Mort et le séjour des morts furent précipités dans l’étang de feu – l’étang de feu, c’est la seconde mort.
###### 15
Et si quelqu’un ne se trouvait pas inscrit dans le livre de la vie, il était précipité dans l’étang de feu.
