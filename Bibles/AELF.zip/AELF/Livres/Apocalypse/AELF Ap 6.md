---
aliases : 
- Apocalypse 6
- Apocalypse 6
- Ap 6
- Revelation 6
tags : 
- Bible/Ap/6
- français
cssclass : français
---

# Apocalypse 6

###### 01
Alors j’ai vu : quand l’Agneau ouvrit l’un des sept sceaux, j’entendis l’un des quatre Vivants dire d’une voix de tonnerre : « Viens ! »
###### 02
Alors j’ai vu : et voici un cheval blanc ; celui qui le montait tenait un arc, une couronne lui fut donnée, et il sortit vainqueur, pour vaincre à nouveau.
###### 03
Et quand il ouvrit le deuxième sceau, j’entendis le deuxième Vivant qui disait : « Viens ! »
###### 04
Alors sortit un autre cheval, rouge feu ; à celui qui le montait il fut donné d’enlever la paix à la terre, pour que les gens s’entretuent, et une grande épée lui fut donnée.
###### 05
Et quand il ouvrit le troisième sceau, j’entendis le troisième Vivant qui disait : « Viens ! » Alors j’ai vu : et voici un cheval noir ; celui qui le montait tenait à la main une balance.
###### 06
Et j’entendis comme une voix au milieu des quatre Vivants ; elle disait : « Un denier, la mesure de blé ! Un denier, les trois mesures d’orge ! Ne fraude pas sur l’huile et sur le vin ! »
###### 07
Et quand il ouvrit le quatrième sceau, j’entendis la voix du quatrième Vivant qui disait : « Viens ! »
###### 08
Alors j’ai vu : et voici un cheval verdâtre ; celui qui le montait se nomme la Mort, et le séjour des morts l’accompagnait. Et il leur fut donné pouvoir sur un quart de la terre pour tuer par le glaive, par la famine et par la peste, et par les fauves de la terre.
###### 09
Et quand il ouvrit le cinquième sceau, je vis sous l’autel les âmes de ceux qui furent égorgés à cause de la parole de Dieu et du témoignage qu’ils avaient porté.
###### 10
Ils crièrent d’une voix forte : « Jusques à quand, Maître saint et vrai,resteras-tu sans juger, sans venger notre sang sur les habitants de la terre ? »
###### 11
Et il fut donné à chacun une robe blanche, et il leur fut dit de patienter encore quelque temps, jusqu’à ce que soient au complet leurs compagnons de service, leurs frères, qui allaient être tués comme eux.
###### 12
Alors j’ai vu : quand il ouvrit le sixième sceau, il y eut un grand tremblement de terre, le soleil devint noir comme une étoffe de crin, et la lune entière, comme du sang,
###### 13
et les étoiles du ciel tombèrent sur la terre comme lorsqu’un figuier secoué par grand vent jette ses fruits.
###### 14
Le ciel se retira comme un livre qu’on referme ; toutes les montagnes et les îles furent déplacées.
###### 15
Les rois de la terre et les grands, les chefs d’armée, les riches et les puissants, tous les esclaves et les hommes libres allèrent se cacher dans les cavernes et les rochers des montagnes.
###### 16
Et ils disaient aux montagnes et aux rochers : « Tombez sur nous, et cachez-nous du regard de celui qui siège sur le Trône et aussi de la colère de l’Agneau.
###### 17
Car il est venu, le grand jour de leur colère, et qui pourrait tenir ? »
