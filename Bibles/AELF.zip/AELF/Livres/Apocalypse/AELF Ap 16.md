---
aliases : 
- Apocalypse 16
- Apocalypse 16
- Ap 16
- Revelation 16
tags : 
- Bible/Ap/16
- français
cssclass : français
---

# Apocalypse 16

###### 01
Alors j’entendis une voix forte venant du Sanctuaire, qui disait aux sept anges : « Allez répandre sur la terre les sept coupes de la fureur de Dieu. »
###### 02
Le premier partit et répandit sa coupe sur la terre : il y eut un ulcère malin et pernicieux sur les hommes qui portaient la marque de la Bête, et sur ceux qui se prosternaient devant son image.
###### 03
Le deuxième répandit sa coupe sur la mer : il y eut du sang comme d’un mort, et toute vie dans la mer mourut.
###### 04
Le troisième répandit sa coupe sur les fleuves et les sources des eaux : et il y eut du sang.
###### 05
Alors j’entendis l’ange des eaux qui disait :
« Tu es juste, toi qui es, et qui étais, toi le Saint,
parce que tu as rendu ce jugement.
###### 06
Ils ont répandu le sang des saints et des prophètes ;
tu leur as donné du sang à boire :
c’est ce qu’ils méritent ! »
###### 07
Puis j’ai entendu l’autel qui disait :
« Oui, Seigneur Dieu, Souverain de l’univers,
ils sont vrais, ils sont justes, tes jugements. »
###### 08
Le quatrième ange répandit sa coupe sur le soleil : il lui fut donné de brûler les hommes de son feu.
###### 09
Les hommes furent brûlés d’une grande brûlure ; ils blasphémèrent le nom du Dieu qui a de tels fléaux en son pouvoir, au lieu de se convertir en lui rendant gloire.
###### 10
Le cinquième répandit sa coupe sur le trône de la Bête : il y eut de l’obscurité sur son royaume. Les gens se mordaient la langue de douleur
###### 11
et ils blasphémèrent le Dieu du ciel sous le coup de leurs douleurs et de leurs ulcères, au lieu de se repentir de leurs agissements.
###### 12
Le sixième répandit sa coupe sur le grand fleuve, l’Euphrate : et l’eau en fut tarie pour préparer la route des rois venant du côté où le soleil se lève.
###### 13
Puis j’ai vu sortir de la gueule du Dragon, de celle de la Bête et de celle du faux prophète, trois esprits impurs, pareils à des grenouilles.
###### 14
Ce sont, en effet, des esprits démoniaques qui produisent des signes, et s’en vont vers les rois du monde entier afin de les rassembler pour la bataille du grand jour de Dieu, le Souverain de l’univers.
###### 15
– Voici que je viens comme un voleur. Heureux celui qui veille et garde sur lui ses vêtements pour ne pas aller nu en laissant voir sa honte.
###### 16
Et ils les rassemblèrent en un lieu appelé en hébreu Harmaguédone.
###### 17
Le septième ange répandit sa coupe dans les airs : une voix forte venant du trône sortit du Sanctuaire ; elle disait : « C’en est fait ! »
###### 18
Il y eut des éclairs, des fracas, des coups de tonnerre ; il y eut un grand tremblement de terre : depuis que sur la terre il y a des hommes, il n'y eut jamais de tremblement de terre aussi grand.
###### 19
Et la grande ville se disloqua en trois parties, et les villes des nations tombèrent. Et Dieu se souvint de Babylone la Grande, pour lui donner à boire le vin de sa fureur, la coupe de sa colère.
###### 20
Toutes les îles s’enfuirent, et les montagnes disparurent.
###### 21
Des grêlons d’une masse énorme tombèrent du ciel sur les hommes, qui blasphémèrent Dieu à cause du fléau de la grêle, car c’était un terrible fléau.
