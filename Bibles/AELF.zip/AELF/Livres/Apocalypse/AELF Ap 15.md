---
aliases : 
- Apocalypse 15
- Apocalypse 15
- Ap 15
- Revelation 15
tags : 
- Bible/Ap/15
- français
cssclass : français
---

# Apocalypse 15

###### 01
Alors j’ai vu dans le ciel un autre signe, grand et merveilleux : sept anges qui détiennent sept fléaux ; ce sont les derniers, puisque s’achève avec eux la fureur de Dieu.
###### 02
J’ai vu comme une mer de cristal, mêlée de feu, et ceux qui sont victorieux de la Bête, de son image, et du chiffre qui correspond à son nom : ils se tiennent debout sur cette mer de cristal, ils ont en main les cithares de Dieu.
###### 03
Ils chantent le cantique de Moïse, serviteur de Dieu, et le cantique de l’Agneau. Ils disent :
(
3) « Grandes, merveilleuses, tes œuvres,
Seigneur Dieu, Souverain de l’univers !
Ils sont justes, ils sont vrais, tes chemins,
Roi des nations.
###### 04
Qui ne te craindrait, Seigneur ?
À ton nom, qui ne rendrait gloire ?
Oui, toi seul es saint !
Oui, toutes les nations viendront
et se prosterneront devant toi ;
oui, ils sont manifestés, tes jugements. »
###### 05
Et après cela, j’ai vu : le Sanctuaire où se trouve la Demeure du Témoignage s’ouvrit dans le ciel,
###### 06
et les sept anges aux sept fléaux sortirent du Sanctuaire, habillés de lin pur et resplendissant ; ils portaient des ceintures d’or autour de la poitrine.
###### 07
L’un des quatre Vivants donna aux sept anges sept coupes d’or, remplies de la fureur de Dieu, lui qui est vivant pour les siècles des siècles.
###### 08
Et le Sanctuaire fut rempli de fumée par la gloire de Dieu et sa puissance, et personne ne pouvait entrer dans le Sanctuaire jusqu’à ce que s’achèvent les sept fléaux des sept anges.
