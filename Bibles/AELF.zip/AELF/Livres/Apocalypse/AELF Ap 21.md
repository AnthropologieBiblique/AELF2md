---
aliases : 
- Apocalypse 21
- Apocalypse 21
- Ap 21
- Revelation 21
tags : 
- Bible/Ap/21
- français
cssclass : français
---

# Apocalypse 21

###### 01
Alors j’ai vu un ciel nouveau et une terre nouvelle, car le premier ciel et la première terre s’en étaient allés et, de mer, il n’y en a plus.
###### 02
Et la Ville sainte, la Jérusalem nouvelle, je l’ai vue qui descendait du ciel, d’auprès de Dieu, prête pour les noces, comme une épouse parée pour son mari.
###### 03
Et j’entendis une voix forte qui venait du Trône. Elle disait :
« Voici la demeure de Dieu avec les hommes ;
il demeurera avec eux,
et ils seront ses peuples,
et lui-même, Dieu avec eux, sera leur Dieu.
###### 04
Il essuiera toute larme de leurs yeux,
et la mort ne sera plus,
et il n’y aura plus ni deuil, ni cri, ni douleur :
ce qui était en premier s’en est allé. »
###### 05
Alors celui qui siégeait sur le Trône déclara : « Voici que je fais toutes choses nouvelles. » Et il dit : « Écris, car ces paroles sont dignes de foi et vraies. »
###### 06
Puis il me dit : « C’est fait. Moi, je suis l’alpha et l’oméga, le commencement et la fin. À celui qui a soif, moi, je donnerai l’eau de la source de vie, gratuitement.
###### 07
Tel sera l’héritage du vainqueur ; je serai son Dieu, et lui sera mon fils.
###### 08
Quant aux lâches, perfides, êtres abominables, meurtriers, débauchés, sorciers, idolâtres et tous les menteurs, la part qui leur revient, c’est l’étang embrasé de feu et de soufre, qui est la seconde mort. »
###### 09
Alors arriva l’un des sept anges aux sept coupes remplies des sept derniers fléaux, et il me parla ainsi : « Viens, je te montrerai la Femme, l’Épouse de l’Agneau. »
###### 10
En esprit, il m’emporta sur une grande et haute montagne ; il me montra la Ville sainte, Jérusalem, qui descendait du ciel, d’auprès de Dieu :
###### 11
elle avait en elle la gloire de Dieu ; son éclat était celui d’une pierre très précieuse, comme le jaspe cristallin.
###### 12
Elle avait une grande et haute muraille, avec douze portes et, sur ces portes, douze anges ; des noms y étaient inscrits : ceux des douze tribus des fils d’Israël.
###### 13
Il y avait trois portes à l’orient, trois au nord, trois au midi, et trois à l’occident.
###### 14
La muraille de la ville reposait sur douze fondations portant les douze noms des douze Apôtres de l’Agneau.
###### 15
Celui qui me parlait tenait un roseau d’or comme mesure, pour mesurer la ville, ses portes, et sa muraille.
###### 16
La ville a la forme d’un carré : sa longueur est égale à sa largeur. Il mesura la ville avec le roseau : douze mille stades ; sa longueur, sa largeur et sa hauteur sont égales.
###### 17
Puis il mesura sa muraille : cent quarante-quatre coudées, mesure d’homme et mesure d’ange.
###### 18
Le matériau de la muraille est de jaspe, et la ville est d’or pur, d’une pureté transparente.
###### 19
Les fondations de la muraille de la ville sont ornées de toutes sortes de pierres précieuses. La première fondation est de jaspe, la deuxième de saphir, la troisième de calcédoine, la quatrième d’émeraude,
###### 20
la cinquième de sardoine, la sixième de cornaline, la septième de chrysolithe, la huitième de béryl, la neuvième de topaze, la dixième de chrysoprase, la onzième d’hyacinthe, la douzième d’améthyste.
###### 21
Les douze portes sont douze perles, chaque porte faite d’une seule perle ; la place de la ville est d’or pur d’une parfaite transparence.
###### 22
Dans la ville, je n’ai pas vu de sanctuaire, car son sanctuaire, c’est le Seigneur Dieu, Souverain de l’univers, et l’Agneau.
###### 23
La ville n’a pas besoin du soleil ni de la lune pour l’éclairer, car la gloire de Dieu l’illumine : son luminaire, c’est l’Agneau.
###### 24
Les nations marcheront à sa lumière, et les rois de la terre y porteront leur gloire.
###### 25
Jour après jour, jamais les portes ne seront fermées, car il n’y aura plus de nuit.
###### 26
On apportera dans la ville la gloire et le faste des nations.
###### 27
Rien de souillé n’y entrera jamais, ni personne qui pratique abomination ou mensonge, mais seulement ceux qui sont inscrits dans le livre de vie de l’Agneau.
