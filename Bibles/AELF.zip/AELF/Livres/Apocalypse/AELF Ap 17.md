---
aliases : 
- Apocalypse 17
- Apocalypse 17
- Ap 17
- Revelation 17
tags : 
- Bible/Ap/17
- français
cssclass : français
---

# Apocalypse 17

###### 01
L’un des sept anges aux sept coupes vint me parler : « Viens, dit-il, je vais te montrer ce que sera la condamnation de la grande prostituée assise au bord des grandes eaux.
###### 02
Les rois de la terre se sont prostitués avec elle, et ceux qui habitent la terre se sont enivrés du vin de sa prostitution. »
###### 03
Il me transporta en esprit au désert.
Et j’ai vu une femme assise sur une bête écarlate qui était couverte de noms blasphématoires et qui avait sept têtes et dix cornes.
###### 04
Cette femme était vêtue de pourpre et d’écarlate, toute parée d’or, de pierres précieuses et de perles ; elle avait dans la main une coupe d’or remplie d’abominations, avec les impuretés de sa prostitution.
###### 05
Il y avait sur son front un nom écrit, un mystère : « Babylone la Grande, la mère des prostitutions et des abominations de la terre. »
###### 06
Et j’ai vu la femme ivre du sang des saints et du sang des témoins de Jésus. En la voyant, je fus saisi d’un grand étonnement.
###### 07
Et l’ange me dit : « Pourquoi es-tu étonné ? Moi, je te dirai le mystère de la femme et de la Bête qui la porte, celle qui a les sept têtes et les dix cornes.
###### 08
La Bête que tu as vue, elle était, mais elle n’est plus ; elle va monter de l’abîme pour aller à sa perdition. Quant aux habitants de la terre dont le nom n’est pas inscrit dans le livre de la vie depuis la fondation du monde, ils seront étonnés au spectacle de la Bête qui était, qui n’est plus et qui va reparaître.
###### 09
Ici, il faut l’intelligence mais avec la sagesse. Les sept têtes sont sept collines sur lesquelles réside la femme ; elles sont aussi sept rois :
###### 10
cinq sont tombés, un est là maintenant, et l’autre n’est pas encore venu, mais quand il viendra, il ne devra rester que peu de temps.
###### 11
Et la Bête qui était et qui n’est plus, est elle-même un huitième roi, mais elle fait partie des sept ; elle va à sa perdition.
###### 12
Les dix cornes que tu as vues sont dix rois qui n’ont pas encore reçu la royauté, mais reçoivent le pouvoir royal avec la Bête pour une heure.
###### 13
Ceux-ci ont un même projet : donner leur puissance et leur pouvoir à la Bête.
###### 14
Ils feront la guerre à l’Agneau, et l’Agneau les vaincra car il est Seigneur des seigneurs et Roi des rois ; et les siens, les appelés, les élus, les fidèles, vaincront avec lui. »
###### 15
Puis il me dit : « Les eaux que tu as vues, là où la prostituée est assise, ce sont des peuples et des foules, des nations et des langues.
###### 16
Quant aux dix cornes que tu as vues, ainsi que la Bête, elles se prendront de haine pour la prostituée, elles la laisseront dépouillée et nue, elles mangeront ses chairs et la brûleront au feu.
###### 17
Car Dieu leur a mis au cœur de réaliser son projet, de réaliser ensemble un même projet : donner à la Bête leur royauté jusqu’à ce que s’accomplissent les paroles de Dieu.
###### 18
La femme que tu as vue, c’est la grande ville qui exerce la royauté sur les rois de la terre. »
