---
aliases : 
- Apocalypse 19
- Apocalypse 19
- Ap 19
- Revelation 19
tags : 
- Bible/Ap/19
- français
cssclass : français
---

# Apocalypse 19

###### 01
Après cela, j’entendis comme la voix forte d’une foule immense dans le ciel, qui proclamait :
« Alléluia !
Le salut, la gloire,
la puissance à notre Dieu.
###### 02
Ils sont vrais, ils sont justes,
ses jugements.
Il a jugé la grande prostituée
qui corrompait la terre par sa prostitution ;
il a réclamé justice du sang de ses serviteurs,
qu’elle a versé de sa main. »
###### 03
Et la foule reprit :
« Alléluia !
La fumée de l’incendie s’élève pour les siècles des siècles. »
###### 04
Les vingt-quatre Anciens et les quatre Vivants se prosternèrent et adorèrent Dieu qui siège sur le trône ; ils proclamaient :
« Amen ! Alléluia ! »
###### 05
Et du Trône sortit une voix qui disait :
« Louez notre Dieu,
vous tous qui le servez,
vous tous qui le craignez,
les petits et les grands. »
###### 06
Alors j’entendis comme la voix d’une foule immense, comme la voix des grandes eaux, ou celle de violents coups de tonnerre. Elle proclamait :
« Alléluia !
Il règne, le Seigneur notre Dieu,
le Souverain de l’univers.
###### 07
Soyons dans la joie, exultons,
et rendons gloire à Dieu !
Car elles sont venues,
les Noces de l’Agneau,
et pour lui son épouse
a revêtu sa parure.
###### 08
Un vêtement de lin fin lui a été donné,
splendide et pur. »
Car le lin, ce sont les actions justes des saints.
###### 09
Puis l’ange me dit : « Écris : Heureux les invités au repas des noces de l’Agneau ! » Il ajouta : « Ce sont les paroles véritables de Dieu. »
###### 10
Je me jetai à ses pieds pour me prosterner devant lui. Il me dit : « Non, ne fais pas cela ! Je suis un serviteur comme toi, comme tes frères qui portent le témoignage de Jésus. Prosterne-toi devant Dieu ! Car c’est le témoignage de Jésus qui inspire la prophétie. »
###### 11
Puis j’ai vu le ciel ouvert, et voici un cheval blanc : celui qui le monte s’appelle Fidèle et Vrai, il juge et fait la guerre avec justice.
###### 12
Ses yeux sont comme une flamme ardente, il a sur la tête plusieurs diadèmes, il porte un nom écrit que nul ne connaît, sauf lui-même.
###### 13
Le vêtement qui l’enveloppe est trempé de sang, et on lui donne ce nom : « le Verbe de Dieu ».
###### 14
Les armées du ciel le suivaient sur des chevaux blancs, elles étaient vêtues de lin fin, d’un blanc pur.
###### 15
De sa bouche sort un glaive acéré, pour en frapper les nations ; lui-même les conduira avec un sceptre de fer, lui-même foulera la cuve du vin de la fureur, la colère de Dieu, Souverain de l’univers ;
###### 16
sur son vêtement et sur sa cuisse, il porte un nom écrit : « Roi des rois et Seigneur des seigneurs ».
###### 17
Puis j’ai vu un ange debout dans le soleil ; il cria d’une voix forte à tous les oiseaux qui volent en plein ciel : « Venez, rassemblez-vous pour le grand repas de Dieu,
###### 18
pour manger la chair des rois, celle des chefs d’armée, celle des puissants, celle des chevaux et de ceux qui les montent, celle de tous les hommes, libres ou esclaves, des petits et des grands. »
###### 19
Et j’ai vu la Bête, les rois de la terre, et leurs armées, rassemblés pour faire la guerre au cavalier et à son armée.
###### 20
La Bête fut capturée, et avec elle le faux prophète, lui qui, en produisant des signes devant elle, avait égaré ceux qui portent la marque de la Bête et se prosternent devant son image. Ils furent jetés vivants, tous les deux, dans l’étang de feu embrasé de soufre.
###### 21
Les autres furent tués par le glaive du cavalier, le glaive qui sort de sa bouche, et tous les oiseaux se rassasièrent de leurs chairs.
