---
aliases : 
- Apocalypse 11
- Apocalypse 11
- Ap 11
- Revelation 11
tags : 
- Bible/Ap/11
- français
cssclass : français
---

# Apocalypse 11

###### 01
Puis il me fut donné un roseau, une sorte de règle, avec cette parole : « Lève-toi, mesure le sanctuaire de Dieu, l’autel et ceux qui s’y prosternent.
###### 02
Mais la cour au-dehors du Sanctuaire, tiens-la en dehors, ne la mesure pas, car elle a été donnée aux nations : elles fouleront aux pieds la Ville sainte pendant quarante-deux mois.
###### 03
Et je donnerai à mes deux témoins de prophétiser, vêtus de toile à sac, pendant mille deux cent soixante jours. »
###### 04
Ce sont eux les deux oliviers, les deux chandeliers, qui se tiennent devant le Seigneur de la terre.
###### 05
Si quelqu’un veut leur faire du mal, un feu jaillit de leur bouche et dévore leurs ennemis ; oui, celui qui voudra leur faire du mal, c’est ainsi qu’il doit mourir.
###### 06
Ces deux témoins ont le pouvoir de fermer le ciel, pour que la pluie ne tombe pas pendant les jours de leur prophétie. Ils ont aussi le pouvoir de changer l’eau en sang et de frapper la terre de toutes sortes de fléaux, aussi souvent qu’ils le voudront.
###### 07
Mais, quand ils auront achevé leur témoignage, la Bête qui monte de l’abîme leur fera la guerre, les vaincra et les fera mourir.
###### 08
Leurs cadavres restent sur la place de la grande ville, qu’on appelle, au sens figuré, Sodome et l’Égypte, là où leur Seigneur aussi a été crucifié.
###### 09
De tous les peuples, tribus, langues et nations, on vient regarder leurs cadavres pendant trois jours et demi, sans qu’il soit permis de les mettre au tombeau.
###### 10
Les habitants de la terre s’en réjouissent, ils sont dans la joie, ils échangent des présents ; ces deux prophètes, en effet, avaient causé bien du tourment aux habitants de la terre.
###### 11
Mais, après ces trois jours et demi, un souffle de vie venu de Dieu entra en eux : ils se dressèrent sur leurs pieds, et une grande crainte tomba sur ceux qui les regardaient.
###### 12
Alors les deux témoins entendirent une voix forte venant du ciel, qui leur disait : « Montez jusqu’ici ! » Et ils montèrent au ciel dans la nuée, sous le regard de leurs ennemis.
###### 13
Et à cette heure-là, il y eut un grand tremblement de terre : le dixième de la ville s’écroula, et dans le tremblement de terre sept mille personnes furent tuées. Les survivants furent saisis de crainte et rendirent gloire au Dieu du ciel.
###### 14
Le deuxième « Malheur ! » est passé ; voici que le troisième « Malheur ! » vient sans tarder.
###### 15
Le septième ange sonna de la trompette. Il y eut dans le ciel des voix fortes qui disaient :
« Il est advenu sur le monde,
le règne de notre Seigneur et de son Christ.
C’est un règne pour les siècles des siècles. »
###### 16
Et les vingt-quatre Anciens qui siègent sur leurs trônes en présence de Dieu, se jetant face contre terre, se prosternèrent devant Dieu
###### 17
en disant :
« À toi, nous rendons grâce,
Seigneur Dieu, Souverain de l’univers,
toi qui es, toi qui étais !
Tu as saisi ta grande puissance
et pris possession de ton règne.
###### 18
Les nations s’étaient mises en colère ;
alors, ta colère est venue
et le temps du jugement pour les morts,
le temps de récompenser tes serviteurs,
les prophètes et les saints,
ceux qui craignent ton nom,
les petits et les grands,
le temps de détruire
ceux qui détruisent la terre. »
###### 19
Le sanctuaire de Dieu, qui est dans le ciel, s’ouvrit, et l’arche de son Alliance apparut dans le Sanctuaire ; et il y eut des éclairs, des fracas, des coups de tonnerre, un tremblement de terre et une forte grêle.
