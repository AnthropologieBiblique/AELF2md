---
aliases : 
- Apocalypse 4
- Apocalypse 4
- Ap 4
- Revelation 4
tags : 
- Bible/Ap/4
- français
cssclass : français
---

# Apocalypse 4

###### 01
Après cela, j’ai vu : et voici qu’il y avait une porte ouverte dans le ciel. Et la voix que j’avais entendue, pareille au son d’une trompette, me parlait en disant : « Monte jusqu’ici, et je te ferai voir ce qui doit ensuite advenir. »
###### 02
Aussitôt je fus saisi en esprit. Voici qu’un trône était là dans le ciel, et sur le Trône siégeait quelqu’un.
###### 03
Celui qui siège a l’aspect d’une pierre de jaspe ou de cornaline ; il y a, tout autour du Trône, un halo de lumière, avec des reflets d’émeraude.
###### 04
Tout autour de ce Trône, vingt-quatre trônes, où siègent vingt-quatre Anciens portant des vêtements blancs et, sur leurs têtes, des couronnes d’or.
###### 05
Et du Trône sortent des éclairs, des fracas, des coups de tonnerre, et sept torches enflammées brûlent devant le Trône : ce sont les sept esprits de Dieu.
###### 06
Devant le Trône, il y a comme une mer, aussi transparente que du cristal. Au milieu, autour du Trône, quatre Vivants, ayant des yeux innombrables en avant et en arrière.
###### 07
Le premier Vivant ressemble à un lion, le deuxième Vivant ressemble à un jeune taureau, le troisième Vivant a comme un visage d’homme, le quatrième Vivant ressemble à un aigle en plein vol.
###### 08
Les quatre Vivants ont chacun six ailes, avec des yeux innombrables tout autour et au-dedans. Jour et nuit, ils ne cessent de dire :
« Saint ! Saint ! Saint, le Seigneur Dieu,
le Souverain de l’univers,
Celui qui était, qui est et qui vient. »
###### 09
Lorsque les Vivants rendent gloire, honneur et action de grâce à celui qui siège sur le Trône, lui qui vit pour les siècles des siècles,
###### 10
les vingt-quatre Anciens se jettent devant Celui qui siège sur le Trône, ils se prosternent face à celui qui vit pour les siècles des siècles ; ils lancent leur couronne devant le Trône en disant :
###### 11
« Tu es digne, Seigneur notre Dieu,
de recevoir
la gloire, l’honneur et la puissance.
C’est toi qui créas l’univers ;
tu as voulu qu’il soit :
il fut créé. »
