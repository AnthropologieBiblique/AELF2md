---
aliases : 
- Apocalypse 1
- Apocalypse 1
- Ap 1
- Revelation 1
tags : 
- Bible/Ap/1
- français
cssclass : français
---

# Apocalypse 1

###### 01
REVELATION DE JESUS CHRIST, que Dieu lui a confiée pour montrer à ses serviteurs ce qui doit bientôt advenir ; cette révélation, il l’a fait connaître à son serviteur Jean par l’envoi de son ange.
###### 02
Jean atteste comme parole de Dieu et témoignage de Jésus Christ tout ce qu’il a vu.
###### 03
Heureux celui qui lit, heureux ceux qui écoutent les paroles de la prophétie et gardent ce qui est écrit en elle, car le temps est proche.
###### 04
Jean, aux sept Églises qui sont en Asie mineure : à vous, la grâce et la paix, de la part de Celui qui est, qui était et qui vient, de la part des sept esprits qui sont devant son trône,
###### 05
de la part de Jésus Christ, le témoin fidèle, le premier-né des morts, le prince des rois de la terre. À lui qui nous aime, qui nous a délivrés de nos péchés par son sang,
###### 06
qui a fait de nous un royaume et des prêtres pour son Dieu et Père, à lui, la gloire et la souveraineté pour les siècles des siècles. Amen.
###### 07
Voici qu’il vient avec les nuées, tout œil le verra,
ils le verront, ceux qui l’ont transpercé ;
et sur lui se lamenteront toutes les tribus de la terre.
Oui ! Amen !
###### 08
Moi, je suis l’Alpha et l’Oméga, dit le Seigneur Dieu, Celui qui est, qui était et qui vient, le Souverain de l’univers.
###### 09
Moi, Jean, votre frère, partageant avec vous la détresse, la royauté et la persévérance en Jésus, je me trouvai dans l’île de Patmos à cause de la parole de Dieu et du témoignage de Jésus.
###### 10
Je fus saisi en esprit, le jour du Seigneur, et j’entendis derrière moi une voix forte, pareille au son d’une trompette.
###### 11
Elle disait : « Ce que tu vois, écris-le dans un livre et envoie-le aux sept Églises : à Éphèse, Smyrne, Pergame, Thyatire, Sardes, Philadelphie et Laodicée. »
###### 12
Je me retournai pour regarder quelle était cette voix qui me parlait. M’étant retourné, j’ai vu sept chandeliers d’or,
###### 13
et au milieu des chandeliers un être qui semblait un Fils d’homme, revêtu d’une longue tunique, une ceinture d’or à hauteur de poitrine ;
###### 14
sa tête et ses cheveux étaient blancs comme la laine blanche, comme la neige, et ses yeux comme une flamme ardente ;
###### 15
ses pieds semblaient d’un bronze précieux affiné au creuset, et sa voix était comme la voix des grandes eaux ;
###### 16
il avait dans la main droite sept étoiles ; de sa bouche sortait un glaive acéré à deux tranchants. Son visage brillait comme brille le soleil dans sa puissance.
###### 17
Quand je le vis, je tombai à ses pieds comme mort, mais il posa sur moi sa main droite, en disant :
« Ne crains pas. Moi, je suis le Premier et le Dernier,
###### 18
le Vivant : j’étais mort, et me voilà vivant pour les siècles des siècles ; je détiens les clés de la mort et du séjour des morts.
###### 19
Écris donc ce que tu as vu, ce qui est, ce qui va ensuite advenir.
###### 20
Quant au mystère des sept étoiles que tu as vues sur ma main droite, et celui des sept chandeliers d’or : les sept étoiles sont les anges des sept Églises, et les sept chandeliers sont les sept Églises. »
