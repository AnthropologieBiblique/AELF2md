---
aliases : 
- Apocalypse 5
- Apocalypse 5
- Ap 5
- Revelation 5
tags : 
- Bible/Ap/5
- français
cssclass : français
---

# Apocalypse 5

###### 01
J’ai vu, dans la main droite de celui qui siège sur le Trône, un livre en forme de rouleau, écrit au-dedans et à l’extérieur, scellé de sept sceaux.
###### 02
Puis j’ai vu un ange plein de force, qui proclamait d’une voix puissante : « Qui donc est digne d’ouvrir le Livre et d’en briser les sceaux ? »
###### 03
Mais personne, au ciel, sur terre ou sous la terre, ne pouvait ouvrir le Livre et regarder.
###### 04
Je pleurais beaucoup, parce que personne n’avait été trouvé digne d’ouvrir le Livre et de regarder.
###### 05
Mais l’un des Anciens me dit : « Ne pleure pas. Voilà qu’il a remporté la victoire, le lion de la tribu de Juda, le rejeton de David : il ouvrira le Livre aux sept sceaux. »
###### 06
Et j’ai vu, entre le Trône, les quatre Vivants et les Anciens, un Agneau debout, comme égorgé ; ses cornes étaient au nombre de sept, ainsi que ses yeux, qui sont les sept esprits de Dieu envoyés sur toute la terre.
###### 07
Il s’avança et prit le Livre dans la main droite de celui qui siégeait sur le Trône.
###### 08
Quand l’Agneau eut pris le Livre, les quatre Vivants et les vingt-quatre Anciens se jetèrent à ses pieds. Ils tenaient chacun une cithare et des coupes d’or pleines de parfums qui sont les prières des saints.
###### 09
Ils chantaient ce cantique nouveau :
« Tu es digne, de prendre le Livre
et d’en ouvrir les sceaux,
car tu fus immolé,
rachetant pour Dieu, par ton sang,
des gens de toute tribu,
langue, peuple et nation.
###### 10
Pour notre Dieu, tu en as fait
un royaume et des prêtres :
ils régneront sur la terre. »
###### 11
Alors j’ai vu : et j’entendis la voix d’une multitude d’anges qui entouraient le Trône, les Vivants et les Anciens ; ils étaient des myriades de myriades, par milliers de milliers.
###### 12
Ils disaient d’une voix forte :
« Il est digne, l’Agneau immolé,
de recevoir puissance et richesse,
sagesse et force,
honneur, gloire et louange. »
###### 13
Toute créature dans le ciel et sur la terre, sous la terre et sur la mer, et tous les êtres qui s’y trouvent, je les entendis proclamer :
« À celui qui siège sur le Trône, et à l’Agneau,
la louange et l’honneur,
la gloire et la souveraineté
pour les siècles des siècles. »
###### 14
Et les quatre Vivants disaient : « Amen ! » ; et les Anciens, se jetant devant le Trône, se prosternèrent.
