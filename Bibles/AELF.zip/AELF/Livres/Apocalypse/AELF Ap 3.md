---
aliases : 
- Apocalypse 3
- Apocalypse 3
- Ap 3
- Revelation 3
tags : 
- Bible/Ap/3
- français
cssclass : français
---

# Apocalypse 3

###### 01
À l’ange de l’Église qui est à Sardes, écris :
Ainsi parle celui qui a les sept esprits de Dieu et les sept étoiles : Je connais ta conduite, je sais que ton nom est celui d’un vivant, mais tu es mort.
###### 02
Sois vigilant, raffermis ce qui te reste et qui allait mourir, car je n’ai pas trouvé que tes actes soient parfaits devant mon Dieu.
###### 03
Eh bien, rappelle-toi ce que tu as reçu et entendu, garde-le et convertis-toi. Si tu ne veilles pas, je viendrai comme un voleur et tu ne pourras savoir à quelle heure je viendrai te surprendre.
###### 04
À Sardes, pourtant, tu en as qui n’ont pas sali leurs vêtements ; habillés de blanc, ils marcheront avec moi, car ils en sont dignes.
###### 05
Ainsi, le vainqueur portera des vêtements blancs ; jamais je n’effacerai son nom du livre de la vie ; son nom, je le proclamerai devant mon Père et devant ses anges.
###### 06
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises.
###### 07
À l’ange de l’Église qui est à Philadelphie, écris :
Ainsi parle le Saint, le Vrai, celui qui détient la clé de David, celui qui ouvre – et nul ne fermera –, celui qui ferme – et nul ne peut ouvrir.
###### 08
Je connais ta conduite ; voici que j’ai mis devant toi une porte ouverte que nul ne peut fermer, car, sans avoir beaucoup de puissance, tu as gardé ma parole et tu n’as pas renié mon nom.
###### 09
Voici que je vais te donner des gens de la synagogue de Satan, qui se disent Juifs et ne le sont pas : ils mentent. Voici ce que je leur ferai : ils viendront, ils se prosterneront à tes pieds ; alors ils connaîtront que moi, je t’ai aimé.
###### 10
Puisque tu as gardé mon appel à persévérer, moi aussi je te garderai de l’heure de l’épreuve qui va venir sur le monde entier pour éprouver les habitants de la terre.
###### 11
Je viens sans tarder : tiens fermement ce que tu as, pour que personne ne prenne ta couronne.
###### 12
Du vainqueur, je ferai une colonne au sanctuaire de mon Dieu ; il n’aura plus jamais à en sortir, et je graverai sur lui le nom de mon Dieu et le nom de la ville de mon Dieu, la Jérusalem nouvelle qui descend du ciel d’auprès de mon Dieu, ainsi que mon nom nouveau.
###### 13
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises.
###### 14
À l’ange de l’Église qui est à Laodicée, écris :
Ainsi parle celui qui est l’Amen, le témoin fidèle et vrai, le principe de la création de Dieu :
###### 15
Je connais tes actions, je sais que tu n’es ni froid ni brûlant – mieux vaudrait que tu sois ou froid ou brûlant.
###### 16
Aussi, puisque tu es tiède – ni brûlant ni froid – je vais te vomir de ma bouche.
###### 17
Tu dis : « Je suis riche, je me suis enrichi, je ne manque de rien », et tu ne sais pas que tu es malheureux, pitoyable, pauvre, aveugle et nu !
###### 18
Alors, je te le conseille : achète chez moi, pour t’enrichir, de l’or purifié au feu, des vêtements blancs pour te couvrir et ne pas laisser paraître la honte de ta nudité, un remède pour l’appliquer sur tes yeux afin que tu voies.
###### 19
Moi, tous ceux que j’aime, je leur montre leurs fautes, et je les corrige. Eh bien, sois fervent et convertis-toi.
###### 20
Voici que je me tiens à la porte, et je frappe. Si quelqu’un entend ma voix et ouvre la porte, j’entrerai chez lui ; je prendrai mon repas avec lui, et lui avec moi.
###### 21
Le vainqueur, je lui donnerai de siéger avec moi sur mon Trône, comme moi-même, après ma victoire, j’ai siégé avec mon Père sur son Trône.
###### 22
Celui qui a des oreilles, qu’il entende ce que l’Esprit dit aux Églises.
