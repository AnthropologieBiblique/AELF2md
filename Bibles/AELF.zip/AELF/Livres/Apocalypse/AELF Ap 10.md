---
aliases : 
- Apocalypse 10
- Apocalypse 10
- Ap 10
- Revelation 10
tags : 
- Bible/Ap/10
- français
cssclass : français
---

# Apocalypse 10

###### 01
Et j’ai vu un autre ange, plein de force, descendre du ciel, ayant une nuée pour manteau, et sur la tête un halo de lumière ; son visage était comme le soleil, et ses jambes comme des colonnes de feu.
###### 02
Il tenait à la main un petit livre ouvert. Il posa le pied droit sur la mer, et le gauche sur la terre ;
###### 03
il cria d’une voix forte, comme un lion qui rugit. Et quand il cria, les sept tonnerres parlèrent, faisant résonner leur voix.
###### 04
Et quand les sept tonnerres eurent parlé, j’allais me mettre à écrire ; mais j’entendis une voix venant du ciel qui disait : « Ce que viennent de dire les sept tonnerres, garde-le scellé, ne l’écris pas ! »
###### 05
Et l’ange que j’avais vu debout sur la mer et sur la terre leva la main droite vers le ciel ;
###### 06
il fit un serment par celui qui est vivant pour les siècles des siècles, celui qui a créé le ciel et tout ce qu’il contient, la terre et tout ce qu’elle contient, la mer et tout ce qu’elle contient. Il déclara : « Du temps, il n’y en aura plus !
###### 07
Dans les jours où retentira la voix du septième ange, quand il sonnera de la trompette, alors se trouvera accompli le mystère de Dieu, selon la bonne nouvelle qu’il a annoncée à ses serviteurs les prophètes. »
###### 08
Et la voix que j’avais entendue, venant du ciel, me parla de nouveau et me dit : « Va prendre le livre ouvert dans la main de l’ange qui se tient debout sur la mer et sur la terre. »
###### 09
Je m’avançai vers l’ange pour lui demander de me donner le petit livre. Il me dit : « Prends, et dévore-le ; il remplira tes entrailles d’amertume, mais dans ta bouche il sera doux comme le miel. »
###### 10
Je pris le petit livre de la main de l’ange, et je le dévorai. Dans ma bouche il était doux comme le miel, mais, quand je l’eus mangé, il remplit mes entrailles d’amertume.
###### 11
Alors on me dit : « Il te faut de nouveau prophétiser sur un grand nombre de peuples, de nations, de langues et de rois. »
