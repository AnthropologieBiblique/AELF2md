---
aliases : 
- Apocalypse 22
- Apocalypse 22
- Ap 22
- Revelation 22
tags : 
- Bible/Ap/22
- français
cssclass : français
---

# Apocalypse 22

###### 01
Puis l’ange me montra l’eau de la vie : un fleuve resplendissant comme du cristal, qui jaillit du trône de Dieu et de l’Agneau.
###### 02
Au milieu de la place de la ville, entre les deux bras du fleuve, il y a un arbre de vie qui donne des fruits douze fois : chaque mois il produit son fruit ; et les feuilles de cet arbre sont un remède pour les nations.
###### 03
Toute malédiction aura disparu. Le trône de Dieu et de l’Agneau sera dans la ville, et les serviteurs de Dieu lui rendront un culte ;
###### 04
ils verront sa face, et son nom sera sur leur front.
###### 05
La nuit aura disparu, ils n’auront plus besoin de la lumière d’une lampe ni de la lumière du soleil, parce que le Seigneur Dieu les illuminera ; ils régneront pour les siècles des siècles.
###### 06
Puis l’ange me dit : « Ces paroles sont dignes de foi et vraies : le Seigneur, le Dieu qui inspire les prophètes, a envoyé son ange pour montrer à ses serviteurs ce qui doit bientôt advenir.
###### 07
Voici que je viens sans tarder. Heureux celui qui garde les paroles de ce livre de prophétie. »
###### 08
C’est moi, Jean, qui entendais et voyais ces choses. Et après avoir entendu et vu, je me jetai aux pieds de l’ange qui me montrait cela, pour me prosterner devant lui.
###### 09
Il me dit : « Non, ne fais pas cela ! Je suis un serviteur comme toi, comme tes frères les prophètes et ceux qui gardent les paroles de ce livre. Prosterne-toi devant Dieu ! »
###### 10
Puis il me dit : « Ne mets pas les scellés sur les paroles de ce livre de prophétie. Le temps est proche, en effet.
###### 11
Que celui qui fait le mal fasse encore le mal, et que l’homme sali se salisse encore ; que le juste pratique encore la justice, et que le saint se sanctifie encore.
###### 12
Voici que je viens sans tarder, et j’apporte avec moi le salaire que je vais donner à chacun selon ce qu’il a fait.
###### 13
Moi, je suis l’alpha et l’oméga, le premier et le dernier, le commencement et la fin.
###### 14
Heureux ceux qui lavent leurs vêtements : ils auront droit d’accès à l’arbre de la vie et, par les portes, ils entreront dans la ville.
###### 15
Dehors les chiens, les sorciers, les débauchés, les meurtriers, les idolâtres, et tous ceux qui aiment et pratiquent le mensonge !
###### 16
Moi, Jésus, j’ai envoyé mon ange vous apporter ce témoignage au sujet des Églises. Moi, je suis le rejeton, le descendant de David, l’étoile resplendissante du matin. »
###### 17
L’Esprit et l’Épouse disent : « Viens ! » Celui qui entend, qu’il dise : « Viens ! » Celui qui a soif, qu’il vienne. Celui qui le désire, qu’il reçoive l’eau de la vie, gratuitement.
###### 18
Et moi, devant tout homme qui écoute les paroles de ce livre de prophétie, je l’atteste : si quelqu’un y fait des surcharges, Dieu le chargera des fléaux qui sont décrits dans ce livre ;
###### 19
et si quelqu’un enlève des paroles à ce livre de prophétie, Dieu lui enlèvera sa part : il n’aura plus accès à l’arbre de la vie ni à la Ville sainte, qui sont décrits dans ce livre.
###### 20
Et celui qui donne ce témoignage déclare : « Oui, je viens sans tarder. » – Amen ! Viens, Seigneur Jésus !
###### 21
Que la grâce du Seigneur Jésus soit avec tous !
