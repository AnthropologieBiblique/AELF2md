---
aliases : 
- Apocalypse 8
- Apocalypse 8
- Ap 8
- Revelation 8
tags : 
- Bible/Ap/8
- français
cssclass : français
---

# Apocalypse 8

###### 01
Quand il ouvrit le septième sceau, il y eut dans le ciel un silence d’environ une demi-heure.
###### 02
Et j’ai vu les sept anges qui se tiennent devant Dieu : il leur fut donné sept trompettes.
###### 03
Un autre ange vint se placer près de l’autel ; il portait un encensoir d’or ; il lui fut donné quantité de parfums pour les offrir, avec les prières de tous les saints, sur l’autel d’or qui est devant le Trône.
###### 04
Et par la main de l’ange monta devant Dieu la fumée des parfums, avec les prières des saints.
###### 05
Puis l’ange prit l’encensoir et le remplit du feu de l’autel ; il le jeta sur la terre : il y eut des coups de tonnerre, des fracas, des éclairs et un tremblement de terre.
###### 06
Puis les sept anges qui avaient les sept trompettes se préparèrent à en sonner.
###### 07
Le premier sonna de la trompette : il y eut de la grêle et du feu mêlés de sang, qui furent jetés sur la terre, et le tiers de la terre brûla, le tiers des arbres brûlèrent, toute l’herbe verte brûla.
###### 08
Le deuxième ange sonna de la trompette : dans la mer fut jetée comme une grande montagne embrasée, et le tiers de la mer fut changé en sang ;
###### 09
dans la mer, le tiers des créatures vivantes mourut, et le tiers des bateaux fut détruit.
###### 10
Le troisième ange sonna de la trompette : du ciel tomba une grande étoile qui flambait comme une torche ; elle tomba sur le tiers des fleuves et sur les sources des eaux.
###### 11
L’étoile se nomme « Absinthe », et le tiers des eaux devint de l’absinthe : beaucoup de gens moururent à cause des eaux devenues amères.
###### 12
Le quatrième ange sonna de la trompette : le tiers du soleil fut frappé, et le tiers de la lune et le tiers des étoiles ; ainsi chacun d’entre eux fut obscurci d’un tiers, le jour perdit le tiers de sa clarté et, de même, la nuit.
###### 13
Alors j’ai vu : et j’entendis un aigle qui volait en plein ciel, disant d’une voix forte : « Malheur ! Malheur ! Malheur pour ceux qui habitent la terre, car la trompette, encore, doit retentir quand les trois anges sonneront ! »
