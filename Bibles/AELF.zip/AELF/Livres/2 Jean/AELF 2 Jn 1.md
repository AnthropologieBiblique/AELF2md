---
aliases : 
- 2 Jean 1
- 2 Jean 1
- 2 Jn 1
- 2 John 1
tags : 
- Bible/2Jn/1
- français
cssclass : français
---

# 2 Jean 1

###### 01
MOI, L’ANCIEN, à la Dame élue de Dieu, et à ses enfants, que j’aime en vérité – non pas moi seul, mais tous ceux qui connaissent la vérité –,
###### 02
à cause de la vérité qui demeure en nous et qui sera avec nous pour toujours.
###### 03
Avec nous seront la grâce, la miséricorde, la paix, de la part de Dieu le Père et de Jésus Christ, le Fils du Père, dans la vérité et dans l’amour.
###### 04
J’ai eu beaucoup de joie à trouver plusieurs de tes enfants qui marchent dans la vérité selon le commandement que nous avons reçu du Père.
###### 05
Et maintenant, Dame élue, je t’adresse une demande : aimons-nous les uns les autres. – Ce que je t’écris là n’est pas un commandement nouveau, nous l’avions depuis le commencement.
###### 06
Or l’amour, c’est que nous marchions selon ses commandements. Tel est le commandement selon lequel vous devez marcher, comme, depuis le commencement, vous l’avez appris.
###### 07
Beaucoup d’imposteurs se sont répandus dans le monde, ils refusent de proclamer que Jésus Christ est venu dans la chair ; celui qui agit ainsi est l’imposteur et l’anti-Christ.
###### 08
Prenez garde à vous-mêmes, pour ne pas perdre le fruit de notre travail, mais pour recevoir intégralement votre salaire.
###### 09
Quiconque va trop loin et ne se tient pas à l’enseignement du Christ, celui-là se sépare de Dieu. Mais celui qui se tient à cet enseignement, celui-là reste attaché au Père et au Fils.
###### 10
Si quelqu’un vient chez vous sans apporter cet enseignement, ne le recevez pas dans votre maison et ne lui adressez pas votre salutation,
###### 11
car celui qui le salue participe à ses œuvres mauvaises.
###### 12
J’ai bien des choses à vous écrire ; je n’ai pas voulu le faire avec du papier et de l’encre, mais j’espère me rendre chez vous et vous parler de vive voix, pour que notre joie soit parfaite.
###### 13
Les enfants de ta sœur, la communauté élue de Dieu, te saluent.
