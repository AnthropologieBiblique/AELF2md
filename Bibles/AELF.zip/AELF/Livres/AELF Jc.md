---
aliases : 
- Jacques
- Jacques
- Jc
- James
tags : 
- Bible/Jc
- français
cssclass : français
---

# Jacques

[[AELF Jc 1|Jacques 1]]
[[AELF Jc 2|Jacques 2]]
[[AELF Jc 3|Jacques 3]]
[[AELF Jc 4|Jacques 4]]
[[AELF Jc 5|Jacques 5]]
