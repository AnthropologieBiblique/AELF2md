---
aliases : 
- Galates
- Galates
- Ga
- Galatians
tags : 
- Bible/Ga
- français
cssclass : français
---

# Galates

[[AELF Ga 1|Galates 1]]
[[AELF Ga 2|Galates 2]]
[[AELF Ga 3|Galates 3]]
[[AELF Ga 4|Galates 4]]
[[AELF Ga 5|Galates 5]]
[[AELF Ga 6|Galates 6]]
