---
aliases : 
- Proverbes 18
- Proverbes 18
- Pr 18
- Proverbs 18
tags : 
- Bible/Pr/18
- français
cssclass : français
---

# Proverbes 18

###### 01
Qui reste en marge n’en fait qu’à sa tête ;
tout bon conseil l’exaspère.
###### 02
L’insensé n’a pas envie de réfléchir,
mais seulement d’étaler ses idées.
###### 03
Quand arrive le méchant, arrive aussi le mépris ;
avec les affronts, le déshonneur.
###### 04
Une eau profonde, les paroles de l’homme !
Torrent jaillissant, la source de la sagesse !
###### 05
Inadmissible de réhabiliter un coupable
en privant le juste de son droit !
###### 06
L’insensé a sur les lèvres la contestation ;
sa bouche incite à en venir aux coups.
###### 07
Les propos de l’insensé font sa ruine,
ses lèvres lui sont un piège.
###### 08
Les mots du calomniateur, quel régal !
On s’en délecte jusqu’au plus profond.
###### 09
Celui qui se relâche dans son travail
et celui qui le sabote sont frères !
###### 10
Le nom du Seigneur est une tour fortifiée ;
le juste y court : hors d’atteinte !
###### 11
La fortune du riche est sa citadelle :
il y voit son rempart.
###### 12
Avant la chute, le cœur s’exalte ;
avant la gloire, il s’humilie.
###### 13
Rétorquer avant d’écouter :
sottise et confusion !
###### 14
Un bon moral rétablit le malade ;
un moral au plus bas, qui le relèvera ?
###### 15
Un cœur intelligent veut acquérir la connaissance,
l’oreille des sages la recherche.
###### 16
Des cadeaux ouvrent les portes,
ils introduisent chez les grands.
###### 17
Qui plaide en premier semble avoir raison ;
vienne la partie adverse, elle contestera.
###### 18
Le tirage au sort met fin à la querelle,
il départage même les puissants.
###### 19
Un frère offensé se ferme plus qu’une forteresse :
la querelle bloque comme le verrou d’une citadelle.
###### 20
Chacun, du fruit de sa bouche, tire profit,
du produit de ses lèvres il se rassasie.
###### 21
La mort et la vie sont au pouvoir de la langue ;
qui aime la parole mangera de son fruit.
###### 22
Il trouve le bonheur celui qui trouve femme :
c’est une bienveillance du Seigneur.
###### 23
Aux supplications du pauvre
le riche répond durement.
###### 24
Il y a des relations qui tournent mal,
mais il y a l’ami plus attaché qu’un frère.
