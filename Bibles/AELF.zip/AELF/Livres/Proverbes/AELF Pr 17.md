---
aliases : 
- Proverbes 17
- Proverbes 17
- Pr 17
- Proverbs 17
tags : 
- Bible/Pr/17
- français
cssclass : français
---

# Proverbes 17

###### 01
Mieux vaut du pain sec, et la paix,
qu’une salle de banquet pleine de discorde.
###### 02
Un serviteur avisé supplantera le fils indigne ;
avec les frères il aura part à l’héritage.
###### 03
Comme le creuset pour l’argent, et le fourneau pour l’or,
le Seigneur éprouve les cœurs.
###### 04
Le malfaiteur s’intéresse à qui parle de fraude,
le menteur tend l’oreille aux propos pernicieux.
###### 05
Qui se moque d’un pauvre insulte Dieu qui l’a fait,
qui se réjouit du malheur ne restera pas impuni.
###### 06
Couronne des vieillards, leurs petits-enfants !
Fierté des fils, leur père !
###### 07
L’abruti n’a que faire d’un langage distingué,
et moins encore, un prince, du langage menteur.
###### 08
Les pots-de-vin portent chance, aux yeux du donateur :
où qu’il aille, tout lui sourit !
###### 09
Qui cherche l’amitié ignore l’offense ;
qui revient sur l’affaire divise les amis.
###### 10
Un reproche fait plus d’effet à l’homme intelligent
que cent coups de bâton à l’insensé !
###### 11
Au révolté qui n’aspire qu’au mal,
on dépêche un émissaire sans pitié.
###### 12
Plutôt tomber sur une ourse privée de ses petits
que sur un insensé en plein délire !
###### 13
Qui rend le mal pour le bien
voit le mal ne plus quitter sa maison.
###### 14
Début de querelle, torrent qui déferle :
avant d’en venir au procès, renonce !
###### 15
Justifier le coupable, donner tort à l’innocent :
deux choses dont le Seigneur a horreur !
###### 16
À quoi bon de l’argent dans la main d’un insensé ?
Pour acheter la sagesse ? Il n’a rien dans la tête !
###### 17
On a des amis en tout temps,
mais un frère est là pour le temps de la détresse.
###### 18
C’est un écervelé, l’homme qui dit « Marché conclu ! »
et se porte caution pour un proche.
###### 19
Qui aime la querelle aime le péché !
La folie des grandeurs entraîne la chute !
###### 20
Un esprit retors ne trouve pas le bonheur ;
qui a la langue perfide tombe dans le malheur.
###### 21
Engendrer un insensé, quelle tristesse !
Le père d’un imbécile n’est pas à la fête.
###### 22
À cœur joyeux, santé florissante !
L’esprit chagrin dessèche jusqu’à l’os.
###### 23
Le méchant accepte un pot-de-vin sous le manteau
pour entraver le cours de la justice.
###### 24
L’homme intelligent a devant lui la sagesse ;
l’insensé la cherche des yeux au bout du monde.
###### 25
Un fils insensé ne fait qu’irriter son père,
et désole sa mère.
###### 26
Punir un innocent est inadmissible ;
frapper des gens de bien n’est pas correct !
###### 27
Qui sait tenir sa langue a du discernement ;
qui garde son sang-froid est homme de réflexion.
###### 28
S’il se tait, même un sot passe pour sage ;
bien malin, celui qui ne dit mot !
