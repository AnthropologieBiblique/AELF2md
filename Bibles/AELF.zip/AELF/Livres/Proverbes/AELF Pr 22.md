---
aliases : 
- Proverbes 22
- Proverbes 22
- Pr 22
- Proverbs 22
tags : 
- Bible/Pr/22
- français
cssclass : français
---

# Proverbes 22

###### 01
Plus désirable un nom qu’une grande richesse,
plus que l’or et l’argent, la faveur !
###### 02
Un riche et un pauvre se rencontrent :
l’un comme l’autre, le Seigneur les a faits.
###### 03
Bien avisé qui voit le malheur et se met à l’abri ;
l’étourdi passe outre, il le paiera.
###### 04
Fruit de l’humilité : la crainte du Seigneur,
et la richesse, et la gloire, et la vie !
###### 05
Épines et embûches sur le chemin du pervers :
qui tient à la vie s’en écarte.
###### 06
Éduque un jeune à mesure de son développement :
jamais il ne déviera, même l’âge venu.
###### 07
Le riche a pouvoir sur les pauvres :
le débiteur sera l’esclave de son créancier.
###### 08
Qui sème la fraude récolte le malheur :
le fléau de sa frénésie lui sera fatal.
###### 09
Qui a bon cœur sera béni :
il partage son pain avec le faible.
###### 10
Chasse l’insolent, la querelle s’en va,
affronts et procès prennent fin.
###### 11
Qui s’attache à purifier son cœur a des paroles aimables,
le roi est son ami.
###### 12
Les yeux du Seigneur veillent sur le savoir,
mais il réduit à rien les propos trompeurs.
###### 13
Le paresseux dit : « Un lion dehors !
Si je sors, je suis mort ! »
###### 14
Gouffre profond, la bouche de la femme d’un autre,
y tombent ceux que réprouve le Seigneur !
###### 15
La folie s’agrippe au cœur d’un jeune :
le bâton de la correction lui fait lâcher prise.
###### 16
Qui opprime le faible le rend fort,
qui donne au riche se rend pauvre !
###### 17
Tends l’oreille, écoute les paroles des sages,
que ton cœur s’attache à mon savoir :
###### 18
tu prendras plaisir à garder en toi ces paroles,
toutes prêtes à venir sur tes lèvres.
###### 19
Pour que ta confiance soit dans le Seigneur,
je vais t’instruire aujourd’hui, toi aussi.
###### 20
N’ai-je pas écrit pour toi trente chapitres
pleins de conseils et de science,
###### 21
afin que tu reconnaisses la parole vraie,
que tu fasses un rapport sûr à celui qui t’envoie ?
###### 22
Ne profite pas de la faiblesse du faible,
n’écrase pas le pauvre au tribunal,
###### 23
car le Seigneur plaidera leur cause,
il ravira la vie de leurs ravisseurs.
###### 24
Ne fréquente pas le coléreux,
n’approche pas l’homme irascible ;
###### 25
sinon, tu prendras leurs manières,
tu seras pris au piège.
###### 26
Ne sois pas de ceux qui disent : « Marché conclu ! »
et se portent caution pour un emprunt :
###### 27
si tu n’as pas de quoi rembourser,
pourquoi risquer la saisie du lit où tu dors ?
###### 28
Ne déplace pas une borne ancienne :
ce sont tes ancêtres qui l’ont posée.
###### 29
As-tu vu un homme habile à l’ouvrage ?
C’est au service des rois qu’il a sa place,
il ne l’a pas auprès des gens obscurs.
