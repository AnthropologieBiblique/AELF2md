---
aliases : 
- Proverbes 12
- Proverbes 12
- Pr 12
- Proverbs 12
tags : 
- Bible/Pr/12
- français
cssclass : français
---

# Proverbes 12

###### 01
Qui aime la discipline est ami du savoir,
qui déteste la critique est un abruti.
###### 02
L’homme de bien gagne la faveur divine ;
le Seigneur condamne le rusé.
###### 03
Nul ne trouve appui dans la méchanceté,
la racine des justes tient ferme.
###### 04
Une femme parfaite est la couronne de son mari,
une femme sans pudeur, le cancer de ses os.
###### 05
Les projets du juste sont droits,
les manœuvres du méchant, des tromperies.
###### 06
Les paroles des méchants sont embûches meurtrières ;
la bouche des honnêtes gens les en garde.
###### 07
Bouscule les méchants : ils disparaissent !
La maison des justes tient bon.
###### 08
On loue quelqu’un pour son bon sens ;
l’esprit tordu mérite le mépris.
###### 09
Mieux vaut être méprisé, mais avoir un serviteur,
que faire l’important et manquer de pain !
###### 10
Le juste connaît les besoins de ses bêtes ;
le méchant n’a que cruauté à la place du cœur !
###### 11
Qui travaille sa terre aura du pain à satiété,
qui poursuit des chimères est un écervelé.
###### 12
Le méchant convoite des proies misérables,
la racine du juste donnera du fruit.
###### 13
Des lèvres criminelles sont un piège dangereux,
mais le juste échappe à son étreinte.
###### 14
Chacun, du fruit de sa bouche, peut tirer grand bien,
comme chacun recueille le salaire de ses mains.
###### 15
Le chemin de l’insensé paraît droit à ses yeux,
mais un sage accepte le conseil.
###### 16
L’insensé manifeste, sur l’heure, son dépit ;
bien avisé qui reste sourd à l’injure !
###### 17
Le témoin véridique manifeste ce qui est juste ;
le faux témoin ne cesse de tromper.
###### 18
Les bavards, c’est comme des coups d’épée,
mais la langue des sages guérit.
###### 19
Parole vraie subsiste à jamais,
propos menteur, le temps d’un clin d’œil !
###### 20
Déception pour le cœur de ceux qui trament le mal,
joie pour les conseillers de paix !
###### 21
Aucun malheur ne frappe le juste,
mais les méchants sont comblés de maux.
###### 22
Le Seigneur a horreur des lèvres menteuses ;
qui agit loyalement lui plaît.
###### 23
L’homme avisé ne montre pas sa science
mais le cœur de l’insensé crie sa folie.
###### 24
La main active aura le pouvoir,
le paresseux aura les corvées !
###### 25
Un souci dans le cœur déprime,
une bonne parole ramène la joie.
###### 26
Le juste montre la voie à son ami,
le chemin des méchants les égare.
###### 27
Point de gibier à rôtir chez les fainéants ;
le bien le plus précieux de l’homme est son activité.
###### 28
Sur le sentier de la justice, la vie !
Qui prend ce chemin ne mourra pas.
