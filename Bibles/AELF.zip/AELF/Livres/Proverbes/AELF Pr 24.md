---
aliases : 
- Proverbes 24
- Proverbes 24
- Pr 24
- Proverbs 24
tags : 
- Bible/Pr/24
- français
cssclass : français
---

# Proverbes 24

###### 01
N’envie pas les méchants,
ne rêve pas d’être avec eux,
###### 02
car ils n’ont dans le cœur que violence
et sur les lèvres, des paroles menaçantes.
###### 03
Avec la sagesse on se bâtit une maison,
avec l’intelligence on la rend solide,
###### 04
avec du savoir-faire on remplit les pièces
de mille biens précieux et beaux.
###### 05
Au sage appartient la force,
celui qui a l’expérience augmente son pouvoir.
###### 06
C’est en bon stratège que tu dois mener la guerre :
élargis ton conseil et tu réussiras !
###### 07
La sagesse vole trop haut pour le fou :
au conseil de la cité, il ne dit mot.
###### 08
Qui fait le mal avec préméditation
mérite le nom de roi des rusés.
###### 09
Le fou n’a de ruse que pour le péché ;
l’insolent, les gens l’ont en horreur.
###### 10
Tu faiblis aux jours difficiles ?
Difficile de croire à ta force !
###### 11
Sauve les condamnés à mort,
fais grâce à ceux qu’on traîne au supplice.
###### 12
Tu oses dire : « Eh oui, nous ne savions pas. »
Mais Celui qui pèse les cœurs, ne comprend-il pas ?
Celui qui observe ton âme, il sait, lui ;
il rendra à chacun selon ses actes.
###### 13
Mange du miel, mon fils, c’est très bon,
un vrai nectar, douceur pour ton palais !
###### 14
Ainsi en sera-t-il pour ton âme, si tu goûtes à la sagesse :
si tu la trouves, tu auras un avenir,
tu n’auras pas espéré en vain.
###### 15
Ne guette pas le domaine du juste,
ne ravage pas sa propriété.
###### 16
Car le juste tombe sept fois mais se relève,
alors que les méchants s’effondrent dans le malheur.
###### 17
Si ton ennemi tombe, ne te réjouis pas ;
s’il s’effondre, ne jubile pas :
###### 18
le Seigneur verrait cela d’un mauvais œil
et détournerait de lui sa colère !
###### 19
Ne t’indigne pas à la vue des malfaiteurs,
ne jalouse pas les méchants,
###### 20
car le mauvais n’a pas d’avenir :
la lampe des méchants s’éteindra.
###### 21
Crains le Seigneur, mon fils, et aussi le roi,
ne fréquente pas le contestataire,
###### 22
car soudain surgira son désastre ;
l’échec que les deux lui réservent, qui le sait ?
###### 23
Voici encore ce que disent les Sages :
Être partial dans un jugement, ce n’est jamais bon !
###### 24
Quiconque dit au coupable : « Tu es innocent »
sera vilipendé par la foule, honni par les nations.
###### 25
Mais à ceux qui sanctionnent, on saura gré ;
sur eux viendra une heureuse bénédiction.
###### 26
Il donne un vrai baiser,
celui qui répond franchement.
###### 27
Assure au-dehors ton travail,
mène-le à bien dans ton champ ;
ensuite, tu construiras ta maison.
###### 28
Ne charge pas sans preuve ton prochain :
tes lèvres seraient-elles trompeuses ?
###### 29
Ne dis pas : « Il me l’a fait, je le lui ferai :
je rendrai à chacun selon ses actes ! »
###### 30
Je suis passé près du champ d’un paresseux,
près de la vigne d’un homme écervelé.
###### 31
Voici que des broussailles avaient poussé partout,
le sol était couvert de ronces,
la murette en pierres était par terre.
###### 32
Voyant cela, moi, je réfléchis ;
je regarde et j’en tire une leçon :
###### 33
un somme par-ci, une sieste par-là,
s’allonger un moment, se croiser les bras,
###### 34
et voilà que survient la pauvreté qui rôdait,
la misère, comme un garde bien armé.
