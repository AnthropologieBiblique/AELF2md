---
aliases : 
- Proverbes 8
- Proverbes 8
- Pr 8
- Proverbs 8
tags : 
- Bible/Pr/8
- français
cssclass : français
---

# Proverbes 8

###### 01
N’est-ce pas la Sagesse qui appelle,
la raison qui élève sa voix ?
###### 02
En haut de la montée, sur la route,
postée à la jonction des chemins,
###### 03
près des portes, aux abords de la cité,
à l’entrée des passages, elle clame :
###### 04
« C’est vous, les humains, que j’appelle,
ma voix s’adresse aux fils d’Adam :
###### 05
vous, les naïfs, devenez habiles,
vous, les insensés, devenez raisonnables.
###### 06
Écoutez-bien, mon discours est capital,
j’ouvre mes lèvres pour dire la droiture.
###### 07
Oui, c’est la vérité que je ne cesse d’annoncer,
mes lèvres ont la malice en horreur.
###### 08
Les paroles de ma bouche ne sont que justice ;
en elles, rien d’oblique ni de retors :
###### 09
toutes sont claires pour qui a l’intelligence,
et droites pour qui a trouvé la connaissance.
###### 10
Choisissez mes leçons et non pas l’argent,
la connaissance plutôt que l’or fin.
###### 11
– La sagesse vaut mieux que les perles :
rien ne l’égale.
###### 12
Moi, la Sagesse, j’habite avec l’habileté,
j’ai appris à connaître bien des finesses.
###### 13
– La crainte du Seigneur, c’est la haine du mal.
Je hais l’orgueil, l’arrogance,
le chemin du mal et la bouche perverse.
###### 14
À moi le conseil et l’efficacité ;
c’est moi l’intelligence, à moi la vigueur !
###### 15
Par moi, les rois agissent en rois
et les souverains édictent ce qui est juste,
###### 16
par moi, les princes agissent en princes :
tous les chefs ont autorité dans le pays.
###### 17
Moi, j’aime ceux qui m’aiment,
ceux qui me recherchent me trouvent.
###### 18
Avec moi, la richesse et la gloire,
fortune durable et juste prospérité.
###### 19
Mon fruit est meilleur que l’or, que l’or fin,
ce qui vient de moi, meilleur qu’un argent purifié.
###### 20
Sur le chemin de la justice je m’avance,
sur le sentier du droit.
###### 21
Je donne un bel héritage à ceux qui m’aiment,
je remplis leurs trésors.
###### 22
Le Seigneur m’a faite pour lui,
principe de son action,
première de ses œuvres, depuis toujours.
###### 23
Avant les siècles j’ai été formée,
dès le commencement, avant l’apparition de la terre.
###### 24
Quand les abîmes n’existaient pas encore, je fus enfantée,
quand n’étaient pas les sources jaillissantes.
###### 25
Avant que les montagnes ne soient fixées,
avant les collines, je fus enfantée,
###### 26
avant que le Seigneur n’ait fait la terre et l’espace,
les éléments primitifs du monde.
###### 27
Quand il établissait les cieux, j’étais là,
quand il traçait l’horizon à la surface de l’abîme,
###### 28
qu’il amassait les nuages dans les hauteurs
et maîtrisait les sources de l’abîme,
###### 29
quand il imposait à la mer ses limites,
si bien que les eaux ne peuvent enfreindre son ordre,
quand il établissait les fondements de la terre.
###### 30
Et moi, je grandissais à ses côtés.
Je faisais ses délices jour après jour,
jouant devant lui à tout moment,
###### 31
jouant dans l’univers, sur sa terre,
et trouvant mes délices avec les fils des hommes.
###### 32
Et maintenant, fils, écoutez-moi.
Heureux ceux qui gardent mes chemins !
###### 33
Écoutez l’instruction et devenez sages,
ne la négligez pas.
###### 34
Heureux l’homme qui m’écoute,
qui veille à ma porte jour après jour,
qui monte la garde devant chez moi.
###### 35
Qui me trouve a trouvé la vie,
c’est une bienveillance du Seigneur.
###### 36
Qui m’offense se fait tort à lui-même :
me haïr, c’est aimer la mort ! »
