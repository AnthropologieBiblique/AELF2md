---
aliases : 
- Proverbes 1
- Proverbes 1
- Pr 1
- Proverbs 1
tags : 
- Bible/Pr/1
- français
cssclass : français
---

# Proverbes 1

###### 01
PROVERBES de Salomon, fils de David, roi d’Israël.
###### 02
Veux-tu connaître la sagesse et l’instruction,
avoir l’intelligence des propos intelligents,
###### 03
veux-tu acquérir une instruction éclairée,
– la justice, le jugement, la droiture –,
###### 04
veux-tu rendre astucieux les naïfs,
donner aux jeunes gens savoir et perspicacité ?
###### 05
Que le sage écoute, il progressera encore,
et l’homme intelligent apprendra à diriger :
###### 06
il saisira les proverbes et les traits d’esprit,
les propos des sages et leurs énigmes.
###### 07
Le savoir commence avec la crainte du Seigneur !
Sagesse et instruction, l’insensé les méprise.
###### 08
Écoute, mon fils, les leçons de ton père,
ne néglige pas l’enseignement de ta mère :
###### 09
c’est comme une couronne de grâce sur ta tête,
un collier à ton cou.
###### 10
Mon fils, si des mauvais garçons veulent t’entraîner,
ne les suis pas !
###### 11
Ils vont te dire : « Marche avec nous,
nous allons faire un coup sanglant,
traquer un innocent, pour voir !
###### 12
Nous allons, comme la Mort, le dévorer vif,
tout entier, pareil à ceux qui descendent à la fosse ;
###### 13
nous trouverons le magot,
un vrai butin à remplir nos maisons !
###### 14
Tente ta chance avec nous,
nous ferons tous bourse commune ! »
###### 15
Eh bien, mon fils, ne marche pas avec eux,
ne mets pas les pieds sur leurs sentiers !
###### 16
Car ils vont au mal d’un pied rapide,
ils ont hâte de verser le sang.
###### 17
– Rien ne sert de tendre un filet, dit-on,
si l’oiseau le voit.
###### 18
Eux, c’est contre eux-mêmes qu’ils montent ce coup sanglant :
ils traquent leur propre vie.
###### 19
Telle est la voie que briguent les brigands :
elle leur coûtera la vie.
###### 20
La Sagesse, au-dehors, lance un appel ;
sur les places, elle élève sa voix ;
###### 21
au-dessus du tumulte, elle crie ;
à l’entrée des portes de la ville, elle tient ce discours :
###### 22
« Combien de temps encore, étourdis,
allez-vous aimer l’étourderie ?
– Les insolents n’aspirent qu’à l’insolence,
et les insensés refusent la connaissance !
###### 23
Tournerez-vous longtemps le dos quand je critique ?
Contre vous, je laisserai libre cours à mon humeur,
je vous ferai savoir ce que j’ai à vous dire.
###### 24
Quand j’ai appelé, vous avez rechigné,
quand j’ai tendu la main, nul ne s’en est soucié !
###### 25
Vous avez récusé tous mes conseils,
vous n’avez pris à cœur aucune de mes critiques.
###### 26
Eh bien, moi aussi, lors de votre malheur, je rirai,
je serai sarcastique quand viendra l’épouvante,
###### 27
quand elle viendra comme une tourmente,
et que le malheur sera là, comme une tornade,
quand viendront sur vous la détresse et l’angoisse.
###### 28
Alors on m’appellera et je ne répondrai pas,
on me cherchera et ne me trouvera pas,
###### 29
car ils ont refusé la connaissance
et n’ont pas choisi la crainte du Seigneur.
###### 30
Ils n’ont pas pris à cœur mes conseils,
ils ont dénigré chacune de mes critiques :
###### 31
alors, ils dégusteront les fruits de leur conduite,
ils pourront se gaver de leurs intrigues.
###### 32
Oui, l’indocilité des étourdis leur sera fatale,
et l’insouciance des insensés les perdra.
###### 33
Celui qui m’écoute demeure en sécurité,
à l’abri, sans malheur à redouter. »
