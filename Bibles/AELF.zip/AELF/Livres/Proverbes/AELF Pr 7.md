---
aliases : 
- Proverbes 7
- Proverbes 7
- Pr 7
- Proverbs 7
tags : 
- Bible/Pr/7
- français
cssclass : français
---

# Proverbes 7

###### 01
Mon fils, garde mes paroles,
conserve précieusement mes préceptes ;
###### 02
garde mes préceptes et tu vivras,
garde mon enseignement comme la prunelle de tes yeux ;
###### 03
attache-les à tes doigts,
inscris-les sur la tablette de ton cœur.
###### 04
Dis à la sagesse : « Tu es ma sœur ! » ;
à l’intelligence, donne le nom de « familière ».
###### 05
Alors tu seras gardé de la femme d’un autre,
de l’étrangère aux propos enjôleurs.
###### 06
Comme j’étais à la fenêtre, chez moi,
je regardais à travers la claire-voie ;
###### 07
je vis quelques étourdis
et, parmi ces garçons, je remarquai un jeune écervelé :
###### 08
il passait par la venelle, près d’un recoin,
il filait vers une maison,
###### 09
le soir venu, à la tombée du jour,
s’enfonçant dans les ténèbres de la nuit.
###### 10
Et voici qu’une femme s’en va vers lui
avec des allures de prostituée aux aguets ;
###### 11
elle trépigne, provocante,
incapable de rester à la maison ;
###### 12
un pas dans la ruelle, deux pas sur la place,
elle guette à tous les coins de rue.
###### 13
Elle l’attrape et l’embrasse
et, d’un air effronté, lui déclare :
###### 14
« Je dois offrir un sacrifice de paix,
et aujourd’hui, je viens accomplir mon vœu ;
###### 15
aussi, je suis sortie pour te rencontrer,
je cherchais à te voir et je t’ai trouvé !
###### 16
J’ai paré mon lit de couvertures,
d’un tissu d’Égypte multicolore ;
###### 17
et sur ma couche, j’ai répandu la myrrhe,
l’aloès et le cinnamome.
###### 18
Viens ! Que l’amour nous enivre jusqu’au matin,
prenons du plaisir à nous aimer !
###### 19
Tu sais, mon mari n’est pas chez lui,
il est en voyage au loin ;
###### 20
il a emporté l’argent de la bourse,
il ne rentrera qu’à la pleine lune. »
###### 21
Avec tout son talent, elle le séduit
et, de ses lèvres enjôleuses, elle l’entraîne.
###### 22
Soudain le voilà qui la suit,
comme le bœuf qu’on mène à l’abattoir,
comme l’insensé qui gambade avant d’être châtié,
###### 23
jusqu’à ce qu’une flèche lui ait crevé le foie.
Ainsi l’oiseau se jette dans le filet,
sans savoir qu’il y va de sa vie.
###### 24
Et maintenant, fils, écoute-moi,
fais attention à mes propos :
###### 25
ne laisse pas ton cœur se détourner vers ses chemins,
ne t’égare pas sur ses sentiers,
###### 26
car nombreux sont ceux qu’elle a blessés à mort,
innombrables, tous ceux qu’elle a tués.
###### 27
Sa maison, c’est le chemin du séjour des morts,
la descente aux enfers.
