---
aliases : 
- Proverbes 21
- Proverbes 21
- Pr 21
- Proverbs 21
tags : 
- Bible/Pr/21
- français
cssclass : français
---

# Proverbes 21

###### 01
Le Seigneur dispose du cœur du roi
comme d’un canal d’irrigation,
il le dirige où il veut.
###### 02
La conduite d’un homme est toujours droite à ses yeux,
mais c’est le Seigneur qui pèse les cœurs.
###### 03
Accomplir la justice et le droit
plaît au Seigneur plus que le sacrifice.
###### 04
Regarder de haut, se rengorger :
ainsi brillent les méchants, mais ce n’est que péché.
###### 05
Les plans de l’homme actif lui assurent du profit ;
mais la précipitation conduit à l’indigence.
###### 06
Une fortune acquise par le mensonge :
illusion fugitive de qui cherche la mort.
###### 07
Les méchants seront victimes de leur violence,
car ils refusent d’agir selon le droit.
###### 08
Les méthodes de l’imposteur sont tortueuses ;
un homme honnête agit droitement.
###### 09
Mieux vaut loger dans un coin de terrasse
que partager sa maison avec une mégère.
###### 10
Le méchant ne désire que le mal ;
il n’a pas un regard de pitié pour son prochain.
###### 11
Quand on punit l’insolent, l’étourdi devient sage ;
le sage, il suffit de le raisonner pour qu’il comprenne.
###### 12
Le juste considère le clan du méchant :
le méchant pervertit les autres pour leur malheur.
###### 13
Qui fait la sourde oreille à la clameur des faibles
criera lui-même sans obtenir de réponse.
###### 14
On apaise une colère par un présent discret,
la fureur violente par un cadeau sous le manteau.
###### 15
L’exercice du droit est une joie pour le juste ;
c’est la terreur des malfaisants.
###### 16
L’homme qui erre loin des voies de la raison
ira reposer parmi les Ombres.
###### 17
Qui aime faire la fête sera sans le sou,
qui aime le vin et les parfums ne fera pas fortune.
###### 18
Le méchant paiera pour le juste,
et le fourbe, à la place des honnêtes gens.
###### 19
Mieux vaut aller vivre au désert
qu’avec une mégère acariâtre !
###### 20
Dans la demeure du sage, abondance et trésor désirable ;
l’insensé n’en fait qu’une bouchée !
###### 21
Qui poursuit justice et fidélité
trouvera la vie et la gloire !
###### 22
Le sage a pris d’assaut une ville de héros,
il en a rasé la citadelle, son lieu sûr.
###### 23
Qui garde sa bouche et sa langue
se garde lui-même de bien des angoisses.
###### 24
L’orgueilleux, le prétentieux, a pour nom : « l’Insolent » !
Il n’agit que dans l’orgueil et l’excès.
###### 25
Les désirs du paresseux le tuent,
car ses mains refusent de passer à l’acte.
###### 26
Au long du jour, il va de désir en désir,
tandis que le juste donne sans compter.
###### 27
Le sacrifice des méchants est une horreur,
d’autant plus qu’ils le font dans un esprit perfide.
###### 28
Le faux témoin périra ;
seul peut parler l’homme qui a entendu.
###### 29
Le méchant prend un air assuré ;
l’homme droit, lui, avance de pied ferme.
###### 30
Point de sagesse, point de raison,
point de projet qui tienne en face du Seigneur !
###### 31
On équipe son cheval pour le jour du combat,
mais c’est le Seigneur qui détient la victoire.
