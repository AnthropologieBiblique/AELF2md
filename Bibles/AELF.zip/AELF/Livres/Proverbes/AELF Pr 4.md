---
aliases : 
- Proverbes 4
- Proverbes 4
- Pr 4
- Proverbs 4
tags : 
- Bible/Pr/4
- français
cssclass : français
---

# Proverbes 4

###### 01
Fils, écoutez les leçons d’un père,
soyez attentifs et vous connaîtrez l’intelligence.
###### 02
Oui, c’est une valeur sûre que je vous transmets,
ne négligez pas mon enseignement !
###### 03
Moi aussi, j’ai été un fils pour mon père,
enfant chéri, unique aux yeux de ma mère.
###### 04
Voilà comment il m’instruisait :
« Que ton cœur reçoive mes paroles,
garde mes préceptes et tu vivras ;
###### 05
acquiers la sagesse, acquiers l’intelligence,
n’oublie pas, ne te détourne pas de ce que dit ma bouche ;
###### 06
la sagesse, ne l’abandonne pas, elle te gardera,
aime-la, elle veillera sur toi. »
###### 07
Ainsi commence la sagesse : elle s’acquiert !
Cède tout ce que tu as pour acquérir l’intelligence.
###### 08
Ouvre-lui la voie, elle t’élèvera ;
si tu l’embrasses, elle fera ta gloire.
###### 09
Elle posera sur ta tête un diadème de grâce,
elle te couronnera de splendeur.
###### 10
Écoute, mon fils, accueille mes paroles,
les années de ta vie en seront augmentées.
###### 11
Je te conduis par un chemin de sagesse,
je te fais cheminer par des sentiers de droiture.
###### 12
Nulle entrave à ta marche :
si tu cours, tu ne trébucheras pas.
###### 13
Tiens-toi à la discipline, ne te relâche pas,
veille sur elle : elle est ta vie.
###### 14
Sur la route des méchants, ne t’engage pas ;
ne t’avance pas sur le chemin des malfaiteurs :
###### 15
évite-le, n’y passe pas,
détourne-toi de lui, passe au-delà !
###### 16
Car ils ne dorment pas qu’ils n’aient commis le mal ;
le sommeil les fuit tant qu’ils n’ont fait chuter personne.
###### 17
C’est de méchanceté qu’ils se nourrissent ;
d’un vin de violence ils s’abreuvent.
###### 18
La route des justes est lumière d’aurore,
sa clarté s’accroît jusqu’au grand jour.
###### 19
Le chemin des méchants, c’est la ténèbre :
ils trébuchent sans savoir sur quoi.
###### 20
Mon fils, sois attentif à mes paroles,
prête l’oreille à mes propos ;
###### 21
ne les perds pas de vue,
garde-les au profond de ton cœur :
###### 22
pour qui les trouve, ils sont la vie,
la guérison de son être de chair.
###### 23
Par-dessus tout, veille sur ton cœur,
c’est de lui que jaillit la vie.
###### 24
Éloigne de ta bouche les propos retors,
écarte la perfidie de tes lèvres.
###### 25
Sache regarder en face,
dirige tes yeux droit devant toi !
###### 26
Aplanis la piste sous tes pieds :
tous tes chemins seront sûrs.
###### 27
Ne dévie ni à droite ni à gauche ;
du mal, écarte ton pied !
