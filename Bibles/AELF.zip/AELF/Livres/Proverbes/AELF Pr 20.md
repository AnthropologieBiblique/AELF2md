---
aliases : 
- Proverbes 20
- Proverbes 20
- Pr 20
- Proverbs 20
tags : 
- Bible/Pr/20
- français
cssclass : français
---

# Proverbes 20

###### 01
Le vin provoque, une boisson forte perturbe :
quiconque s’y aventure perd toute raison.
###### 02
Rugissement d’un lion, la menace du roi :
qui se fâche avec lui risque sa vie.
###### 03
Gloire à l’homme qui évite un procès !
Tous les insensés s’y précipitent !
###### 04
En automne, le paresseux ne laboure pas ;
au temps de la moisson, il cherche… et il n’y a rien !
###### 05
Les projets du cœur sont une eau profonde,
l’homme raisonnable y puisera.
###### 06
Tout un chacun proteste de sa bonne foi,
mais un homme de confiance, qui le trouvera ?
###### 07
Le juste marche droit :
heureux ses enfants après lui !
###### 08
Au tribunal, quand le roi préside,
d’un regard, il dissipe le mal !
###### 09
Qui peut dire : « J’ai purifié mon cœur,
maintenant, je suis sans péché » ?
###### 10
Deux poids, deux mesures :
le Seigneur en a horreur !
###### 11
On jugera d’un jeune à sa façon de faire :
travaille-t-il proprement, selon les règles ?
###### 12
L’oreille qui entend, l’œil qui voit :
le Seigneur les a faits l’un et l’autre.
###### 13
Ne prends pas le goût du sommeil, tu deviendrais pauvre ;
tiens les yeux ouverts, tu seras rassasié.
###### 14
« Mauvais ! Mauvais ! » dit l’acheteur,
mais, tournant les talons, il se frotte les mains !
###### 15
De l’or, il y en a ; des pierres précieuses, il n’en manque pas ;
mais la parole intelligente, c’est perle rare !
###### 16
Quelqu’un s’est-il porté garant pour un tiers, saisis son manteau ;
s’il l’a fait pour des étrangers, prends-lui un gage !
###### 17
Il est délicieux, le pain de la fraude,
mais après, la bouche en reste pleine de gravier !
###### 18
Avec des projets bien concertés, te voilà sûr ;
mène la guerre en bon stratège !
###### 19
Qui colporte des cancans trahira le secret :
ne fréquente pas les bavards !
###### 20
Qui maudit père et mère,
sa lampe s’éteindra au cœur de la nuit !
###### 21
Une fortune acquise en toute hâte
finira par te porter malheur !
###### 22
Ne dis pas : « Je rendrai le mal qu’on m’a fait ! » ;
compte sur le Seigneur, il te sauvera !
###### 23
Tricher sur le poids, le Seigneur en a horreur :
rien de bon dans une balance truquée !
###### 24
C’est le Seigneur qui dirige les pas de l’homme :
un mortel, comment saurait-il où il va ?
###### 25
Voici un piège : dire à la légère : « C’est sacré »,
et n’y réfléchir qu’après s’être engagé !
###### 26
Le roi sage disperse au vent les méchants :
il a traîné sur eux la roue du battage.
###### 27
C’est une lampe divine, l’esprit de l’homme ;
il explore le tréfonds de son être.
###### 28
Fidélité, loyauté forment la garde du roi,
la fidélité affermira son trône !
###### 29
La beauté de la jeunesse, c’est sa vigueur ;
la parure des anciens, leurs cheveux blancs !
###### 30
Faire saigner la plaie prévient l’infection ;
ainsi la correction guérit en profondeur !
