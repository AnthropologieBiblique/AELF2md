---
aliases : 
- Proverbes 28
- Proverbes 28
- Pr 28
- Proverbs 28
tags : 
- Bible/Pr/28
- français
cssclass : français
---

# Proverbes 28

###### 01
Le coupable s’enfuit quand nul ne le poursuit,
les innocents ont l’assurance des lions.
###### 02
Quand le pays se révolte, les chefs sont légion ;
vienne un homme de bon sens et d’expérience, l’ordre règne.
###### 03
Un homme pauvre qui exploite les faibles,
c’est le déluge : plus rien à manger !
###### 04
Ceux qui rejettent la loi font l’éloge du méchant,
ceux qui observent la loi leur font la guerre.
###### 05
La racaille ne comprend rien au droit ;
qui cherche le Seigneur comprendra tout !
###### 06
Mieux vaut un pauvre à la conduite intègre
qu’un homme tortueux et louvoyant, même riche !
###### 07
Qui garde la loi est un fils intelligent ;
qui s’encanaille fait la honte de son père.
###### 08
Qui accroît son bien par usure et intérêts
amasse pour qui aura pitié des faibles.
###### 09
Qui fait la sourde oreille à la loi,
sa prière n’inspirera que dégoût.
###### 10
Qui égare les gens honnêtes sur la voie du mal
tombera lui-même dans son piège ;
les gens intègres hériteront le bonheur.
###### 11
Il se prend pour un sage, l’homme riche,
mais un faible, perspicace, le démasque !
###### 12
Le triomphe des justes, on le fête avec éclat ;
que surgissent des méchants : plus personne !
###### 13
Qui cache ses fautes ne réussira pas ;
qui les avoue et s’en détourne obtiendra miséricorde.
###### 14
Heureux l’homme qui reste vulnérable !
Qui endurcit son cœur tombera dans le malheur !
###### 15
Un lion qui rugit, un ours qui charge,
ainsi le criminel qui domine un peuple faible !
###### 16
Moins le prince est malin, plus il est rapace !
Qui renonce à ses intérêts verra de longs jours.
###### 17
Un homme traqué par le sang qu’il a versé
fuira jusqu’à la tombe : n’allez pas le retenir !
###### 18
Qui marche droit sera sauvé ;
qui louvoie entre deux routes sur l’une des deux tombera !
###### 19
Qui travaille sa terre aura du pain à satiété ;
qui poursuit des chimères aura de la misère à satiété !
###### 20
Un homme de confiance est comblé de bénédictions.
Courir après la fortune n’a rien d’innocent.
###### 21
Être partial dans un jugement n’est jamais bon ;
pour une bouchée de pain, un homme s’en rend coupable.
###### 22
L’envieux louche sur la fortune
sans voir que l’indigence s’abat sur lui !
###### 23
On finit par aimer l’homme qui ose critiquer
bien plus que l’homme à la langue mielleuse !
###### 24
Qui met son père et sa mère sur la paille
en disant : « Ce n’est pas ma faute ! »
n’est rien d’autre qu’un brigand.
###### 25
Qui donne libre cours à ses envies provoque des querelles,
qui se fie au Seigneur sera comblé !
###### 26
Ne se fier qu’à soi-même, c’est folie !
Seul le chemin de la sagesse permet d’en réchapper.
###### 27
Qui donne au pauvre ne manquera de rien ;
qui détourne les yeux sera chargé de malédictions.
###### 28
Quand surgissent les méchants, on se cache ;
quand ils périssent, nombreux sont les justes !
