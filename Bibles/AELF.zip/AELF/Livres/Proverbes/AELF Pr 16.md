---
aliases : 
- Proverbes 16
- Proverbes 16
- Pr 16
- Proverbs 16
tags : 
- Bible/Pr/16
- français
cssclass : français
---

# Proverbes 16

###### 01
Dans son cœur, l’homme propose ;
par sa parole, Dieu dispose.
###### 02
Chacun trouve sa conduite pure,
mais le Seigneur pèse les esprits.
###### 03
Remets ton action au Seigneur,
et tes projets réussiront.
###### 04
Le Seigneur a tout fait selon son dessein,
même le méchant, pour les jours de malheur.
###### 05
Le Seigneur a horreur des prétentieux :
promis, juré, ils ne resteront pas impunis.
###### 06
Fidélité et loyauté effacent une faute,
la crainte du Seigneur détourne du mal.
###### 07
Quand le Seigneur apprécie la conduite de l’homme,
il lui concilie même ses ennemis.
###### 08
Mieux vaut peu dans la justice
que de grands profits hors du droit !
###### 09
L’homme, en son cœur, fait des projets de route,
et le Seigneur dirige ses pas.
###### 10
Sentence sur les lèvres du roi :
quand il juge, sa bouche est infaillible.
###### 11
Une balance juste plaît au Seigneur,
chacun des poids est son œuvre.
###### 12
Les rois ont le mal en horreur,
car la justice affermit le trône.
###### 13
Des lèvres justes ont la faveur du roi,
il aime celui qui parle avec droiture.
###### 14
La fureur du roi est messagère de mort,
mais un sage saura l’apaiser.
###### 15
La lumière sur le visage du roi donne la vie,
sa faveur est comme une pluie de printemps.
###### 16
Mieux vaut acquérir la sagesse que l’or,
et l’intelligence plutôt que l’argent.
###### 17
La route des hommes droits se détourne du mal ;
qui surveille son chemin garde sa vie.
###### 18
L’orgueil précède l’effondrement,
et la prétention, la chute.
###### 19
Mieux vaut être humble parmi des gens modestes,
que partager un butin avec des orgueilleux.
###### 20
Un homme avisé trouvera le bonheur ;
qui se fie au Seigneur est plus heureux encore !
###### 21
La sagesse du cœur, on l’appelle intelligence ;
la douceur des paroles aide à apprendre.
###### 22
Le bon sens, pour qui le possède, est source de vie,
mais les fous n’enseignent que folie.
###### 23
Le sage, en son cœur, affine ses propos,
et sa parole aide à apprendre.
###### 24
Les paroles aimables sont un rayon de miel :
douces au palais, elles redonnent des forces.
###### 25
Il y a un chemin qui semble droit,
mais au terme, ce sont des chemins de mort.
###### 26
L’estomac du travailleur l’oblige à travailler,
c’est la faim qui le presse !
###### 27
Le vaurien prépare un mauvais coup :
sur ses lèvres, c’est comme un feu dévorant.
###### 28
Un pervers sème la discorde,
le calomniateur divise les amis.
###### 29
Un violent entraîne son compagnon
et lui fait prendre le mauvais chemin.
###### 30
S’il ferme les yeux, c’est qu’il médite un coup pervers ;
s’il serre les lèvres, le mal est fait !
###### 31
Les cheveux blancs sont une couronne splendide :
on la trouve sur les chemins de la justice.
###### 32
L’homme patient vaut mieux que le héros :
mieux vaut maîtriser son humeur que prendre une ville.
###### 33
On tire au sort avec un dé,
mais le Seigneur décide de tout.
