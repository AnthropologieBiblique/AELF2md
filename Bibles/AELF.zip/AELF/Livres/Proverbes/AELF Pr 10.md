---
aliases : 
- Proverbes 10
- Proverbes 10
- Pr 10
- Proverbs 10
tags : 
- Bible/Pr/10
- français
cssclass : français
---

# Proverbes 10

###### 01
Proverbes de Salomon.
Le fils sage fait la joie de son père,
le fils insensé désole sa mère.
###### 02
Bien mal acquis ne profite jamais :
c’est la justice qui délivre de la mort.
###### 03
Le Seigneur ne laisse pas le juste mourir de faim,
il rejette l’avidité des méchants.
###### 04
Main nonchalante appauvrit,
main diligente enrichit.
###### 05
Qui récolte en été est quelqu’un d’avisé,
qui dort à la moisson est digne de mépris.
###### 06
Bénédictions sur la tête du juste !
La bouche du méchant dissimule sa violence.
###### 07
On se souvient du juste pour le bénir,
mais le renom des méchants se flétrit.
###### 08
Un cœur sage accepte des règles ;
un sot bavard court à sa perte.
###### 09
Qui marche droit marche en sécurité,
qui louvoie sur son chemin sera démasqué.
###### 10
Qui fait des clins d’œil provoque des troubles,
qui reproche avec franchise fait œuvre de paix.
###### 11
La bouche du juste est source de vie,
la bouche du méchant dissimule sa violence.
###### 12
La haine suscite des querelles,
l’amour couvre toutes les offenses.
###### 13
Sur les lèvres intelligentes se trouve la sagesse,
et le bâton, sur le dos de l’écervelé !
###### 14
Les sages gardent leur savoir comme un trésor,
mais la bouche du sot, c’est le désastre imminent.
###### 15
La fortune du riche est sa citadelle ;
la misère, la terreur des faibles.
###### 16
Le salaire du juste lui sert à vivre ;
les gains du méchant ne servent qu’à pécher !
###### 17
Qui retient une leçon devient chemin de vie ;
qui néglige les avertissements fourvoie.
###### 18
Qui a le mensonge aux lèvres dissimule sa haine ;
qui propage la calomnie est un insensé.
###### 19
À trop parler on n’évite pas le péché :
qui tient sa langue est bien avisé.
###### 20
Argent de bon aloi, la langue du juste !
Le cœur des méchants n’a guère de valeur.
###### 21
Les propos des justes nourrissent la multitude,
mais les sots meurent d’avoir l’esprit borné.
###### 22
La bénédiction du Seigneur enrichit,
et l’effort de l’homme n’y ajoute rien.
###### 23
Le plaisir de l’insensé : commettre des horreurs ;
celui de l’homme réfléchi : la sagesse.
###### 24
Ce que redoute le méchant lui échoit,
ce que désirent les justes leur est accordé.
###### 25
Que passe une tempête, et le méchant n’est plus ;
le juste reste inébranlable.
###### 26
Vinaigre sur les dents, fumée dans les yeux,
tel est le paresseux pour ceux qui l’emploient !
###### 27
La crainte du Seigneur accroît les jours,
les années des méchants sont comptées.
###### 28
L’espérance des justes est joie ;
pour les méchants, tout espoir est perdu.
###### 29
Le chemin du Seigneur est un lieu sûr pour l’homme intègre
et un désastre pour ceux qui font le mal !
###### 30
Jamais le juste ne sera ébranlé ;
les méchants n’habiteront pas le pays.
###### 31
La bouche du juste a pour fruit la sagesse,
la langue perverse sera coupée.
###### 32
Les lèvres du juste savent être bienveillantes,
les méchants n’ont que perversité à la bouche.
