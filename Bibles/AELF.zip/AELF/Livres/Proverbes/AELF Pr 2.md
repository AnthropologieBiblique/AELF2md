---
aliases : 
- Proverbes 2
- Proverbes 2
- Pr 2
- Proverbs 2
tags : 
- Bible/Pr/2
- français
cssclass : français
---

# Proverbes 2

###### 01
Mon fils, accueille mes paroles,
conserve précieusement mes préceptes,
###### 02
l’oreille attentive à la sagesse,
le cœur incliné vers la raison.
###### 03
Oui, si tu fais appel à l’intelligence,
si tu invoques la raison,
###### 04
si tu la recherches comme l’argent,
si tu creuses comme un chercheur de trésor,
###### 05
alors tu comprendras la crainte du Seigneur,
tu découvriras la connaissance de Dieu.
###### 06
Car c’est le Seigneur qui donne la sagesse ;
connaissance et raison sortent de sa bouche.
###### 07
Il réserve aux hommes droits la réussite :
pour qui marche dans l’intégrité, il est un bouclier,
###### 08
gardien des sentiers du droit,
veillant sur le chemin de ses fidèles.
###### 09
Alors tu comprendras la justice, le jugement, la droiture,
seuls sentiers qui mènent au bonheur.
###### 10
Car la sagesse viendra dans ton cœur,
la connaissance fera tes délices,
###### 11
la perspicacité te gardera,
la raison veillera sur toi.
###### 12
Tu seras préservé des chemins du mal,
de l’homme aux propos pervers,
###### 13
de ceux qui délaissent la route droite
pour aller sur les chemins de ténèbre :
###### 14
ils prennent plaisir à faire le mal,
ils se complaisent dans la pire des perversités ;
###### 15
leurs routes sont tortueuses,
ils ne font que dévier sur leurs pistes.
###### 16
Tu seras préservé de la femme d’un autre,
l’étrangère aux paroles enjôleuses,
###### 17
celle qui a délaissé l’ami de sa jeunesse,
oublié l’alliance de son Dieu.
###### 18
Sa maison incline vers la mort,
ses détours mènent aux Ombres ;
###### 19
quiconque va chez elle n’en reviendra jamais,
il n’atteindra jamais la route de la vie.
###### 20
C’est pourquoi il te faut prendre le bon chemin,
garder la route des justes :
###### 21
les hommes droits habiteront le pays,
les gens intègres y resteront,
###### 22
mais les méchants seront extirpés du pays,
les fourbes en seront arrachés.
