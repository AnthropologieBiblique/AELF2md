---
aliases : 
- Proverbes 14
- Proverbes 14
- Pr 14
- Proverbs 14
tags : 
- Bible/Pr/14
- français
cssclass : français
---

# Proverbes 14

###### 01
Sagesse de femme bâtit sa maison ;
Folie la détruit de sa propre main.
###### 02
Qui craint le Seigneur marche avec droiture,
qui dévie en ses chemins le méprise.
###### 03
Sur la bouche de l’insensé pointe l’orgueil,
les lèvres des sages s’en garderont.
###### 04
Nulle bête de trait : la mangeoire est vide ;
les récoltes sont belles quand le taureau est fort.
###### 05
Un témoin véridique ne ment pas ;
le faux témoin ment comme il respire.
###### 06
L’insolent cherche la sagesse, mais en vain !
Le savoir est à la portée de l’homme intelligent.
###### 07
Détourne-toi de l’insensé :
tu n’apprendras de ses lèvres rien qui vaille !
###### 08
La sagesse de l’homme avisé éclaire son chemin ;
la folie des insensés ne fait que les tromper.
###### 09
Les fous se moquent des sacrifices d’expiation ;
les gens honnêtes y trouvent grâce.
###### 10
Seul le cœur connaît sa peine,
et à sa joie, nul ne prend part.
###### 11
La maison des méchants sera rasée,
la demeure des honnêtes gens sera florissante.
###### 12
Il y a un chemin qui semble droit,
mais au terme, ce sont des chemins de mort.
###### 13
Même dans le rire, un cœur peut s’attrister,
et au terme, la joie se changer en affliction !
###### 14
Un cœur pervers se satisfait de sa conduite,
et plus encore, un homme de bien !
###### 15
Le naïf croit tout ce qu’on lui dit,
l’homme avisé regarde où il met les pieds.
###### 16
Le sage craint le mal et s’en détourne ;
l’insensé fonce, plein d’assurance.
###### 17
L’homme impatient fait des sottises,
et l’intrigant se rend odieux.
###### 18
Les naïfs ont en partage la bêtise ;
la science est la couronne des gens avisés.
###### 19
Des mauvais s’inclineront devant les bons,
des méchants attendront à la porte du juste.
###### 20
Un pauvre est rejeté, même par son ami,
mais il y a foule pour aduler un riche.
###### 21
Qui méprise son prochain est un pécheur.
Heureux qui a pitié des petites gens !
###### 22
Ne s’égarent-ils pas, les artisans du mal ?
Ils sont fidèles et loyaux, les artisans du bien.
###### 23
En tout labeur on trouve du profit,
mais le bavardage ne mène qu’à l’indigence.
###### 24
La couronne des sages, c’est leur richesse,
mais la folie des insensés reste folie !
###### 25
Il sauve des vies, le témoin qui dit vrai ;
le faux témoin ne cesse de tromper.
###### 26
La crainte du Seigneur assure puissamment :
il est un refuge pour ses enfants.
###### 27
La crainte du Seigneur est source de vie :
elle détourne des pièges mortels.
###### 28
Un peuple nombreux donne prestige au roi ;
le déclin de la population consterne le prince !
###### 29
L’homme patient a du discernement ;
l’impulsif arbore sa folie.
###### 30
Un cœur paisible est vie pour le corps ;
la passion est un cancer pour les os.
###### 31
Qui exploite le faible insulte Dieu qui l’a fait ;
qui a pitié du misérable l’honore.
###### 32
Le méchant est terrassé par sa malice ;
dans la mort même, le juste garde confiance.
###### 33
Dans un cœur intelligent repose la Sagesse ;
au milieu des insensés, elle se fera connaître !
###### 34
La justice grandit une nation ;
le péché est la honte des peuples.
###### 35
Le serviteur avisé a la faveur du roi,
l’effronté n’a droit qu’à sa fureur.
