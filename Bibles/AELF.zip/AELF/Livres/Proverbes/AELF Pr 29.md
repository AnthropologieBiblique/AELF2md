---
aliases : 
- Proverbes 29
- Proverbes 29
- Pr 29
- Proverbs 29
tags : 
- Bible/Pr/29
- français
cssclass : français
---

# Proverbes 29

###### 01
Qui raidit la nuque sous la critique
sera brisé, soudain, sans appel !
###### 02
Quand se multiplient les justes, le peuple est en joie ;
sous la domination des méchants, il gémit.
###### 03
Qui a la sagesse pour amie réjouit son père ;
qui fréquente les prostituées y perdra son bien.
###### 04
Un roi qui fait justice affermit le pays ;
rapace, il le ruinera.
###### 05
Flatter son prochain,
c’est tendre un filet sous ses pas !
###### 06
Piège pour le méchant, sa révolte !
Bonheur et joie pour le juste !
###### 07
Le juste connaît la cause des faibles,
le méchant l’ignore.
###### 08
Les provocateurs embrasent la cité,
les sages font retomber la colère.
###### 09
Le sage est-il en procès avec un fou,
qu’on se fâche ou plaisante,
plus moyen d’avoir la paix !
###### 10
Les meurtriers haïssent l’homme intègre,
les honnêtes gens ne lui veulent que du bien.
###### 11
L’insensé à toute heure exprime ses humeurs,
le sage a du recul et les tempère.
###### 12
Quand le maître prête l’oreille aux mensonges,
tous les serviteurs tournent mal.
###### 13
Le pauvre et l’exploiteur se rencontrent :
à tous deux, le Seigneur donne la lumière !
###### 14
Le roi qui rend justice aux faibles selon la vérité
ne cesse d’affermir son trône.
###### 15
Coups de bâton et remontrances procurent la sagesse ;
un jeune, renvoyé, fait la honte de sa mère.
###### 16
Plus les méchants se multiplient, plus le crime prolifère,
mais les justes seront témoins de leur chute.
###### 17
Corrige ton fils, il te donnera du repos,
il fera tes délices !
###### 18
Faute de prophétie, le peuple se relâche ;
heureux celui qui observe la loi !
###### 19
Pour corriger un serviteur, la parole ne suffit pas,
car il comprend mais n’obtempère pas.
###### 20
As-tu vu quelqu’un qui parle à tout propos ?
D’un sot, tu peux attendre davantage.
###### 21
Qui gâte un serviteur en son jeune âge
n’en fera qu’un insolent.
###### 22
Un coléreux provoque des querelles,
un fou furieux multiplie les crimes.
###### 23
L’orgueil d’un homme l’humiliera,
l’esprit humble obtiendra la gloire.
###### 24
Le complice d’un voleur met sa vie en danger,
si, appelé à témoigner, il ne le dénonce pas.
###### 25
Les peurs d’un homme lui sont autant de pièges :
qui se fie au Seigneur reste hors d’atteinte.
###### 26
Beaucoup recherchent la faveur d’un chef,
mais c’est du Seigneur que chacun tient son droit.
###### 27
Les justes ont horreur des gens pervers,
le méchant a horreur de qui marche droit.
