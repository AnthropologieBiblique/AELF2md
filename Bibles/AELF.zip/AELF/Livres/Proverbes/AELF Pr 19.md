---
aliases : 
- Proverbes 19
- Proverbes 19
- Pr 19
- Proverbs 19
tags : 
- Bible/Pr/19
- français
cssclass : français
---

# Proverbes 19

###### 01
Mieux vaut un pauvre à la conduite intègre
qu’un homme aux propos retors : c’est lui l’insensé !
###### 02
Sans la réflexion, le zèle ne vaut rien ;
qui se précipite manque son but.
###### 03
La sottise d’un homme entrave sa route,
et c’est contre Dieu qu’il tourne sa colère !
###### 04
La fortune multiplie les relations,
mais le faible voit partir son seul ami.
###### 05
Un faux témoin ne reste pas impuni :
il ment comme il respire, il n’en réchappera pas.
###### 06
Il y a foule pour flatter un prince,
et chacun veut être l’ami d’un mécène.
###### 07
Tous les frères du pauvre le repoussent,
et, bien sûr, ses amis ont pris leurs distances ;
il en parle encore, mais ils ne sont plus là !
###### 08
Qui acquiert du jugement s’aime soi-même,
qui reste clairvoyant trouve le bonheur.
###### 09
Un faux témoin ne reste pas impuni :
il ment comme il respire, il se perdra.
###### 10
Qu’un insensé ait la vie douce, c’est choquant ;
qu’un esclave commande aux princes, c’est pire encore !
###### 11
Un homme de bon sens retient sa colère,
il met son point d’honneur à passer sur l’offense.
###### 12
Rugissement d’un lion, la colère du roi ;
rosée sur l’herbe, sa faveur !
###### 13
Un fils stupide, c’est une calamité pour son père ;
les querelles d’une épouse,
c’est un goutte à goutte qui n’en finit pas.
###### 14
Maison et fortune sont héritage paternel,
mais du Seigneur vient l’épouse avisée.
###### 15
La paresse fait tomber dans l’apathie :
l’homme indolent aura faim.
###### 16
Qui garde une règle se garde lui-même,
qui ne veille pas à sa conduite mourra.
###### 17
Qui prend pitié du faible prête au Seigneur :
il saura lui rendre son bienfait.
###### 18
Corrige ton fils, tant qu’il y a de l’espoir ;
mais ne t’emporte pas jusqu’à causer sa mort !
###### 19
Une colère violente doit être punie ;
si tu la tolères, tu incites à recommencer !
###### 20
Écoute les conseils, accepte la correction :
tu finiras par t’assagir !
###### 21
Il y a bien des projets dans le cœur d’un homme ;
le dessein du Seigneur, lui, se réalisera.
###### 22
Ce qu’on attend d’un homme, c’est la bonne foi :
mieux vaut un pauvre qu’un menteur !
###### 23
La crainte du Seigneur mène à la vie :
vie comblée, lieu de repos inaccessible au malheur !
###### 24
Le paresseux plonge sa main dans le plat,
il ne la ramènera même pas jusqu’à sa bouche !
###### 25
Tape sur l’insolent, et l’étourdi en tirera la leçon ;
critique l’homme intelligent, lui saura comprendre !
###### 26
Qui agresse son père et met en fuite sa mère
est un fils indigne par qui vient le déshonneur !
###### 27
Cesse, mon fils, d’écouter les leçons,
et tu iras te perdre loin du savoir !
###### 28
Un vaurien témoigne en se moquant du droit,
le méchant laisse sa bouche vomir des insanités !
###### 29
Le châtiment est fait pour les insolents,
et les coups pour l’échine des insensés !
