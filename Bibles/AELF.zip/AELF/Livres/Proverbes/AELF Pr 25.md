---
aliases : 
- Proverbes 25
- Proverbes 25
- Pr 25
- Proverbs 25
tags : 
- Bible/Pr/25
- français
cssclass : français
---

# Proverbes 25

###### 01
Voici encore des proverbes de Salomon, que transcrivirent les gens d’Ézékias, roi de Juda.
###### 02
La gloire de Dieu, c’est de voiler ;
la gloire des rois, c’est de scruter.
###### 03
Et le ciel en sa hauteur, et la terre en sa profondeur,
et le cœur des rois, nul ne peut les scruter.
###### 04
Ôte les scories de l’argent,
il en sortira un vase d’orfèvre ;
###### 05
ôte la corruption de l’entourage du roi,
son trône s’affermira dans la justice.
###### 06
Ne cherche pas à briller devant le roi,
ne te mets pas à la place des grands ;
###### 07
mieux vaut que l’on te dise : « Monte ici »,
plutôt que d’être rabaissé devant un prince.
Ce que tu as vu de tes yeux,
###### 08
ne te presse pas d’en faire état dans un procès :
sinon, comment mettre un point final
aux accusations de ton adversaire ?
###### 09
Vide ta querelle avec ton adversaire,
sans divulguer les confidences d’un tiers :
###### 10
sinon, qui le saura te fera honte,
et cet affront sera sans appel.
###### 11
Pommes d’or incrustées d’argent,
la parole dite à point nommé.
###### 12
Anneau d’or, collier d’or pur,
la critique du sage pour l’oreille attentive.
###### 13
Fraîcheur de neige un jour de moisson,
tel est le messager fidèle, pour qui l’envoie,
vrai réconfort pour son maître !
###### 14
Des nuages et du vent, mais point de pluie :
tel est l’homme qui promet monts et merveilles !
###### 15
À force de patience on peut fléchir un juge :
une langue délicate peut broyer un os.
###### 16
Tu as trouvé du miel ? Manges-en à ta faim !
Si tu t’en gaves, tu le vomiras.
###### 17
Ne va pas trop souvent chez ton voisin !
Si tu exagères, il te haïra.
###### 18
Coup de massue, poignard, flèche acérée,
le faux témoignage qui vient d’un ami !
###### 19
Dent qui branle, pied qui flanche,
le secours d’un traître au jour mauvais.
###### 20
C’est retirer le manteau un jour de gel,
verser du vinaigre sur une plaie,
que de chanter des chansons à qui va mal !
###### 21
Si ton ennemi a faim, donne-lui du pain à manger ;
s’il a soif, donne-lui de l’eau à boire ;
###### 22
ce sont des braises que tu places sur sa tête,
et le Seigneur te le rendra.
###### 23
Le vent du nord est gros de la pluie ;
parler à mots couverts fait monter la colère.
###### 24
Mieux vaut loger dans un coin de terrasse
que partager sa maison avec une mégère.
###### 25
De l’eau fraîche pour une gorge sèche,
les bonnes nouvelles d’un pays lointain.
###### 26
Une source trouble, une fontaine polluée,
le juste qui perd pied devant un méchant.
###### 27
Manger du miel tant et plus, ce n’est pas bon ;
courir après la gloire, non plus.
###### 28
Ville éventrée, sans rempart,
l’homme qui ne maîtrise pas ses humeurs !
