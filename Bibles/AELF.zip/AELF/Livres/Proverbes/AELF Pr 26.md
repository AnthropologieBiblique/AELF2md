---
aliases : 
- Proverbes 26
- Proverbes 26
- Pr 26
- Proverbs 26
tags : 
- Bible/Pr/26
- français
cssclass : français
---

# Proverbes 26

###### 01
Pas plus que neige en été ou pluie à la moisson,
la gloire ne convient à un sot.
###### 02
Comme un battement d’ailes, comme un envol d’hirondelles,
maudire sans raison ne mène à rien.
###### 03
Un fouet pour le cheval, une bride pour l’âne,
tel le bâton pour l’échine des sots !
###### 04
Ne réponds pas à l’insensé selon sa folie,
sinon tu vas lui ressembler, toi aussi !
###### 05
Réponds à l’insensé selon sa folie,
sinon il va se prendre pour un sage !
###### 06
Il en aura les bras coupés, l’injure à la bouche,
celui qui confie une mission à l’insensé.
###### 07
Elles vont de travers, les jambes du boiteux,
comme un proverbe dans la bouche du sot.
###### 08
Autant bloquer le caillou dans la fronde
que de faire honneur à un sot.
###### 09
Le harpon que brandit un ivrogne,
ainsi le proverbe dans la bouche d’un sot.
###### 10
C’est beaucoup de blessures pour tous
que d’embaucher l’insensé ou le premier venu.
###### 11
Comme le chien retourne à son vomi,
l’insensé revient à ses folies.
###### 12
As-tu vu quelqu’un qui se prend pour un sage ?
D’un sot, tu peux attendre davantage.
###### 13
Le paresseux dit : « Il y a un fauve sur le chemin,
un lion qui rôde par les rues ! »
###### 14
La porte tourne sur ses gonds,
le paresseux se retourne sur son lit.
###### 15
Le paresseux plonge sa main dans le plat :
quel effort pour la ramener à sa bouche !
###### 16
Le paresseux se croit plus sage
que sept qui répondraient à bon escient.
###### 17
Il attrape un chien par les oreilles,
celui qui se mêle des querelles d’autrui.
###### 18
Comme un homme qui fait le fou
et lance des brandons et des flèches de mort,
###### 19
ainsi l’homme qui trompe son prochain,
et puis déclare : « Mais je plaisantais ! »
###### 20
Quand le bois vient à manquer, le feu s’éteint ;
faute de calomniateur, cesse la querelle.
###### 21
Du charbon sur les braises, du bois sur le feu :
ainsi l’homme querelleur attise le procès.
###### 22
Les mots du calomniateur, quel régal !
On s’en délecte jusqu’au plus profond.
###### 23
Scories d’argent plaquées sur un tesson,
des lèvres de feu avec un cœur mauvais !
###### 24
L’ennemi se cache derrière ses lèvres,
il dissimule, au fond de lui, sa tromperie.
###### 25
Au charme de sa voix ne te fie pas,
il a, dans le cœur, sept projets abominables.
###### 26
Sa ruse a beau cacher sa haine,
sa malice apparaîtra au grand jour.
###### 27
Qui creuse une fosse y tombera,
qui fait rouler une pierre la verra revenir sur lui.
###### 28
Langue menteuse a de la haine pour ses victimes,
bouche mielleuse mène à la ruine.
