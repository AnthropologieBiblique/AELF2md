---
aliases : 
- Proverbes 31
- Proverbes 31
- Pr 31
- Proverbs 31
tags : 
- Bible/Pr/31
- français
cssclass : français
---

# Proverbes 31

###### 01
Paroles de Lemouël, roi de Massa,
instruit par sa mère.
###### 02
Non, mon fils,
non, fils de mes entrailles,
non, fils de mes vœux !
###### 03
Ne livre pas aux femmes ta vigueur,
ta conduite à celles qui perdent les rois !
###### 04
Jamais les rois, Lemouël,
jamais les rois ne doivent boire de vin,
ni les princes de boissons fortes,
###### 05
de peur qu’en buvant ils n’oublient les lois
et ne lèsent tous les miséreux de leurs droits.
###### 06
Donne une boisson forte à qui va mourir,
du vin à qui trouve la vie trop amère :
###### 07
qu’il boive et qu’il oublie sa misère,
qu’il cesse de remâcher ses tourments !
###### 08
Prends la parole en faveur du muet,
pour la cause de tous les affligés ;
###### 09
prends la parole et dis le droit
pour la cause du pauvre et du malheureux !
###### 10
Aleph — Une femme parfaite, qui la trouvera ?
Elle est précieuse plus que les perles !
###### 11
Beth — Son mari peut lui faire confiance :
il ne manquera pas de ressources.
###### 12
Gimel — Elle fait son bonheur, et non pas sa ruine,
tous les jours de sa vie.
###### 13
Daleth — Elle sait choisir la laine et le lin,
et ses mains travaillent volontiers.
###### 14
Hé — Elle est comme les navires marchands,
faisant venir ses vivres de très loin.
###### 15
Waw — Elle est debout quand il fait encore nuit
pour préparer les repas de sa maison
et donner ses ordres aux servantes.
###### 16
Zaïn — A-t-elle des visées sur un champ ? Elle l’acquiert.
Avec le produit de son travail, elle plante une vigne.
###### 17
Heth — Elle rayonne de force
et retrousse ses manches !
###### 18
Teth — Elle s’assure de la bonne marche des affaires,
sa lampe ne s’éteint pas de la nuit.
###### 19
Yod — Elle tend la main vers la quenouille,
ses doigts dirigent le fuseau.
###### 20
Kaph — Ses doigts s’ouvrent en faveur du pauvre,
elle tend la main au malheureux.
###### 21
Lamed — Elle ne craint pas la neige pour sa maisonnée,
car tous les siens ont des vêtements doublés.
###### 22
Mem — Elle s’est fait des couvertures,
des vêtements de pourpre et de lin fin.
###### 23
Noun — Aux portes de la ville, on reconnaît son mari
siégeant parmi les anciens du pays.
###### 24
Samek — Elle fabrique de l’étoffe pour la vendre,
elle propose des ceintures au marchand.
###### 25
Aïn — Revêtue de force et de splendeur,
elle sourit à l’avenir.
###### 26
Pé — Sa bouche s’exprime avec sagesse
et sa langue enseigne la bonté.
###### 27
Çadé — Attentive à la marche de sa maison,
elle ne mange pas le pain de l’oisiveté.
###### 28
Qoph — Ses fils, debout, la disent bienheureuse
et son mari fait sa louange :
###### 29
Resh — « Bien des femmes ont fait leurs preuves,
mais toi, tu les surpasses toutes ! »
###### 30
Shine — Le charme est trompeur et la beauté s’évanouit ;
seule, la femme qui craint le Seigneur mérite la louange.
###### 31
Taw — Célébrez-la pour les fruits de son travail :
et qu’aux portes de la ville, ses œuvres disent sa louange !
