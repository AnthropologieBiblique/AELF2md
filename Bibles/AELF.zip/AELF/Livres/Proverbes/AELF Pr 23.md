---
aliases : 
- Proverbes 23
- Proverbes 23
- Pr 23
- Proverbs 23
tags : 
- Bible/Pr/23
- français
cssclass : français
---

# Proverbes 23

###### 01
Si tu es à la table d’un grand,
fais bien attention à ce qui est devant toi ;
###### 02
mets un couteau sur ta gorge
si tu es gourmand ;
###### 03
ne lorgne pas les bons plats :
en manger te décevra !
###### 04
Ne cours pas après la richesse,
qu’elle cesse de t’obséder !
###### 05
L’as-tu suivie des yeux ? Elle a disparu !
Car elle se donne des ailes ;
comme un aigle, elle s’envole vers le ciel !
###### 06
Ne partage pas le pain de l’envieux,
ne lorgne pas ses bons plats !
###### 07
Car il calcule tout, il est ainsi fait ;
il te dit : « Mange et bois ! »,
mais il n’est pas de cœur avec toi.
###### 08
La bouchée sitôt avalée, tu vas la vomir,
et tu en seras pour tes compliments !
###### 09
À l’oreille d’un sot ne dis mot :
il n’a que mépris pour tes paroles sensées !
###### 10
Ne déplace pas une borne ancienne,
n’empiète pas sur la terre des orphelins
###### 11
car leur Défenseur est puissant, il plaiderait leur cause contre toi.
###### 12
Dispose ton cœur à l’instruction
et tes oreilles aux paroles du savoir.
###### 13
N’hésite pas à corriger ton garçon,
il ne va pas mourir pour des coups de baguette !
###### 14
Toi, par des coups de baguette,
c’est de la tombe que tu le sauveras !
###### 15
Mon fils, si tu as le cœur sage,
mon cœur à moi se réjouira,
###### 16
et j’exulterai de tout mon être
quand tes lèvres parleront avec droiture.
###### 17
Que ton cœur n’envie pas les pécheurs,
mais qu’il reste tout le jour dans la crainte du Seigneur :
###### 18
il y a, certes, un avenir,
tu n’auras pas espéré en vain.
###### 19
Et toi, mon fils, écoute et sois un sage ;
garde ton cœur dans le droit chemin !
###### 20
Ne sois pas de ceux qui s’enivrent
et qui font bonne chère,
###### 21
car l’ivrogne et le glouton courent à la ruine ;
ils se réveillent un jour vêtus de haillons.
###### 22
Écoute ton père, c’est lui qui t’a engendré ;
ne méprise pas ta mère en ses vieux jours.
###### 23
– Achète la vérité, ne la vends jamais !
De même, la sagesse, l’instruction, l’intelligence ! –
###### 24
Il exulte, le père d’un homme juste ;
celui qui engendre un sage est comblé de joie.
###### 25
Que se réjouissent ton père et ta mère,
qu’elle exulte, celle qui t’a donné le jour !
###### 26
Donne-moi ton cœur, mon fils ;
que tes yeux suivent mes pas !
###### 27
La prostituée est un gouffre profond,
l’étrangère est un puits dont on ne peut sortir.
###### 28
Elle aussi, comme un voleur, est aux aguets,
multipliant les perfidies entre les hommes.
###### 29
Pour qui les « Aïe ! » ? Pour qui les « Hou-là-là ! » ?
Pour qui les querelles ? Pour qui les soupirs ?
Pour qui les coups à tort et à travers ?
Pour qui le regard trouble ?
###### 30
Pour ceux qui perdent leur temps à s’enivrer,
à courir après les boissons fortes !
###### 31
Ne lorgne pas le vin qui rougeoie,
si beaux que soient ses reflets dans la coupe,
car il va droit au but :
###### 32
il finit par mordre comme un serpent,
il pique comme une vipère ;
###### 33
tes yeux verront d’étranges choses,
tu diras des absurdités,
###### 34
tu seras comme pris du mal de mer
comme à la dérive tout en haut d’un mât :
###### 35
« On m’a frappé, mais je n’ai pas mal,
on m’a battu, mais je ne sais plus…
Quand vais-je me réveiller ?
J’en redemanderai encore ! »
