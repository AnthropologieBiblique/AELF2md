---
aliases : 
- Proverbes 11
- Proverbes 11
- Pr 11
- Proverbs 11
tags : 
- Bible/Pr/11
- français
cssclass : français
---

# Proverbes 11

###### 01
Le Seigneur a horreur des balances truquées,
le poids exact lui plaît.
###### 02
Que vienne l’arrogance, viendra le mépris !
La sagesse est avec les humbles.
###### 03
L’intégrité des honnêtes gens les guidera,
la perfidie des fourbes les mènera à la ruine.
###### 04
La fortune n’est d’aucune utilité au jour de la colère,
c’est la justice qui délivre de la mort.
###### 05
La justice des gens intègres leur trace un droit chemin,
et le méchant succombe à sa propre méchanceté.
###### 06
La justice des honnêtes gens les rendra libres,
les fourbes restent prisonniers de leur convoitise.
###### 07
À la mort du méchant, son espoir périt :
c’est peine perdue de compter sur les richesses !
###### 08
Un juste est tiré de l’angoisse,
un méchant y tombe à sa place.
###### 09
Par sa langue l’impie détruit son voisin :
les justes le savent et se tirent d’affaire.
###### 10
Le succès des justes réjouit la cité,
la perte des méchants fait exploser sa joie !
###### 11
La bénédiction due aux hommes droits grandit la cité,
la bouche des méchants l’anéantit.
###### 12
Qui se moque du voisin est un écervelé ;
l’homme intelligent se tait.
###### 13
Qui colporte des cancans trahira le secret,
l’homme de confiance n’en soufflera mot.
###### 14
Sans l’art de gouverner, un peuple tombe :
un conseil élargi le sauvera.
###### 15
Qui cautionne un inconnu s’attire des ennuis ;
refuser toute caution, c’est plus sûr !
###### 16
Une femme charmante reçoit des hommages,
l’homme énergique capte la richesse.
###### 17
Un homme bon se fait du bien à lui-même,
un homme dur se rend malheureux.
###### 18
Le salaire du méchant n’est qu’illusion ;
à qui sème la justice, la récompense est assurée.
###### 19
Oui, la justice mène à la vie ;
qui poursuit le mal va vers la mort !
###### 20
Le Seigneur a horreur des esprits retors ;
les gens à la conduite intègre lui plaisent.
###### 21
Promis, juré, le malfaiteur ne restera pas impuni,
mais la race des justes sera sauve !
###### 22
Comme l’anneau d’or au groin d’un pourceau,
une jolie femme dépourvue de tact !
###### 23
Les justes n’ont qu’un désir : le bien !
Pour les méchants, rien d’autre à espérer que la colère !
###### 24
Tel est prodigue et s’enrichit encore ;
tel autre, économe à l’excès, n’y gagne que misère !
###### 25
Une personne généreuse deviendra prospère ;
qui donne à boire sera lui-même désaltéré.
###### 26
Le peuple maudit celui qui accapare le blé,
il bénit celui qui le met sur le marché.
###### 27
Qui poursuit le bien cherche aussi à plaire ;
tendre au mal, c’est en faire les frais.
###### 28
Qui se fie à sa richesse tombera ;
comme un arbre verdoyant, le juste fleurira.
###### 29
Qui perturbe sa maison héritera le vent,
et le sot sera l’esclave de l’homme au cœur sage !
###### 30
Le fruit du juste devient arbre de vie :
le sage entraîne les autres à sa suite.
###### 31
Si le juste reçoit rétribution sur cette terre,
combien plus le méchant et le pécheur !
