---
aliases : 
- Proverbes 30
- Proverbes 30
- Pr 30
- Proverbs 30
tags : 
- Bible/Pr/30
- français
cssclass : français
---

# Proverbes 30

###### 01
Paroles d’Agour, fils de Yaqé, de Massa.
Oracle de cet homme pour Ytiel, pour Ytiel et Oukal.
###### 02
Oui, je suis le plus stupide des hommes,
aucune intelligence humaine en moi :
###### 03
je n’ai pas étudié la sagesse,
mais la science du Dieu saint, je la connais.
###### 04
Qui est monté au ciel et en est descendu ?
Qui a retenu le vent au creux de sa main ?
Qui a serré les eaux dans son manteau ?
Qui a fixé toutes les limites de la terre ?
Quel est son nom ?
Quel est le nom de son fils ? Sans doute, tu le sais !
###### 05
Toute parole de Dieu est éprouvée au feu ;
il est un bouclier pour qui s’abrite en lui.
###### 06
N’ajoute rien à ce qu’il dit :
il te le reprocherait comme un mensonge.
###### 07
Seigneur, je n’ai que deux choses à te demander,
ne me les refuse pas avant que je meure !
###### 08
Éloigne de moi mensonge et fausseté,
ne me donne ni pauvreté ni richesse,
accorde-moi seulement ma part de pain.
###### 09
Car, dans l’abondance, je pourrais te renier
en disant : « Le Seigneur, qui est-ce ? »
Ou alors, la misère ferait de moi un voleur,
et je profanerais le nom de mon Dieu !
###### 10
Ne calomnie pas devant son maître un serviteur,
il te maudirait, et tu en porterais la faute.
###### 11
Quelle génération ! Ils maudissent leur père
et ne bénissent pas leur mère.
###### 12
Quelle génération ! Ils se croient purs
et ne balaient pas devant leur porte.
###### 13
Quelle génération ! Ils prennent un air supérieur
et vous regardent de haut.
###### 14
Quelle génération ! Ils ont des dents comme des épées,
des mâchoires comme des scies
pour dévorer les pauvres du pays,
retrancher les malheureux d’entre les humains.
###### 15
La sangsue a deux filles, « Apporte » et « Apporte »,
cela fait trois insatiables
et quatre encore qui ne diront jamais « Assez ! » :
###### 16
le séjour des morts et le ventre stérile,
la terre jamais gorgée d’eau,
et le feu qui ne dit jamais « Assez ! »
###### 17
L’œil qui toise un père,
qui dédaigne d’obéir à une mère,
les corbeaux du torrent le crèveront,
les vautours le dévoreront.
###### 18
Il y a trois merveilles qui me dépassent,
quatre dont je ne sais rien :
###### 19
le chemin de l’aigle dans le ciel,
le chemin du serpent sur le rocher,
le chemin du navire en haute mer
et le chemin de l’homme chez la jeune fille.
###### 20
Et puis il y a le chemin de la femme adultère :
comme si, après y avoir goûté,
elle pouvait s’essuyer la bouche et déclarer :
« Je n’ai rien fait de mal ! »
###### 21
Il y a trois causes aux tremblements de terre,
quatre situations que la terre ne peut supporter :
###### 22
un esclave qui se prend pour le roi,
un abruti, la panse pleine,
###### 23
une peste qui trouve un mari
et une servante qui supplante sa maîtresse.
###### 24
Il y en a quatre, tout petits sur la terre,
mais sages entre les sages :
###### 25
les fourmis, race bien faible,
qui font en été leurs provisions ;
###### 26
les damans, race chétive,
qui, dans le rocher, se font un gîte ;
###### 27
point de roi chez les sauterelles,
mais elles avancent toutes en bon ordre ;
###### 28
le lézard, on l’attrape à la main,
mais il est chez lui au palais du roi.
###### 29
Il y en a trois qui ont fière allure,
quatre dont la démarche est superbe :
###### 30
le lion, le plus vaillant des animaux,
qui ne recule devant rien,
###### 31
le coq sur ses ergots, et le bouc,
enfin, le roi, à la tête de son armée.
###### 32
Si tu t’es emporté sottement,
et si tu t’en rends compte,
mets la main sur ta bouche !
###### 33
Car, du lait battu, sort du beurre ;
d’un coup sur le nez, sort du sang ;
d’un coup de colère, sort un procès.
