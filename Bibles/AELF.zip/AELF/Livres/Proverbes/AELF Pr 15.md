---
aliases : 
- Proverbes 15
- Proverbes 15
- Pr 15
- Proverbs 15
tags : 
- Bible/Pr/15
- français
cssclass : français
---

# Proverbes 15

###### 01
Une réponse paisible calme la fureur,
un mot blessant déclenche la colère.
###### 02
La langue des sages rend la science aimable,
la bouche des insensés ne débite que des sottises.
###### 03
En tout lieu, les yeux du Seigneur :
ils observent les méchants et les bons.
###### 04
La langue qui réconforte est un arbre de vie ;
perfide, elle vous coupe le souffle.
###### 05
Un sot se moque des leçons de son père ;
bien avisé qui tient compte des avertissements !
###### 06
La maison du juste regorge de richesse,
les gains du méchant sont précaires !
###### 07
Les lèvres des sages sèment le savoir ;
pour le cœur des insensés, il n’en va pas ainsi !
###### 08
Le sacrifice des méchants, le Seigneur l’a en horreur,
mais il accueille la prière des honnêtes gens.
###### 09
Le chemin du méchant fait horreur au Seigneur ;
il aime celui qui recherche la justice.
###### 10
Rude leçon pour qui s’écarte du sentier :
refuser l’avertissement, c’est la mort !
###### 11
Le séjour des morts et l’abîme sont devant le Seigneur :
à plus forte raison le cœur des hommes !
###### 12
Un insolent n’aime pas qu’on le reprenne ;
aussi ne va-t-il guère avec les sages.
###### 13
À cœur joyeux, visage épanoui ;
à cœur chagrin, soupirs désolés.
###### 14
Un cœur intelligent recherche le savoir,
la bouche des insensés se repaît de sottises.
###### 15
Pour le malheureux, tous les jours sont mauvais ;
pour le cœur content, c’est un perpétuel festin.
###### 16
Mieux vaut peu, avec la crainte du Seigneur,
qu’un grand trésor et ses embarras.
###### 17
Mieux vaut un plat de légumes servi avec amour
que du veau gras et de la haine.
###### 18
Un homme irascible provoque la querelle,
un homme patient apaise la dispute.
###### 19
Le chemin du paresseux est un buisson de ronces,
la route des honnêtes gens est dégagée.
###### 20
Le fils sage fait la joie de son père ;
insensé, l’homme qui méprise sa mère !
###### 21
L’écervelé se complaît dans sa bêtise,
l’homme intelligent va droit son chemin.
###### 22
Sans concertation, le projet avorte ;
un conseil élargi lui donne consistance.
###### 23
Quel plaisir de trouver la répartie !
Qu’elle est bonne, la parole qui tombe à pic !
###### 24
Pour l’homme avisé, le sentier de vie est une montée ;
il évite ainsi la descente au séjour des morts.
###### 25
La maison des orgueilleux, le Seigneur la renverse ;
il fixe les bornes du terrain de la veuve.
###### 26
Le Seigneur a horreur des calculs pervers ;
les paroles bienveillantes sont pures.
###### 27
Péril en la demeure pour l’homme âpre au gain !
Qui refuse tout pot-de-vin vivra.
###### 28
Le juste réfléchit en son cœur avant de répondre ;
la bouche du méchant vomit le mal.
###### 29
Le Seigneur est loin des méchants,
mais il écoute la prière des justes.
###### 30
Un regard lumineux réjouit le cœur,
une bonne nouvelle donne des forces.
###### 31
Qui sait écouter les leçons de la vie
aura sa place entre les sages.
###### 32
Qui refuse l’éducation se méprise lui-même,
qui écoute les leçons gagne en intelligence.
###### 33
La crainte du Seigneur est école de sagesse :
avant les honneurs, l’humilité !
