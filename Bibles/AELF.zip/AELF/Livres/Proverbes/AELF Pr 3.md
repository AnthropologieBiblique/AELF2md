---
aliases : 
- Proverbes 3
- Proverbes 3
- Pr 3
- Proverbs 3
tags : 
- Bible/Pr/3
- français
cssclass : français
---

# Proverbes 3

###### 01
Mon fils, n’oublie pas mon enseignement ;
que ton cœur observe mes préceptes :
###### 02
la longueur de tes jours, les années de ta vie,
et ta paix en seront augmentées.
###### 03
Que fidélité et loyauté ne te quittent pas,
attache-les à ton cou,
écris-les sur les tablettes de ton cœur !
###### 04
Tu trouveras grâce et seras rayonnant
aux yeux de Dieu et des hommes.
###### 05
De tout ton cœur, fais confiance au Seigneur,
ne t’appuie pas sur ton intelligence.
###### 06
Reconnais-le, où que tu ailles,
c’est lui qui aplanit ta route.
###### 07
Ne te complais pas dans ta sagesse,
crains le Seigneur, écarte-toi du mal !
###### 08
Voilà le traitement pour ton corps,
l’élixir pour tes os.
###### 09
Rends gloire au Seigneur avec tes biens,
donne-lui les prémices de ton revenu :
###### 10
tes greniers se rempliront de blé,
le vin nouveau débordera de tes cuves.
###### 11
Mon fils, ne rejette pas les leçons du Seigneur,
ne dédaigne pas ses critiques,
###### 12
car le Seigneur reprend celui qu’il aime,
comme fait un père pour le fils qu’il chérit.
###### 13
Heureux qui trouve la sagesse,
qui accède à la raison !
###### 14
C’est une bonne affaire, meilleure qu’une affaire d’argent,
plus rentable que l’or.
###### 15
La sagesse est plus précieuse que les perles,
rien ne l’égale :
###### 16
dans sa main droite, longueur de jours,
dans sa main gauche, richesse et gloire !
###### 17
Ses chemins sont chemins de délices,
tous ses sentiers, des lieux de paix.
###### 18
Pour qui la tient, elle est arbre de vie ;
qui la saisit est un homme heureux.
###### 19
Le Seigneur a fondé la terre avec sagesse ;
il a établi les cieux avec intelligence.
###### 20
C’est par sa science que les abîmes se sont ouverts
et que, des nuages, perle la rosée.
###### 21
Mon fils, ne perds jamais de vue
le savoir-faire et la perspicacité :
###### 22
ils te seront force de vie,
une parure à ton cou.
###### 23
Alors tu iras ton chemin avec assurance,
ton pied n’achoppera pas.
###### 24
Au moment de dormir, nulle anxiété ;
une fois endormi, ton sommeil sera doux.
###### 25
Tu n’as rien à craindre, ni l’angoisse soudaine,
ni la tourmente qui surprend les méchants :
###### 26
c’est le Seigneur qui sera ton assurance,
il gardera ton pied des embûches.
###### 27
Ne refuse pas un bienfait à qui tu le dois,
quand ce geste est à ta portée.
###### 28
Ne dis pas à ton prochain : « Va-t’en, tu reviendras,
je donnerai demain ! », alors que tu as de quoi.
###### 29
Ne travaille pas au malheur de ton prochain,
alors qu’il vit sans méfiance auprès de toi.
###### 30
Ne cherche pas de vaine querelle
à qui ne t’a pas fait de mal.
###### 31
N’envie pas l’homme violent,
n’adopte pas ses procédés.
###### 32
Car le Seigneur a horreur des gens tortueux ;
il ne s’attache qu’aux hommes droits.
###### 33
Malédiction du Seigneur sur la maison du méchant,
bénédiction sur la demeure des justes.
###### 34
Il se moque des moqueurs,
aux humbles il accorde sa grâce.
###### 35
Aux sages, la gloire en partage,
aux insensés, toute la honte !
