---
aliases : 
- Proverbes 27
- Proverbes 27
- Pr 27
- Proverbs 27
tags : 
- Bible/Pr/27
- français
cssclass : français
---

# Proverbes 27

###### 01
Ne te félicite pas du lendemain,
tu ne sais pas ce qu’aujourd’hui va enfanter.
###### 02
Qu’un autre te loue, mais pas ta bouche,
n’importe qui, mais pas tes lèvres !
###### 03
Ça pèse, la pierre, c’est lourd, le sable,
plus lourd encore, les humeurs d’un sot !
###### 04
La rage est sans pitié, la colère, impétueuse ;
mais qui tiendra devant la jalousie ?
###### 05
Mieux vaut franche critique
qu’amitié hypocrite !
###### 06
Un ami donne des coups loyalement ;
les baisers de l’ennemi sont trompeurs.
###### 07
Ventre repu fait fi du miel ;
à ventre affamé tout est doux, même le fiel !
###### 08
Comme l’oiseau migrant loin de son nid,
ainsi va l’émigré loin de chez lui.
###### 09
Baumes et parfums mettent le cœur en joie :
la douceur de l’ami l’emporte sur les rêves.
###### 10
Ne laisse pas tomber ton ami, ni l’ami de ton père ;
ne va pas chez ton frère le jour où tu es ruiné :
mieux vaut proche voisin que frère lointain !
###### 11
Sois un sage, mon fils, pour ma plus grande joie,
et j’aurai de quoi répondre à qui m’insulte.
###### 12
Bien avisé qui voit le malheur et se met à l’abri ;
l’étourdi passe outre, il le paiera.
###### 13
Quelqu’un s’est-il porté garant pour un tiers, saisis son manteau ;
s’il l’a fait pour des étrangers, prends-lui un gage !
###### 14
Bénir un ami, tôt matin, à grands cris ?
Autant le maudire !
###### 15
La gouttière qui ne cesse de couler un jour de pluie
et l’épouse querelleuse, c’est tout un :
###### 16
autant vouloir retenir le vent
ou prendre de l’huile avec ses doigts !
###### 17
Le fer s’aiguise avec le fer,
et l’homme s’aiguise à rencontrer son prochain !
###### 18
Qui soigne son figuier en mangera les fruits,
qui veille sur son maître en recevra l’honneur.
###### 19
Comme un visage voit son reflet dans l’eau,
ainsi l’homme se voit-il en son cœur.
###### 20
Le séjour des morts et l’abîme sont insatiables,
les yeux de l’homme aussi sont insatiables !
###### 21
On éprouve l’argent au creuset, l’or au fourneau,
et l’homme par la bouche de qui fait son éloge.
###### 22
Quand tu pilerais le sot dans un mortier,
au milieu du grain, avec le pilon,
sa sottise ne se détacherait pas de lui !
###### 23
Juge bien de la mine de tes moutons,
et prends soin de tes troupeaux,
###### 24
car la richesse n’est pas éternelle
ni les trésors assurés d’âge en âge !
###### 25
On fauche le foin, le regain apparaît,
on ramasse l’herbe des montagnes :
###### 26
les brebis te paieront le vêtement,
les boucs, le prix d’un champ ;
###### 27
le lait de chèvre suffira à te nourrir,
à nourrir ta maison, faire vivre tes servantes.
