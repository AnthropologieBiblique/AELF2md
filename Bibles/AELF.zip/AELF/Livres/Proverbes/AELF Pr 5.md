---
aliases : 
- Proverbes 5
- Proverbes 5
- Pr 5
- Proverbs 5
tags : 
- Bible/Pr/5
- français
cssclass : français
---

# Proverbes 5

###### 01
Mon fils, sois attentif à ma sagesse,
prête l’oreille à mes raisons ;
###### 02
pour garder un esprit avisé,
que tes lèvres s’en tiennent au vrai savoir !
###### 03
Oui, le miel coule des lèvres de la femme d’un autre ;
plus que l’huile, onctueuse est sa bouche,
###### 04
mais elle laisse à la fin amertume d’absinthe,
blessure d’une épée à deux tranchants.
###### 05
Vers la mort descendent ses pas,
son pied touche au séjour des morts ;
###### 06
jamais elle n’ouvrira un chemin de vie ;
ses pistes se perdent sans qu’elle en sache rien.
###### 07
Maintenant, mon fils, écoute-moi,
ne t’écarte pas de ce que dit ma bouche :
###### 08
éloigne de cette femme ton chemin,
n’approche pas du seuil de sa maison.
###### 09
Sinon, tu laisseras chez d’autres ta vigueur
et tes années au mari sans pitié !
###### 10
Oui, des étrangers dévoreront ton énergie,
tu travailleras dur pour la maison d’un autre,
###### 11
si bien qu’à la fin, tu hurleras,
ton corps et ta chair épuisés.
###### 12
« Ah, diras-tu, comment ai-je pu haïr la discipline,
compter pour rien les avertissements ?
###### 13
Je n’ai pas écouté les maîtres ;
je n’ai pas prêté l’oreille à ceux qui me formaient.
###### 14
Pour un peu, le pire me serait arrivé
devant la communauté rassemblée. »
###### 15
Bois de l’eau à ta citerne,
des eaux vives de ton puits !
###### 16
Tes sources iraient-elles se répandre au-dehors,
couler en ruisseaux sur les places ?
###### 17
Qu’elles soient pour toi,
pour toi seul, sans partage !
###### 18
Que ta fontaine soit bénie,
qu’elle soit ta joie, la femme de ta jeunesse,
###### 19
biche de tes amours, gracieuse gazelle !
Laisse-toi toujours enivrer de ses charmes,
reste éperdu d’amour pour elle !
###### 20
Pourquoi, mon fils, t’éprendre d’une autre,
enlacer une étrangère ?
###### 21
Le Seigneur a les yeux sur les chemins de l’homme,
il observe toutes ses pistes.
###### 22
Les crimes du méchant se retournent contre lui,
il est captif des liens de son péché.
###### 23
Il mourra, faute de discipline ;
par trop de folie, il se perdra.
