---
aliases : 
- Proverbes 9
- Proverbes 9
- Pr 9
- Proverbs 9
tags : 
- Bible/Pr/9
- français
cssclass : français
---

# Proverbes 9

###### 01
La Sagesse a bâti sa maison,
elle a taillé sept colonnes.
###### 02
Elle a tué ses bêtes, et préparé son vin,
puis a dressé la table.
###### 03
Elle a envoyé ses servantes, elle appelle
sur les hauteurs de la cité :
###### 04
« Vous, étourdis, passez par ici ! »
À qui manque de bon sens, elle dit :
###### 05
« Venez, mangez de mon pain,
buvez le vin que j’ai préparé.
###### 06
Quittez l’étourderie et vous vivrez,
prenez le chemin de l’intelligence. »
[
###### 07
Qui corrige l’insolent ne reçoit que mépris,
qui reprend le méchant s’en trouve sali.
###### 08
Ne reprends pas l’insolent, il va te haïr ;
reprends le sage, il t’aimera.
###### 09
Si tu donnes au sage, il devient plus sage ;
si tu instruis le juste, il progresse encore.]
###### 10
La sagesse commence avec la crainte du Seigneur,
connaître le Dieu saint, voilà l’intelligence !
###### 11
– « Par moi, se multiplient tes jours
et s’augmentent les années de ta vie. »
###### 12
Si tu es sage, c’est pour toi que tu es sage ;
si tu fais l’insolent, toi seul en pâtiras.
###### 13
Dame Folie fait du tapage ;
c’est une étourdie qui ne connaît rien.
###### 14
Assise à la porte de sa maison,
elle trône sur les hauteurs de la cité
###### 15
pour appeler les passants
qui vont droit leur chemin :
###### 16
« Vous, étourdis, passez par ici ! »
À qui manque de bon sens, elle dit :
###### 17
« Bien douce est l’eau qu’on a volée,
savoureux, le pain pris en secret ! »
###### 18
Et lui ne sait pas que des Ombres sont là,
que ses invités descendent au séjour des morts.
