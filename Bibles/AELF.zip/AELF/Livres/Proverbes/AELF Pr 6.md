---
aliases : 
- Proverbes 6
- Proverbes 6
- Pr 6
- Proverbs 6
tags : 
- Bible/Pr/6
- français
cssclass : français
---

# Proverbes 6

###### 01
Mon fils, si tu t’es porté caution pour un proche,
si tu as dit « Marché conclu ! » pour un étranger,
###### 02
si tu es piégé par tes propres paroles,
prisonnier de tes propres paroles,
###### 03
alors, fais ceci, mon fils, pour t’en sortir,
puisque te voilà entre les mains d’un autre :
va, humilie-toi, insiste auprès de lui,
###### 04
interdis tout sommeil à tes yeux,
et tout répit à tes paupières,
###### 05
échappe-toi, comme la gazelle loin du chasseur,
comme l’oiseau de la main de l’oiseleur.
###### 06
Va vers la fourmi, paresseux !
Regarde-la marcher et deviens sage :
###### 07
elle n’a pas de supérieur,
ni surveillant ni gouverneur,
###### 08
et tout l’été, elle fait ses provisions,
elle amasse, à la moisson, de quoi manger.
###### 09
Combien de temps vas-tu rester couché, paresseux ?
Quand vas-tu émerger de ton sommeil ?
###### 10
Un somme par-ci, une sieste par-là,
s’allonger un moment, se croiser les bras,
###### 11
et voilà que survient la pauvreté, comme un rôdeur,
la misère, comme un garde bien armé.
###### 12
C’est un vaurien, un faux-jeton :
il se promène, tordant sa bouche,
###### 13
lançant des clins d’œil, des appels du pied,
donnant ses consignes avec les doigts ;
###### 14
le cœur pervers, il prépare des mauvais coups,
à tout moment, il déclenche des querelles.
###### 15
Voilà pourquoi, soudain, vient sa ruine,
brusquement il est brisé,
et c’est sans remède.
###### 16
Il y a six choses que le Seigneur déteste,
sept qu’il a en horreur :
###### 17
le regard hautain, la langue menteuse,
les mains qui versent le sang innocent,
###### 18
le cœur occupé de projets coupables,
les pieds qui s’empressent de courir au mal,
###### 19
le faux témoin qui ment comme il respire,
et l’homme qui déclenche des querelles entre frères.
###### 20
Garde les préceptes de ton père, mon fils,
ne rejette pas l’enseignement de ta mère ;
###### 21
tiens-les toujours fixés à ton cœur,
attache-les à ton cou :
###### 22
dans tes démarches, ils te guideront,
dans ton sommeil, ils te garderont,
à ton réveil, ils te tiendront compagnie.
###### 23
Car ces préceptes sont une lampe,
l’enseignement, une lumière :
instruction et discipline sont un chemin de vie.
###### 24
Ainsi, tu seras gardé de la femme mauvaise,
des propos enjôleurs de l’étrangère ;
###### 25
ne convoite pas sa beauté dans ton cœur,
ne succombe pas à ses œillades !
###### 26
À la prostituée, il suffit de gagner son pain ;
la femme mariée, elle, pourchasse celui qui l’enrichira.
###### 27
Peut-on mettre du feu dans sa poche
sans brûler ses vêtements ?
###### 28
Peut-on marcher sur des charbons ardents
sans se griller les pieds ?
###### 29
De même, courir après la femme de son prochain :
nul n’y touchera sans en être puni.
###### 30
Point de mépris pour un voleur
si c’est la faim qui l’a poussé ;
###### 31
mais s’il est pris, il doit payer sept fois plus :
tous les biens de sa maison !
###### 32
L’adultère, lui, est un écervelé,
il fait d’une femme le bourreau de sa vie.
###### 33
Il recevra coups et affronts,
son déshonneur ne s’effacera pas
###### 34
car un mari jaloux devient fou de rage,
il est sans pitié au jour de la vengeance :
###### 35
nul dédommagement ne l’apaisera ;
de multiples cadeaux ne le fléchiront pas.
