---
aliases : 
- 1 Thessaloniciens 4
- 1 Thessaloniciens 4
- 1 Th 4
- 1 Thessalonians 4
tags : 
- Bible/1Th/4
- français
cssclass : français
---

# 1 Thessaloniciens 4

###### 01
Pour le reste, frères, vous avez appris de nous comment il faut vous conduire pour plaire à Dieu ; et c’est ainsi que vous vous conduisez déjà. Faites donc de nouveaux progrès, nous vous le demandons, oui, nous vous en prions dans le Seigneur Jésus.
###### 02
Vous savez bien quelles instructions nous vous avons données de la part du Seigneur Jésus.
###### 03
La volonté de Dieu, c’est que vous viviez dans la sainteté, en vous abstenant de la débauche,
###### 04
et en veillant chacun à rester maître de son corps dans un esprit de sainteté et de respect,
###### 05
sans vous laisser entraîner par la convoitise comme font les païens qui ne connaissent pas Dieu.
###### 06
Dans ce domaine, il ne faut pas agir au détriment de son frère ni lui causer du tort, car de tout cela le Seigneur fait justice, comme nous vous l’avons déjà dit et attesté.
###### 07
En effet, Dieu nous a appelés, non pas pour que nous restions dans l’impureté, mais pour que nous vivions dans la sainteté.
###### 08
Ainsi donc celui qui rejette mes instructions, ce n’est pas un homme qu’il rejette, c’est Dieu lui-même, lui qui vous donne son Esprit Saint.
###### 09
Pour ce qui est de l’amour fraternel, vous n’avez pas besoin que je vous en parle dans ma lettre, car vous avez appris vous-mêmes de Dieu à vous aimer les uns les autres,
###### 10
et c’est ce que vous faites envers tous les frères de la province de Macédoine. Frères, nous vous encourageons à progresser encore :
###### 11
ayez à cœur de vivre calmement, de vous occuper chacun de vos propres affaires et de travailler de vos mains comme nous vous l’avons ordonné.
###### 12
Ainsi, votre conduite méritera le respect des gens du dehors, et vous ne manquerez de rien.
###### 13
Frères, nous ne voulons pas vous laisser dans l’ignorance au sujet de ceux qui se sont endormis dans la mort ; il ne faut pas que vous soyez abattus comme les autres, qui n’ont pas d’espérance.
###### 14
Jésus, nous le croyons, est mort et ressuscité ; de même, nous le croyons aussi, ceux qui se sont endormis, Dieu, par Jésus, les emmènera avec lui.
###### 15
Car, sur la parole du Seigneur, nous vous déclarons ceci : nous les vivants, nous qui sommes encore là pour la venue du Seigneur, nous ne devancerons pas ceux qui se sont endormis.
###### 16
Au signal donné par la voix de l’archange, et par la trompette divine, le Seigneur lui-même descendra du ciel, et ceux qui sont morts dans le Christ ressusciteront d’abord.
###### 17
Ensuite, nous les vivants, nous qui sommes encore là, nous serons emportés sur les nuées du ciel, en même temps qu’eux, à la rencontre du Seigneur. Ainsi, nous serons pour toujours avec le Seigneur.
###### 18
Réconfortez-vous donc les uns les autres avec ce que je viens de dire.
