---
aliases : 
- 1 Thessaloniciens 1
- 1 Thessaloniciens 1
- 1 Th 1
- 1 Thessalonians 1
tags : 
- Bible/1Th/1
- français
cssclass : français
---

# 1 Thessaloniciens 1

###### 01
PAUL, SILVAIN ET TIMOTHEE,
à l’Église de Thessalonique
qui est en Dieu le Père
et dans le Seigneur Jésus Christ.
À vous, la grâce et la paix.
###### 02
À tout moment, nous rendons grâce à Dieu au sujet de vous tous, en faisant mémoire de vous dans nos prières. Sans cesse,
###### 03
nous nous souvenons que votre foi est active, que votre charité se donne de la peine, que votre espérance tient bon en notre Seigneur Jésus Christ, en présence de Dieu notre Père.
###### 04
Nous le savons, frères bien-aimés de Dieu, vous avez été choisis par lui.
###### 05
En effet, notre annonce de l’Évangile n’a pas été, chez vous, simple parole, mais puissance, action de l’Esprit Saint, pleine certitude : vous savez comment nous nous sommes comportés chez vous pour votre bien.
###### 06
Et vous-mêmes, en fait, vous nous avez imités, nous et le Seigneur, en accueillant la Parole au milieu de bien des épreuves, avec la joie de l’Esprit Saint.
###### 07
Ainsi vous êtes devenus un modèle pour tous les croyants de Macédoine et de Grèce.
###### 08
Et ce n’est pas seulement en Macédoine et en Grèce qu’à partir de chez vous la parole du Seigneur a retenti, mais la nouvelle de votre foi en Dieu s’est si bien répandue partout que nous n’avons pas besoin d’en parler.
###### 09
En effet, les gens racontent, à notre sujet, l’accueil que nous avons reçu chez vous ; ils disent comment vous vous êtes convertis à Dieu en vous détournant des idoles, afin de servir le Dieu vivant et véritable,
###### 10
et afin d’attendre des cieux son Fils qu’il a ressuscité d’entre les morts, Jésus, qui nous délivre de la colère qui vient.
