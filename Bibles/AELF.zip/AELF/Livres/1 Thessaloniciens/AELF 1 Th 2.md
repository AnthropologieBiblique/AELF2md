---
aliases : 
- 1 Thessaloniciens 2
- 1 Thessaloniciens 2
- 1 Th 2
- 1 Thessalonians 2
tags : 
- Bible/1Th/2
- français
cssclass : français
---

# 1 Thessaloniciens 2

###### 01
Frères, vous le savez bien vous-mêmes, notre venue chez vous n’a pas été inutile.
###### 02
Nous venions de souffrir et d’être outragés à Philippes, comme vous le savez ; nous avons cependant trouvé en notre Dieu pleine assurance pour vous annoncer, au prix de grandes luttes, l’Évangile de Dieu.
###### 03
Et quand nous vous exhortions, ce n’était pas avec des doctrines fausses, ni des motifs impurs, ni par ruse.
###### 04
En effet, pour nous confier l’Évangile, Dieu a éprouvé notre valeur, de sorte que nous parlons, non pas pour plaire aux hommes, mais à Dieu, lui qui met nos cœurs à l’épreuve.
###### 05
Jamais, nous n’avons eu un mot de flatterie, vous le savez, jamais de motifs intéressés, Dieu en est témoin ;
###### 06
jamais nous n’avons recherché la gloire qui vient des hommes, ni auprès de vous ni auprès d’autres personnes.
###### 07
Alors que nous aurions pu nous imposer en qualité d’apôtres du Christ, au contraire, nous avons été pleins de douceur avec vous, comme une mère qui entoure de soins ses nourrissons.
###### 08
Ayant pour vous une telle affection, nous aurions voulu vous donner non seulement l’Évangile de Dieu, mais jusqu’à nos propres vies, car vous nous étiez devenus très chers.
###### 09
Vous vous rappelez, frères, nos peines et nos fatigues : c’est en travaillant nuit et jour, pour n’être à la charge d’aucun d’entre vous, que nous vous avons annoncé l’Évangile de Dieu.
###### 10
Vous êtes témoins, et Dieu aussi, de notre attitude si sainte, si juste et irréprochable envers vous, les croyants.
###### 11
Et vous savez bien que nous avons été pour chacun de vous comme un père avec ses enfants :
###### 12
nous vous avons exhortés et encouragés, nous vous avons suppliés d’avoir une conduite digne de Dieu, lui qui vous appelle à son Royaume et à sa gloire.
###### 13
Et voici pourquoi nous ne cessons de rendre grâce à Dieu : quand vous avez reçu la parole de Dieu que nous vous faisions entendre, vous l’avez accueillie pour ce qu’elle est réellement, non pas une parole d’hommes, mais la parole de Dieu qui est à l’œuvre en vous, les croyants.
###### 14
En effet, frères, vous avez imité les Églises de Dieu qui vivent en Judée dans le Christ Jésus, parce que vous avez souffert de la part de vos compatriotes de la même manière qu’elles ont souffert de la part des Juifs.
###### 15
Ceux-ci ont tué le Seigneur Jésus et les prophètes, et nous ont persécutés ; ils déplaisent à Dieu ; ils sont les adversaires de tous les hommes,
###### 16
puisqu’ils nous empêchent de proclamer la Parole aux païens pour qu’ils soient sauvés ; cela met sans cesse un comble à leurs péchés. Mais, à la fin, la colère de Dieu les a rejoints.
###### 17
Quant à nous, frères, séparés de vous pour un temps – de visage mais non de cœur – nous avons tout fait pour revoir votre visage, tellement nous en avions le désir.
###### 18
Nous avons donc voulu aller chez vous – moi, Paul, j’ai essayé une fois, même deux fois – mais Satan nous en a empêchés.
###### 19
En effet, qui est notre espérance ? Qui est notre joie et la couronne dont nous serons fiers devant notre Seigneur Jésus lors de sa venue ? N’est-ce pas vous ?
###### 20
Oui, c’est vous qui êtes notre gloire et notre joie.
