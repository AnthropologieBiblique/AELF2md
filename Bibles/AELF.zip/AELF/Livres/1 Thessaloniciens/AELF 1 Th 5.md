---
aliases : 
- 1 Thessaloniciens 5
- 1 Thessaloniciens 5
- 1 Th 5
- 1 Thessalonians 5
tags : 
- Bible/1Th/5
- français
cssclass : français
---

# 1 Thessaloniciens 5

###### 01
Pour ce qui est des temps et des moments de la venue du Seigneur, vous n’avez pas besoin, frères, que je vous en parle dans ma lettre.
###### 02
Vous savez très bien que le jour du Seigneur vient comme un voleur dans la nuit.
###### 03
Quand les gens diront : « Quelle paix ! Quelle tranquillité ! », c’est alors que, tout à coup, la catastrophe s’abattra sur eux, comme les douleurs sur la femme enceinte : ils ne pourront pas y échapper.
###### 04
Mais vous, frères, comme vous n’êtes pas dans les ténèbres, ce jour ne vous surprendra pas comme un voleur.
###### 05
En effet, vous êtes tous des fils de la lumière, des fils du jour ; nous n’appartenons pas à la nuit et aux ténèbres.
###### 06
Alors, ne restons pas endormis comme les autres, mais soyons vigilants et restons sobres.
###### 07
Les gens qui dorment, c’est la nuit qu’ils dorment ; ceux qui s’enivrent, c’est la nuit qu’ils sont ivres,
###### 08
mais nous qui sommes du jour, restons sobres ; mettons la cuirasse de la foi et de l’amour et le casque de l’espérance du salut.
###### 09
Car Dieu ne nous a pas destinés à subir la colère, mais à entrer en possession du salut par notre Seigneur Jésus Christ,
###### 10
mort pour nous afin de nous faire vivre avec lui, que nous soyons en train de veiller ou de dormir.
###### 11
Ainsi, réconfortez-vous mutuellement et édifiez-vous l’un l’autre, comme vous le faites déjà.
###### 12
Nous vous demandons, frères, de reconnaître ceux qui se donnent de la peine parmi vous, ceux qui, dans le Seigneur, vous dirigent et vous donnent des avertissements ;
###### 13
estimez-les infiniment avec amour en raison de leur travail. Vivez en paix entre vous.
###### 14
Nous vous en prions, frères : avertissez ceux qui vivent de façon désordonnée, donnez du courage à ceux qui en ont peu, soutenez les faibles, soyez patients envers tous.
###### 15
Prenez garde que personne ne rende le mal pour le mal, mais recherchez toujours ce qui est bien, entre vous et avec tous.
###### 16
Soyez toujours dans la joie,
###### 17
priez sans relâche,
###### 18
rendez grâce en toute circonstance : c’est la volonté de Dieu à votre égard dans le Christ Jésus.
###### 19
N’éteignez pas l’Esprit,
###### 20
ne méprisez pas les prophéties,
###### 21
mais discernez la valeur de toute chose : ce qui est bien, gardez-le ;
###### 22
éloignez-vous de toute espèce de mal.
###### 23
Que le Dieu de la paix lui-même vous sanctifie tout entiers ; que votre esprit, votre âme et votre corps, soient tout entiers gardés sans reproche pour la venue de notre Seigneur Jésus Christ.
###### 24
Il est fidèle, Celui qui vous appelle : tout cela, il le fera.
###### 25
Frères, priez aussi pour nous.
###### 26
Saluez tous les frères par un baiser de paix.
###### 27
Je vous en conjure au nom du Seigneur : que cette lettre soit lue à tous les frères.
###### 28
La grâce de notre Seigneur Jésus Christ soit avec vous.
