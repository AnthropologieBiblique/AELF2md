---
aliases : 
- 1 Thessaloniciens 3
- 1 Thessaloniciens 3
- 1 Th 3
- 1 Thessalonians 3
tags : 
- Bible/1Th/3
- français
cssclass : français
---

# 1 Thessaloniciens 3

###### 01
C’est pourquoi, n’y tenant plus, nous avons préféré rester seuls à Athènes, Silvain et moi,
###### 02
et nous vous avons envoyé Timothée, notre frère, collaborateur de Dieu pour l’annonce de l’Évangile du Christ. Il devait vous affermir et vous réconforter dans votre foi,
###### 03
afin que personne ne soit ébranlé dans les détresses actuelles, car vous savez bien, vous-mêmes, que nous y sommes exposés.
###### 04
En effet, quand nous étions chez vous, nous vous annoncions que la détresse devait nous atteindre, et c’est ce qui est arrivé, vous le savez bien.
###### 05
Voilà pourquoi, n’y tenant plus, j’ai envoyé quelqu’un pour savoir où en était votre foi, de peur que peut-être le Tentateur ne vous ait tentés, et que notre peine ne soit perdue.
###### 06
Or Timothée vient de nous arriver de chez vous, et il nous a apporté la bonne nouvelle de votre foi et de votre charité ; il nous a dit que vous gardez toujours un bon souvenir de nous, et que vous avez le très vif désir de nous revoir, comme nous l’avons à votre égard.
###### 07
C’est pourquoi, frères, nous sommes réconfortés grâce à vous au milieu de toutes nos difficultés et de notre détresse, à cause de votre foi.
###### 08
Et maintenant nous revivons, puisque vous autres, vous tenez bon dans le Seigneur.
###### 09
Comment pourrions-nous assez rendre grâce à Dieu à votre sujet, pour toute la joie que nous avons à cause de vous devant notre Dieu ?
###### 10
Nous le prions avec ardeur, jour et nuit, pour que nous puissions revoir votre visage et compléter ce qui manque à votre foi.
###### 11
Que Dieu lui-même, notre Père, et que notre Seigneur Jésus nous tracent le chemin jusqu’à vous.
###### 12
Que le Seigneur vous donne, entre vous et à l’égard de tous les hommes, un amour de plus en plus intense et débordant, comme celui que nous avons pour vous.
###### 13
Et qu’ainsi il affermisse vos cœurs, les rendant irréprochables en sainteté devant Dieu notre Père, lors de la venue de notre Seigneur Jésus avec tous les saints. Amen.
