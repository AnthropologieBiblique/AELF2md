---
aliases : 
- Tobie 10
- Tobie 10
- Tb 10
- Tobit 10
tags : 
- Bible/Tb/10
- français
cssclass : français
---

# Tobie 10

###### 01
De son côté, Tobith faisait quotidiennement le décompte des jours nécessaires à l’aller et au retour. Quand les jours furent écoulés, son fils n’était pas encore là.
###### 02
Il se dit : « Peut-être a-t-il été retenu là-bas ? À moins que Gabaël soit mort et qu’il ne trouve personne pour lui rendre l’argent ? »
###### 03
Tobith commençait à s’attrister.
###### 04
Quant à sa femme Anna, elle répétait : « Mon enfant a péri ; il n’est plus au nombre des vivants. » Elle se mettait à pleurer et à se lamenter sur son fils :
###### 05
« Hélas, mon enfant, je t’ai laissé partir, toi, la lumière de mes yeux ! »
###### 06
Et Tobith lui disait : « Tais-toi donc, ma sœur ! Ne t’inquiète pas ! Notre fils va bien. Ils ont dû avoir un contretemps là-bas. D’ailleurs, celui qui l’accompagne est un homme de confiance ; c’est un de nos frères. Ne te tourmente pas au sujet de Tobie, ma sœur : il sera bientôt là. »
###### 07
Mais Anna répondait : « Tais-toi ! N’essaie pas de me tromper. Mon enfant a péri. » Et, chaque jour, elle se précipitait pour surveiller elle-même la route par laquelle son fils était parti, car elle ne se fiait plus à personne. Après le coucher du soleil, elle rentrait pour se lamenter et pleurer toute la nuit, sans trouver le sommeil.
###### 08
Au bout des quatorze jours de noces que Ragouël avait juré de faire pour sa fille, Tobie alla le trouver et lui dit : « Laisse-moi partir. Car je sais que mon père et ma mère ne croient plus me revoir. Je t’en prie, père, laisse-moi partir et je rentrerai chez mon père. Je t’ai déjà décrit dans quel état je l’ai laissé. »
###### 09
Ragouël lui répondit : « Reste, mon enfant, reste avec moi. J’enverrai à ton père Tobith des messagers qui lui apporteront de tes nouvelles. » Mais Tobie répliqua : « Pas du tout ! Je t’en prie, laisse-moi partir pour retrouver mon père. »
###### 10
Aussitôt Ragouël confia à Tobie Sarra, sa femme, et lui remit la moitié de tous les biens qu’il possédait : serviteurs et servantes, bœufs et brebis, ânes et chameaux, vêtements, argent et mobilier.
###### 11
Il les laissa partir et fit ses adieux à Tobie en lui disant : « Porte-toi bien, mon enfant ! Va, et porte-toi bien ! Que le Seigneur du ciel vous guide, toi et ta femme Sarra, et qu’il m’accorde de voir vos enfants avant de mourir ! »
###### 12
Et il dit à sa fille Sarra : « Va chez ton beau-père et ta belle-mère. Désormais ils sont tes parents, tout comme ceux qui t’ont donné la vie. Va en paix, mon enfant. Puissé-je n’entendre dire que du bien de toi, tant que je vivrai ! » Puis il les embrassa et les laissa partir.
###### 13
Quant à Edna, elle dit à Tobie : « Mon fils et frère bien-aimé, que le Seigneur te ramène et qu’il me donne de vivre assez longtemps pour voir, avant de mourir, tes enfants et ceux de ma fille Sarra ! Devant le Seigneur, je mets ma fille sous ta protection. Ne lui cause de peine aucun jour de ta vie. Va en paix, mon enfant. Désormais je suis ta mère, comme Sarra est ta sœur. Puissions-nous tous connaître un égal bonheur chaque jour de notre vie ! » Elle les embrassa tendrement tous les deux et les laissa partir.
###### 14
Tobie quitta Ragouël, en bonne santé et tout joyeux. Il bénit le Seigneur du ciel et de la terre, le roi de l’univers, pour l’heureuse issue de son voyage. Puis, il bénit Ragouël et Edna en leur disant : « Que le Seigneur me permette de vous honorer tous les jours de ma vie. »
