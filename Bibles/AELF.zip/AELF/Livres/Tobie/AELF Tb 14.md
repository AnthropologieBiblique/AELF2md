---
aliases : 
- Tobie 14
- Tobie 14
- Tb 14
- Tobit 14
tags : 
- Bible/Tb/14
- français
cssclass : français
---

# Tobie 14

###### 01
C’est ainsi que Tobith acheva son cantique d’action de grâce.
###### 02
Tobith mourut dans la paix à l’âge de cent douze ans et il fut enterré dignement à Ninive. Il avait soixante-deux ans quand il perdit l’usage de ses yeux. Après avoir retrouvé la vue, il vécut dans l’abondance et fit des aumônes. Il continua de bénir Dieu et de célébrer la grandeur divine.
###### 03
Au moment de mourir, il appela son fils Tobie et lui fit ces recommandations : « Mon enfant, emmène tes enfants,
###### 04
pars vite en Médie, car je crois à cette parole de Dieu que le prophète Nahoum a proférée contre Ninive : tout doit arriver, tout se produira contre Assour et Ninive, comme l’ont annoncé les prophètes d’Israël que Dieu a envoyés ; tout se produira, et rien ne sera retranché de toutes leurs paroles ; toutes choses arriveront en leur temps. Il y aura alors plus de sécurité en Médie qu’en Assour et en Babylonie. Car je sais bien, moi, et je crois que s’accomplira tout ce que Dieu a dit ; tout doit arriver, aucune de ses paroles ne sera effacée.
Nos frères qui habitent sur la terre d’Israël seront tous disséminés et emmenés en exil loin de ce bon pays. Tout le pays d’Israël deviendra un désert, Samarie et Jérusalem seront un désert, et la Maison de Dieu sera livrée à la désolation et à l’incendie, jusqu’au temps fixé.
###### 05
Mais Dieu les prendra de nouveau en pitié, il les ramènera au pays d’Israël, et ils rebâtiront sa Maison, non pas dans l’état de jadis, mais en attendant que s’accomplissent les temps favorables. Ils reviendront alors tous de leur captivité, ils reconstruiront Jérusalem magnifiquement, et la Maison de Dieu y sera rebâtie, comme l’ont annoncé les prophètes d’Israël.
###### 06
Toutes les nations de la terre entière, toutes se convertiront et craindront Dieu en vérité. Tous abandonneront les idoles qui les trompaient et les menaient à l’erreur, et, dans la justice, ils béniront le Dieu des siècles.
###### 07
Tous les fils d’Israël seront sauvés en ces jours-là, pour s’être souvenus de Dieu en vérité ; ils se rassembleront, ils viendront à Jérusalem et habiteront pour toujours en sécurité dans la terre d’Abraham, qui leur sera donnée. Ceux qui aiment Dieu en vérité se réjouiront ; ceux qui commettent le péché et l’injustice disparaîtront de toute la terre.
8-
###### 09
Et maintenant, mes enfants, je vous donne ce commandement : servez Dieu en vérité, faites ce qui lui plaît. Ordonnez à vos enfants de pratiquer la justice et l’aumône, afin qu’ils se souviennent de Dieu et qu’en tout temps ils bénissent son nom en vérité et de toute leur force. Quant à toi, mon enfant, quitte Ninive, ne reste pas ici. Dès que tu auras enterré ta mère auprès de moi, ne reste pas un jour de plus dans cette contrée. Car, je le vois, il y a ici beaucoup d’injustices, et les impostures se multiplient, sans que personne en ait honte.
###### 10
Mon enfant, considère comment Nadab a traité Ahikar qui l’avait élevé : n’a-t-il pas voulu le précipiter en terre tout vivant ? Mais Dieu lui a jeté son infamie au visage : Ahikar est ressorti à la lumière, tandis que Nadab s’enfonçait dans les ténèbres éternelles, pour avoir tenté de tuer Ahikar. À cause de ses aumônes, Ahikar a échappé au piège mortel que Nadab lui avait tendu. Nadab y tomba lui-même et y trouva la mort.
###### 11
Ainsi donc, mes enfants, voyez ce que produit l’aumône ; voyez aussi ce que produit l’injustice : elle conduit à la mort… Mais voici que le souffle m’abandonne. »
On déposa alors Tobith sur un lit, il mourut et on l’enterra dignement.
###### 12
À la mort de sa mère, Tobie l’enterra près de son père. Puis il partit pour la Médie avec sa femme et s’établit à Ecbatane, chez son beau-père Ragouël.
###### 13
Il prit grand soin de ses beaux-parents dans leur vieillesse et il les enterra à Ecbatane de Médie. Il hérita alors du patrimoine de son beau-père, comme de celui de Tobith, son père.
###### 14
Il mourut, respecté de tous, à l’âge de cent dix-sept ans.
###### 15
Avant de mourir, il apprit la ruine de Ninive et il vit ses habitants arriver en Médie, déportés par Cyaxare, roi de Médie. Tobie bénit Dieu pour tout ce qu’il avait fait aux gens de Ninive et d’Assour. Avant sa mort, il se réjouit du sort de Ninive et il bénit le Seigneur Dieu pour les siècles des siècles.
