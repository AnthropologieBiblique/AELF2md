---
aliases : 
- Tobie 11
- Tobie 11
- Tb 11
- Tobit 11
tags : 
- Bible/Tb/11
- français
cssclass : français
---

# Tobie 11

###### 01
Comme ils approchaient de Kaserîn, qui se trouve en face de Ninive,
###### 02
Raphaël dit à Tobie : « Tu sais dans quel état nous avons laissé ton père.
###### 03
Prenons de l’avance sur ta femme et allons préparer la maison, avant que les autres n’arrivent. »
###### 04
Ils partirent donc tous deux ensemble. Raphaël dit : « Prends avec toi le fiel du poisson. » Et le chien les suivait.
###### 05
Or, Anna était assise à l’entrée de la cour et surveillait la route par laquelle son fils était parti.
###### 06
Elle le reconnut qui arrivait et cria à Tobith : « Voici ton fils qui revient, et aussi son compagnon de voyage. »
###### 07
Raphaël dit à Tobie, avant que celui-ci ne s’approche de son père : « J’ai la certitude que ses yeux vont s’ouvrir.
###### 08
Étale sur eux le fiel du poisson ; le remède provoquera la contraction des yeux et en détachera le voile blanchâtre. Ton père retrouvera la vue et verra la lumière. »
###### 09
Anna courut se jeter au cou de son fils et lui dit : « Je te revois, mon enfant. À présent, je peux mourir ! » Et elle se mit à pleurer.
###### 10
Quant à Tobith, il se leva et franchit l’entrée de la cour en trébuchant.
###### 11
Tobie alla vers lui, le fiel du poisson à la main. Il lui souffla dans les yeux, le saisit et lui dit : « Confiance, père ! » Puis il lui appliqua le remède et en rajouta.
###### 12
Ensuite, de ses deux mains, il lui retira les pellicules en partant du coin des yeux.
###### 13
Tobith se jeta alors au cou de son fils et lui dit en pleurant : « Je te revois, mon enfant, toi, la lumière de mes yeux ! »
###### 14
Et il ajouta :
« Béni soit Dieu !
Béni soit son grand nom !
Bénis soient tous ses saints anges !
Que son grand nom soit sur nous !
Bénis soient tous les anges
pour tous les siècles !
Car Dieu m’avait frappé,
mais voici que je revois
mon fils Tobie ! »
###### 15
Tobie entra dans la maison, tout joyeux et bénissant Dieu à pleine voix. Il raconta à son père qu’il avait fait bon voyage, qu’il rapportait l’argent et comment il avait épousé Sarra, la fille de Ragouël : « La voilà qui arrive, ajouta-t-il ; elle est aux portes de Ninive. »
###### 16
Tobith partit à la rencontre de sa belle-fille, aux portes de Ninive ; il était tout joyeux et bénissait Dieu. En le voyant marcher d’un pas ferme et traverser la ville sans que personne le conduise par la main, les habitants furent émerveillés, et Tobith proclamait que Dieu l’avait pris en pitié et lui avait rouvert les yeux.
###### 17
Quand il arriva près de Sarra, la femme de son fils Tobie, il la bénit en disant : « Sois la bienvenue, ma fille! Béni soit ton Dieu de t’avoir menée vers nous ! Béni soit ton père ! Béni soit mon fils Tobie et bénie sois-tu, ma fille ! Sois la bienvenue dans ta maison, sois comblée de bénédiction et de joie. Entre, ma fille ! »
###### 18
Ce jour-là fut un jour de joie pour tous les Juifs qui habitaient Ninive.
###### 19
Alors arrivèrent, tout joyeux, chez Tobith ses neveux Ahikar et Nabad.
