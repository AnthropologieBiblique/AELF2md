---
aliases : 
- Tobie 6
- Tobie 6
- Tb 6
- Tobit 6
tags : 
- Bible/Tb/6
- français
cssclass : français
---

# Tobie 6

###### 01
Le garçon partit, et l’ange avec lui ; le chien partit aussi avec lui et il les accompagnait. Ils firent donc route ensemble. Survint la première nuit, et ils campèrent au bord d’un fleuve, le Tigre.
###### 02
Comme le garçon descendait se laver les pieds dans le Tigre, un grand poisson bondit hors de l’eau et voulut avaler son pied. Le garçon cria.
###### 03
Mais l’ange lui dit : « Attrape le poisson, et maîtrise-le. » Le garçon saisit le poisson et le hissa sur la berge.
###### 04
L’ange lui dit : « Éventre le poisson, enlève-lui le fiel, le cœur et le foie, mets-les à part pour les emporter, et jette les entrailles. Car le fiel, le cœur et le foie sont des remèdes efficaces. »
###### 05
Le garçon éventra le poisson, recueillit le fiel, le cœur et le foie, puis il grilla une partie du poisson et la mangea, et il garda l’autre partie après l’avoir salée.
###### 06
Ils poursuivirent tous deux la route, jusqu’aux abords de la Médie.
###### 07
Le garçon interrogea alors l’ange : « Azarias, mon frère, le cœur, le foie et le fiel du poisson, en quoi sont-ils un remède ? »
###### 08
L’ange lui répondit : « Si tu fais brûler le cœur et le foie du poisson devant un homme ou une femme attaqués par un démon ou un esprit mauvais, l’agresseur s’enfuit au loin, et ses victimes en seront délivrées pour toujours.
###### 09
Quant au fiel, si tu l’appliques sur les yeux d’un homme atteint de leucomes et si tu souffles dessus, les yeux seront guéris. »
###### 10
Quand il fut entré en Médie et que déjà il approchait d’Ecbatane,
###### 11
Raphaël dit au garçon : « Tobie, mon frère », et celui-ci répondit : « Qu’y a-t-il ? » Raphaël reprit : « Nous devons loger cette nuit chez Ragouël. Cet homme est ton parent, et il a une fille qui s’appelle Sarra.
###### 12
À part elle, il n’a ni fils ni fille. Tu es le plus proche parent de Sarra : c’est à toi qu’elle revient en priorité et tu as aussi le droit d’hériter de la fortune de son père. D’ailleurs, c’est une jeune fille intelligente, courageuse et très belle, et son père est un homme de bien. »
###### 13
Il ajouta : « C’est ton droit de l’épouser. Écoute-moi bien, mon frère. Cette nuit, je parlerai au père de la jeune fille pour qu’il t’accorde sa main, et, à notre retour de Raguès, nous célébrerons les noces. Je sais que Ragouël ne peut te la refuser ni la fiancer à un autre. Sinon, il encourrait la mort selon le décret du Livre de Moïse, car il sait que sa fille te revient de préférence à tout autre. Ainsi donc, écoute-moi bien, mon frère : dès cette nuit, nous aurons un entretien au sujet de cette jeune fille et nous conviendrons du mariage. Quand nous quitterons Raguès, nous la prendrons avec nous et nous l’emmènerons chez toi. »
###### 14
Tobie répondit à Raphaël : « Azarias, mon frère, j’ai entendu dire qu’elle a déjà eu sept maris et qu’ils sont morts dans leur chambre nuptiale : ils ont succombé la nuit même où ils voulaient s’approcher d’elle. J’ai même entendu dire qu’un démon les tuait.
###### 15
Voilà pourquoi j’ai peur, car ce n’est pas elle que le démon attaque, mais il tue quiconque veut s’approcher d’elle. Or je suis le fils unique de mon père, et, si je venais à mourir, je causerais à mon père et ma mère un chagrin qui les conduirait dans la tombe, et ils n’ont pas d’autre fils que moi pour les enterrer ! »
###### 16
Raphaël lui répondit : « As-tu oublié les instructions de ton père, qui t’a commandé de prendre femme dans son clan ? Et maintenant, écoute-moi bien, mon frère : ne t’inquiète pas au sujet de ce démon et prends Sarra comme épouse. Car je sais que cette nuit même elle te sera accordée.
###### 17
Mais, quand tu entreras dans la chambre nuptiale, prends le cœur du poisson et un peu de son foie, dépose-les sur le brûle-parfums, et l’odeur s’en répandra. Dès que le démon l’aura sentie, il prendra la fuite et il ne reparaîtra plus jamais auprès d’elle.
###### 18
Quand tu seras sur le point de t’unir à elle, levez-vous d’abord tous les deux, priez et demandez au Seigneur du ciel de faire venir sur vous sa miséricorde et son salut. N’aie pas peur, car c’est à toi qu’elle a été destinée depuis toujours, et c’est toi qui la sauveras. Elle te suivra, et j’ai bien l’idée que tu auras d’elle des enfants, qui seront pour toi comme des frères. Ne t’inquiète pas. »
###### 19
En apprenant de Raphaël qu’il avait une parente dans son clan, il s’éprit d’elle passionnément et il lui fut attaché de tout son cœur.
