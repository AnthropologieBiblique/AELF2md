---
aliases : 
- Tobie 4
- Tobie 4
- Tb 4
- Tobit 4
tags : 
- Bible/Tb/4
- français
cssclass : français
---

# Tobie 4

###### 01
Ce jour-là, Tobith se souvint de l’argent qu’il avait mis en dépôt chez Gabaël, à Raguès de Médie.
###### 02
Il se dit en lui-même : « Voici que j’ai réclamé la mort. Ne devrais-je pas appeler mon fils Tobie et lui parler de cet argent avant de mourir ? »
###### 03
Il appela son fils Tobie, qui vint à lui. Tobith lui dit : « Mon enfant, quand je mourrai, enterre-moi dignement. Honore ta mère et ne l’abandonne pas aussi longtemps qu’elle vivra. Fais ce qui lui est agréable et ne l’attriste en rien.
###### 04
Souviens-toi, mon enfant, de tous les risques qu’elle a courus pour toi quand tu étais dans son sein. Quand elle mourra, enterre-la auprès de moi, dans le même tombeau.
###### 05
Chaque jour, mon enfant, souviens-toi du Seigneur. Garde-toi de pécher et de transgresser ses commandements. Fais ce qui est juste tous les jours de ta vie et ne marche pas dans les voies de l’injustice.
###### 06
Car ceux qui agissent selon la vérité réussiront dans leurs entreprises. À tous ceux qui pratiquent la justice,
###### 07
fais l’aumône avec les biens qui t’appartiennent. Ne détourne ton visage d’aucun pauvre, et le visage de Dieu ne se détournera pas de toi.
###### 08
Mon fils, agis suivant ce que tu as : si tu es dans l’abondance, donne davantage ; mais si tu as peu, donne selon le peu que tu as. Quand tu fais l’aumône, mon fils, n’aie aucun doute :
###### 09
tu te constitues un beau trésor pour les jours de détresse,
###### 10
car l’aumône délivre de la mort et empêche d’aller dans les ténèbres.
###### 11
Pour tous ceux qui la pratiquent, elle est une bonne offrande devant le Dieu Très-Haut.
###### 12
Mon fils, garde-toi de toute union illégale. Et tout d’abord, prends femme dans la descendance de tes pères. Ne prends pas une étrangère, car nous sommes les fils des prophètes : de Noé, qui fut le premier prophète, d’Abraham, Isaac et Jacob, nos pères des origines. Souviens-toi, mon fils : ils ont tous pris femme dans le clan de leurs frères ; ils ont été bénis dans leurs fils, et leur descendance aura un héritage.
###### 13
Quant à toi, mon fils, aime tes frères, et ne jette pas un regard orgueilleux sur les filles de tes frères. Car, dans l’orgueil, il y a ruine et grand désordre et, dans une conduite indigne, abaissement et indigence extrême : c’est le début de la misère.
###### 14
Donne son salaire à quiconque aura travaillé pour toi ; paie-le aussitôt, et ne garde chez toi le salaire de personne. Ta récompense ne tardera pas si tu sers Dieu en vérité. Sois vigilant, mon fils, et fais preuve de sagesse dans toutes tes actions et toutes tes paroles.
###### 15
Ne fais à personne ce que tu détestes, et que cela n’entre dans ton cœur aucun jour de ta vie.
###### 16
Donne de ton pain aux affamés et de tes vêtements à ceux qui sont nus. En outre, fais l’aumône de tout ton superflu.
###### 17
Mon fils, répands ton pain et ton vin sur la tombe des justes, et ne donne rien aux pécheurs.
###### 18
Prends conseil auprès d’un homme sage, et ne méprise aucun conseil utile.
###### 19
En toute occasion, bénis ton Dieu, demande-lui de rendre droits tes chemins et de bien orienter tes pensées, car les nations païennes ne pensent rien de bon. C’est le Seigneur qui donne le bon conseil. Le Seigneur abaisse qui il veut jusqu’au fond du séjour des morts. Ainsi donc, mon enfant, souviens-toi de ces commandements, et qu’ils ne s’effacent pas de ton cœur.
###### 20
À présent, mon enfant, je te signale que j’ai mis en dépôt dix talents d’argent chez Gabaël, le frère de Gabri, à Raguès de Médie.
###### 21
Ne t’effraye pas, mon enfant, si nous sommes devenus pauvres : tu as de grands biens si tu crains Dieu, si tu fuis tout péché et si tu fais le bien devant le Seigneur ton Dieu. »
