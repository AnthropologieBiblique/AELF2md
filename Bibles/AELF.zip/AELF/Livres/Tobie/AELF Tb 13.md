---
aliases : 
- Tobie 13
- Tobie 13
- Tb 13
- Tobit 13
tags : 
- Bible/Tb/13
- français
cssclass : français
---

# Tobie 13

###### 01
Tobith dit alors :
###### 1b
Béni soit Dieu, le Vivant, à jamais !
Béni soit son règne !
###### 02
C’est lui qui châtie et prend pitié,
qui fait descendre aux profondeurs des enfers
et retire de la grande perdition :
nul n’échappe à sa main.
###### 03
Rendez-lui grâce, fils d’Israël, à la face des nations
où lui-même vous a dispersés ;
###### 04
là, il vous a montré sa grandeur :
exaltez-le à la face des vivants.
Car il est notre Seigneur,
lui, notre Dieu, notre Père,
il est Dieu, pour les siècles des siècles !
###### 05
Il vous frappera pour vos péchés,
mais il vous prendra tous en pitié,
il vous rassemblera de toutes les nations
où vous avez été disséminés.
###### 06
Si vous revenez vers lui de cœur et d’âme
pour vivre, dans la vérité, devant lui,
alors il reviendra vers vous
et jamais plus ne cachera sa face.
###### 07
Regardez ce qu’il a fait pour vous,
rendez-lui grâce à pleine voix !
Bénissez le Seigneur de justice,
exaltez le Roi des siècles !
###### 08
Et moi, en terre d’exil, je lui rends grâce ;
je montre sa grandeur et sa force
au peuple des pécheurs.
« Revenez, pécheurs,
et vivez devant lui dans la justice.
Qui sait s’il ne vous rendra pas
son amour et sa grâce ! »
###### 09
J’exalterai mon Dieu, le Roi du ciel ;
mon âme se réjouit de sa grandeur.
Que tous lui rendent grâce à Jérusalem
et qu’ils disent :
###### 10
Jérusalem, ville sainte,
Dieu va te frapper pour les œuvres de tes fils,
mais de nouveau il aura pitié des fils des justes.
###### 11
Rends toute grâce au Seigneur
et bénis le Roi des siècles !
Qu’il relève en toi le sanctuaire,
###### 12
Qu’il réjouisse en toi les exilés,
qu’il aime en toi les malheureux,
pour les siècles sans fin.
###### 13
Une lumière brillante brillera
jusqu’aux limites de la terre.
De loin, viendront des peuples nombreux
vers ton nom qui est saint,
les mains chargées de leurs offrandes
pour le Roi du ciel.
Les générations des générations t’empliront d’allégresse,
et le nom de l’Élue restera pour les siècles.
[
###### 14
Maudits soient tous ceux qui te menaceront,
maudits soient tous ceux qui te détruiront
ou raseront tes remparts,
tous ceux qui abattront tes tours
et mettront le feu à tes maisons.
Mais bénis soient tous ceux qui te respecteront,
à jamais !]
###### 15
Réjouis-toi, exulte, à cause des fils des justes :
tous rassemblés, ils béniront le Seigneur éternel.
Heureux ceux qui t’aiment :
ils se réjouiront de ta paix.
###### 16
Heureux tous ceux qui s’affligeront sur toi
à cause de toutes tes épreuves :
en toi ils se réjouiront,
ils prendront part à ta joie pour toujours.
Mon âme, bénis le Seigneur, le Grand Roi :
###### 17
il bâtira, dans Jérusalem, sa maison pour les siècles !
heureux serai-je, s’il reste quelqu’un de ma descendance
pour contempler ta gloire et célébrer le Roi du ciel.
Les portes de Jérusalem seront d’émeraude et de saphir ;
ses murs, de pierre précieuse ;
les tours de Jérusalem seront en or,
et leurs créneaux, en or pur ;
ses rues, pavées de rubis et de pierres d’Ophir.
###### 18
Ses portes retentiront de chants de joie,
et ses demeures diront : « Alléluia !
Béni soit le Dieu d’Israël ! »
Que les bénis de Dieu bénissent le Nom très saint,
pour les siècles et à jamais !
