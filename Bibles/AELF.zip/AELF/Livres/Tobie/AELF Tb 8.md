---
aliases : 
- Tobie 8
- Tobie 8
- Tb 8
- Tobit 8
tags : 
- Bible/Tb/8
- français
cssclass : français
---

# Tobie 8

###### 01
Quand on eut fini de manger et de boire, on décida d’aller se coucher. On conduisit le jeune homme jusqu’à la chambre, où on le fit entrer.
###### 02
Tobie se souvint alors des paroles de Raphaël ; il sortit de sa besace le foie et le cœur du poisson et les déposa sur le brûle-parfums.
###### 03
L’odeur du poisson repoussa le démon, qui s’enfuit par les airs jusqu’en Égypte. Raphaël s’y rendit, et aussitôt entrava et ligota le démon.
###### 04
Or les parents de Sarra avaient quitté la chambre et fermé la porte. Tobie sortit du lit et dit à Sarra : « Lève-toi, ma sœur. Prions, et demandons à notre Seigneur de nous combler de sa miséricorde et de son salut. »
###### 05
Elle se leva, et ils se mirent à prier et à demander que leur soit accordé le salut. Tobie commença ainsi :
« Béni sois-tu, Dieu de nos pères ;
béni soit ton nom
dans toutes les générations, à jamais.
Que les cieux te bénissent
et toute ta création, dans tous les siècles.
###### 06
C’est toi qui as fait Adam ;
tu lui as fait une aide et un appui :
Ève, sa femme.
Et de tous deux est né le genre humain.
C’est toi qui as dit :
“Il n’est pas bon que l’homme soit seul.
Je vais lui faire une aide
qui lui soit semblable.”
###### 07
Ce n’est donc pas pour une union illégitime
que je prends ma sœur que voici,
mais dans la vérité de la Loi.
Daigne me faire miséricorde, ainsi qu’à elle,
et nous mener ensemble à un âge avancé. »
###### 08
Puis ils dirent d’une seule voix :
« Amen ! Amen ! »
###### 09
Et ils se couchèrent pour la nuit. Quant à Ragouël, il se leva, appela ses serviteurs, et ils s’en allèrent creuser une tombe.
###### 10
« Car, se disait-il, si jamais Tobie était mort, nous serions objet de risée et de blâme. »
###### 11
Quand ils eurent fini de creuser la tombe, Ragouël rentra chez lui, appela sa femme
###### 12
et lui dit : « Envoie une jeune servante : qu’elle aille voir si Tobie est encore vivant. Et s’il est mort, nous l’enterrerons, sans que personne ne le sache. »
###### 13
Ils envoyèrent donc la servante, allumèrent pour elle une lampe et lui ouvrirent la porte. Elle entra et les trouva couchés qui dormaient ensemble.
###### 14
La servante sortit pour annoncer que Tobie était vivant et que rien de mal n’était arrivé.
###### 15
Alors Ragouël bénit le Dieu du ciel en s’écriant :
« Béni sois-tu, ô Dieu,
par toute bénédiction pure !
Béni sois-tu dans tous les siècles !
###### 16
Béni sois-tu de m’avoir rempli de joie :
ce que je redoutais ne s’est pas réalisé,
mais tu as agi envers nous
selon ta grande miséricorde.
###### 17
Béni sois-tu d’avoir pris en pitié deux enfants uniques !
Accorde-leur, ô Maître, miséricorde et salut ;
fais qu’ils arrivent ensemble au terme de leur vie
dans l’allégresse et la miséricorde. »
###### 18
Puis Ragouël donna aux serviteurs l’ordre de combler la tombe, avant le point du jour.
###### 19
Il dit à sa femme de cuire des pains en quantité ; lui, il alla choisir deux bœufs et quatre béliers de son troupeau, qu’il fit apprêter. Et on commença les préparatifs.
###### 20
Alors il appela Tobie et lui dit : « J’en fais le serment : Pendant quatorze jours, tu ne bougeras pas d’ici, mais tu resteras chez moi à manger et à boire, et tu rendras la joie à ma fille, qui a tant souffert.
###### 21
Reçois dès aujourd’hui la moitié de mes biens, puis tu retourneras en bonne santé chez ton père. Quant au reste de ma fortune, elle vous reviendra après ma mort et celle de ma femme. Confiance, mon enfant ! Je suis ton père et Edna est ta mère. Nous sommes auprès de toi et de ta sœur, nous le sommes dès maintenant et pour toujours. Confiance, mon enfant ! »
