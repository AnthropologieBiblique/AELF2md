---
aliases : 
- Tobie 2
- Tobie 2
- Tb 2
- Tobit 2
tags : 
- Bible/Tb/2
- français
cssclass : français
---

# Tobie 2

###### 01
C’est ainsi que, sous le règne d’Asarhaddone, je revins chez moi, et ma femme Anna me fut rendue, ainsi que mon fils Tobie. Lors de notre fête de la Pentecôte, qui est la sainte fête des Semaines, on me prépara un bon repas et je m’étendis pour le prendre.
###### 02
On plaça devant moi une table et on me servit quantité de petits plats. Alors je dis à mon fils Tobie : « Va, mon enfant, essaie de trouver parmi nos frères déportés à Ninive un pauvre qui se souvienne de Dieu de tout son cœur ; amène-le pour qu’il partage mon repas. Moi, mon enfant, j’attendrai que tu sois de retour. »
###### 03
Tobie partit chercher un pauvre parmi nos frères. À son retour, il dit : « Père ! – Qu’y a-t-il, mon enfant ? – Père, quelqu’un de notre nation a été assassiné ; il a été jeté sur la place publique, il vient d’y être étranglé. »
###### 04
Laissant là mon repas avant même d’y avoir touché, je me précipitai, j’enlevai de la place le cadavre que je déposai dans une dépendance en attendant le coucher du soleil pour l’enterrer.
###### 05
À mon retour, je pris un bain et je mangeai mon pain dans le deuil,
###### 06
en me rappelant la parole que le prophète Amos avait dite sur Béthel :
« Vos fêtes se changeront en deuil,
et tous vos chants en lamentation. »
###### 07
Et je me mis à pleurer. Puis, quand le soleil fut couché, je partis creuser une tombe pour enterrer le mort.
###### 08
Mes voisins se moquaient de moi : « N’a-t-il donc plus peur ?, disaient-ils. On l’a déjà recherché pour le tuer à cause de cette manière d’agir, et il a dû s’enfuir. Et voilà qu’il recommence à enterrer les morts ! »
###### 09
Cette nuit-là, je pris un bain, puis j’entrai dans la cour de ma maison et je m’étendis contre le mur de la cour, le visage découvert à cause de la chaleur.
###### 10
Je ne m’aperçus pas qu’il y avait des moineaux dans le mur, au-dessus de moi, et leur fiente me tomba toute chaude dans les yeux et provoqua des leucomes. Je me rendis chez les médecins pour être soigné, mais plus ils m’appliquaient leurs baumes, plus ce voile blanchâtre m’empêchait de voir, et je finis par devenir complètement aveugle : je restai privé de la vue durant quatre ans. Tous mes frères s’apitoyaient sur mon sort, et Ahikar pourvut à mes besoins pendant deux ans jusqu’à son départ pour l’Élymaïde.
###### 11
Pendant ce temps-là, ma femme Anna, pour gagner sa vie, exécutait des travaux d’ouvrière,
###### 12
qu’elle livrait à ses patrons, et ceux-ci lui réglaient son salaire. Or, le sept du mois de Dystros, elle acheva une pièce de tissu et l’envoya à ses patrons ; ils lui réglèrent tout ce qu’ils lui devaient et, pour un repas de fête, ils lui offrirent un chevreau pris à sa mère.
###### 13
Arrivé chez moi, le chevreau se mit à bêler. J’appelai ma femme et lui dis : « D’où vient ce chevreau ? N’aurait-il pas été volé ? Rends-le à ses propriétaires. Car nous ne sommes pas autorisés à manger quoi que ce soit de volé ! »
###### 14
Elle me dit : « Mais c’est un cadeau qu’on m’a donné en plus de mon salaire ! » Je refusai de la croire, je lui dis de rendre l’animal à ses propriétaires, et je me fâchai contre ma femme à cause de cela. Alors elle me répliqua : « Qu’en est-il donc de tes aumônes ? Qu’en est-il de tes bonnes œuvres ? On voit bien maintenant ce qu’elles signifient ! »
