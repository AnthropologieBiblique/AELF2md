---
aliases : 
- Tobie 1
- Tobie 1
- Tb 1
- Tobit 1
tags : 
- Bible/Tb/1
- français
cssclass : français
---

# Tobie 1

###### 01
VOICI L’HISTOIRE de Tobith, fils de Tobiël, fils d’Ananiël, fils d’Adouël, fils de Gabaël, fils de Raphaël, fils de Ragouël, de la descendance d’Asiël, de la tribu de Nephtali.
###### 02
À l’époque de Salmanasar, roi des Assyriens, Tobith fut déporté de Thisbé ; cette ville se trouve au sud de Cadès de Nephtali, en Haute-Galilée, à l’est de Haçor, au-delà de la route qui conduit à l’ouest, au nord de Phogor.
###### 03
Moi, Tobith, j’ai marché dans les voies de la vérité et j’ai fait ce qui est juste tous les jours de ma vie ; j’ai fait beaucoup d’aumônes à mes frères et aux gens de ma nation qui avaient été emmenés captifs avec moi au pays des Assyriens, à Ninive.
###### 04
Quand j’étais jeune, je vivais dans mon pays, la terre d’Israël. Toute la tribu de mon ancêtre Nephtali s’était séparée de la maison de David et de Jérusalem. Et pourtant, cette ville avait été choisie parmi tout Israël comme lieu de sacrifice pour toutes les tribus d’Israël : c’est là qu’avait été consacré le temple où Dieu réside, temple bâti pour toutes les générations à venir.
###### 05
Tous mes frères, ainsi que la maison de mon ancêtre Nephtali, offraient des sacrifices, sur tous les monts de Galilée, en l’honneur du veau que le roi d’Israël Jéroboam avait érigé à Dane.
###### 06
Quant à moi, j’étais le seul à me rendre souvent à Jérusalem pour les fêtes, selon ce qui est écrit pour tout Israël dans une ordonnance perpétuelle. J’accourais à Jérusalem, apportant les prémices, les premiers-nés, les dîmes des troupeaux et les premières tontes des brebis ;
###### 07
je les donnais aux prêtres, fils d’Aaron, pour le service de l’autel, et je donnais la dîme du froment, du vin, de l’huile, des grenades, des figues et des autres fruits aux fils de Lévi qui officient à Jérusalem. J’acquittais la deuxième dîme en argent, sauf les années sabbatiques, et j’allais dépenser cette somme à Jérusalem chaque année.
###### 08
La troisième dîme, je la donnais aux orphelins, aux veuves et aux immigrés qui résidaient chez les fils d’Israël, je la leur apportais tous les trois ans et nous la mangions. Je suivais en cela l’ordonnance faite à ce sujet dans la loi de Moïse et les commandements qu’avait donnés Débora, la mère de mon père, car ce dernier était mort, me laissant orphelin.
###### 09
Quand je fus arrivé à l’âge adulte, je pris femme dans la lignée de nos pères et, d’elle, j’ai eu un fils, que j’appelai Tobie.
###### 10
Déporté chez les Assyriens, j’arrivai à Ninive. Tous mes frères et les gens de ma race mangeaient la même nourriture que les païens,
###### 11
mais moi, je me gardais de manger une telle nourriture.
###### 12
Puisque je me souvenais de mon Dieu de toute mon âme,
###### 13
le Très-Haut m’accorda grâce et beauté aux yeux de Salmanasar, et j’achetais pour le roi tout ce dont il avait besoin ;
###### 14
je me rendais en Médie où, jusqu’à sa mort, je fis des achats pour lui. Et dans ce pays de Médie, je confiai à Gabaël, frère de Gabri, des bourses qui contenaient dix talents d’argent.
###### 15
Quand Salmanasar fut mort et que Sennakérib, son fils, lui succéda, les routes de Médie furent bloquées et je ne pus continuer à me rendre en Médie.
###### 16
À l’époque de Salmanasar, je faisais beaucoup d’aumônes à mes frères de race ;
###### 17
je donnais mon pain à ceux qui avaient faim et des vêtements à ceux qui étaient nus ; si je voyais le cadavre de quelqu’un de ma nation, jeté derrière le rempart de Ninive, je l’enterrais.
###### 18
De même, j’enterrais tous ceux que tua Sennakérib. Il faut savoir que, lorsqu’il revint en fuite de Judée, aux jours du jugement que lui infligea le Roi du ciel pour les blasphèmes qu’il avait proférés, Sennakérib tua, dans sa fureur, de nombreux fils d’Israël ; je dérobais leurs corps et je les enterrais ; Sennakérib les chercha et ne les trouva pas.
###### 19
Mais un des habitants de Ninive alla dire au roi que c’était moi qui les enterrais, et je me cachai. Quand j’appris que le roi était renseigné à mon sujet et que j’étais recherché pour être mis à mort, je pris peur et m’enfuis furtivement.
###### 20
Tous mes biens furent saisis, et il ne me resta rien qui ne fût confisqué au profit du trésor royal, sauf ma femme Anna et mon fils Tobie.
###### 21
Moins de quarante jours plus tard, Sennakérib fut assassiné par deux de ses fils, qui s’enfuirent au mont Ararat, et son fils Asarhaddone lui succéda. Il plaça Ahikar, fils de mon frère Anaël, à la tête de toutes les finances de son royaume, et celui-ci eut donc la haute main sur toute l’administration.
###### 22
Alors Ahikar intervint en ma faveur, et je revins à Ninive. Ahikar, en effet, avait été grand échanson, garde du sceau, chef de l’administration et des finances sous Sennakérib, roi des Assyriens, et Asarhaddone l’avait reconduit dans ses fonctions. Or il était de ma famille : c’était mon neveu.
