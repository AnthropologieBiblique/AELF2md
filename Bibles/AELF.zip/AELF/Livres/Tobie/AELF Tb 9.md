---
aliases : 
- Tobie 9
- Tobie 9
- Tb 9
- Tobit 9
tags : 
- Bible/Tb/9
- français
cssclass : français
---

# Tobie 9

###### 01
Tobie appela Raphaël et lui dit :
###### 02
« Azarias, mon frère, prends avec toi quatre serviteurs et deux chameaux. Va trouver Gabaël à Raguès, donne-lui le reçu, prends l’argent et amène Gabaël avec toi pour mes noces.
3-
###### 04
Tu sais que mon père compte les jours et, si j’ai un seul jour de retard, je lui causerai beaucoup de peine. Tu connais aussi le serment qu’a fait Ragouël ; je ne puis aller à l’encontre de son serment. »
###### 05
Raphaël partit donc à Raguès de Médie avec quatre serviteurs et deux chameaux, et ils s’arrêtèrent pour la nuit chez Gabaël. Raphaël lui remit le reçu et lui apprit que Tobie, fils de Tobith, avait pris femme et l’invitait à son mariage. Gabaël alla chercher les sacoches munies de leurs sceaux, les compta devant Raphaël, et ils les chargèrent sur les chameaux.
###### 06
Ils partirent ensemble de bon matin pour aller aux noces. Arrivés chez Ragouël, ils trouvèrent Tobie à table. Celui-ci se leva d’un bond et salua Gabaël, qui se mit à pleurer et qui le bénit en disant : « Fils d’un homme de bien, juste et généreux, tu es toi-même un homme de bien ! Que le Seigneur du ciel te bénisse, toi et ta femme, ainsi que ton père et la mère de ta femme ! Que Dieu soit béni pour m’avoir donné de voir Tobith, mon cousin germain, dans un autre lui-même. »
