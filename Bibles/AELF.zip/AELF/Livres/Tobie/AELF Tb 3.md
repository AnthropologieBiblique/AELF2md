---
aliases : 
- Tobie 3
- Tobie 3
- Tb 3
- Tobit 3
tags : 
- Bible/Tb/3
- français
cssclass : français
---

# Tobie 3

###### 01
La mort dans l’âme, je gémissais et je pleurais ; puis, au milieu de mes gémissements, je commençai à prier :
###### 02
« Tu es juste, Seigneur,
toutes tes œuvres sont justes,
tous tes chemins, miséricorde et vérité ;
c’est toi qui juges le monde.
###### 03
Et maintenant, Seigneur,
souviens-toi de moi et regarde :
ne me punis pas pour mes péchés, mes égarements,
ni pour ceux de mes pères, qui ont péché devant toi
###### 04
et refusé d’entendre tes commandements.
Tu nous as livrés au pillage,
à la déportation et à la mort,
pour être la fable, la risée, le sarcasme
de toutes les nations où tu nous as disséminés.
###### 05
Et maintenant encore, ils sont vrais
les nombreux jugements que tu portes contre moi,
pour mes péchés et ceux de mes pères,
car nous n’avons pas pratiqué tes commandements
ni marché dans la vérité devant toi.
###### 06
Et maintenant, agis avec moi comme il te plaira,
ordonne que mon souffle me soit repris,
pour que je disparaisse de la face de la terre
et devienne, moi-même, terre.
Pour moi, mieux vaut mourir que vivre,
car j’ai entendu des insultes mensongères,
et je suis accablé de tristesse.
Seigneur, ordonne
que je sois délivré de cette adversité,
laisse-moi partir au séjour éternel,
et ne détourne pas de moi ta face, Seigneur.
Car, pour moi, mieux vaut mourir
que connaître tant d’adversité à longueur de vie.
Ainsi, je n’aurai plus à entendre
de telles insultes. »
###### 07
Or ce jour-là, Sarra, la fille de Ragouël d’Ecbatane en Médie, se fit, elle aussi, insulter par une jeune servante de son père :
###### 08
elle avait été mariée sept fois, et Asmodée, le pire des démons, tuait les maris avant qu’ils ne se soient approchés d’elle. Donc, la servante dit à Sarra : « C’est toi qui as tué tes maris ! En voilà déjà sept à qui tu as été donnée en mariage, et d’aucun d’entre eux tu n’as porté le nom.
###### 09
Pourquoi nous fouetter, sous prétexte que tes maris sont morts ? Va les rejoindre : puissions-nous ne jamais voir de toi un fils ni une fille ! »
###### 10
Ce jour-là, Sarra, la mort dans l’âme, se mit à pleurer. Et elle monta dans la chambre haute de la maison de son père avec l’intention de se pendre. Mais, à la réflexion, elle se dit : « Eh bien, non ! On irait insulter mon père et lui dire : “Tu n’avais qu’une fille, une fille très aimée, et elle s’est pendue à cause de ses malheurs !” Je ferais ainsi descendre mon vieux père plein de tristesse au séjour des morts. Mieux vaut pour moi ne pas me pendre, mais supplier le Seigneur de me faire mourir, pour que je n’aie plus à entendre de telles insultes à longueur de vie. »
###### 11
À l’instant même, elle étendit les mains vers la fenêtre et fit cette prière :
« Béni sois-tu, Dieu de miséricorde ;
béni soit ton nom pour les siècles ;
que toutes tes œuvres te bénissent à jamais !
###### 12
Et maintenant, j’élève vers toi
mon visage et mes yeux.
###### 13
Parle : que je disparaisse de la terre
et n’aie plus à entendre d’insultes.
###### 14
Tu sais, toi, Maître, que je suis indemne
de toute impureté d’homme.
###### 15
Je n’ai pas déshonoré mon nom
ni le nom de mon père sur ma terre d’exil.
Je suis la fille unique de mon père,
il n’a pas d’autre enfant pour hériter de lui,
ni de parent proche ou lointain
pour qui je devrais me garder comme épouse.
J’ai déjà perdu sept maris :
à quoi bon vivre encore ?
Et s’il ne te semble pas bon de me tuer, Seigneur,
entends au moins l’insulte qui m’est faite. »
###### 16
À cet instant précis, la prière de l’un et de l’autre fut portée en présence de la gloire de Dieu où elle fut entendue.
###### 17
Et Raphaël fut envoyé pour les guérir tous deux : à Tobith pour enlever le voile blanchâtre qui couvrait ses yeux afin que, de ses yeux, il voie la lumière de Dieu, et à Sarra, fille de Ragouël, pour la donner en mariage à Tobie, fils de Tobith, et expulser d’elle Asmodée, le pire des démons ; en effet c’est à Tobie que revenait le droit de l’épouser plutôt qu’à tous ses prétendants.
Juste à ce moment, Tobith rentrait de la cour dans sa maison tandis que Sarra, fille de Ragouël, descendait de la chambre haute.
