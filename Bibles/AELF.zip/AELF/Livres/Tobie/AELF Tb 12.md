---
aliases : 
- Tobie 12
- Tobie 12
- Tb 12
- Tobit 12
tags : 
- Bible/Tb/12
- français
cssclass : français
---

# Tobie 12

###### 01
Quand les noces furent achevées, Tobith appela son fils Tobie et lui dit : « Mon enfant, pense à donner son salaire à ton compagnon de voyage, et ajoute un supplément. »
###### 02
Tobie lui répondit : « Père, quelle somme vais-je lui donner comme salaire ? Même si je lui donnais la moitié des biens qu’il a rapportés avec moi, je n’y perdrais pas :
###### 03
il m’a ramené ici en bonne santé, il a guéri ma femme, il a rapporté l’argent avec moi, et il t’a guéri. Quelle somme vais-je donc lui donner comme salaire ?
###### 04
– Mon enfant, reprit Tobith, il est juste qu’il reçoive la moitié de tout ce qu’il a rapporté. »
###### 05
Tobith appela Raphaël et lui dit : « Accepte comme salaire la moitié de tout ce que tu as rapporté, et va, porte-toi bien ! »
###### 06
Alors l’ange les prit tous deux à part et leur dit : « Bénissez Dieu et célébrez-le devant tous les vivants pour le bien qu’il vous a fait. Bénissez-le et chantez son nom. Annoncez à tous les hommes les actions de Dieu comme elles le méritent, et n’hésitez pas à le célébrer.
###### 07
S’il est bon de tenir cachés les secrets d’un roi, il faut révéler les œuvres de Dieu et les célébrer comme elles le méritent.
Faites le bien, et le mal ne vous atteindra pas.
###### 08
Mieux vaut prier avec vérité et faire l’aumône avec justice, qu’être riche avec injustice. Mieux vaut faire l’aumône qu’amasser de l’or.
###### 09
L’aumône délivre de la mort et purifie de tout péché. Ceux qui font l’aumône seront rassasiés de vie,
###### 10
tandis que le pécheur et l’homme injuste sont leurs propres ennemis.
###### 11
Je veux vous révéler toute la vérité, sans rien vous cacher. Je viens de vous dire que, s’il est bon de tenir cachés les secrets d’un roi, il faut révéler les œuvres de Dieu comme elles le méritent.
###### 12
Eh bien ! Quand tu priais en même temps que Sarra, c’était moi qui présentais votre prière devant la gloire de Dieu, pour qu’il la garde en mémoire, et je faisais de même lorsque tu enterrais les morts.
###### 13
Quand tu n’as pas hésité à te lever, à laisser ton repas et à partir enterrer un mort, c’est alors que j’ai été envoyé vers toi pour te mettre à l’épreuve,
###### 14
mais Dieu m’a aussi envoyé pour te guérir, ainsi que Sarra, ta belle-fille.
###### 15
Moi, je suis Raphaël, l’un des sept anges qui se tiennent ou se présentent devant la gloire du Seigneur. »
###### 16
Les deux hommes furent alors bouleversés et ils tombèrent face contre terre, saisis de crainte.
###### 17
Mais Raphaël leur dit : « Ne craignez pas ! La paix soit avec vous ! Bénissez Dieu à jamais !
###### 18
Tant que je me suis trouvé avec vous, je n’y étais point par un effet de ma bienveillance, mais par la volonté de Dieu. Bénissez-le donc chaque jour, chantez-lui des hymnes !
###### 19
Vous avez cru me voir manger, mais ce que vous avez vu n’était qu’une apparence.
###### 20
Et maintenant, bénissez le Seigneur sur la terre ! Célébrez Dieu ! Voici que je remonte auprès de celui qui m’a envoyé. Mettez par écrit tout ce qui vous est arrivé. » Alors l’ange remonta au ciel.
###### 21
Ils se relevèrent, mais ils ne pouvaient plus le voir.
###### 22
Ils bénirent Dieu, chantèrent pour lui et le célébrèrent pour la grandeur de ses œuvres : un ange de Dieu leur était apparu !
