---
aliases : 
- Tobie 7
- Tobie 7
- Tb 7
- Tobit 7
tags : 
- Bible/Tb/7
- français
cssclass : français
---

# Tobie 7

###### 01
Entré à Ecbatane, Tobie dit à Raphaël : « Azarias, mon frère, conduis-moi tout droit chez notre frère Ragouël. » Raphaël le conduisit donc chez Ragouël. Ils le trouvèrent assis à l’entrée de la cour et le saluèrent les premiers. Il leur répondit : « Grande joie à vous, frères, soyez les bienvenus ! », et il les fit entrer dans sa maison.
###### 02
Il dit à sa femme Edna : « Comme ce jeune homme ressemble à mon frère Tobith ! »
###### 03
Edna les interrogea : « D’où êtes-vous, frères ? » Ils lui dirent : « Nous appartenons à la tribu des fils de Nephtali déportés à Ninive.
###### 04
– Connaissez-vous notre frère Tobith ?, demanda-t-elle. – Oui, nous le connaissons, dirent-ils.
###### 05
– Va-t-il bien ? – Il est vivant et en bonne santé. » Et Tobie ajouta : « C’est mon père. »
###### 06
Ragouël se précipita pour l’embrasser, se mit à pleurer et lui dit : « Béni sois-tu, mon enfant : tu es le fils d’un homme de bien ! Quel grand malheur que soit devenu aveugle cet homme juste et généreux ! » Il se jeta au cou de Tobie, son frère, et se remit à pleurer.
###### 07
Et sa femme Edna pleura sur Tobith, et Sarra, leur fille, pleura elle aussi.
###### 08
Ragouël tua un bélier de son troupeau pour recevoir ses hôtes chaleureusement.
###### 09
Tobie et Raphaël prirent un bain, ils se lavèrent, avant de prendre place pour le repas. Puis, Tobie dit à Raphaël : « Azarias, mon frère, demande à Ragouël de me donner en mariage Sarra ma parente. »
###### 10
Ragouël entendit ces mots et dit au jeune Tobie : « Cette nuit, mange, bois, prends du bon temps : toi seul as le droit d’épouser ma fille Sarra, et moi-même je n’ai pas le pouvoir de la donner à un autre homme, puisque tu es mon plus proche parent. Pourtant, je dois te dire la vérité, mon enfant :
###### 11
je l’ai donnée en mariage à sept de nos frères, et ils sont morts la nuit même, au moment où ils allaient s’approcher d’elle. Mais à présent, mon enfant, mange et bois : le Seigneur interviendra en votre faveur. »
###### 12
Tobie répliqua : « Je ne mangerai ni ne boirai rien, tant que tu n’auras pas pris de décision à mon sujet. » Ragouël lui dit : « Soit ! elle t’est donnée en mariage selon le décret du Livre de Moïse ; c’est un jugement du ciel qui te l’a accordée. Emmène donc ta sœur. Car, dès à présent, tu es son frère et elle est ta sœur. À partir d’aujourd’hui elle t’est donnée pour toujours. Que le Seigneur du ciel veille sur vous cette nuit, mon enfant, et vous comble de sa miséricorde et de sa paix ! »
###### 13
Ragouël appela Sarra, qui vint vers lui. Il prit la main de sa fille et la confia à Tobie, en disant : « Emmène-la : conformément à la Loi et au décret consigné dans le Livre de Moïse, elle t’est donnée pour femme. Prends-la et conduis-la en bonne santé chez ton père. Et que le Dieu du ciel vous guide dans la paix ! »
###### 14
Puis il appela sa femme et lui dit d’apporter une feuille sur laquelle il écrivit l’acte de mariage, selon lequel il donnait Sarra à Tobie conformément au décret de la loi de Moïse. Après quoi, on commença à manger et à boire.
###### 15
Ragouël s’adressa à sa femme Edna : « Va préparer la seconde chambre, ma sœur, et tu y conduiras notre fille. »
###### 16
Elle s’en alla préparer le lit dans la chambre, comme Ragouël l’avait demandé, y conduisit sa fille et pleura sur elle. Puis, elle essuya ses larmes et lui dit :
###### 17
« Confiance, ma fille ! Que le Seigneur du ciel change ta douleur en joie ! Confiance, ma fille ! » Puis elle se retira.
