---
aliases : 
- 2 Chroniques 14
- 2 Chroniques 14
- 2 Ch 14
- 2 Chronicles 14
tags : 
- Bible/2Ch/14
- français
cssclass : français
---

# 2 Chroniques 14

###### 01
Asa fit ce qui est bon et droit aux yeux du Seigneur son Dieu.
###### 02
Il supprima les autels d’origine étrangère et les lieux sacrés ; il brisa les stèles et abattit les poteaux sacrés.
###### 03
Il dit à Juda de chercher le Seigneur, Dieu de leurs pères, et de pratiquer la Loi et le Commandement.
###### 04
Il supprima de toutes les villes de Juda les lieux sacrés et les colonnes à encens. Et le royaume fut tranquille sous son règne.
###### 05
Il construisit en Juda des villes fortes, car le pays était tranquille. Et il n’y eut pas de guerre contre lui en ces années-là, car le Seigneur lui avait procuré le repos.
###### 06
Asa dit aux gens de Juda : « Construisons ces villes, entourons-les d’un rempart, avec des tours, des portes et des verrous. Tout le pays est encore devant nous. Comme nous avons cherché le Seigneur notre Dieu, il nous a cherchés et nous a donné le repos de tous côtés. »
Ils construisirent donc et le firent avec succès.
###### 07
Asa avait comme armée trois cent mille hommes de Juda portant le grand bouclier et la lance, et deux cent quatre-vingt mille hommes de Benjamin portant le petit bouclier et tirant à l’arc ; tous étaient de vaillants guerriers.
###### 08
Zèrah l’Éthiopien marcha contre eux avec une armée de mille milliers d’hommes et trois cents chars, et il parvint jusqu’à Marésha.
###### 09
Asa marcha au-devant de lui, et ils se rangèrent en bataille dans la vallée de Sefata, près de Marésha.
###### 10
Asa invoqua le Seigneur son Dieu, en disant : « Seigneur, il n’y a pas de différence pour toi entre aider le puissant et aider celui qui est sans force. Alors, aide-nous, Seigneur notre Dieu, car nous nous appuyons sur toi, et nous sommes venus, en ton nom, contre cette multitude. Tu es le Seigneur notre Dieu : qu’un mortel ne l’emporte pas sur toi ! »
###### 11
Le Seigneur battit les Éthiopiens devant Asa et devant les gens de Juda, et les Éthiopiens s’enfuirent.
###### 12
Asa et le peuple qui était avec lui les poursuivirent jusqu’à Guérar. Il tomba tant d’Éthiopiens qu’il n’y eut aucun survivant, parce qu’ils avaient été taillés en pièces devant le Seigneur et devant son armée. Asa et le peuple emportèrent un très grand butin.
###### 13
Ils frappèrent toutes les villes aux alentours de Guérar, car la terreur du Seigneur s’était emparée d’elles. Ils pillèrent toutes les villes, car il s’y trouvait un grand butin.
###### 14
Ils s’en prirent même aux enclos des troupeaux, ils emmenèrent du petit bétail en quantité et des chameaux. Puis ils revinrent à Jérusalem.
