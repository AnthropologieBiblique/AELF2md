---
aliases : 
- 2 Chroniques 7
- 2 Chroniques 7
- 2 Ch 7
- 2 Chronicles 7
tags : 
- Bible/2Ch/7
- français
cssclass : français
---

# 2 Chroniques 7

###### 01
Quand Salomon eut achevé de prier, le feu descendit du ciel, il dévora l’holocauste et les sacrifices ; et la gloire du Seigneur remplit la Maison.
###### 02
Les prêtres ne purent entrer dans la Maison du Seigneur, car la gloire du Seigneur remplissait la Maison du Seigneur.
###### 03
Tous les fils d’Israël, voyant le feu descendre et la gloire du Seigneur sur la Maison, s’inclinèrent face contre terre sur le dallage ; ils se prosternèrent pour rendre grâce au Seigneur « car il est bon, éternel est son amour ! »
###### 04
Le roi et tout le peuple offraient des sacrifices devant le Seigneur.
###### 05
Le roi Salomon offrit en sacrifice vingt-deux mille bœufs et cent vingt mille moutons. C’est ainsi que le roi et tout le peuple firent la dédicace de la Maison de Dieu.
###### 06
Les prêtres se tenaient à leur poste, ainsi que les lévites avec les instruments de musique du Seigneur, ceux qu’avait faits le roi David, afin de rendre grâce au Seigneur « car éternel est son amour ! », comme au temps où, par eux, David psalmodiait. Les prêtres, en face d’eux, sonnaient de la trompette, et tout Israël se tenait debout.
###### 07
Salomon consacra le milieu de la cour qui était devant la Maison du Seigneur. C’est là, en effet, qu’il offrit les holocaustes et les graisses des sacrifices de paix, car l’autel de bronze que Salomon avait fait ne pouvait pas contenir l’holocauste, l’offrande de céréales et les graisses.
###### 08
Salomon – et tout Israël avec lui – célébra, en ce temps-là, la fête pendant sept jours. Ce fut un très grand rassemblement depuis l’Entrée-de-Hamath jusqu’au Torrent d’Égypte.
###### 09
On avait célébré la dédicace de l’autel pendant sept jours ; le huitième jour, on fit une réunion solennelle, et la fête dura encore sept jours.
###### 10
Le vingt-troisième jour du septième mois, Salomon renvoya le peuple à ses tentes. Joyeux, ils avaient le cœur content pour le bien que le Seigneur avait accordé à David, à Salomon, et à Israël, son peuple.
###### 11
Salomon acheva la Maison du Seigneur et la maison du roi, et tout ce que Salomon avait désiré faire dans la Maison du Seigneur et dans sa propre maison, il le mena à bien.
###### 12
Alors le Seigneur apparut à Salomon durant la nuit, et il lui dit : « J’ai entendu ta prière et j’ai choisi pour moi ce lieu comme maison de sacrifices.
###### 13
Si je ferme le ciel et qu’il n’y ait pas de pluie, si je commande à la sauterelle de dévorer le pays, si j’envoie la peste dans mon peuple,
###### 14
et que mon peuple, sur qui est prononcé mon nom, s’incline et prie, s’il recherche ma face et revient de sa conduite mauvaise, moi, j’écouterai depuis les cieux, je pardonnerai son péché et je guérirai son pays.
###### 15
Maintenant mes yeux sont ouverts, et mes oreilles attentives à la prière faite en ce lieu.
###### 16
À présent, j’ai choisi et consacré cette Maison, afin que mon nom y soit à jamais ; mes yeux et mon cœur y seront pour toujours.
###### 17
Pour toi, si tu marches devant moi comme l’a fait David, ton père, afin d’agir en tout selon mes commandements, et si tu gardes mes décrets et mes ordonnances,
###### 18
alors je maintiendrai le trône de ta royauté selon ce que j’ai conclu avec David, ton père, en lui disant : “Aucun des tiens régnant sur Israël ne sera écarté.”
###### 19
Mais si vous vous détournez, et si vous abandonnez les commandements et les décrets que j’ai placés devant vous, si vous suivez et servez d’autres dieux et vous prosternez devant eux,
###### 20
alors j’arracherai les fils d’Israël de ma terre, celle que je leur ai donnée ; et cette Maison que j’ai consacrée à mon nom, je la rejetterai loin de ma face ; et j’en ferai la fable et la risée de tous les peuples.
###### 21
Cette Maison, qui avait été sublime, sera objet de stupéfaction pour quiconque passera près d’elle ; il dira : “Pourquoi donc le Seigneur a-t-il agi de cette manière envers ce pays et envers cette Maison ?”
###### 22
On lui répondra : “C’est qu’ils ont abandonné le Seigneur, Dieu de leurs pères, lui qui les avait fait sortir du pays d’Égypte. Ils se sont attachés à d’autres dieux, devant lesquels ils se sont prosternés et qu’ils ont servis. Voilà pourquoi il a fait venir sur eux tout ce malheur.” »
