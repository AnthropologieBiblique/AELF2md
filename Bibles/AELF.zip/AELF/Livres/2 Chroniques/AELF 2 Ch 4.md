---
aliases : 
- 2 Chroniques 4
- 2 Chroniques 4
- 2 Ch 4
- 2 Chronicles 4
tags : 
- Bible/2Ch/4
- français
cssclass : français
---

# 2 Chroniques 4

###### 01
Il fit un autel de bronze, dont la longueur était de vingt coudées, la largeur de vingt coudées et la hauteur de dix coudées.
###### 02
Il fit la Mer, bassin en métal fondu, de dix coudées de diamètre, car son pourtour était circulaire. Elle avait cinq coudées de haut. Un cordeau de trente coudées en aurait fait le tour.
###### 03
Au-dessous, des figures de bœufs encerclaient la Mer, tout autour, dix par coudées. Les bœufs étaient disposés sur deux rangées, fondus ensemble avec la Mer.
###### 04
La Mer était dressée sur douze bœufs : trois faisaient face au nord, trois faisaient face à l’ouest, trois faisaient face au sud, trois faisaient face à l’est. La Mer reposait directement dessus, leurs arrière-trains étaient tournés vers l’intérieur.
###### 05
L’épaisseur de la Mer était d’une largeur de paume, son rebord était comme le bord d’une coupe, en forme de fleur de lis. Sa contenance était de trois mille mesures.
###### 06
Il fit dix cuves, qu’il disposa ainsi : cinq à droite et cinq à gauche. Elles servaient aux ablutions, mais on y nettoyait aussi ce qui était utile pour l’holocauste. Les prêtres faisaient leurs ablutions dans la Mer.
###### 07
Il fit dix chandeliers d’or selon le modèle prescrit, et il les plaça dans la Grande Salle : cinq à droite et cinq à gauche.
###### 08
Il fit dix tables et les plaça dans la Grande Salle : cinq à droite et cinq à gauche. Il fit cent bols en or pour l’aspersion.
###### 09
Il fit le parvis des prêtres et la grande cour, ainsi que les portes pour la grande cour. Et ces portes, il les plaqua de bronze.
###### 10
Quant à la Mer, il la posa du côté droit, au sud-est.
###### 11
Houram fit les vases, les pelles, et les bols pour l’aspersion. Houram acheva le travail qu’il avait à faire pour le roi Salomon dans la Maison de Dieu :
###### 12
les deux colonnes, les arrondis des chapiteaux sur le sommet des deux colonnes ; les deux filets pour couvrir les deux arrondis des chapiteaux sur le sommet des colonnes ;
###### 13
les quatre cents grenades destinées aux deux filets – deux rangées de grenades par filet –, de façon à couvrir les deux arrondis des chapiteaux, jusque sur le flanc des colonnes ;
###### 14
il fit les bases et fit les cuves sur les bases ;
###### 15
la Mer – une seule –, avec les douze bœufs en dessous d’elle ;
###### 16
les vases, les pelles, les fourchettes : tous les objets. Houram-Abiv les avait fabriqués en bronze luisant, pour le roi Salomon dans la Maison du Seigneur.
###### 17
C’est dans la région du Jourdain, entre Souccoth et Seréda, que le roi les avait fait mouler dans des couches d’argile.
###### 18
Salomon fit tous ces objets. Il y en avait tant que l’on ne pouvait estimer le poids du bronze employé.
###### 19
Salomon fit tous les objets de la Maison de Dieu : l’autel d’or, et les tables pour le pain de l’offrande ;
###### 20
les chandeliers et leurs lampes, en or fin, que l’on allume selon la règle devant le Saint des saints ;
###### 21
les fleurs, les lampes et les pincettes, en or, d’un or incomparable ;
###### 22
les ciseaux, les bols pour l’aspersion, les gobelets, les brûle-parfums, en or fin ; l’entrée de la Maison, ses portes intérieures pour le Saint des saints, et les portes de la Maison pour la Grande Salle : en or !
