---
aliases : 
- 2 Chroniques 11
- 2 Chroniques 11
- 2 Ch 11
- 2 Chronicles 11
tags : 
- Bible/2Ch/11
- français
cssclass : français
---

# 2 Chroniques 11

###### 01
Roboam arriva à Jérusalem. Il rassembla la maison de Juda et de Benjamin : cent quatre-vingt mille guerriers d’élite, pour combattre Israël, afin de rendre la royauté à Roboam.
###### 02
Alors la parole du Seigneur fut adressée à Shemaya, homme de Dieu :
###### 03
« Parle à Roboam, fils de Salomon, roi de Juda, ainsi qu’à tout Israël, dans le territoire de Juda et de Benjamin :
###### 04
“Ainsi parle le Seigneur : Ne montez pas, ne faites pas la guerre à vos frères. Retournez chacun chez soi, car je suis moi-même à l’origine de cette affaire.” » Alors ils écoutèrent les paroles du Seigneur et ils s’en retournèrent, au lieu de marcher contre Jéroboam.
###### 05
Roboam résida à Jérusalem et construisit en Juda des villes fortes.
###### 06
Il construisit Bethléem, Étam, Teqoa,
###### 07
Beth-Sour, Soko, Adoullam,
###### 08
ainsi que Gath, Marésha, Zif,
###### 09
Adoraïm, Lakish, Azéqa,
###### 10
Soréa, Ayyalone et Hébron, qui sont des villes fortes en Juda et en Benjamin.
###### 11
Il les fortifia puissamment et y plaça des gouverneurs, ainsi que des dépôts de vivres, d’huile et de vin.
###### 12
Dans chacune de ces villes, il y avait des boucliers et des lances. Il rendit ces villes extrêmement fortes, et il eut pour lui Juda et Benjamin.
###### 13
Les prêtres et les lévites qui se trouvaient dans tout Israël vinrent de tout leur territoire se présenter devant lui.
###### 14
Les lévites, en effet, abandonnèrent leurs pâturages et leurs propriétés, et vinrent en Juda et à Jérusalem, parce que Jéroboam et ses fils les avaient écartés du sacerdoce du Seigneur.
###### 15
Jéroboam institua des prêtres à lui pour les lieux sacrés, pour les boucs et les veaux, idoles qu’il avait fabriquées.
###### 16
À la suite des lévites, les hommes de toutes les tribus d’Israël qui prenaient à cœur de chercher le Seigneur, Dieu d’Israël, vinrent à Jérusalem pour sacrifier au Seigneur, Dieu de leurs pères.
###### 17
Pendant trois ans, ils rendirent plus fort le royaume de Juda et ils soutinrent Roboam, fils de Salomon, car pendant trois ans ils marchèrent dans le chemin de David et de Salomon.
###### 18
Roboam prit pour femme Mahalath, fille de Yerimoth, fils de David, et d’Abihaïl, fille d’Éliab, fils de Jessé.
###### 19
Elle lui enfanta des fils : Yéoush, Shemarya et Zaham.
###### 20
Après elle, Roboam prit Maaka, fille d’Absalom, qui lui enfanta Abiya, Attaï, Ziza et Shelomith.
###### 21
Roboam aima Maaka, fille d’Absalom, plus que toutes ses autres femmes et concubines. Il eut en effet dix-huit femmes et soixante concubines, et il engendra vingt-huit fils et soixante filles.
###### 22
Aussi Roboam donna-t-il le premier rang à Abiya, fils de Maaka, comme chef parmi ses frères, afin de le faire roi.
###### 23
Il eut l’intelligence de disperser tous ses fils dans toutes les régions de Juda et de Benjamin, et dans toutes les villes fortes ; il leur procura des vivres en abondance et demanda pour eux des femmes en grand nombre.
