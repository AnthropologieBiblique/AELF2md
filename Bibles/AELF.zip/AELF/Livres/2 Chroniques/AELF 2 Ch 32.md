---
aliases : 
- 2 Chroniques 32
- 2 Chroniques 32
- 2 Ch 32
- 2 Chronicles 32
tags : 
- Bible/2Ch/32
- français
cssclass : français
---

# 2 Chroniques 32

###### 01
Après ces événements et ces actes de loyauté, Sennakérib, roi d’Assour, se mit en marche et entra en Juda. Il campa contre les villes fortifiées et donna l’ordre d’en forcer les remparts.
###### 02
Quand Ézékias vit que Sennakérib arrivait avec l’intention d’attaquer Jérusalem,
###### 03
il tint conseil avec ses officiers et ses vaillants guerriers pour obstruer les eaux des sources qui étaient en dehors de la ville, et ils lui apportèrent leur aide.
###### 04
Une foule nombreuse se rassembla, et l’on obstrua toutes les sources, ainsi que le torrent qui coulait au milieu du pays. On disait : « Pourquoi les rois d’Assour trouveraient-ils, en arrivant, de l’eau en abondance ? »
###### 05
Ézékias se mit courageusement à rebâtir tout le rempart qui était en ruine et à restaurer les tours. Il édifia un second mur à l’extérieur, fortifia le Terre-Plein de la Cité de David, et fabriqua en quantité des javelots et des boucliers.
###### 06
Il plaça les officiers de l’armée à la tête du peuple, les réunit près de lui sur la place à la porte de la ville, et, s’adressant à leur cœur, il leur dit :
###### 07
« Soyez forts et courageux ! Ne craignez pas, ne vous effrayez pas devant le roi d’Assour, ni devant la multitude qui est avec lui. Car il y a plus grand avec nous qu’avec lui :
###### 08
avec lui, une force humaine ; avec nous, le Seigneur notre Dieu, pour nous secourir et mener nos combats. » Le peuple trouva soutien dans les paroles d’Ézékias, roi de Juda.
###### 09
Après cela, Sennakérib, roi d’Assour, qui se trouvait lui-même, avec toute son armée, devant la ville de Lakish, envoya ses serviteurs à Jérusalem vers Ézékias, roi de Juda, et vers tous les habitants de Juda qui étaient à Jérusalem, pour leur dire :
###### 10
« Ainsi parle Sennakérib, roi d’Assour : En quoi mettez-vous votre confiance, vous qui êtes assiégés dans Jérusalem ?
###### 11
Ézékias n’est-il pas en train de vous duper, pour vous faire mourir de faim et de soif, lorsqu’il dit : “Le Seigneur notre Dieu nous délivrera de la main du roi d’Assour” ?
###### 12
N’est-ce pas lui, Ézékias, qui a supprimé ses lieux sacrés et ses autels, en disant aux gens de Juda et de Jérusalem ces mots : “C’est devant un seul autel que vous vous prosternerez et que vous brûlerez de l’encens” ?
###### 13
Ne savez-vous pas ce que nous avons fait, moi et mes pères, à tous les peuples des autres pays ? Les dieux des nations ont-ils été capables de délivrer leur pays de ma main ?
###### 14
De tous les dieux de ces nations que mes pères ont voués à l’anathème, quel est celui qui a pu délivrer son peuple de ma main, pour que votre dieu puisse vous délivrer de ma main ?
###### 15
Et maintenant, qu’Ézékias ne vous trompe pas et ne vous dupe pas ! Ne vous fiez pas à lui, car aucun dieu d’aucune nation ni d’aucun royaume ne peut délivrer son peuple de ma main, ni de la main de mes pères ! À plus forte raison, vos dieux ne vous délivreront pas de ma main ! »
###### 16
Les serviteurs de Sennakérib parlèrent encore contre le Seigneur Dieu et contre Ézékias, son serviteur.
###### 17
Sennakérib écrivit également des lettres pour insulter le Seigneur, Dieu d’Israël. Voilà ce qu’il disait contre lui : « De même que les dieux des nations des pays n’ont pu délivrer leur peuple de ma main, de même le dieu d’Ézékias ne délivrera pas son peuple de ma main. »
###### 18
Les serviteurs de Sennakérib crièrent cela d’une voix forte, en judéen, au peuple de Jérusalem qui était sur le rempart, pour lui faire peur et l’épouvanter, afin de s’emparer de la ville.
###### 19
Ils parlaient du Dieu de Jérusalem comme des dieux des autres peuples de la terre, qui sont ouvrage de mains humaines.
###### 20
Dans cette situation, le roi Ézékias et le prophète Isaïe, fils d’Amots, se mirent en prière et supplièrent le ciel.
###### 21
Alors le Seigneur envoya un ange qui anéantit tous les vaillants guerriers, les chefs et les officiers, dans le camp du roi d’Assour. Celui-ci retourna dans son pays, la honte au visage. Il entra dans la maison de son dieu, et quelques-uns de ses propres enfants le mirent à mort par l’épée.
###### 22
Ainsi, le Seigneur sauva Ézékias et les habitants de Jérusalem de la main de Sennakérib, roi d’Assour, et de la main de tous les ennemis : il leur assura la tranquillité de tous côtés.
###### 23
Beaucoup de gens apportèrent à Jérusalem des offrandes pour le Seigneur, et de riches présents à Ézékias, roi de Juda. Désormais, son prestige grandit aux yeux de toutes les nations.
###### 24
En ces jours-là, Ézékias fut atteint d’une maladie mortelle. Il pria le Seigneur qui lui parla et lui accorda un prodige.
###### 25
Mais Ézékias ne répondit pas au bienfait reçu, car son cœur s’était enflé d’orgueil. Aussi la colère du Seigneur fut-elle sur lui, sur Juda et Jérusalem.
###### 26
Alors Ézékias, dont le cœur était orgueilleux, s’humilia, et les habitants de Jérusalem avec lui. Et la colère du Seigneur ne vint pas sur eux pendant la vie d’Ézékias.
###### 27
Ézékias eut richesse et gloire en très grande abondance. Il amassa des trésors : argent, or, pierres précieuses, aromates, boucliers, et toute sorte d’objets précieux.
###### 28
Il eut des entrepôts pour ses provisions de froment, de vin nouveau et d’huile fraîche, des étables pour toute espèce de bétail, et des troupeaux pour ses parcs.
###### 29
Il se construisit des villes, il eut de nombreux troupeaux de petit et de gros bétail, car Dieu lui avait donné de très grands biens.
###### 30
C’est lui, Ézékias, qui obstrua la sortie supérieure des eaux du Guihone, et les détourna en bas vers l’ouest de la Cité de David. Ézékias réussit dans toutes ses entreprises.
###### 31
Et même, face aux ambassadeurs que les princes de Babylone lui envoyèrent afin de s’informer du prodige qui avait eu lieu dans le pays, c’est pour le mettre à l’épreuve que Dieu l’abandonna, pour connaître le fond de son cœur.
###### 32
Le reste des actions d’Ézékias, ce qu’il a fait avec fidélité,
voici que cela est écrit dans la Vision du prophète Isaïe, fils d’Amots,
et dans le livre des Annales des rois de Juda et d’Israël.
###### 33
Ézékias reposa avec ses pères,
et on l’ensevelit dans la partie haute
des tombeaux des fils de David.
À sa mort, tous les gens de Juda
et les habitants de Jérusalem lui rendirent hommage.
Son fils Manassé régna à sa place.
