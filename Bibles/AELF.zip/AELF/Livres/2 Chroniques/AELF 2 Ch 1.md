---
aliases : 
- 2 Chroniques 1
- 2 Chroniques 1
- 2 Ch 1
- 2 Chronicles 1
tags : 
- Bible/2Ch/1
- français
cssclass : français
---

# 2 Chroniques 1

###### 01
SALOMON, FILS DE DAVID, s’affermit dans sa royauté. Le Seigneur son Dieu était avec lui ; il l’éleva au sommet de la grandeur.
###### 02
Salomon s’adressa à tout Israël : aux officiers de millier et de centaine, aux juges et à tous les responsables de tout Israël, chefs des familles.
###### 03
Salomon et toute l’assemblée avec lui se rendirent au lieu sacré de Gabaon. C’est là que se trouvait la tente de la Rencontre de Dieu, celle que Moïse, le serviteur du Seigneur, avait faite dans le désert.
###### 04
Mais l’arche de Dieu, David l’avait fait monter de Qiryath-Yearim vers l’endroit qu’il avait fait préparer pour elle ; pour elle, en effet, il avait dressé une tente à Jérusalem.
###### 05
À Gabaon, devant la Demeure du Seigneur, se trouvait l’autel de bronze, qu’avait fait Beçalel, fils d’Ouri, fils de Hour. Alors Salomon et l’assemblée consultèrent le Seigneur.
###### 06
En ce lieu, Salomon monta à l’autel de bronze qui était devant le Seigneur, près de la tente de la Rencontre, et il y offrit en sacrifice mille holocaustes.
###### 07
Cette nuit-là, Dieu apparut à Salomon et lui dit : « Demande ce que je dois te donner. »
###### 08
Salomon répondit à Dieu : « Tu as traité David, mon père, avec une grande fidélité, et tu m’as fait roi à sa place.
###### 09
À présent, Seigneur Dieu, la parole que tu as adressée à David mon père se vérifie, car c’est toi qui m’as fait roi sur un peuple aussi nombreux que la poussière de la terre.
###### 10
Maintenant, Seigneur, donne-moi sagesse et connaissance, pour que je sache comment me comporter à la tête de ce peuple. Qui, en effet, peut gouverner ce grand peuple qui est le tien ? »
###### 11
Dieu répondit à Salomon : « Puisque c’est cela que tu as pris à cœur et que tu ne m’as demandé ni richesse, ni biens, ni gloire, ni la vie de tes ennemis, puisque tu ne m’as pas demandé non plus de longs jours, mais que tu as demandé pour toi sagesse et connaissance, afin de gouverner mon peuple sur lequel je te fais roi,
###### 12
la sagesse et la connaissance te sont données. Je te donnerai aussi la richesse, les biens et la gloire, comme aucun roi n’en a eu avant toi et comme aucun n’en aura après toi. »
###### 13
Salomon quitta le lieu sacré de Gabaon pour Jérusalem, loin de la tente de la Rencontre, et il régna sur Israël.
###### 14
Salomon rassembla des chars et des cavaliers ; il eut ainsi mille quatre cents chars et douze mille cavaliers ; il les cantonna dans les villes de garnison et près du roi, à Jérusalem.
###### 15
À Jérusalem, le roi fit abonder l’argent et l’or autant que les pierres, et les cèdres autant que les sycomores dans le Bas-Pays.
###### 16
Les chevaux de Salomon provenaient d’Égypte, et le groupe des courtiers du roi, à Qewé, les achetaient pour un prix convenu.
###### 17
Ces derniers montaient et ramenaient d’Égypte un char pour six cents pièces d’argent et un cheval pour cent cinquante. Il en était de même pour tous les rois hittites et pour les rois d’Aram que ces courtiers approvisionnaient.
###### 18
Salomon donna l’ordre de bâtir une maison pour le nom du Seigneur et, pour lui-même, une maison royale.
