---
aliases : 
- 2 Chroniques 2
- 2 Chroniques 2
- 2 Ch 2
- 2 Chronicles 2
tags : 
- Bible/2Ch/2
- français
cssclass : français
---

# 2 Chroniques 2

###### 01
Salomon engagea soixante-dix mille porteurs, quatre-vingt mille ouvriers pour les carrières dans la montagne et, avec eux, trois mille six cents contremaîtres.
###### 02
Salomon envoya ce message à Houram, roi de Tyr : « Tu as agi en faveur de mon père David, à qui tu as fait parvenir des cèdres pour se bâtir une maison où habiter.
###### 03
Or voici que je vais bâtir une maison pour le nom du Seigneur mon Dieu ; je la lui consacrerai ; on y brûlera de l’encens aromatique devant lui ; on y disposera la rangée de pains pour l’offrande perpétuelle et on y fera des holocaustes matin et soir, pour les sabbats, les nouvelles lunes et les solennités du Seigneur notre Dieu. Cela incombe à Israël pour toujours.
###### 04
La maison que je vais bâtir sera grande, car notre Dieu est plus grand que tous les dieux.
###### 05
Mais qui serait capable de lui bâtir une maison, quand les cieux et les hauteurs des cieux ne peuvent le contenir ? Et qui suis-je, moi, pour lui bâtir une maison, si ce n’était en vue de brûler de l’encens devant lui ?
###### 06
Maintenant, envoie-moi un homme habile à travailler l’or, l’argent, le bronze, le fer, la pourpre rouge, le carmin et la pourpre violette, et connaissant l’art de la gravure ; il se joindra aux artisans qui sont près de moi en Juda et à Jérusalem, ceux que David mon père a préparés.
###### 07
Fais-moi parvenir du Liban des bois de cèdre, de cyprès et de santal, car je sais que tes serviteurs peuvent abattre les arbres du Liban. Et voici que mes serviteurs seront avec tes serviteurs,
###### 08
pour me préparer des bois en quantité, car la Maison que je vais bâtir sera grande et merveilleuse.
###### 09
À tes serviteurs, les bûcherons qui abattront ces arbres, je donne, pour les nourrir, vingt mille quintaux de blé, vingt mille quintaux d’orge, ainsi que vingt mille mesures de vin et vingt mille mesures d’huile. »
###### 10
Houram, roi de Tyr, répondit par une lettre qu’il envoya à Salomon : « C’est parce que le Seigneur aime son peuple qu’il t’a établi roi sur eux. »
###### 11
Houram dit encore : « Béni soit le Seigneur, Dieu d’Israël, lui qui a fait le ciel et la terre ! Il a donné au roi David un fils sage, prudent et intelligent, qui bâtira une maison pour le Seigneur et, pour lui-même, une maison royale.
###### 12
Maintenant j’envoie un homme habile et intelligent, appelé Houram-Abi ;
###### 13
il est le fils d’une femme originaire de Dane, mais son père est de Tyr. Il sait travailler l’or, l’argent, le bronze, le fer, la pierre, le bois, la pourpre rouge, la pourpre violette, le lin et le carmin ; il connaît l’art de la gravure et saura réaliser toute œuvre qui lui sera confiée, en collaborant avec tes artisans et ceux de mon seigneur David, ton père.
###### 14
Et maintenant, le blé, l’orge, l’huile et le vin dont mon seigneur a parlé, qu’il les envoie à ses serviteurs.
###### 15
De notre côté, nous abattrons des arbres du Liban, selon tous tes besoins ; nous te les apporterons à Jaffa par radeaux sur la mer, et toi, tu les feras monter à Jérusalem. »
###### 16
Salomon recensa tous les étrangers qui résidaient dans le pays d’Israël, après le recensement qu’avait fait David son père : on en trouva cent cinquante-trois mille six cents.
###### 17
Il en employa soixante-dix mille comme porteurs, quatre-vingt mille comme ouvriers pour les carrières dans la montagne et trois mille six cents comme contremaîtres pour faire travailler les gens.
