---
aliases : 
- 2 Chroniques 31
- 2 Chroniques 31
- 2 Ch 31
- 2 Chronicles 31
tags : 
- Bible/2Ch/31
- français
cssclass : français
---

# 2 Chroniques 31

###### 01
Lorsque tout cela fut achevé, tous les fils d’Israël qui étaient présents partirent pour les villes de Juda. Ils brisèrent les stèles, coupèrent les poteaux sacrés, détruisirent complètement les lieux sacrés et les autels dans tout le territoire de Juda et de Benjamin, d’Éphraïm et de Manassé. Ensuite, tous les fils d’Israël retournèrent dans leurs villes, chacun dans sa propriété.
###### 02
Ézékias établit les classes des prêtres et des lévites, classe par classe, chacun selon son service, qu’il soit prêtre ou lévite, pour s’occuper des holocaustes et des sacrifices de paix, pour officier, rendre grâce et louer, aux portes des camps du Seigneur.
###### 03
Le roi fit don d’une part de ses biens pour les holocaustes, holocaustes du matin et du soir, holocaustes des sabbats, des nouvelles lunes et des solennités, selon ce qui est écrit dans la Loi du Seigneur.
###### 04
Il dit au peuple qui habitait Jérusalem de donner la part qui revient aux prêtres et aux lévites, pour qu’ils s’attachent fermement à la Loi du Seigneur.
###### 05
Dès que cette parole se fut répandue, les fils d’Israël offrirent en abondance les prémices du froment, du vin nouveau, de l’huile fraîche, du miel et de tous les produits des champs. Ils apportèrent la dîme de tout, en abondance.
###### 06
Les fils d’Israël et de Juda qui habitaient dans les villes de Juda, apportèrent à leur tour la dîme du gros et du petit bétail, ainsi que la dîme des offrandes saintes consacrées au Seigneur leur Dieu. Et ils en firent des tas et des tas.
###### 07
Le troisième mois, on commença à former les tas, et le septième mois, tout était terminé.
###### 08
Ézékias et les princes vinrent voir tout ce qui avait été entassé, et ils bénirent le Seigneur et son peuple Israël.
###### 09
Ézékias interrogea à ce sujet les prêtres et les lévites.
###### 10
Azarias, le chef des prêtres, de la maison de Sadoc, lui dit : « Depuis que l’on a commencé d’apporter les contributions dans la Maison du Seigneur, nous avons mangé et nous avons été rassasiés. Il en est resté en abondance, car le Seigneur a béni son peuple, et le reste forme cette grande quantité. »
###### 11
Ézékias ordonna de préparer des salles dans la Maison du Seigneur, et on les prépara.
###### 12
On apporta fidèlement les contributions, la dîme et les offrandes saintes. Le lévite Konanias en fut chargé, et son frère Shiméï le secondait.
###### 13
Yeïel, Azazyahou, Nahath, Asahel, Yerimoth, Yozabad, Éliël, Yismakya, Mahath et Benaya étaient surveillants, sous l’autorité de Konanias et de son frère Shiméï, par disposition du roi Ézékias et d’Azarias, chef de la Maison de Dieu.
###### 14
Le lévite Coré, fils de Yimna, gardien de la porte de l’orient, fut préposé aux offrandes volontaires présentées à Dieu, afin de répartir les contributions revenant au Seigneur, et les offrandes très saintes.
###### 15
Éden, Minyamine, Josué, Shemayahou, Amaryahou et Shekanyahou l’assistaient fidèlement dans les villes sacerdotales, pour faire la distribution à leurs frères prêtres, grands et petits, selon leurs classes.
###### 16
En plus des hommes déjà enregistrés, à partir de trois ans et au-dessus, tous ceux qui entraient dans la Maison du Seigneur recevaient chaque jour quelque chose pour leur service, selon leurs fonctions et d’après leurs classes.
###### 17
Les prêtres furent enregistrés selon la maison de leurs pères, et les lévites, à partir de vingt ans et au-dessus, selon leurs fonctions et leurs classes.
###### 18
Furent enregistrés aussi tous leurs jeunes enfants, leurs femmes, leurs fils et leurs filles, toute l’assemblée, car en toute fidélité ils s’occupaient saintement des offrandes saintes.
###### 19
En ce qui concerne les fils d’Aaron, les prêtres, qui se trouvaient dans les terres à pâturage autour de leurs villes, il y avait dans chaque ville des hommes désignés par leurs noms pour distribuer des parts à chacun des prêtres et à quiconque était enregistré comme lévite.
###### 20
Voilà ce que fit Ézékias dans tout le pays de Juda. Il fit ce qui est bon, droit et vrai devant le Seigneur son Dieu.
###### 21
Dans toute œuvre qu’il entreprit pour le service de la Maison de Dieu, pour la Loi et les commandements, cherchant son Dieu, il agit de tout son cœur et il réussit.
