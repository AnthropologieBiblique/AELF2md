---
aliases : 
- 2 Chroniques 22
- 2 Chroniques 22
- 2 Ch 22
- 2 Chronicles 22
tags : 
- Bible/2Ch/22
- français
cssclass : français
---

# 2 Chroniques 22

###### 01
Les habitants de Jérusalem firent roi à la place de Joram Ocozias, son plus jeune fils, car la troupe qui avait investi le camp avec les Arabes avait mis à mort tous les aînés. Ainsi devint roi Ocozias, fils de Joram, roi de Juda.
###### 02
Il avait quarante-deux ans lorsqu’il devint roi, et il régna un an à Jérusalem. Sa mère s’appelait Athalie, fille d’Omri.
###### 03
Lui aussi marcha dans les chemins de la maison d’Acab, car sa mère lui donnait de mauvais conseils.
###### 04
Il fit ce qui est mal aux yeux du Seigneur, comme les gens de la maison d’Acab, car après la mort de son père, ils furent ses conseillers, pour son malheur.
###### 05
C’est même sur leur conseil qu’il partit avec Joram, fils d’Acab, roi d’Israël, pour combattre à Ramoth-de-Galaad Hazaël, roi d’Aram. Mais les Araméens blessèrent Joram.
###### 06
Il revint à Yizréel se faire soigner des blessures qu’il avait reçues dans le combat contre Hazaël, roi d’Aram.
Ocozias, fils de Joram, roi de Juda, descendit à Yizréel pour voir Joram, fils d’Acab, parce qu’il était blessé.
###### 07
De cette visite à Joram Dieu fit la perte d’Ocozias. À son arrivée, celui-ci sortit avec Joram à la rencontre de Jéhu, fils de Nimshi, à qui le Seigneur avait donné l’onction pour supprimer la maison d’Acab.
###### 08
Alors que Jéhu faisait justice de la maison d’Acab, il trouva les princes de Juda et les neveux d’Ocozias qui étaient à son service, et les tua.
###### 09
Puis il chercha Ocozias. On se saisit d’Ocozias dans Samarie où il se cachait, on l’amena à Jéhu et on le mit à mort. On l’ensevelit, car on disait : « Il est le fils de Josaphat, et celui-ci a cherché le Seigneur de tout son cœur. » De la maison d’Ocozias, il n’y eut plus personne en mesure de régner.
###### 10
Lorsqu’Athalie, mère d’Ocozias, apprit que son fils était mort, elle entreprit de faire périr toute la descendance royale, dans la maison de Juda.
###### 11
Mais Josabeth, fille du roi Joram, prit Joas, fils d’Ocozias, pour le soustraire au massacre. Elle le cacha, lui et sa nourrice, dans une chambre de la Maison du Seigneur. Josabeth, fille du roi Joram et femme du prêtre Joad, – elle était en effet la sœur d’Ocozias – le dissimula ainsi aux regards d’Athalie, qui ne put le mettre à mort.
###### 12
Joas demeura avec Josabeth pendant six ans, caché dans la Maison de Dieu, tandis qu’Athalie régnait sur le pays.
