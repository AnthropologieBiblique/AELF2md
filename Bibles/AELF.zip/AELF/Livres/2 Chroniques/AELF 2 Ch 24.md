---
aliases : 
- 2 Chroniques 24
- 2 Chroniques 24
- 2 Ch 24
- 2 Chronicles 24
tags : 
- Bible/2Ch/24
- français
cssclass : français
---

# 2 Chroniques 24

###### 01
Joas avait sept ans lorsqu’il devint roi, et il régna quarante ans à Jérusalem. Le nom de sa mère était Cibya ; elle était de Bershéba.
###### 02
Joas fit ce qui est droit aux yeux du Seigneur pendant toute la vie du prêtre Joad.
###### 03
Joad lui fit épouser deux femmes, dont il eut des fils et des filles.
###### 04
Après quoi, Joas eut à cœur de restaurer la Maison du Seigneur.
###### 05
Il réunit les prêtres et les lévites et leur dit : « Allez dans les villes de Juda, recueillez de l’argent auprès de tous les fils d’Israël, pour réparer d’année en année la Maison de votre Dieu, et hâtez-vous de le faire ! » Mais les lévites ne se hâtèrent pas.
###### 06
Le roi convoqua Joad, le chef des prêtres, et lui dit : « Pourquoi n’as-tu pas exigé des lévites qu’ils apportent, de Juda et de Jérusalem, l’impôt que Moïse, serviteur du Seigneur, et l’assemblée d’Israël ont fixé pour la Tente du Témoignage ?
###### 07
Athalie, l’impiété en personne, ainsi que ses fils ont en effet laissé se dégrader la Maison de Dieu. Ils ont même utilisé pour le culte de Baal les objets sacrés de la Maison du Seigneur. »
###### 08
Le roi ordonna alors de fabriquer un coffre et de le placer à la porte de la Maison du Seigneur, à l’extérieur.
###### 09
On proclama dans Juda et dans Jérusalem qu’il fallait apporter au Seigneur l’impôt que Moïse, serviteur de Dieu, avait fixé à Israël dans le désert.
###### 10
Tous les princes et tout le peuple se réjouirent. Ils apportèrent l’impôt et le versèrent dans le coffre jusqu’à paiement complet.
###### 11
Chaque fois que les lévites apportaient le coffre aux inspecteurs du roi, si on voyait qu’il y avait beaucoup d’argent, le secrétaire du roi et l’intendant du grand prêtre venaient vider le coffre et le remportaient pour le remettre à sa place. Ainsi faisaient-ils chaque jour, et ils récoltaient beaucoup d’argent.
###### 12
Le roi et Joad remettaient l’argent au maître d’œuvre, pour le service de la Maison du Seigneur. Celui-ci engageait des tailleurs de pierre et des charpentiers pour restaurer la Maison du Seigneur, et aussi des artisans du fer et du bronze pour réparer la Maison du Seigneur.
###### 13
Les maîtres d’œuvre se mirent au travail, et, entre leurs mains, les travaux de réfection progressèrent. Ils remirent en état la Maison de Dieu et la consolidèrent.
###### 14
Lorsqu’ils eurent achevé, ils apportèrent devant le roi et Joad le reste de l’argent, avec lequel on fabriqua des objets pour la Maison du Seigneur, objets pour le service et pour les holocaustes, coupes et autres ustensiles d’or et d’argent. On offrit continuellement des holocaustes dans la Maison du Seigneur, pendant toute la vie de Joad.
###### 15
Joad devint très âgé, il fut rassasié de jours et il mourut. Il avait cent trente ans quand il mourut.
###### 16
On l’ensevelit dans la Cité de David avec les rois, parce qu’il avait fait du bien en Israël, à l’égard de Dieu et de sa Maison.
###### 17
Après la mort de Joad, les princes de Juda vinrent se prosterner devant le roi, et alors le roi les écouta.
###### 18
Les gens abandonnèrent la Maison du Seigneur, Dieu de leurs pères, pour servir les poteaux sacrés et les idoles. À cause de cette infidélité, la colère de Dieu s’abattit sur Juda et sur Jérusalem.
###### 19
Pour les ramener à lui, Dieu envoya chez eux des prophètes. Ceux-ci transmirent le message, mais personne ne les écouta.
###### 20
Dieu revêtit de son esprit Zacharie, le fils du prêtre Joad. Zacharie se présenta devant le peuple et lui dit : « Ainsi parle Dieu : Pourquoi transgressez-vous les commandements du Seigneur ? Cela fera votre malheur : puisque vous avez abandonné le Seigneur, le Seigneur vous abandonne. »
###### 21
Ils s’ameutèrent alors contre lui et, par commandement du roi, le lapidèrent sur le parvis de la Maison du Seigneur.
###### 22
Le roi Joas, en faisant mourir Zacharie, fils de Joad, oubliait la fidélité que Joad lui avait témoignée. Zacharie s’était écrié en mourant : « Que le Seigneur le voie, et qu’il fasse justice ! »
###### 23
Or, à la fin de l’année, l’armée d’Aram monta contre le roi Joas et arriva en Juda et à Jérusalem. Ses hommes massacrèrent tous les princes du peuple et envoyèrent tout le butin au roi de Damas.
###### 24
L’armée d’Aram ne comptait qu’un petit nombre d’hommes, et pourtant le Seigneur leur livra une armée très importante, parce que les gens de Juda avaient abandonné le Seigneur, Dieu de leurs pères ; et Joas reçut le châtiment qu’il méritait.
###### 25
Lorsque les Araméens partirent, le laissant dans de grandes souffrances, ses serviteurs complotèrent contre lui parce qu’il avait répandu le sang du fils du prêtre Joad, et ils le tuèrent sur son lit. Il mourut, et on l’ensevelit dans la Cité de David, mais non pas dans les tombeaux des rois.
###### 26
Voici ceux qui complotèrent contre lui : Zabad, fils d’une Ammonite nommée Shiméath, et Yehozabad, fils d’une Moabite nommée Shimrith.
###### 27
Ce qui concerne ses fils,
les nombreuses prophéties lancées contre lui,
les aménagements de la Maison de Dieu,
cela est écrit dans le Commentaire du livre des Rois.
Son fils Amasias régna à sa place.
