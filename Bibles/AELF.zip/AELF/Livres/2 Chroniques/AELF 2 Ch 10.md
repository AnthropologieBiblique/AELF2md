---
aliases : 
- 2 Chroniques 10
- 2 Chroniques 10
- 2 Ch 10
- 2 Chronicles 10
tags : 
- Bible/2Ch/10
- français
cssclass : français
---

# 2 Chroniques 10

###### 01
Roboam se rendit à Sichem ; c’est à Sichem, en effet, que tout Israël était venu pour le faire roi.
###### 02
Jéroboam, fils de Nebath, apprit la nouvelle. Il était alors en Égypte, où il s’était enfui loin du roi Salomon. Il revint d’Égypte.
###### 03
On envoya chercher Jéroboam, et il vint, ainsi que tout Israël. Ils s’adressèrent à Roboam en ces termes :
###### 04
« Ton père a rendu pénible notre joug ; maintenant, allège la pénible servitude imposée par ton père, et le joug pesant qu’il nous a infligé ; alors nous te servirons. »
###### 05
Il leur répondit : « Attendez trois jours, puis revenez vers moi. » Et le peuple se retira.
###### 06
Le roi Roboam prit conseil des anciens, ceux qui s’étaient tenus en présence de son père Salomon, de son vivant. Il leur dit : « Quelle réponse conseillez-vous de faire à ce peuple ? »
###### 07
Ils lui dirent alors : « Si tu te montres bon envers ce peuple, si tu les accueilles, si tu leur adresses des paroles bienveillantes, ils seront tes serviteurs pour toujours. »
###### 08
Mais il négligea le conseil que lui donnaient les anciens ; il prit conseil des jeunes gens qui avaient grandi avec lui et se tenaient en sa présence.
###### 09
Il leur demanda : « Que conseillez-vous ? Quelle réponse allons-nous faire à ce peuple qui m’a parlé en disant : “Allège donc le joug que nous a infligé ton père” ? »
###### 10
Les jeunes gens qui avaient grandi avec lui répondirent : « Voici ce que tu répondras à ce peuple qui t’a parlé en disant : “Ton père a rendu pesant notre joug mais toi, pour nous, allège-le !” Voici ce que tu leur diras : “Mon petit doigt est plus fort que les reins de mon père.
###### 11
S’il est vrai que mon père vous accablait sous un joug pesant, je vais, moi, ajouter encore à votre joug. Mon père vous a corrigés avec des lanières ? Eh bien, moi, ce sera avec des fouets à pointes de fer !” »
###### 12
Le troisième jour, Jéroboam revint, ainsi que tout le peuple, auprès de Roboam, conformément à la parole du roi : « Revenez vers moi le troisième jour. »
###### 13
Le roi leur répondit durement, Roboam négligeant ainsi le conseil des anciens.
###### 14
Il parla au peuple en suivant le conseil des jeunes gens. Il leur dit : « Mon père a rendu pesant votre joug, je vais, moi, y ajouter encore. Mon père vous a corrigés avec des lanières ? Et bien moi, ce sera avec des fouets à pointes de fer ! »
###### 15
Ainsi, le roi n’écouta pas le peuple ; en effet, la tournure que prenaient les choses venait de Dieu, pour que s’accomplisse la parole que le Seigneur avait dite par l’intermédiaire d’Ahias de Silo à Jéroboam, fils de Nebath.
###### 16
Tout Israël vit que le roi ne les avait pas écoutés. Le peuple rétorqua au roi :
« Quelle part avons-nous chez David ?
Pas d’héritage chez le fils de Jessé !
Chacun de vous à ses tentes, Israël !
Maintenant, David, pourvois donc à ta maison ! »
Et tout Israël s’en alla dans ses tentes.
###### 17
Quant aux fils d’Israël qui demeuraient dans les villes de Juda, Roboam régna sur eux.
###### 18
Le roi Roboam envoya Adoram, le chef de la corvée ; mais les fils d’Israël le lapidèrent, et il mourut. Et le roi Roboam se vit contraint de monter sur un char pour s’enfuir à Jérusalem.
###### 19
Les dix tribus d’Israël rejetèrent la maison de David, jusqu’à ce jour.
