---
aliases : 
- 2 Chroniques 5
- 2 Chroniques 5
- 2 Ch 5
- 2 Chronicles 5
tags : 
- Bible/2Ch/5
- français
cssclass : français
---

# 2 Chroniques 5

###### 01
Ainsi fut parachevé tout le travail entrepris par Salomon pour la Maison du Seigneur. Salomon fit apporter les objets sacrés de David son père : l’argent, l’or et tous les ustensiles ; il les déposa dans les trésors de la Maison de Dieu.
###### 02
Salomon rassembla à Jérusalem les anciens d’Israël et tous les chefs des tribus, les chefs de famille des fils d’Israël, pour aller chercher l’arche de l’Alliance du Seigneur dans la Cité de David, c’est-à-dire à Sion.
###### 03
Tous les hommes d’Israël se rassemblèrent auprès du roi au septième mois, durant la fête des Tentes.
###### 04
Quand tous les anciens d’Israël furent arrivés, les lévites se chargèrent de l’Arche.
###### 05
Ils emportèrent l’Arche et la tente de la Rencontre avec tous les objets sacrés qui s’y trouvaient ; ce sont les prêtres lévites qui les transportèrent.
###### 06
Le roi Salomon, et toute la communauté d’Israël qu’il avait convoquée devant l’Arche, offrirent en sacrifice des moutons et des bœufs : il y en avait tant qu’on ne pouvait les compter.
###### 07
Puis les prêtres transportèrent l’Arche de l’alliance du Seigneur à sa place, dans la chambre sacrée que l’on appelle le Saint des saints, sous les ailes des kéroubim.
###### 08
Ceux-ci étendaient leurs ailes au-dessus de l’emplacement de l’Arche : ils abritaient l’Arche et ses barres.
###### 09
Les barres étaient si longues que l’on pouvait voir leurs extrémités depuis l’Arche, devant le Saint des saints ; mais on ne les voyait pas de l’extérieur. Elles y sont encore à ce jour.
###### 10
Dans l’Arche, il n’y avait rien, sinon les deux tables de la Loi que Moïse y avait placées, au mont Horeb, quand le Seigneur avait conclu alliance avec les fils d’Israël à leur sortie d’Égypte.
###### 11
Alors les prêtres sortirent du sanctuaire. En effet, tous les prêtres qui se trouvaient là s’étaient sanctifiés sans observer l’ordre des classes ;
###### 12
les lévites qui étaient chantres étaient au complet : Asaf, Hémane, Yedoutoune, leurs fils et leurs frères, vêtus de lin, se tenaient debout avec des cymbales, des harpes et des cithares, à l’orient de l’autel ; il y avait auprès d’eux cent vingt prêtres sonnant de la trompette.
###### 13
Tous ensemble, ceux qui jouaient de la trompette et ceux qui chantaient louaient et célébraient le Seigneur d’une seule voix. Élevant la voix au son des trompettes, des cymbales et des instruments de musique, ils louaient le Seigneur : « Car il est bon, éternel est son amour. »
Alors la Maison, la Maison du Seigneur, fut remplie par une nuée,
###### 14
et, à cause d’elle, les prêtres durent interrompre le service divin : la gloire du Seigneur remplissait la Maison de Dieu.
