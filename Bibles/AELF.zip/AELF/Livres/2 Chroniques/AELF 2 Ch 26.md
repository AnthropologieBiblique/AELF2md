---
aliases : 
- 2 Chroniques 26
- 2 Chroniques 26
- 2 Ch 26
- 2 Chronicles 26
tags : 
- Bible/2Ch/26
- français
cssclass : français
---

# 2 Chroniques 26

###### 01
Tout le peuple de Juda prit Ozias, âgé de seize ans, et le fit roi, à la place de son père Amasias.
###### 02
C’est lui qui rebâtit Eilath et la réintégra en Juda, après que le roi Amasias eut reposé avec ses pères.
###### 03
Ozias avait seize ans lorsqu’il devint roi, et il régna cinquante-deux ans à Jérusalem. Sa mère s’appelait Jékolie ; elle était de Jérusalem.
###### 04
Il fit ce qui est droit aux yeux du Seigneur, tout comme avait fait Amasias, son père.
###### 05
Il s’appliqua à rechercher Dieu tant que vécut Zacharie, qui avait l’intelligence des visions de Dieu ; et tout le temps qu’il rechercha le Seigneur, Dieu le fit réussir.
###### 06
Il partit en guerre contre les Philistins, il démantela le rempart de Gath, le rempart de Yabné, le rempart d’Ashdod, et construisit des villes dans la région d’Ashdod et chez les Philistins.
###### 07
Dieu lui vint en aide contre les Philistins, contre les Arabes qui habitaient à Gour-Baal, et contre les Méounites.
###### 08
Les Ammonites payèrent tribut à Ozias, dont la renommée parvint jusqu’à l’entrée de l’Égypte, car il était devenu extrêmement puissant.
###### 09
Ozias construisit des tours à Jérusalem, sur la porte de l’Angle, sur la porte de la Vallée, et sur le Contrefort ; et il les fortifia.
###### 10
Il construisit des tours dans le désert et creusa de nombreuses citernes, car il avait de nombreux troupeaux dans le Bas-Pays et sur le Plateau. Il avait aussi des cultivateurs et des vignerons, dans les montagnes et au Carmel, car il aimait la terre.
###### 11
Ozias avait une armée entraînée, capable d’aller au combat, répartie par troupes selon le nombre des hommes recensés par Yéiël, le secrétaire, et Maasias, le scribe ; elle était sous l’autorité de Hananias, l’un des officiers du roi.
###### 12
Le nombre total des chefs de famille des vaillants guerriers était de deux mille six cents.
###### 13
Ils avaient sous leur autorité une armée de trois cent sept mille cinq cents hommes, d’une grande valeur au combat, pour aider le roi en face de l’ennemi.
###### 14
Ozias procura à toute cette armée des boucliers, des lances, des casques, des cuirasses, des arcs, et des frondes avec leurs pierres.
###### 15
Il fit également fabriquer à Jérusalem des engins conçus par un ingénieur, destinés à être placés sur les tours et aux angles, pour lancer des traits et de grosses pierres. Sa renommée se répandit au loin car il fut merveilleusement aidé, au point qu’il devint puissant.
###### 16
Mais lorsqu’il fut devenu puissant, son cœur s’enorgueillit jusqu’à le perdre, et il fut infidèle au Seigneur son Dieu. Il entra dans le temple du Seigneur pour brûler de l’encens sur l’autel de l’encens.
###### 17
Le prêtre Azarias entra après lui, avec quatre-vingts prêtres du Seigneur, des hommes courageux.
###### 18
Ils s’opposèrent au roi Ozias et lui dirent : « Ce n’est pas à toi, Ozias, de brûler de l’encens pour le Seigneur, mais aux prêtres, descendants d’Aaron, qui ont été consacrés pour brûler de l’encens. Sors du sanctuaire, car tu as été infidèle, et cela ne te vaudra pas la gloire qui vient du Seigneur Dieu. »
###### 19
Ozias, qui tenait à la main un encensoir pour brûler de l’encens, se mit en rage. Tandis qu’il était en rage contre les prêtres, la lèpre apparut sur son front, en leur présence, dans la Maison du Seigneur, devant l’autel de l’encens.
###### 20
Le grand prêtre Azarias et tous les prêtres se tournèrent vers lui, et voici que son front était couvert de lèpre ! En toute hâte ils l’expulsèrent, et lui-même se pressa de sortir, parce que le Seigneur l’avait frappé.
###### 21
Le roi Ozias fut lépreux jusqu’au jour de sa mort, et il habita, lépreux, dans une maison à l’écart ; en effet, il était exclu de la Maison du Seigneur. Son fils Yotam, maître du palais du roi, gouvernait les gens du pays.
###### 22
Le reste des actions d’Ozias, des premières aux dernières,
le prophète Isaïe, fils d’Amots, les a écrites.
###### 23
Ozias reposa avec ses pères,
et on l’ensevelit avec eux
dans le champ de la sépulture des rois,
car on disait : « Il est lépreux ! »
Son fils Yotam régna à sa place.
