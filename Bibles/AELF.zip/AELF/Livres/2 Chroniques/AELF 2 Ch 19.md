---
aliases : 
- 2 Chroniques 19
- 2 Chroniques 19
- 2 Ch 19
- 2 Chronicles 19
tags : 
- Bible/2Ch/19
- français
cssclass : français
---

# 2 Chroniques 19

###### 01
Josaphat, roi de Juda, revint en paix dans sa maison, à Jérusalem.
###### 02
Jéhu, un voyant, fils de Hanani, sortit à sa rencontre. Il dit au roi Josaphat : « Fallait-il porter secours au méchant ? Est-ce que tu aimes ceux qui haïssent le Seigneur ? C’est pourquoi la colère du Seigneur est sur toi.
###### 03
Toutefois, il y a aussi en toi quelque chose de bon, puisque tu as fait disparaître du pays les poteaux sacrés ; et que tu as appliqué ton cœur à chercher Dieu. »
###### 04
Josaphat habitait à Jérusalem. De nouveau, il visita le peuple depuis Bershéba jusqu’à la montagne d’Éphraïm et il les fit revenir vers le Seigneur, le Dieu de leurs pères.
###### 05
Il établit des juges dans le pays, dans toutes les villes fortifiées de Juda, un pour chaque ville.
###### 06
Il dit aux juges : « Soyez attentifs à ce que vous ferez, car ce n’est pas selon les hommes que vous jugez, mais selon le Seigneur ; il est avec vous quand vous prononcez un jugement.
###### 07
Et maintenant, que pèse sur vous la crainte du Seigneur ! Prenez garde à ce que vous faites, car dans le Seigneur notre Dieu il n’y a ni perfidie, ni partialité, ni vénalité. »
###### 08
À Jérusalem également Josaphat établit des lévites, des prêtres et des chefs de famille d’Israël, pour juger selon le Seigneur et régler les litiges ; ils habitaient à Jérusalem.
###### 09
Il leur donna des ordres, en disant : « Voici comment vous agirez, avec la crainte du Seigneur, dans la fidélité et d’un cœur sans partage.
###### 10
Chaque fois que vos frères, établis dans leurs villes, porteront devant vous un litige concernant une affaire de sang ou concernant la Loi – commandement, décrets ou ordonnances –, vous les avertirez, pour qu’ils ne se rendent pas coupables envers le Seigneur, et que sa colère ne soit pas sur vous ni sur vos frères. En agissant ainsi, vous ne vous rendrez pas coupables.
###### 11
Et voici qu’Amarias, le chef des prêtres, veillera sur vous pour tout ce qui concerne le Seigneur, et Zebadias, fils de Yishmaël, chef de la maison de Juda, pour tout ce qui concerne le roi ; les lévites vous serviront de scribes. Soyez forts et agissez ! Et que le Seigneur soit avec celui qui fait le bien ! »
