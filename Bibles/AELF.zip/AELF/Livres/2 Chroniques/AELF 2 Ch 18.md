---
aliases : 
- 2 Chroniques 18
- 2 Chroniques 18
- 2 Ch 18
- 2 Chronicles 18
tags : 
- Bible/2Ch/18
- français
cssclass : français
---

# 2 Chroniques 18

###### 01
Josaphat possédait en abondance richesses et gloire, et il s’allia par un mariage avec Acab.
###### 02
Après quelques années, il descendit chez Acab, à Samarie. Acab sacrifia pour lui et le peuple qui l’accompagnait quantité de moutons et de bœufs, et il l’incita à monter contre Ramoth-de-Galaad.
###### 03
Acab, roi d’Israël, dit à Josaphat, roi de Juda : « Viendrais-tu avec moi à Ramoth-de-Galaad ? » Il lui répondit : « Il en est de moi comme de toi, de mon peuple comme de ton peuple ; nous serons avec toi au combat. »
###### 04
Josaphat dit au roi d’Israël : « Mais consulte d’abord la parole du Seigneur. »
###### 05
Le roi d’Israël réunit les prophètes au nombre de quatre cents. Il leur demanda : « Irons-nous à Ramoth-de-Galaad pour combattre, ou dois-je y renoncer ? » Ils dirent : « Monte ! Dieu livrera la ville aux mains du roi. »
###### 06
Mais Josaphat reprit : « N’y a-t-il ici aucun autre prophète du Seigneur, par qui nous pourrions le consulter ? »
###### 07
Le roi d’Israël répondit à Josaphat : « Il y a encore un homme par qui nous pourrions consulter le Seigneur, mais moi, je le hais, car il ne prophétise aucun bonheur à mon sujet, mais toujours du malheur. Il s’agit de Michée, fils de Yimla. » Josaphat répliqua : « Que le roi ne parle pas ainsi ! »
###### 08
Le roi d’Israël appela un dignitaire et lui dit : « Vite, fais venir Michée, fils de Yimla ! »
###### 09
Le roi d’Israël et Josaphat, roi de Juda, siégeaient, en tenue d’apparat, chacun sur son trône. Ils siégeaient sur l’esplanade à l’entrée de la porte de Samarie. Et, devant eux, tous les prophètes se mettaient à prophétiser.
###### 10
Sédécias, fils de Kenahana, s’était fabriqué des cornes de fer. Il disait : « Ainsi parle le Seigneur : Avec cela tu pourfendras Aram jusqu’à l’exterminer. »
###### 11
Tous les prophètes prophétisaient de la même manière ; ils disaient : « Monte à Ramoth-de-Galaad ! Tu réussiras ! Le Seigneur livrera la ville aux mains du roi. »
###### 12
Le messager qui était allé appeler Michée lui dit : « Voici les paroles des prophètes ; d’une seule voix ils annoncent du bien pour le roi. Que ta parole soit donc conforme à celle de chacun : annonce du bien ! »
###### 13
Michée répondit : « Par le Seigneur qui est vivant ! Ce que mon Dieu dira, c’est cela que j’annoncerai ! »
###### 14
Il entra chez le roi qui lui dit : « Michée, irons-nous à Ramoth-de-Galaad pour combattre, ou dois-je y renoncer ? » Il répondit : « Montez ! Vous réussirez. Ses habitants seront livrés entre vos mains. »
###### 15
Le roi lui rétorqua : « Combien de fois devrai-je t’adjurer de me dire seulement la vérité au nom du Seigneur ? »
###### 16
Michée dit alors :
« J’ai vu tout Israël dispersé sur les montagnes comme des brebis sans berger.
Le Seigneur a dit :
“Ces gens n’ont plus de maître ;
qu’ils retournent en paix, chacun dans sa maison.” »
###### 17
Le roi d’Israël dit à Josaphat : « Ne te l’avais-je pas dit ? Il ne prophétise à mon sujet rien de bon, mais seulement du mal ! »
###### 18
Michée reprit : « Eh bien ! Écoutez la parole du Seigneur ! J’ai vu le Seigneur qui siégeait sur son trône ; toute l’armée des cieux se tenait à sa droite et à sa gauche.
###### 19
Le Seigneur demanda : “Qui séduira Acab, roi d’Israël, pour qu’il monte et qu’il tombe à Ramoth-de-Galaad ?” Ils répondirent, l’un disant une chose, l’autre disant autre chose.
###### 20
Alors un esprit s’avança et se tint en présence du Seigneur. Il dit : “Moi, je le séduirai.” Le Seigneur reprit : “De quelle manière ?”
###### 21
Il répondit : “J’avancerai, je deviendrai esprit de mensonge dans la bouche de tous ses prophètes.” Le Seigneur déclara : “Tu le séduiras, tu l’auras même en ton pouvoir. Avance, et fais comme tu as dit.” »
###### 22
Michée continua : « Maintenant donc, voici que le Seigneur a mis un esprit de mensonge dans la bouche des prophètes qui sont là, voici que le Seigneur annonce contre toi le malheur. »
###### 23
Sédécias, fils de Kenahana, s’approcha et frappa Michée sur la joue, en disant : « Par quel chemin l’esprit du Seigneur s’est-il échappé de moi pour te parler ? »
###### 24
Michée répondit : « Eh bien ! Le jour où tu fuiras dans une chambre retirée pour te cacher, tu le verras. »
###### 25
Le roi d’Israël donna cet ordre : « Saisissez-vous de Michée et remettez-le aux mains d’Amone, gouverneur de la ville, et à Joas, le fils du roi.
###### 26
Vous direz : “Ainsi parle le roi : Mettez cet homme en prison, nourrissez-le de rations réduites de pain et d’eau jusqu’à ce que je revienne sain et sauf”. »
###### 27
Michée reprit : « Si vraiment tu reviens sain et sauf, c’est que le Seigneur n’a pas parlé par ma bouche. » Il ajouta : « Vous, tous les peuples, écoutez ! »
###### 28
Le roi d’Israël et Josaphat, roi de Juda, montèrent à Ramoth-de-Galaad.
###### 29
Le roi d’Israël dit à Josaphat : « Je vais me déguiser pour marcher au combat, mais toi, revêts ta tenue. » Le roi d’Israël se déguisa pour marcher au combat.
###### 30
Le roi d’Aram avait donné cet ordre à ses commandants de chars : « Vous n’attaquerez ni petit ni grand, mais uniquement le roi d’Israël ! »
###### 31
Lorsque les commandants de chars virent Josaphat, ils dirent : « C’est le roi d’Israël. » Et ils l’encerclèrent pour l’attaquer. Mais Josaphat poussa un cri. Le Seigneur le secourut, et Dieu les entraîna loin de lui.
###### 32
Alors les commandants de chars virent que ce n’était pas le roi d’Israël et ils se détournèrent de lui.
###### 33
Un homme tira de l’arc au hasard et atteignit le roi d’Israël entre les attaches et la cuirasse. Le roi dit au conducteur du char : « Tourne bride et fais-moi sortir du champ de bataille, car je me sens mal ! »
###### 34
Le combat, ce jour-là, devint très violent. Le roi d’Israël se maintint debout sur son char, face aux Araméens, jusqu’au soir. Et il mourut au coucher du soleil.
