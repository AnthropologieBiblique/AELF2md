---
aliases : 
- 2 Chroniques 30
- 2 Chroniques 30
- 2 Ch 30
- 2 Chronicles 30
tags : 
- Bible/2Ch/30
- français
cssclass : français
---

# 2 Chroniques 30

###### 01
Ézékias envoya des messagers à tout Israël et Juda – il écrivit même des lettres à Éphraïm et Manassé –, les invitant à venir à la Maison du Seigneur à Jérusalem, pour célébrer la Pâque en l’honneur du Seigneur, Dieu d’Israël.
###### 02
Le roi, ses princes et toute l’assemblée délibérèrent à Jérusalem pour célébrer la Pâque au deuxième mois.
###### 03
En effet, on ne pouvait pas la célébrer en son temps, puisque les prêtres ne s’étaient pas sanctifiés en assez grand nombre, et que le peuple ne s’était pas réuni à Jérusalem.
###### 04
Ce projet parut juste aux yeux du roi et de toute l’assemblée.
###### 05
On décida de faire passer une proclamation dans tout Israël, depuis Bershéba jusqu’à Dane, pour que l’on vienne célébrer la Pâque à Jérusalem en l’honneur du Seigneur, Dieu d’Israël. Car seul un petit nombre l’avait célébrée selon ce qui est écrit !
###### 06
Les coursiers partirent, avec des lettres écrites de la main du roi et de ses princes, dans tout Israël et Juda, pour dire, selon le commandement du roi : « Fils d’Israël, revenez au Seigneur, Dieu d’Abraham, d’Isaac et d’Israël, afin qu’il revienne, lui, à ceux d’entre vous qui restent, après avoir échappé à la main des rois d’Assour.
###### 07
Ne soyez pas comme vos pères, ni comme vos frères, qui ont été infidèles au Seigneur, Dieu de leurs pères : il les a livrés à la désolation, comme vous le voyez.
###### 08
Maintenant, ne raidissez pas votre nuque comme vos pères. Tendez la main vers le Seigneur en geste de soumission. Venez à son sanctuaire, qu’il a consacré pour toujours. Servez le Seigneur votre Dieu, pour que se détourne de vous l’ardeur de sa colère.
###### 09
Si vous revenez au Seigneur, vos frères et vos fils trouveront miséricorde auprès de ceux qui les ont emmenés captifs, et ils pourront revenir en ce pays ; car le Seigneur votre Dieu est tendre et miséricordieux, et il n’écartera pas de vous sa face, si vous revenez à lui. »
###### 10
Les coursiers passèrent ainsi de ville en ville, dans le pays d’Éphraïm et de Manassé, jusqu’à Zabulon. Mais on se riait d’eux, on se moquait d’eux.
###### 11
Toutefois, quelques hommes d’Asher, de Manassé et de Zabulon s’humilièrent et vinrent à Jérusalem.
###### 12
La main de Dieu fut aussi sur Juda, pour leur donner un cœur loyal, afin qu’ils exécutent le commandement du roi et des princes selon la parole du Seigneur.
###### 13
Un peuple nombreux se réunit à Jérusalem pour célébrer au deuxième mois la fête des Pains sans levain : ce fut une très nombreuse assemblée.
###### 14
Ils se levèrent pour supprimer les autels qui étaient dans Jérusalem ; ils supprimèrent toutes les tables où l’on brûlait l’encens et les jetèrent dans le ravin du Cédron.
###### 15
Ils immolèrent la Pâque, le quatorzième jour du deuxième mois. Les prêtres et les lévites, emplis de confusion, s’étaient sanctifiés et avaient fait venir les victimes pour les holocaustes dans la Maison du Seigneur.
###### 16
Ils se tenaient à leur poste, selon leur coutume, conformément à la loi de Moïse, homme de Dieu. Les prêtres faisaient l’aspersion avec le sang qu’apportaient les lévites.
###### 17
Bon nombre dans l’assemblée ne s’étaient pas sanctifiés. Les lévites étaient donc chargés, à la place de tous ceux qui n’étaient pas purs, d’immoler les victimes pascales pour accomplir un acte saint envers le Seigneur.
###### 18
Or, une grande partie du peuple, beaucoup de gens d’Éphraïm, de Manassé, d’Issakar et de Zabulon, ne s’étaient pas purifiés, en sorte qu’ils mangèrent la Pâque sans se conformer à ce qui est prescrit. Alors Ézékias intercéda pour eux en disant : « Que le Seigneur, lui qui est bon, pardonne à
###### 19
tous ceux qui ont appliqué leur cœur à chercher Dieu, le Seigneur, Dieu de leurs pères, bien qu’ils n’aient pas la pureté qui convient aux choses saintes. »
###### 20
Le Seigneur exauça Ézékias, il épargna le peuple.
###### 21
Les fils d’Israël qui se trouvaient à Jérusalem célébrèrent la fête des Pains sans levain pendant sept jours, en grande joie. Jour après jour, les lévites et les prêtres louaient le Seigneur avec les puissants instruments de musique du Seigneur.
###### 22
Ézékias s’adressa au cœur de tous les lévites qui montraient une grande intelligence dans le service du Seigneur. Ils partagèrent pendant sept jours le repas de la solennité ; ils offraient des sacrifices de paix et célébraient le Seigneur, Dieu de leurs pères.
###### 23
Puis toute l’assemblée se mit d’accord pour prolonger de sept jours la célébration, et on fêta les sept jours dans la joie.
###### 24
Car Ézékias, roi de Juda, avait prélevé pour l’assemblée mille jeunes taureaux et sept mille moutons, et les princes avaient prélevé pour l’assemblée mille jeunes taureaux et dix mille moutons. Les prêtres, en grand nombre, s’étaient sanctifiés.
###### 25
Toute l’assemblée de Juda, les prêtres et les lévites, et toute l’assemblée venue d’Israël, furent dans la joie, ainsi que les immigrés venus du pays d’Israël et résidant en Juda.
###### 26
Il y eut grande joie dans Jérusalem, car, depuis le temps de Salomon, fils de David, roi d’Israël, rien de pareil ne s’était produit à Jérusalem.
###### 27
Les prêtres lévites se levèrent pour bénir le peuple. Leur voix fut entendue, et leur prière parvint aux cieux, au séjour de la Sainteté.
