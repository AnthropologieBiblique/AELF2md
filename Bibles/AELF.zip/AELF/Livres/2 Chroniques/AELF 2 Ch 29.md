---
aliases : 
- 2 Chroniques 29
- 2 Chroniques 29
- 2 Ch 29
- 2 Chronicles 29
tags : 
- Bible/2Ch/29
- français
cssclass : français
---

# 2 Chroniques 29

###### 01
Ézékias devint roi à l’âge de vingt-cinq ans et il régna vingt-neuf ans à Jérusalem. Le nom de sa mère était Abiya, fille de Zacharie.
###### 02
Il fit ce qui est droit aux yeux du Seigneur, tout comme avait fait David, son ancêtre.
###### 03
La première année de son règne, le premier mois, il rouvrit les portes de la Maison du Seigneur et les répara.
###### 04
Il fit venir les prêtres et les lévites et, les ayant réunis sur la place de l’Orient,
###### 05
il leur dit : « Écoutez-moi, lévites ! Maintenant, sanctifiez-vous, sanctifiez la Maison du Seigneur, Dieu de vos pères, et du sanctuaire enlevez la souillure.
###### 06
Car nos pères ont été infidèles, ils ont fait ce qui est mal aux yeux du Seigneur notre Dieu. Ils l’ont abandonné, ils ont détourné leur visage de la demeure du Seigneur, et lui ont tourné le dos.
###### 07
Ils ont même fermé les portes du Vestibule, ils ont éteint les lampes, ils ont cessé de brûler de l’encens et d’offrir l’holocauste dans le sanctuaire du Dieu d’Israël.
###### 08
La colère du Seigneur s’est abattue sur Juda et sur Jérusalem. Il les a livrés à la terreur, à la désolation et à la moquerie, comme vous le voyez de vos yeux.
###### 09
Voilà pourquoi nos pères sont tombés sous l’épée, et nos fils, nos filles et nos femmes sont en captivité.
###### 10
Maintenant j’ai l’intention de conclure une alliance avec le Seigneur, Dieu d’Israël, pour que se détourne de nous l’ardeur de sa colère.
###### 11
Maintenant, mes fils, ne soyez plus négligents, car c’est vous que le Seigneur a choisis, pour vous tenir devant lui et le servir, pour être ses serviteurs et brûler de l’encens. »
###### 12
Alors les lévites se mirent à l’œuvre : parmi les fils de Qehath : Mahath fils d’Amasaï, Joël fils d’Azarias ; parmi les fils de Merari : Qish fils d’Abdi, Azarias fils de Yehallélel ; parmi les Guershonites : Yoah fils de Zimma, Éden fils de Yoah ;
###### 13
parmi les fils d’Éliçafane : Shimri et Yéiël ; parmi les fils d’Asaf : Zacharie et Mattanyahou ;
###### 14
parmi les fils de Hémane : Yeïel et Shiméï ; parmi les fils de Yedoutoune : Shemaya et Ouzziel.
###### 15
Ils réunirent leurs frères, se sanctifièrent et, selon l’ordre du roi conforme aux paroles du Seigneur, ils vinrent purifier la Maison du Seigneur.
###### 16
Les prêtres entrèrent à l’intérieur de la Maison du Seigneur pour la purifier. Ils emportèrent sur le parvis de la Maison du Seigneur tous les objets impurs qu’ils trouvèrent dans le temple du Seigneur. Les lévites les ramassèrent pour les emporter dehors, dans le ravin du Cédron.
###### 17
Ils commencèrent cette sanctification le premier jour du premier mois. Le huitième jour du mois, ils entrèrent dans le Vestibule du Seigneur. Ils mirent huit jours à sanctifier la Maison du Seigneur, et le seizième jour du premier mois ils avaient achevé.
###### 18
Ils se rendirent ensuite dans les appartements du roi Ézékias et lui dirent : « Nous avons purifié toute la Maison du Seigneur, l’autel des holocaustes et tous ses ustensiles, la table où l’on dispose les pains de l’offrande et tous ses ustensiles.
###### 19
Et tous les objets que, pendant son règne, le roi Acaz avait profanés par son infidélité, nous les avons remis en état et sanctifiés : les voici devant l’autel du Seigneur. »
###### 20
Le roi Ézékias, s’étant levé de bon matin, réunit les princes de la ville et monta à la Maison du Seigneur.
###### 21
On amena sept taureaux, sept béliers, sept agneaux et sept boucs, en sacrifice pour la faute, à l’intention du royaume, du sanctuaire et de Juda. Le roi dit aux prêtres, descendants d’Aaron, d’offrir les holocaustes sur l’autel du Seigneur.
###### 22
On immola les bœufs, et les prêtres recueillirent le sang dont on aspergea l’autel ; on immola les béliers, et de leur sang on aspergea l’autel ; on immola les agneaux, et de leur sang on aspergea l’autel.
###### 23
Ensuite, devant le roi et l’assemblée, on fit avancer les boucs destinés au sacrifice pour la faute, et on leur imposa les mains.
###### 24
Les prêtres les immolèrent et, de leur sang répandu sur l’autel, ils firent un sacrifice pour la faute, en expiation pour tout Israël. C’est en effet pour tout Israël que le roi avait ordonné l’holocauste et le sacrifice pour la faute.
###### 25
Il plaça les lévites dans la Maison du Seigneur, au son des cymbales, des harpes et des cithares, selon le commandement de David, de Gad, le voyant du roi, et du prophète Nathan. Car ce commandement venait du Seigneur par l’intermédiaire de ses prophètes.
###### 26
Quand les lévites, avec les instruments de David, et les prêtres, avec les trompettes, eurent pris place,
###### 27
Ézékias ordonna d’offrir l’holocauste sur l’autel. Au moment où commença l’holocauste commencèrent aussi le cantique au Seigneur et la sonnerie des trompettes, avec accompagnement des instruments de David, roi d’Israël.
###### 28
Toute l’assemblée se prosterna ; on chanta le cantique, et les trompettes sonnèrent jusqu’à l’achèvement de l’holocauste.
###### 29
Lorsqu’on eut achevé d’offrir l’holocauste, le roi et tous ceux qui étaient avec lui s’inclinèrent et se prosternèrent.
###### 30
Le roi Ézékias et les princes dirent aux lévites de célébrer le Seigneur en reprenant les paroles de David et d’Asaf le voyant. Ils célébrèrent donc dans la joie, puis se mirent à genoux et se prosternèrent.
###### 31
Ézékias prit alors la parole et dit : « Maintenant, vous avez reçu l’investiture du Seigneur ; approchez-vous donc, offrez des sacrifices d’action de grâce dans la Maison du Seigneur. » Alors l’assemblée offrit des sacrifices d’action de grâce, et tous ceux que leur cœur y incitait offrirent des holocaustes.
###### 32
Le nombre des holocaustes qu’offrit l’assemblée fut de soixante-dix bœufs, cent béliers et deux cents agneaux, le tout en holocauste pour le Seigneur.
###### 33
On consacra encore six cents bœufs et trois mille brebis.
###### 34
Toutefois les prêtres n’étaient pas assez nombreux pour dépecer toutes les victimes de l’holocauste. Alors leurs frères, les lévites, les aidèrent jusqu’à ce que le travail soit achevé, et que les prêtres se soient sanctifiés. Les lévites, en effet, avaient mis plus d’empressement que les prêtres à se sanctifier.
###### 35
Il y eut aussi de nombreux holocaustes, outre les graisses des sacrifices de paix et les libations pour les holocaustes. Ainsi fut rétabli le service de la Maison du Seigneur.
###### 36
Ézékias et le peuple se réjouirent de ce que Dieu avait réalisé pour le peuple, car cela s’était fait rapidement.
