---
aliases : 
- 2 Chroniques 8
- 2 Chroniques 8
- 2 Ch 8
- 2 Chronicles 8
tags : 
- Bible/2Ch/8
- français
cssclass : français
---

# 2 Chroniques 8

###### 01
Au terme des vingt années pendant lesquelles Salomon avait bâti la Maison du Seigneur et sa propre maison,
###### 02
Salomon rebâtit les villes que lui avait données Houram ; il y établit les fils d’Israël.
###### 03
Puis Salomon se rendit à Hamath-Soba et il s’en empara.
###### 04
Il rebâtit Tadmor dans le désert, ainsi que toutes les villes d’entrepôts qu’il avait bâties dans la région de Hamath.
###### 05
Il rebâtit Beth-Horone-le-Haut et Beth-Horone-le-Bas – c’étaient des villes fortifiées avec des remparts, des portes et des verrous – ;
###### 06
puis il rebâtit Baalath et toutes les villes d’entrepôts appartenant à Salomon, toutes les villes de garnison pour les chars et celles des cavaliers. Salomon construisit tout ce qu’il désirait, dans Jérusalem, au Liban et dans tout le pays soumis à son autorité.
###### 07
Il restait toute une population de Hittites, d’Amorites, de Perizzites, de Hivvites et de Jébuséens, qui n’étaient pas d’Israël.
###### 08
Ceux d’entre leurs fils qui, après eux, étaient restés dans le pays, et que les fils d’Israël n’avaient pas exterminés, Salomon les réquisitionna pour la corvée, jusqu’à ce jour.
###### 09
Mais, d’entre les fils d’Israël, Salomon ne soumit personne au servage pour ses travaux, car ils étaient des hommes de guerre, chefs de ses écuyers, chefs de ses chars et de ses cavaliers.
###### 10
Voici le nombre des chefs des préposés aux travaux du roi Salomon : deux cent cinquante qui commandaient le peuple.
###### 11
Salomon fit monter la fille de Pharaon de la Cité de David à la maison qu’il avait bâtie pour elle. Il disait en effet : « Une femme ne peut demeurer pour moi dans la maison de David, roi d’Israël, car les lieux où l’arche du Seigneur est entrée sont saints. »
###### 12
En ce temps-là, Salomon offrait des holocaustes au Seigneur sur l’autel du Seigneur qu’il avait bâti devant le Vestibule.
###### 13
Il offrait des sacrifices suivant le rituel de chaque jour, selon le commandement de Moïse, pour les sabbats, les nouvelles lunes et les solennités ; de même, trois fois par an, pour la fête des Pains sans levain, la fête des Semaines et la fête des Tentes.
###### 14
Puis, selon ce que David son père avait ordonné, il établit les classes des prêtres dans leur service, les lévites dans leurs fonctions pour louer et officier en présence des prêtres selon le rituel de chaque jour, ainsi que les portiers suivant leurs classes aux diverses portes ; car tel était le commandement de David, l’homme de Dieu.
###### 15
On ne s’écarta en rien du commandement donné par le roi au sujet des prêtres et des lévites, même en ce qui concerne les trésors.
###### 16
Tout le travail de Salomon fut bien mené, dès avant le jour de la fondation de la Maison du Seigneur jusqu’à son achèvement. Parfaite était la Maison du Seigneur !
###### 17
Alors Salomon se rendit à Écione-Guéber et vers Eilath, sur le rivage de la mer, au pays d’Édom.
###### 18
Houram, par l’intermédiaire de ses serviteurs, lui dépêcha des navires ainsi que des serviteurs connaissant bien la mer. Ils arrivèrent avec les serviteurs de Salomon à Ophir et s’y procurèrent quatre cent cinquante lingots d’or, qu’ils rapportèrent au roi Salomon.
