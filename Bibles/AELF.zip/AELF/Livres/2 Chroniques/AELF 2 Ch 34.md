---
aliases : 
- 2 Chroniques 34
- 2 Chroniques 34
- 2 Ch 34
- 2 Chronicles 34
tags : 
- Bible/2Ch/34
- français
cssclass : français
---

# 2 Chroniques 34

###### 01
Josias avait huit ans lorsqu’il devint roi, et il régna trente et un ans à Jérusalem.
###### 02
Il fit ce qui est droit aux yeux du Seigneur, et il marcha sur les chemins de David, son ancêtre ; il ne s’en écarta ni à droite ni à gauche.
###### 03
La huitième année de son règne, alors qu’il était encore un jeune homme, il commença à chercher le Dieu de David, son ancêtre. La douzième année, il commença à purifier le pays de Juda et Jérusalem des lieux sacrés, des poteaux sacrés, des idoles sculptées ou fondues.
###### 04
On détruisit en sa présence les autels des Baals. Les colonnes à encens qui étaient en haut, au-dessus d’eux, il les abattit ; les poteaux sacrés et les idoles sculptées ou fondues, il les brisa, les réduisit en poussière qu’il répandit ensuite sur les tombeaux de ceux qui leur avaient offert des sacrifices.
###### 05
Il brûla les ossements des prêtres sur leurs autels, et purifia le pays de Juda et Jérusalem.
###### 06
Dans les villes de Manassé, d’Éphraïm, de Siméon, et jusqu’en Nephtali, sur toutes les places,
###### 07
il détruisit les autels et les poteaux sacrés ; les idoles, il les brisa et les réduisit en poussière ; toutes les colonnes à encens, il les abattit dans tout le pays d’Israël. Et il revint à Jérusalem.
###### 08
La dix-huitième année de son règne, après avoir purifié le pays et la Maison du Seigneur, Josias envoya Shafane, fils d’Açalyahou, Maaséyahou, gouverneur de la ville, et Yoah, fils de Yoahaz, archiviste, pour réparer la Maison du Seigneur son Dieu.
###### 09
Ils se rendirent chez Helcias, le grand-prêtre, et lui donnèrent l’argent apporté à la Maison de Dieu, celui que les lévites, gardiens du seuil, avaient recueilli de Manassé, d’Éphraïm, et de tout le reste d’Israël, de tout Juda et Benjamin, et des habitants de Jérusalem.
###### 10
On le remit entre les mains des maîtres d’œuvre, préposés à la Maison du Seigneur, on le remit à ces derniers, qui travaillaient à la Maison du Seigneur, pour consolider et réparer la Maison.
###### 11
Ceux-ci le remirent aux charpentiers et aux ouvriers du bâtiment, pour acheter des pierres de taille et du bois pour les assemblages, et refaire la charpente des bâtiments qu’avaient endommagés les rois de Juda.
###### 12
Ces hommes accomplissaient leur travail avec honnêteté. Ils étaient sous la surveillance de Yahath et d’Obadyahou, lévites d’entre les fils de Merari. Zacharie et Meshoullam, d’entre les fils de Qehath, étaient chargés de les diriger, ainsi que tous les lévites habiles à jouer des instruments de musique.
###### 13
Ils surveillaient les porteurs et dirigeaient tous les artisans dans les divers services. D’autres lévites étaient secrétaires, scribes et portiers.
###### 14
Comme on retirait l’argent apporté à la Maison du Seigneur, le prêtre Helcias trouva le livre de la Loi du Seigneur transmise par Moïse.
###### 15
Helcias prit la parole et dit au secrétaire Shafane : « J’ai trouvé le livre de la Loi dans la Maison du Seigneur. » Et Helcias donna le livre à Shafane.
###### 16
Shafane porta le livre au roi et, de plus, lui rendit compte de ce qui s’était passé : « Tout ce qui a été confié à tes serviteurs, ils l’ont fait.
###### 17
L’argent qui se trouvait dans la Maison du Seigneur, ils l’ont versé et remis entre les mains des préposés et des maîtres d’œuvre. »
###### 18
Shafane, le secrétaire, annonça au roi : « Le prêtre Helcias m’a donné un livre. » Et Shafane fit au roi la lecture de ce livre.
###### 19
Après avoir entendu les paroles de la Loi, le roi déchira ses vêtements.
###### 20
Il donna cet ordre à Helcias, à Ahiqam, fils de Shafane, à Abdone, fils de Mika, au secrétaire Shafane, ainsi qu’à Asaya, serviteur du roi :
###### 21
« Allez consulter le Seigneur, pour moi et pour ce qui reste d’Israël et de Juda, au sujet des paroles du livre qu’on vient de retrouver. La fureur du Seigneur est grande : elle s’est déversée sur nous, parce que nos pères n’ont pas observé la parole du Seigneur et n’ont pas pratiqué tout ce qui est écrit dans ce livre. »
###### 22
Alors Helcias et ceux que le roi avait désignés allèrent chez la prophétesse Houlda, femme du gardien des vêtements Shalloum, fils de Toqhath, fils de Hasra. Elle habitait à Jérusalem, dans la ville nouvelle. Quand ils lui eurent parlé de cette affaire,
###### 23
elle leur dit : « Ainsi parle le Seigneur, Dieu d’Israël : Dites à l’homme qui vous a envoyés vers moi :
###### 24
“Ainsi parle le Seigneur : Moi, je vais faire venir un malheur sur ce lieu et sur ses habitants, accomplissant ainsi toutes les malédictions écrites dans le livre qu’on a lu en présence du roi de Juda.
###### 25
Parce qu’ils m’ont abandonné, et qu’ils ont brûlé de l’encens pour d’autres dieux, afin de provoquer mon indignation par toutes les œuvres de leurs mains, ma fureur s’est déversée sur ce lieu et ne s’éteindra plus !”
###### 26
Mais au roi de Juda qui vous a envoyés consulter le Seigneur, vous direz : “Ainsi parle le Seigneur, Dieu d’Israël : Ces paroles, tu les as entendues :
###### 27
puisque ton cœur s’est attendri et que tu t’es humilié devant Dieu, quand tu as entendu ses paroles contre ce lieu et ses habitants, puisque tu t’es humilié devant moi, que tu as déchiré tes vêtements et pleuré devant moi, eh bien ! moi aussi, j’ai entendu – oracle du Seigneur.
###### 28
Moi, je te réunirai à tes pères, tu seras ramené en paix dans leurs tombeaux ; tes yeux ne verront rien de tout le malheur que je fais venir sur ce lieu et sur ses habitants.” » Helcias et ses compagnons rapportèrent au roi la réponse.
###### 29
Le roi fit convoquer tous les anciens de Juda et de Jérusalem,
###### 30
et il monta à la Maison du Seigneur avec tous les gens de Juda, les habitants de Jérusalem, les prêtres et les lévites, et tout le peuple, du plus grand au plus petit. Il lut devant eux toutes les paroles du livre de l’Alliance retrouvé dans la Maison du Seigneur.
###### 31
Le roi était debout, à sa place, et il conclut l’Alliance en présence du Seigneur, afin de suivre le Seigneur, d’observer ses commandements, ses édits et ses décrets, de tout son cœur et de toute son âme, et d’accomplir les paroles de l’Alliance inscrites dans ce Livre.
###### 32
Il fit s’engager tous ceux qui se trouvaient à Jérusalem et en Benjamin ; et les habitants de Jérusalem agirent conformément à l’alliance de Dieu, le Dieu de leurs pères.
###### 33
Josias supprima toutes les abominations de tous les territoires appartenant aux fils d’Israël, et il obligea tous ceux qui se trouvaient en Israël à servir le Seigneur, leur Dieu. Tant qu’il vécut, ils ne s’écartèrent pas du Seigneur, le Dieu de leurs pères.
