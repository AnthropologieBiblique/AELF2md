---
aliases : 
- 2 Chroniques 6
- 2 Chroniques 6
- 2 Ch 6
- 2 Chronicles 6
tags : 
- Bible/2Ch/6
- français
cssclass : français
---

# 2 Chroniques 6

###### 01
Alors Salomon s’écria :
« Le Seigneur déclare demeurer dans la nuée obscure.
###### 02
Et maintenant, je t’ai construit, Seigneur,
une maison somptueuse,
un lieu où tu habiteras éternellement. »
###### 03
Puis le roi se retourna et bénit toute l’assemblée d’Israël ; toute l’assemblée d’Israël se tenait debout.
###### 04
Il dit :
« Béni soit le Seigneur, Dieu d’Israël ! De ses mains, il a accompli ce qu’il avait dit de sa bouche à David mon père :
###### 05
“Depuis le jour où j’ai fait sortir mon peuple du pays d’Égypte, je n’ai choisi aucune ville entre toutes les tribus d’Israël pour y construire une maison où serait mon nom, et je n’ai pas choisi d’homme pour être chef de mon peuple Israël.
###### 06
Mais j’ai choisi Jérusalem pour que mon nom y demeure, et j’ai choisi David pour qu’il soit le chef de mon peuple Israël.”
###### 07
Or David, mon père, avait pris à cœur de construire une maison pour le nom du Seigneur, Dieu d’Israël.
###### 08
Mais le Seigneur a dit à David, mon père : “Tu as pris à cœur de construire une maison pour mon nom, et tu as bien fait de prendre cela à cœur.
###### 09
Cependant, ce n’est pas toi qui construiras la maison, mais ton fils, issu de toi : c’est lui qui construira la maison pour mon nom.”
###### 10
Le Seigneur a réalisé la parole qu’il avait dite, et j’ai succédé à David, mon père, je me suis assis sur le trône d’Israël, comme l’avait dit le Seigneur, et j’ai construit la maison pour le nom du Seigneur, Dieu d’Israël.
###### 11
Là j’ai placé l’Arche où se trouve l’Alliance du Seigneur, qu’il a conclue avec les fils d’Israël. »
###### 12
Salomon se plaça devant l’autel du Seigneur, en face de toute l’assemblée d’Israël, et il étendit les mains.
###### 13
En effet, Salomon avait dressé une estrade de bronze et l’avait installée au milieu de la cour ; elle avait cinq coudées de long, cinq coudées de large et trois coudées de haut. Il y prit place, fléchit les genoux en face de toute l’assemblée d’Israël, puis il étendit les mains vers le ciel,
###### 14
et fit cette prière :
« Seigneur, Dieu d’Israël, il n’y a pas de Dieu comme toi, ni dans les cieux ni sur la terre : tu gardes ton Alliance et ta fidélité envers tes serviteurs, quand ils marchent devant toi de tout leur cœur.
###### 15
Tu as gardé pour ton serviteur David, mon père, ce que tu lui avais dit ; et ce que tu lui avais dit de ta bouche, de ta main aujourd’hui tu l’as accompli.
###### 16
Maintenant, Seigneur, Dieu d’Israël, par égard pour ton serviteur David, mon père, garde la parole que tu lui avais dite : “Tes descendants qui siégeront sur le trône d’Israël ne seront pas écartés de ma présence, pourvu que tes fils veillent à suivre leur chemin en marchant selon ma Loi, comme tu as marché devant moi.”
###### 17
Maintenant, Seigneur, Dieu d’Israël, que se vérifie la parole que tu as dite à ton serviteur David !
###### 18
Est-ce que, vraiment, Dieu habiterait avec l’homme sur la terre ? Les cieux et les hauteurs des cieux ne peuvent te contenir : encore moins cette Maison que j’ai bâtie !
###### 19
Sois attentif à la prière et à la supplication de ton serviteur. Écoute, Seigneur mon Dieu, la prière et le cri qu’il lance vers toi.
###### 20
Que tes yeux soient ouverts jour et nuit sur cette Maison, sur ce lieu dont tu as dit que là tu mettrais ton nom. Écoute donc la prière que ton serviteur fera en ce lieu.
###### 21
Écoute les supplications de ton serviteur et de ton peuple Israël, lorsqu’ils prieront en ce lieu. Toi, depuis les cieux où tu habites, écoute et pardonne.
###### 22
Quand un homme aura péché contre son prochain et qu’on lui imposera un serment qui peut se retourner contre lui, s’il vient à prêter ce serment devant ton autel dans cette Maison,
###### 23
toi, depuis les cieux, écoute, agis et juge tes serviteurs. Le coupable, rends-lui son dû : que sa conduite retombe sur sa tête ; déclare juste le juste : traite-le selon sa justice !
###### 24
Quand ton peuple Israël aura été battu devant l’ennemi, parce qu’il aura péché contre toi, s’il revient et célèbre ton nom, s’il prie et te supplie dans cette Maison,
###### 25
toi, depuis les cieux, écoute, pardonne le péché de ton peuple Israël et fais-les revenir sur le sol que tu leur as donné ainsi qu’à leurs pères.
###### 26
Lorsque les cieux seront fermés et qu’il n’y aura pas de pluie, parce que les fils d’Israël auront péché contre toi, s’ils prient vers ce lieu et célèbrent ton nom, s’ils se détournent de leur péché, parce que tu les auras humiliés,
###### 27
toi, dans les cieux, écoute, pardonne le péché de tes serviteurs et de ton peuple Israël. Tu leur enseigneras le bon chemin par où ils doivent marcher, et tu accorderas la pluie à ta terre, celle que tu as donnée à ton peuple en héritage.
###### 28
Lorsqu’il y aura la famine dans le pays, lorsqu’il y aura la peste, la rouille et la nigelle du blé, les sauterelles et les criquets, lorsque son ennemi assiégera une ville dans le pays, en tout fléau, en toute maladie,
###### 29
quel que soit le motif de la prière ou de la supplication émanant de tout homme ou de tout ton peuple Israël, dès l’instant où chacun reconnaît sa plaie et sa douleur, et qu’il tend les mains vers cette maison,
###### 30
toi, depuis les cieux où tu habites, écoute, pardonne. Traite chacun selon toute sa conduite, puisque tu connais son cœur – toi seul, en effet, connais le cœur de l’homme –,
###### 31
afin qu’ils te craignent, en marchant dans tes voies, tous les jours qu’ils vivront sur le sol que tu as donné à nos pères.
###### 32
Si, à cause de ton grand nom, à cause de ta main forte et de ton bras étendu, un étranger, qui n’est pas de ton peuple Israël, vient d’un pays lointain prier dans cette Maison,
###### 33
toi, depuis les cieux où tu habites, écoute-le. Exauce toutes les demandes de l’étranger. Ainsi, tous les peuples de la terre, comme ton peuple Israël, vont reconnaître ton nom et te craindre. Et ils sauront que ton nom est invoqué sur cette Maison que j’ai bâtie.
###### 34
Lorsque ton peuple partira en guerre contre ses ennemis, dans la direction où tu l’auras envoyé, et qu’il te priera, tourné vers cette ville que tu as choisie et vers la Maison que j’ai bâtie pour ton nom,
###### 35
toi, depuis les cieux, écoute leur prière et leur supplication, et rends-leur justice.
###### 36
Lorsqu’ils pécheront contre toi – car il n’est pas d’être humain qui ne commette quelque péché – et que tu seras irrité contre eux, alors tu les livreras à la merci de leurs ennemis, et leurs vainqueurs les emmèneront captifs dans un pays lointain ou proche.
###### 37
Si, au pays où ils auront été emmenés captifs, ils rentrent en eux-mêmes, s’ils se repentent, s’ils élèvent vers toi leur supplication dans le pays de leur captivité, en disant : “Nous avons péché, nous avons commis une faute, nous avons fait ce qui est mal” ;
###### 38
s’ils reviennent à toi de tout leur cœur et de toute leur âme, au pays de leur captivité, là où ils ont été emmenés captifs, et s’ils prient, tournés vers le pays que tu as donné à leurs pères, vers la ville que tu as choisie et vers la Maison que j’ai bâtie pour ton nom,
###### 39
toi, depuis les cieux où tu habites, écoute leur prière et leur supplication, rends-leur justice et pardonne à ton peuple qui a péché contre toi.
###### 40
À présent, mon Dieu, que tes yeux restent ouverts,
et tes oreilles attentives à la prière faite en ce lieu !
###### 41
Et maintenant, monte, Seigneur Dieu,
vers le lieu de ton repos,
toi, et l’arche de ta force !
Que tes prêtres, Seigneur Dieu, soient vêtus de salut,
que tes fidèles exultent dans le bonheur !
###### 42
Seigneur Dieu, ne repousse pas la face de ton messie,
souviens-toi de ce que David, ton serviteur,
a fait avec fidélité ! »
