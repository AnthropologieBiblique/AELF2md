---
aliases : 
- 2 Chroniques 17
- 2 Chroniques 17
- 2 Ch 17
- 2 Chronicles 17
tags : 
- Bible/2Ch/17
- français
cssclass : français
---

# 2 Chroniques 17

###### 01
Son fils Josaphat régna à sa place. Il s’affermit contre Israël.
###### 02
Il installa des troupes dans toutes les villes fortifiées de Juda, il plaça des préfets dans le pays de Juda et dans les villes d’Éphraïm dont s’était emparé Asa, son père.
###### 03
Le Seigneur fut avec Josaphat car celui-ci marcha dans les chemins où David, son père, avait marché en ses débuts. Il ne chercha pas les Baals,
###### 04
mais c’est le Dieu de son père qu’il chercha ; il marcha selon ses commandements, sans agir comme Israël.
###### 05
Le Seigneur confirma la royauté entre ses mains. Tout Juda offrait des présents à Josaphat, qui eut en abondance richesse et gloire.
###### 06
Son cœur s’exalta dans les chemins du Seigneur, et il supprima de nouveau en Juda les lieux sacrés et les poteaux sacrés.
###### 07
La troisième année de son règne, il envoya ses officiers Ben-Haïl, Abdias, Zacharie, Nathanaël et Michée, pour donner un enseignement dans les villes de Juda.
###### 08
Des lévites les accompagnaient : Shemayahou, Netanyahou, Zebadyahou, Asaël, Shemiramoth, Jonathan, Adonias, Tobie, Tob-Adonias, et avec eux les prêtres Élishama et Joram.
###### 09
Ils enseignaient dans Juda, emportant avec eux le livre de la Loi du Seigneur ; ils firent le tour de toutes les villes de Juda, donnant un enseignement parmi le peuple.
###### 10
La terreur du Seigneur s’empara de tous les royaumes des pays qui entouraient Juda, et ils ne firent pas la guerre à Josaphat.
###### 11
De chez les Philistins, on apporta à Josaphat des présents et de l’argent comme tribut ; même les Arabes lui amenèrent du petit bétail : sept mille sept cents béliers et sept mille sept cents boucs.
###### 12
Josaphat devenait de plus en plus important. Il construisit en Juda des citadelles et des villes d’entrepôts.
###### 13
Il avait une nombreuse main-d’œuvre dans les villes de Juda, et des hommes de guerre, vaillants guerriers, à Jérusalem.
###### 14
En voici le dénombrement, selon la maison de leurs pères : pour Juda, comme officiers de millier, il y avait l’officier Adna, et avec lui trois cent mille vaillants guerriers ;
###### 15
à ses côtés, l’officier Yohanane, et avec lui deux cent quatre-vingt mille hommes ;
###### 16
à ses côtés, Amasya, fils de Zikri, engagé volontaire pour le Seigneur, et avec lui deux cent mille vaillants guerriers.
###### 17
De Benjamin, il y avait Élyada, vaillant guerrier, et avec lui deux cent mille hommes armés de l’arc et du bouclier ;
###### 18
à ses côtés, Yehozabad, et avec lui cent quatre-vingt mille hommes équipés pour la guerre.
###### 19
Tels étaient ceux qui servaient le roi, sans compter ceux que le roi avait placés dans les villes fortes, sur tout le territoire de Juda.
