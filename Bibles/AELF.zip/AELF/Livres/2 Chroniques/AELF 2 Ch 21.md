---
aliases : 
- 2 Chroniques 21
- 2 Chroniques 21
- 2 Ch 21
- 2 Chronicles 21
tags : 
- Bible/2Ch/21
- français
cssclass : français
---

# 2 Chroniques 21

###### 01
Josaphat reposa avec ses pères.
Il fut enseveli avec eux dans la Cité de David.
Son fils Joram régna à sa place.
###### 02
Celui-ci avait des frères, fils de Josaphat : Azaria, Yehiel, Zacharie, Azarias, Mikaël et Shefatias. Tous ceux-là étaient fils de Josaphat, roi d’Israël.
###### 03
Leur père leur avait donné de nombreux cadeaux en argent, en or et en objets précieux, ainsi que des villes fortes en Juda. Mais la royauté, il l’avait donnée à Joram, parce qu’il était l’aîné.
###### 04
Joram s’établit à la tête du royaume de son père, et s’y affermit ; alors il tua par l’épée tous ses frères et quelques princes d’Israël.
###### 05
Joram avait trente-deux ans lorsqu’il devint roi, et il régna huit ans à Jérusalem.
###### 06
Il marcha dans le chemin des rois d’Israël, comme avait fait la maison d’Acab, car il avait pour femme une fille d’Acab. Et il fit ce qui est mal aux yeux du Seigneur.
###### 07
Mais le Seigneur ne voulut pas détruire la maison de David, à cause de l’alliance qu’il avait conclue avec David et parce qu’il avait promis de lui donner, à lui et à ses fils, une lampe pour toujours.
###### 08
Du temps de Joram, le pays d’Édom se révolta contre la domination de Juda et se donna un roi.
###### 09
Joram passa la frontière avec ses officiers et tous ses chars. S’étant levé de nuit, il battit les Édomites qui l’encerclaient, lui et les commandants de chars.
###### 10
Édom fut en révolte contre la domination de Juda jusqu’à ce jour. Alors, en ce temps-là, la ville de Libna se révolta contre sa domination.
Joram, en effet, avait abandonné le Seigneur, Dieu de ses pères.
###### 11
Il fit même des lieux sacrés dans les montagnes de Juda. Il poussa les habitants de Jérusalem à se prostituer, et dévoya les gens de Juda.
###### 12
Une lettre du prophète Élie lui parvint, qui disait : « Ainsi parle le Seigneur, le Dieu de ton père David : Tu n’as pas marché dans les chemins de Josaphat, ton père, ni dans les chemins d’Asa, roi de Juda,
###### 13
mais tu as marché dans le chemin des rois d’Israël, tu as poussé à la prostitution les gens de Juda et les habitants de Jérusalem comme l’avait fait la maison d’Acab, tu as même tué tes frères – la maison de ton père –, et ils étaient meilleurs que toi.
###### 14
C’est pourquoi le Seigneur va frapper d’un grand fléau ton peuple, tes fils, tes femmes et tout ce qui t’appartient.
###### 15
Toi, tu seras frappé de nombreuses maladies, d’un mal d’entrailles tel que, par l’effet de ce mal, tu te videras jour après jour de tes entrailles. »
###### 16
Le Seigneur excita contre Joram l’esprit des Philistins et des Arabes voisins des Éthiopiens.
###### 17
Ils montèrent contre le pays de Juda et l’envahirent. Ils s’emparèrent de toutes les richesses qui se trouvaient dans la maison du roi, ainsi que de ses fils et de ses femmes. Il ne lui resta plus qu’un fils, Ocozias, le plus jeune.
###### 18
Après tout cela, le Seigneur le frappa aux entrailles d’un mal incurable.
###### 19
De jour en jour, par l’effet de son mal il se vidait de ses entrailles jusqu’à la fin de la deuxième année, et il mourut dans de cruelles souffrances. Le peuple ne fit pas pour lui de brasier comme on l’avait fait pour ses pères.
###### 20
Joram avait trente-deux ans lorsqu’il devint roi,
et il régna huit ans à Jérusalem.
Il partit sans laisser de regrets.
On l’ensevelit dans la Cité de David,
mais non pas dans les tombeaux des rois.
