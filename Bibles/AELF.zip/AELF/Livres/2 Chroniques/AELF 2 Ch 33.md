---
aliases : 
- 2 Chroniques 33
- 2 Chroniques 33
- 2 Ch 33
- 2 Chronicles 33
tags : 
- Bible/2Ch/33
- français
cssclass : français
---

# 2 Chroniques 33

###### 01
Manassé avait douze ans lorsqu’il devint roi, et il régna cinquante-cinq ans à Jérusalem.
###### 02
Il fit ce qui est mal aux yeux du Seigneur, selon les coutumes abominables des nations que le Seigneur avait dépossédées devant les fils d’Israël.
###### 03
Il rebâtit les lieux sacrés qu’avait détruits Ézékias, son père, et il fit élever des autels aux Baals. Il fabriqua des poteaux sacrés ; il se prosterna devant toute l’armée des cieux et s’en fit le serviteur.
###### 04
Il bâtit des autels dans la Maison du Seigneur, alors que le Seigneur avait dit : « Dans Jérusalem, mon nom sera à jamais ».
###### 05
Manassé bâtit aussi des autels à toute l’armée des cieux, dans les deux cours de la Maison du Seigneur.
###### 06
C’est lui qui fit passer ses fils par le feu, dans la vallée de Ben-Hinnome. Il pratiqua divination, incantation et enchantement, il interrogea les spectres et les esprits. Il fit de maintes façons ce qui est mal aux yeux du Seigneur, pour provoquer son indignation.
###### 07
Il plaça dans la Maison de Dieu la statue de l’idole qu’il avait faite. Or, Dieu avait dit à David et à son fils Salomon : « Dans cette Maison, et dans Jérusalem que j’ai choisie parmi toutes les tribus d’Israël, je mettrai mon nom à jamais.
###### 08
Je ne ferai plus s’écarter les pas d’Israël loin de la terre que j’ai destinée à vos pères, pourvu qu’ils veillent à faire tout ce que je leur ai ordonné, selon toute la Loi, les décrets et les ordonnances, transmis par Moïse. »
###### 09
Manassé égara les gens de Juda et les habitants de Jérusalem, de sorte qu’ils firent le mal, plus encore que les nations que le Seigneur avait anéanties devant les fils d’Israël.
###### 10
Le Seigneur s’adressa à Manassé et à son peuple, mais ils n’y prêtèrent pas attention.
###### 11
Alors le Seigneur fit venir contre eux les officiers de l’armée du roi d’Assour. Ils prirent Manassé avec des crochets, l’attachèrent avec une double chaîne de bronze et l’emmenèrent à Babylone.
###### 12
Dans son angoisse, Manassé apaisa le visage du Seigneur son Dieu en s’humiliant profondément devant le Dieu de ses pères.
###### 13
Il le pria ; le Seigneur l’exauça, entendit sa supplication : il le fit revenir à Jérusalem dans son royaume. Et Manassé reconnut que le Seigneur est Dieu.
###### 14
Après cela, il bâtit un rempart à l’extérieur de la Cité de David, à l’ouest, vers Guihone, dans la vallée, jusqu’à l’entrée de la porte des Poissons, de manière à entourer l’Ophel ; ce rempart, il le fit très élevé. Il plaça des officiers de l’armée dans toutes les villes fortifiées de Juda.
###### 15
Il supprima de la Maison du Seigneur les dieux étrangers et l’idole, ainsi que tous les autels qu’il avait bâtis sur la montagne de la Maison du Seigneur et dans Jérusalem, et les jeta hors de la ville.
###### 16
Il restaura l’autel du Seigneur, il y offrit des sacrifices de paix et d’action de grâce ; puis il ordonna aux gens de Juda de servir le Seigneur, Dieu d’Israël.
###### 17
Toutefois, le peuple sacrifiait encore dans les lieux sacrés, mais seulement au Seigneur son Dieu.
###### 18
Le reste des actions de Manassé,
la prière qu’il adressa à son Dieu,
et les paroles des voyants qui lui parlèrent
au nom du Seigneur, Dieu d’Israël,
cela se trouve dans les Actes des rois d’Israël.
###### 19
Sa prière, et comment il fut exaucé,
tous ses péchés et ses infidélités,
les endroits où il bâtit des lieux sacrés,
et dressa des poteaux sacrés et des idoles
avant de s’être humilié,
voici que cela est écrit dans les Actes de Hozaï.
###### 20
Manassé reposa avec ses pères,
et on l’ensevelit dans sa maison.
Son fils Amone régna à sa place.
###### 21
Amone avait vingt-deux ans lorsqu’il devint roi, et il régna deux ans à Jérusalem.
###### 22
Il fit ce qui est mal aux yeux du Seigneur, comme avait fait Manassé, son père. Amone offrit des sacrifices à toutes les idoles qu’avait fabriquées Manassé, son père, et il les servit.
###### 23
Il ne s’humilia pas devant le Seigneur, comme l’avait fait Manassé, son père. En effet, lui, Amone, multiplia les offenses.
###### 24
Ses serviteurs complotèrent contre lui ; ils le mirent à mort dans sa maison.
###### 25
Mais les gens du pays frappèrent tous ceux qui avaient comploté contre le roi Amone, et ce sont les gens du pays qui firent roi son fils Josias à sa place.
