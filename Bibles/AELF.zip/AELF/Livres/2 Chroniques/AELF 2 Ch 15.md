---
aliases : 
- 2 Chroniques 15
- 2 Chroniques 15
- 2 Ch 15
- 2 Chronicles 15
tags : 
- Bible/2Ch/15
- français
cssclass : français
---

# 2 Chroniques 15

###### 01
L’Esprit de Dieu fut sur Azarias, fils d’Oded,
###### 02
qui sortit au-devant d’Asa et lui dit : « Écoutez-moi, Asa, et tout Juda et Benjamin ! Le Seigneur est avec vous quand vous êtes avec lui. Si vous le cherchez, il se laisse trouver par vous ; mais si vous l’abandonnez, il vous abandonne.
###### 03
Pendant longtemps, Israël a été sans vrai Dieu, sans prêtre pour enseigner et sans Loi.
###### 04
Mais dans sa détresse il est revenu vers le Seigneur, Dieu d’Israël ; ils l’ont cherché, et le Seigneur s’est laissé trouver par eux.
###### 05
En ce temps-là, il n’y avait pas de sécurité pour ceux qui allaient et venaient, car de nombreux désordres pesaient sur tous les habitants du pays.
###### 06
On se heurtait, nation contre nation, ville contre ville ; car Dieu les frappait de panique par toutes sortes de détresses.
###### 07
Mais vous, soyez forts, et que vos mains ne faiblissent pas, car vos actions auront leur récompense. »
###### 08
Lorsqu’il entendit ces paroles et la prophétie d’Azarias, fils d’Oded, Asa prit courage. Il fit disparaître les horreurs de tout le pays de Juda et de Benjamin, ainsi que des villes dont il s’était emparé dans la montagne d’Éphraïm. Et il remit en état l’autel du Seigneur qui se trouvait devant le Vestibule du Seigneur.
###### 09
Asa rassembla tout Juda et Benjamin, et ceux d’Éphraïm, de Manassé et de Siméon qui résidaient parmi eux. Car des gens d’Israël étaient passés en grand nombre de son côté, en voyant que le Seigneur son Dieu était avec lui.
###### 10
Ils se rassemblèrent à Jérusalem, le troisième mois de la quinzième année du règne d’Asa.
###### 11
Ce jour-là, ils offrirent au Seigneur, sur le butin qu’ils avaient ramené, sept cents bœufs et sept mille moutons.
###### 12
Ils s’engagèrent par une alliance à chercher le Seigneur, Dieu de leurs pères, de tout leur cœur et de toute leur âme.
###### 13
Et quiconque ne chercherait pas le Seigneur, Dieu d’Israël, serait mis à mort, le petit comme le grand, homme ou femme.
###### 14
Ils prêtèrent serment au Seigneur, d’une voix forte, avec des ovations, des trompettes et des cors.
###### 15
Tous ceux de Juda se réjouirent de ce serment, car ils l’avaient prêté de tout leur cœur, et c’est de leur plein gré qu’ils avaient cherché le Seigneur qui se laissa trouver par eux. Et le Seigneur leur procura le repos de tous côtés.
###### 16
Asa destitua Maaka, grand-mère du roi, du titre de reine mère, parce qu’elle avait fabriqué une Infamie pour Ashéra. Asa abattit cette Infamie, la réduisit en poussière et la brûla dans le ravin du Cédron.
###### 17
Mais les lieux sacrés ne disparurent pas d’Israël, bien que le cœur d’Asa fût intègre tous les jours de sa vie.
###### 18
Il fit apporter à la Maison de Dieu les objets sacrés de son père et ceux qu’il avait lui-même consacrés : l’argent, l’or et les ustensiles.
###### 19
Il n’y eut plus de guerre jusqu’à la trente-cinquième année du règne d’Asa.
