---
aliases : 
- 2 Chroniques 27
- 2 Chroniques 27
- 2 Ch 27
- 2 Chronicles 27
tags : 
- Bible/2Ch/27
- français
cssclass : français
---

# 2 Chroniques 27

###### 01
Yotam avait vingt-cinq ans lorsqu’il devint roi, et il régna seize ans à Jérusalem. Sa mère s’appelait Yerousha, fille de Sadoc.
###### 02
Il fit ce qui est droit aux yeux du Seigneur, tout comme avait fait Ozias, son père, sans toutefois entrer dans le temple du Seigneur. Mais le peuple continuait à se corrompre.
###### 03
C’est Yotam qui bâtit la porte Haute de la Maison du Seigneur ; il fit beaucoup de travaux sur le rempart d’Ophel.
###### 04
Il construisit des villes dans la montagne de Juda, et, dans les régions boisées, des citadelles et des tours.
###### 05
C’est lui qui combattit le roi des fils d’Ammone et l’emporta sur eux. Les fils d’Ammone lui donnèrent, cette année-là, cent talents d’argent, dix mille quintaux de blé et dix mille quintaux d’orge. Et ils lui en apportèrent autant, la deuxième et la troisième année.
###### 06
Yotam s’affermit, car il marchait constamment en présence du Seigneur son Dieu.
###### 07
Le reste des actions de Yotam,
toutes ses guerres et ce qu’il a entrepris,
voici que cela est écrit dans le Livre des rois d’Israël et de Juda.
###### 08
Il avait vingt-cinq ans lorsqu’il devint roi,
et il régna seize ans à Jérusalem.
###### 09
Yotam reposa avec ses pères,
et on l’ensevelit dans la Cité de David.
Son fils Acaz régna à sa place.
