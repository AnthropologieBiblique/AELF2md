---
aliases : 
- 2 Chroniques 12
- 2 Chroniques 12
- 2 Ch 12
- 2 Chronicles 12
tags : 
- Bible/2Ch/12
- français
cssclass : français
---

# 2 Chroniques 12

###### 01
Quand Roboam eut affermi sa royauté et fut devenu fort, il abandonna la Loi du Seigneur, et tout Israël le suivit.
###### 02
La cinquième année du règne de Roboam, Shishaq, roi d’Égypte, monta contre Jérusalem, parce que le peuple avait été infidèle au Seigneur.
###### 03
Avec mille deux cents chars, soixante mille cavaliers, et une foule innombrable venue d’Égypte avec lui : Libyens, Soukkiens, Éthiopiens,
###### 04
il s’empara des villes fortes de Juda et atteignit Jérusalem.
###### 05
Le prophète Shemaya vint trouver Roboam et les princes de Juda, qui s’étaient regroupés à Jérusalem pour fuir Shishaq. Il leur dit : « Ainsi parle le Seigneur : Vous, vous m’avez abandonné, eh bien, moi aussi, je vous ai abandonnés à la main de Shishaq. »
###### 06
Les princes d’Israël et le roi s’inclinèrent et dirent : « Le Seigneur est juste. »
###### 07
Le Seigneur vit qu’ils s’inclinaient. La parole du Seigneur fut adressée à Shemaya : « Ils se sont inclinés ; moi, je ne les détruirai pas. Je leur permettrai sous peu d’en réchapper, et ma colère ne se déversera pas sur Jérusalem par la main de Shishaq.
###### 08
Mais ils deviendront ses esclaves et ils sauront la différence entre me servir et servir les royaumes des autres pays. »
###### 09
Shishaq, roi d’Égypte, monta contre Jérusalem. Il s’empara des trésors de la Maison du Seigneur et des trésors de la maison du roi. Il s’empara de tout. Il s’empara même des boucliers d’or qu’avait faits Salomon.
###### 10
Le roi Roboam fit, pour les remplacer, des boucliers de bronze, et les confia aux chefs des gardes, à la porte de la maison du roi.
###### 11
Chaque fois que le roi se rendait à la Maison du Seigneur, les gardes venaient prendre ces boucliers, puis ils les rapportaient dans la salle des gardes.
###### 12
Parce que le roi s’était incliné, la colère du Seigneur se détourna de lui et ne détruisit pas le pays jusqu’à l’extermination : il y avait encore en Juda quelque chose de bon.
###### 13
Le roi Roboam s’affermit à Jérusalem et y régna. Roboam avait quarante et un ans lorsqu’il devint roi, et il régna dix-sept ans à Jérusalem, la ville que le Seigneur avait choisie parmi toutes les tribus d’Israël pour y mettre son nom. Sa mère s’appelait Naama, l’Ammonite.
###### 14
Il fit ce qui est mal, car il n’appliqua pas son cœur à chercher le Seigneur.
###### 15
Les actions de Roboam, des premières aux dernières,
cela n’est-il pas écrit dans les Actes du prophète Shemaya,
et de Iddo le voyant, selon l’ordre généalogique ?
Il y eut continuellement la guerre entre Roboam et Jéroboam.
###### 16
Roboam reposa avec ses pères.
Il fut enseveli dans la Cité de David.
Son fils Abiya régna à sa place.
