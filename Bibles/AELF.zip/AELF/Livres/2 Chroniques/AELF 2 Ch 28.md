---
aliases : 
- 2 Chroniques 28
- 2 Chroniques 28
- 2 Ch 28
- 2 Chronicles 28
tags : 
- Bible/2Ch/28
- français
cssclass : français
---

# 2 Chroniques 28

###### 01
Acaz avait vingt ans lorsqu’il devint roi, et il régna seize ans à Jérusalem. Il ne fit pas ce qui est droit aux yeux du Seigneur, comme avait fait David, son ancêtre.
###### 02
Il marcha dans le chemin des rois d’Israël, et il fit même des idoles de métal fondu en l’honneur des Baals.
###### 03
C’est lui qui brûla de l’encens dans la vallée de Ben-Hinnom, et fit passer ses fils par le feu, selon les coutumes abominables des nations que le Seigneur avait dépossédées devant les fils d’Israël.
###### 04
Il offrit des sacrifices et brûla de l’encens dans les lieux sacrés, sur les collines et sous tout arbre verdoyant.
###### 05
Le Seigneur son Dieu le livra aux mains du roi des Araméens. Ceux-ci le vainquirent, et firent un grand nombre de prisonniers qu’ils emmenèrent à Damas. Il fut également livré aux mains du roi d’Israël qui lui infligea une grande défaite.
###### 06
En un seul jour, Pèqah, fils de Remalyahou, tua en Juda cent vingt mille hommes, tous de vaillants guerriers, car ils avaient abandonné le Seigneur, Dieu de leurs pères.
###### 07
Zikri, guerrier d’Éphraïm, tua Maasias, fils du roi, Azriqam, chef de la maison du roi, et Elqana, le second du roi.
###### 08
Les fils d’Israël firent prisonniers parmi leurs frères deux cent mille femmes, fils et filles. Ils prirent aussi un grand butin qu’ils emportèrent à Samarie.
###### 09
Il y avait là un prophète du Seigneur, nommé Oded. Il sortit au-devant de l’armée qui arrivait à Samarie, et dit : « Voici que, dans sa fureur contre Juda, le Seigneur, Dieu de vos pères, les a livrés entre vos mains, et vous les avez tués avec une rage qui est parvenue jusqu’au ciel.
###### 10
Et maintenant, vous parlez de soumettre les fils de Juda et de Jérusalem pour qu’ils soient vos serviteurs et vos servantes. Mais n’avez-vous pas à vous reprocher quelque offense envers le Seigneur votre Dieu ?
###### 11
Alors, maintenant écoutez-moi, et renvoyez les prisonniers que vous avez faits parmi vos frères, car l’ardeur de la colère du Seigneur est sur vous. »
###### 12
Quelques-uns d’entre les chefs des fils d’Éphraïm, Azarias, fils de Yohanane, Bérékia, fils de Meshillémoth, Yehizqia, fils de Shalloum, et Amasa, fils de Hadlaï, se dressèrent contre ceux qui revenaient de l’expédition.
###### 13
Ils leur dirent : « Ne faites pas entrer ici les prisonniers : ce serait nous charger d’une offense envers le Seigneur, et ajouter à nos péchés et à nos offenses. Notre offense est déjà grande, et l’ardeur de la colère du Seigneur est sur Israël. »
###### 14
La troupe abandonna les prisonniers et le butin devant les princes et toute l’assemblée.
###### 15
Alors se levèrent les hommes désignés par leurs noms, qui prirent en charge les prisonniers. Avec le butin, ils habillèrent tous ceux d’entre eux qui étaient nus, leur donnèrent de quoi se vêtir et se chausser, les firent manger et boire, et les soignèrent. Ils conduisirent sur des ânes tous les éclopés et les emmenèrent à Jéricho, la ville des Palmiers, auprès de leurs frères. Puis ils retournèrent à Samarie.
###### 16
À cette époque, le roi Acaz envoya demander de l’aide aux rois d’Assour :
###### 17
les Édomites étaient encore venus, avaient battu Juda et emmené des prisonniers ;
###### 18
les Philistins s’étaient répandus dans les villes du Bas-Pays et du Néguev de Juda ; ils avaient pris Beth-Shèmesh, Ayyalone, Guedéroth, Soko et ses dépendances, Timna et ses dépendances, Guimzo et ses dépendances, et s’y étaient installés.
###### 19
En effet, le Seigneur humiliait Juda à cause d’Acaz, roi d’Israël, qui laissait Juda se relâcher et qui était gravement infidèle au Seigneur.
###### 20
Téglath-Phalasar, roi d’Assour, vint l’attaquer et l’assiégea, au lieu de le soutenir.
###### 21
En effet, Acaz avait dépouillé la Maison du Seigneur, la maison du roi et des princes, pour faire des présents au roi d’Assour. Mais cela ne lui fut d’aucune aide.
###### 22
Au temps où il était assiégé, le roi Acaz, lui, continuait à être infidèle au Seigneur.
###### 23
Il offrit des sacrifices aux dieux de Damas qui l’avaient frappé, car il se disait : « Puisque les dieux des rois d’Aram leur viennent en aide, je leur offrirai des sacrifices, et ils me viendront en aide ! » Mais ces dieux furent une cause de chute pour lui et pour tout Israël.
###### 24
Acaz rassembla les objets de la Maison de Dieu et les brisa ; il ferma les portes de la Maison du Seigneur, et se fit des autels dans tous les coins de Jérusalem.
###### 25
Dans chacune des villes de Juda, il établit des lieux sacrés pour brûler de l’encens à d’autres dieux. Et il provoqua l’indignation du Seigneur, Dieu de ses pères.
###### 26
Le reste de ses actions et toutes ses entreprises,
des premières aux dernières,
voici que cela est écrit dans le Livre des rois de Juda et d’Israël.
###### 27
Acaz reposa avec ses pères,
et on l’ensevelit dans la ville, à Jérusalem,
car on ne le mit pas dans les tombeaux des rois d’Israël.
Son fils Ézékias régna à sa place.
