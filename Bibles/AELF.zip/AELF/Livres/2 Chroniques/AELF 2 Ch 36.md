---
aliases : 
- 2 Chroniques 36
- 2 Chroniques 36
- 2 Ch 36
- 2 Chronicles 36
tags : 
- Bible/2Ch/36
- français
cssclass : français
---

# 2 Chroniques 36

###### 01
Les gens du pays prirent alors Joakaz, fils de Josias, et le firent roi à la place de son père, à Jérusalem.
###### 02
Joakaz avait vingt-trois ans lorsqu’il devint roi, et il régna trois mois à Jérusalem.
###### 03
Le roi d’Égypte le destitua à Jérusalem et imposa au pays un tribut de cent talents d’argent et d’un talent d’or.
###### 04
Le roi d’Égypte fit roi Élyakim, frère de Joakaz, sur Juda et Jérusalem, et il changea son nom en celui de Joakim. Quant à son frère Joakaz, Nékao le prit et l’emmena en Égypte.
###### 05
Joakim avait vingt-cinq ans lorsqu’il devint roi, et il régna onze ans à Jérusalem. Il fit ce qui est mal aux yeux du Seigneur son Dieu.
###### 06
Nabucodonosor, roi de Babylone, monta contre lui et l’enchaîna d’une double chaîne de bronze pour l’emmener à Babylone.
###### 07
Nabucodonosor emporta à Babylone une partie des objets de la Maison du Seigneur et les déposa dans son palais, à Babylone.
###### 08
Le reste des actions de Joakim,
les abominations qu’il commit et ce qui lui est arrivé,
voici que cela est écrit dans le Livre des rois d’Israël et de Juda.
Son fils Jékonias régna à sa place.
###### 09
Jékonias avait huit ans lorsqu’il devint roi, et il régna trois mois et dix jours à Jérusalem. Il fit ce qui est mal aux yeux du Seigneur.
###### 10
Au retour du printemps, le roi Nabucodonosor l’envoya chercher et le fit emmener à Babylone, avec les objets précieux de la Maison du Seigneur. Il fit roi, sur Juda et sur Jérusalem, Sédécias, frère de Jékonias.
###### 11
Sédécias avait vingt et un ans lorsqu’il devint roi, et il régna onze ans à Jérusalem.
###### 12
Il fit ce qui est mal aux yeux du Seigneur son Dieu, et ne s’humilia pas devant le prophète Jérémie, qui parlait au nom du Seigneur.
###### 13
Il se révolta même contre le roi Nabucodonosor qui lui avait fait prêter serment par Dieu. Il raidit sa nuque et endurcit son cœur, plutôt que de revenir au Seigneur, Dieu d’Israël.
###### 14
Tous les chefs des prêtres et du peuple multipliaient les infidélités, en imitant toutes les abominations des nations païennes, et ils profanaient la Maison que le Seigneur avait consacrée à Jérusalem.
###### 15
Le Seigneur, le Dieu de leurs pères, sans attendre et sans se lasser, leur envoyait des messagers, car il avait pitié de son peuple et de sa Demeure.
###### 16
Mais eux tournaient en dérision les envoyés de Dieu, méprisaient ses paroles, et se moquaient de ses prophètes ; finalement, il n’y eut plus de remède à la fureur grandissante du Seigneur contre son peuple.
###### 17
Alors le Seigneur fit monter contre eux le roi des Chaldéens, qui tua par l’épée les jeunes gens à l’intérieur du sanctuaire, n’épargna ni le jeune homme ni la jeune fille, ni le vieillard ni l’infirme : le Seigneur les livra tous entre ses mains.
###### 18
Tous les objets, grands ou petits, de la Maison de Dieu, les trésors de la Maison du Seigneur et les trésors du roi et de ses princes, Nabucodonosor emporta tout cela à Babylone.
###### 19
Les Babyloniens brûlèrent la Maison de Dieu, détruisirent le rempart de Jérusalem, incendièrent tous ses palais, et réduisirent à rien tous leurs objets précieux.
###### 20
Nabucodonosor déporta à Babylone ceux qui avaient échappé au massacre ; ils devinrent les esclaves du roi et de ses fils jusqu’au temps de la domination des Perses.
###### 21
Ainsi s’accomplit la parole du Seigneur proclamée par Jérémie : « La terre sera dévastée et elle se reposera durant soixante-dix ans, jusqu’à ce qu’elle ait compensé par ce repos tous les sabbats profanés. »
###### 22
Or, la première année du règne de Cyrus, roi de Perse, pour que soit accomplie la parole du Seigneur proclamée par Jérémie, le Seigneur inspira Cyrus, roi de Perse. Et celui-ci fit publier dans tout son royaume – et même consigner par écrit – :
###### 23
« Ainsi parle Cyrus, roi de Perse : Le Seigneur, le Dieu du ciel, m’a donné tous les royaumes de la terre ; et il m’a chargé de lui bâtir une maison à Jérusalem, en Juda. Quiconque parmi vous fait partie de son peuple, que le Seigneur son Dieu soit avec lui, et qu’il monte à Jérusalem ! »
