---
aliases : 
- 2 Chroniques 13
- 2 Chroniques 13
- 2 Ch 13
- 2 Chronicles 13
tags : 
- Bible/2Ch/13
- français
cssclass : français
---

# 2 Chroniques 13

###### 01
La dix-huitième année du règne de Jéroboam, Abiya devint roi sur Juda.
###### 02
Il régna trois ans à Jérusalem. Sa mère s’appelait Maaka, fille d’Ouriel ; elle était de Guibéa. Il y eut la guerre entre Abiya et Jéroboam.
###### 03
Abiya engagea le combat avec une armée de vaillants soldats, quatre cent mille hommes d’élite. Et Jéroboam se rangea en bataille en face de lui, avec huit cent mille hommes d’élite, de vaillants guerriers.
###### 04
Abiya se dressa au sommet du mont Semaraïm, qui est dans la montagne d’Éphraïm. Il cria : « Écoutez-moi, Jéroboam et tout Israël !
###### 05
Ne savez-vous pas que le Seigneur, Dieu d’Israël, a donné à David la royauté sur Israël, pour toujours, à lui et à ses fils, par une alliance indestructible ?
###### 06
Mais Jéroboam, fils de Nebath, serviteur de Salomon, fils de David, s’est dressé et s’est révolté contre son maître.
###### 07
Autour de lui se sont groupés des gens de rien, des vauriens, et ils ont vaincu Roboam, fils de Salomon. Roboam, jeune et de cœur timoré, n’a pu leur tenir tête.
###### 08
Et maintenant, vous parlez de tenir tête à la royauté du Seigneur qui est entre les mains des fils de David ! Vous êtes une foule immense, et vous avez apporté les veaux d’or que Jéroboam vous a faits pour qu’ils soient vos dieux.
###### 09
N’avez-vous pas expulsé les prêtres du Seigneur, les fils d’Aaron et les lévites, pour vous faire des prêtres comme les peuples des autres pays ? Quiconque vient recevoir l’investiture en apportant un jeune taureau et sept béliers devient prêtre de ce qui n’est pas Dieu !
###### 10
Mais nous, notre Dieu, c’est le Seigneur, et nous ne l’avons pas abandonné ! Les prêtres qui servent le Seigneur sont fils d’Aaron, et il y a des lévites en fonction.
###### 11
Ils font brûler pour le Seigneur des holocaustes matin après matin et soir après soir, avec de l’encens aromatique ; ils disposent la rangée de pains sur la table pure, ils allument le chandelier d’or et ses lampes soir après soir. Car nous gardons l’observance du Seigneur notre Dieu, mais vous, vous avez abandonné le Seigneur !
###### 12
Voici que Dieu est avec nous, en tête, ainsi que ses prêtres et les trompettes de l’acclamation pour les faire sonner contre vous. Fils d’Israël, ne combattez pas le Seigneur, Dieu de vos pères, car vous ne gagnerez pas ! »
###### 13
Jéroboam les fit contourner, sur leurs arrières, par une troupe placée en embuscade. Ainsi son armée se trouva devant Juda, et l’embuscade derrière.
###### 14
Ceux de Juda firent volte-face, et voici qu’il leur fallait combattre devant et derrière. Alors ils crièrent vers le Seigneur, et les prêtres sonnèrent de la trompette.
###### 15
Les hommes de Juda poussèrent le cri de guerre, et, au cri de guerre des hommes de Juda, Dieu battit Jéroboam et tout Israël, en face d’Abiya et des gens de Juda.
###### 16
Les fils d’Israël s’enfuirent devant Juda, et Dieu les livra entre leurs mains.
###### 17
Abiya et son peuple leur infligèrent une grande défaite : du côté d’Israël tombèrent, frappés à mort, cinq cent mille hommes d’élite.
###### 18
En ce temps-là, les fils d’Israël furent abaissés, et, au contraire, les fils de Juda rendus plus forts, parce qu’ils s’étaient appuyés sur le Seigneur, Dieu de leurs pères.
###### 19
Abiya poursuivit Jéroboam et lui prit des villes : Béthel et ses dépendances, Yeshana et ses dépendances, Éphrone et ses dépendances.
###### 20
Jéroboam ne retrouva plus sa puissance durant le règne d’Abiya. Le Seigneur le frappa, et il mourut.
###### 21
Quant à Abiya, il s’affermit. Il prit quatorze femmes et engendra vingt-deux fils et seize filles.
###### 22
Le reste des actions d’Abiya,
sa conduite et ses actions,
sont écrites dans le Commentaire du prophète Iddo.
###### 23
Abiya reposa avec ses pères,
et on l’ensevelit dans la Cité de David.
Son fils Asa régna à sa place.
De son temps, le pays fut tranquille pendant dix ans.
