---
aliases : 
- 2 Chroniques 16
- 2 Chroniques 16
- 2 Ch 16
- 2 Chronicles 16
tags : 
- Bible/2Ch/16
- français
cssclass : français
---

# 2 Chroniques 16

###### 01
La trente-sixième année du règne d’Asa, Baasa, roi d’Israël, monta contre Juda. Il fortifia la ville de Rama pour empêcher quiconque de communiquer avec Asa, roi de Juda.
###### 02
Asa prit de l’argent et de l’or dans les trésors de la Maison du Seigneur et de la maison du roi pour en envoyer à Ben-Hadad, roi d’Aram, qui résidait à Damas. Il lui fit dire :
###### 03
« Il y a une alliance entre moi et toi, comme entre mon père et ton père ! Voici que je t’envoie de l’argent et de l’or. Va, romps ton alliance avec Baasa, roi d’Israël : qu’il s’éloigne de moi ! »
###### 04
Ben-Hadad écouta le roi Asa. Il envoya les chefs de ses armées contre les villes d’Israël. Il frappa les villes de Yone, Dane, Abel-Maïm et tous les entrepôts des villes de Nephtali.
###### 05
Lorsque Baasa apprit cela, il cessa aussitôt de fortifier Rama et arrêta ses travaux.
###### 06
Alors Asa, le roi, prit avec lui tous les gens de Juda. Ils enlevèrent de Rama les pierres et le bois dont Baasa s’était servi pour la construire, et Asa les réemploya pour fortifier Guéba et Mispa.
###### 07
En ce temps-là, Hanani le voyant vint trouver Asa, roi de Juda, et lui dit : « Parce que tu t’es appuyé sur le roi d’Aram et que tu ne t’es pas appuyé sur le Seigneur ton Dieu, à cause de cela l’armée du roi d’Aram s’est échappée de tes mains.
###### 08
Les Éthiopiens et les Libyens ne formaient-ils pas une armée nombreuse, avec des chars et des chevaux en grande quantité ? Et cependant, parce que tu t’es appuyé sur le Seigneur, il les a livrés entre tes mains.
###### 09
Car les yeux du Seigneur scrutent toute la terre, pour affermir ceux dont le cœur est tout entier à lui. Tu as agi en insensé dans cette affaire : désormais, il y aura des guerres contre toi. »
###### 10
Asa se mit en colère contre le voyant et le fit mettre en prison, aux fers, car il était furieux contre lui à cause de ces paroles. Dans le même temps, Asa maltraita une partie du peuple.
###### 11
Les actions d’Asa, des premières aux dernières,
voici qu’elles sont écrites dans le Livre des rois de Juda et d’Israël.
###### 12
La trente-troisième année de son règne, Asa eut les pieds malades, d’une très grave maladie. Pourtant, même pendant sa maladie, il n’eut pas recours au Seigneur, mais aux médecins.
###### 13
Asa reposa avec ses pères :
il mourut la quarante et unième année de son règne.
###### 14
On l’ensevelit dans le tombeau
qu’il s’était fait creuser dans la Cité de David.
On l’étendit sur un lit couvert d’aromates et de toutes sortes de baumes préparés selon l’art des embaumeurs. Et on alluma pour lui un brasier grandiose.
