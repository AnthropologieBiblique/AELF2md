---
aliases : 
- 2 Chroniques 23
- 2 Chroniques 23
- 2 Ch 23
- 2 Chronicles 23
tags : 
- Bible/2Ch/23
- français
cssclass : français
---

# 2 Chroniques 23

###### 01
Au bout de sept ans, le prêtre Joad prit une décision courageuse. Il appela auprès de lui les officiers de centaine : Azaria, fils de Jéroham, Ismaël, fils de Yohanane, Azarias, fils d’Obed, Maaséya, fils d’Adaya, et Élishafath, fils de Zikri, qui avaient fait alliance avec lui.
###### 02
Ils parcoururent le pays de Juda et rassemblèrent, de toutes les villes de Juda, les lévites et les chefs de famille d’Israël ; puis ils vinrent à Jérusalem.
###### 03
Toute l’assemblée conclut une alliance avec le roi dans la Maison de Dieu. Et Joad leur dit : « Voici le fils du roi : il doit régner, selon ce que le Seigneur a déclaré au sujet des fils de David.
###### 04
Voilà ce que vous allez faire : un tiers d’entre vous, ceux qui entrent en service le jour du sabbat, prêtres et lévites, garderont les portes ;
###### 05
un tiers se tiendra dans la maison du roi, un tiers à la porte de la Fondation, et tout le peuple dans les parvis de la Maison du Seigneur.
###### 06
Que personne n’entre dans la Maison du Seigneur, sauf les prêtres et les lévites de service ; eux pourront entrer, car ils sont consacrés, mais tout le peuple observera l’ordre du Seigneur.
###### 07
Les lévites feront cercle autour du roi, chacun les armes à la main. Celui qui entrera dans la Maison sera mis à mort. Et vous accompagnerezle roi quand il part en campagne et en revient. »
###### 08
Les lévites et tout Juda exécutèrent tous les ordres du prêtre Joad. Chacun prit ses hommes, ceux qui entraient en service le jour du sabbat, et ceux qui en sortaient. Car le prêtre Joad n’avait exempté aucune des classes.
###### 09
Le prêtre Joad remit aux officiers de centaine les lances, les grands et les petits boucliers du roi David, qui étaient conservés dans la Maison de Dieu.
###### 10
Il fit placer tout le peuple, les javelots à la main, devant l’autel, du côté sud et du côté nord de la Maison, afin d’entourer le futur roi.
###### 11
Alors on fit avancer le fils du roi, on lui remit le diadème et le Témoignage, et on le fit roi. Puis Joad et ses fils lui donnèrent l’onction, et on cria : « Vive le roi ! »
###### 12
Athalie entendit la clameur du peuple, qui courait et acclamait le roi. Elle accourut vers le peuple à la Maison du Seigneur.
###### 13
Et voilà ce qu’elle vit : le roi debout devant sa colonne, à l’entrée ; auprès de lui, les officiers et les trompettes, et tout le peuple du pays criant sa joie tandis que les trompettes sonnaient, et que les chantres, accompagnés des instruments de musique, dirigeaient les acclamations. Alors, Athalie déchira ses vêtements et s’écria : « Trahison ! Trahison ! »
###### 14
Le prêtre Joad fit sortir les officiers de centaine qui commandaient la troupe et leur donna cet ordre : « Faites-la sortir de la Maison, entre les rangs. Si quelqu’un veut la suivre, qu’il soit mis à mort par l’épée. » En effet, le prêtre Joad avait interdit de la mettre à mort dans la Maison du Seigneur.
###### 15
On mit la main sur elle, et elle arriva à la maison du roi par l’entrée de la porte des Chevaux. C’est là qu’elle fut mise à mort.
###### 16
Joad conclut une alliance entre lui-même, tout le peuple et le roi, pour que le peuple soit le peuple du Seigneur.
###### 17
Alors, tout le peuple entra dans le temple de Baal et le démolit. Ils brisèrent ses autels et ses statues et, devant les autels, ils tuèrent Matane, prêtre de Baal.
###### 18
Joad posta ensuite des gardes devant la Maison du Seigneur sous l’autorité des prêtres lévites. David avait réparti ceux-ci dans la Maison du Seigneur pour qu’ils offrent, comme cela est écrit dans la loi de Moïse, les holocaustes du Seigneur, dans la joie et les chants, selon les indications de David.
###### 19
Il posta des gardes aux portes de la Maison du Seigneur, pour que n’y entre, en aucun cas, une personne en état d’impureté.
###### 20
Il prit ensuite les officiers, les notables, ceux qui avaient autorité sur le peuple, et tous les gens du pays. Il fit descendre le roi de la Maison du Seigneur. Ils entrèrent, par la porte Haute, dans la maison du roi et ils firent asseoir le roi sur le trône de la royauté.
###### 21
Tous les gens du pays étaient dans la joie, et la ville retrouva le calme. Quant à Athalie, on l’avait mise à mort par l’épée.
