---
aliases : 
- 2 Chroniques 20
- 2 Chroniques 20
- 2 Ch 20
- 2 Chronicles 20
tags : 
- Bible/2Ch/20
- français
cssclass : français
---

# 2 Chroniques 20

###### 01
À quelque temps de là, les fils de Moab et les fils d’Ammone, et avec eux des Méounites, vinrent faire la guerre à Josaphat.
###### 02
On vint en informer Josaphat : « Une grande multitude s’avance contre toi, venant d’au-delà de la Mer, du pays d’Édom ; elle est déjà à Haceçone-Tamar, c’est-à-dire Enn-Guèdi. »
###### 03
Josaphat prit peur et décida de consulter le Seigneur ; puis il proclama un jeûne pour tout Juda.
###### 04
Les gens de Juda se rassemblèrent pour chercher secours auprès du Seigneur ; c’est de toutes les villes de Juda que l’on vint chercher le Seigneur.
###### 05
Alors Josaphat se tint debout au milieu de l’assemblée de Juda, à Jérusalem, dans la Maison du Seigneur, devant le nouveau parvis.
###### 06
Il dit : « Seigneur, Dieu de nos pères, n’es-tu pas le Dieu qui est au ciel ? N’est-ce pas toi qui domines sur tous les royaumes des nations ? Dans ta main, force et puissance ; nul ne peut tenir devant toi.
###### 07
N’est-ce pas toi, ô notre Dieu, qui, face à ton peuple Israël, as dépossédé les habitants de ce pays, et l’as donné pour toujours à la descendance d’Abraham ton ami ?
###### 08
Là ils se sont établis et ils ont construit un sanctuaire pour ton nom. Ils disaient :
###### 09
“Si un malheur tombe sur nous, épée, châtiment, peste ou famine, nous nous tiendrons devant cette Maison et devant toi, puisque ton nom est dans cette Maison. Nous crierons vers toi du fond de notre détresse ; toi, tu entendras et tu sauveras.”
###### 10
Maintenant, voici les fils d’Ammone, de Moab et de la montagne de Séïr, chez qui tu n’as pas laissé entrer les fils d’Israël lorsqu’ils venaient du pays d’Égypte : ils se sont écartés d’eux sans les anéantir !
###### 11
Les voici qui nous récompensent en venant nous chasser de ton héritage, dont tu nous as fait hériter.
###### 12
Ô notre Dieu, ne rendras-tu pas contre eux un jugement ? Car nous sommes sans force en face de cette foule immense qui marche contre nous. Nous ne savons que faire, mais nos yeux se tournent vers toi. »
###### 13
Tous les gens de Juda se tenaient debout devant le Seigneur, et même leurs petits enfants, leurs femmes et leurs fils.
###### 14
Il y avait là Yahaziel, fils de Zacharie, fils de Benaya, fils de Yehiel, fils de Mattanya ; il était lévite, du groupe des fils d’Asaf. L’Esprit du Seigneur fut sur lui, au milieu de l’assemblée.
###### 15
Yahaziel s’écria : « Soyez attentifs, vous tous de Juda et habitants de Jérusalem, et toi, roi Josaphat ! Ainsi vous parle le Seigneur : Ne craignez pas, ne vous effrayez pas devant cette foule immense ; car ce combat n’est pas le vôtre, mais celui de Dieu.
###### 16
Demain, descendez vers eux ; voici qu’ils arrivent par la montée de Ciç ; vous les trouverez à l’extrémité du ravin près du désert de Yerouël.
###### 17
Mais là, vous n’aurez pas à combattre ; restez sur place et prenez position ; vous verrez comment le Seigneur va vous sauver. Juda et Jérusalem, ne craignez pas, ne vous effrayez pas : demain, sortez à leur rencontre, le Seigneur sera avec vous. »
###### 18
Josaphat se mit à genoux, face contre terre. Tous les gens de Juda et les habitants de Jérusalem tombèrent devant la face du Seigneur et se prosternèrent devant lui.
###### 19
Les lévites appartenant aux fils des Qehatites et aux fils des Coréites se levèrent pour louer à pleine voix le Seigneur, Dieu d’Israël.
###### 20
De grand matin, ils se levèrent et partirent pour le désert de Teqoa. À leur départ, Josaphat, debout, s’écria : « Écoutez-moi, gens de Juda et habitants de Jérusalem. Ayez confiance dans le Seigneur votre Dieu, et vous tiendrez ; ayez confiance en ses prophètes, et vous réussirez. »
###### 21
Après avoir pris conseil du peuple, il mit en place des hommes qui chantaient le Seigneur et louaient la splendeur de sa sainteté. Précédant la troupe, ils disaient : « Rendez grâce au Seigneur, éternel est son amour ! »
###### 22
Au moment où ils entonnaient l’acclamation et la louange, le Seigneur tendit une embuscade aux fils d’Ammone, de Moab et de la montagne de Séïr, qui marchaient contre Juda. Ceux-ci furent battus.
###### 23
Les fils d’Ammone et de Moab se dressèrent contre les habitants de la montagne de Séïr pour les vouer à l’anathème et les anéantir. Puis, lorsqu’ils en eurent fini avec les habitants de Séïr, ils s’entraînèrent les uns les autres à se détruire.
###### 24
Les gens de Juda parvinrent au promontoire d’où l’on a vue sur le désert, et ils se tournèrent vers la foule : elle n’était plus que cadavres gisant à terre, et pas un survivant !
###### 25
Josaphat vint avec son peuple piller leur butin ; ils trouvèrent du bétail en quantité, des biens, des vêtements, et des objets précieux. Ils en ramassèrent plus qu’ils ne pouvaient porter. Il leur fallut trois jours pour piller le butin, car il était considérable.
###### 26
Le quatrième jour, ils se rassemblèrent dans la vallée de la Bénédiction. Là, en effet, ils bénirent le Seigneur. Voilà pourquoi on a donné à ce lieu le nom de « vallée de la Bénédiction », jusqu’à ce jour.
###### 27
Tous les hommes de Juda et de Jérusalem, Josaphat à leur tête, se mirent en marche pour retourner à Jérusalem dans la joie, car le Seigneur les avait réjouis au détriment de leurs ennemis.
###### 28
Ils entrèrent à Jérusalem au son des harpes, des cithares et des trompettes, jusqu’à la Maison du Seigneur.
###### 29
La terreur de Dieu s’empara de tous les royaumes des pays environnants, lorsqu’ils apprirent que le Seigneur avait combattu contre les ennemis d’Israël.
###### 30
Alors le règne de Josaphat fut calme. Son Dieu lui donna le repos de tous côtés.
###### 31
Josaphat régna sur Juda. Il avait trente-cinq ans lorsqu’il devint roi, et il régna vingt-cinq ans à Jérusalem. Le nom de sa mère était Azouba ; elle était fille de Shilki.
###### 32
Il marcha dans le chemin de son père Asa ; il ne s’en détourna pas, faisant ce qui est droit aux yeux du Seigneur.
###### 33
Toutefois les lieux sacrés ne disparurent pas, et le peuple n’attachait toujours pas son cœur au Dieu de ses pères.
###### 34
Le reste des actions de Josaphat,
des premières aux dernières,
cela est écrit dans les Annales de Jéhu, fils de Hanani,
qui ont été reportées dans le Livre des rois d’Israël.
###### 35
Après cela, Josaphat, roi de Juda, s’associa avec le roi d’Israël, Ocozias, dont la conduite était mauvaise.
###### 36
Il s’associa avec lui afin de construire des navires pour aller à Tarsis. Ils construisirent les navires à Écione-Guéber.
###### 37
Mais Élièzer, fils de Dodavahou, de Marésha, prophétisa contre Josaphat en disant : « Parce que tu t’es associé à Ocozias, le Seigneur a fait une brèche dans tes œuvres. » Les navires se brisèrent et ne purent aller à Tarsis.
