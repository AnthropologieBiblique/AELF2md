---
aliases : 
- 2 Chroniques 3
- 2 Chroniques 3
- 2 Ch 3
- 2 Chronicles 3
tags : 
- Bible/2Ch/3
- français
cssclass : français
---

# 2 Chroniques 3

###### 01
Alors Salomon commença à bâtir la Maison du Seigneur à Jérusalem, sur le mont Moriya, là où le Seigneur était apparu à David, son père, à l’emplacement que David avait préparé sur l’aire d’Ornane le Jébuséen.
###### 02
C’est au deuxième mois de la quatrième année de son règne qu’il commença à bâtir.
###### 03
Les fondations établies par Salomon pour bâtir la Maison de Dieu étaient, en longueur, de soixante coudées d’ancienne mesure et, en largeur, de vingt coudées.
###### 04
Devant la Grande Salle de la Maison, le vestibule était long de vingt coudées dans le sens de la largeur de la Maison ; il avait cent vingt coudées de haut. Salomon le plaqua d’or pur à l’intérieur.
###### 05
La Grande Maison, il la recouvrit de bois de cyprès, qu’il recouvrit ensuite d’or pur, rehaussé de palmiers et de chaînettes.
###### 06
Il revêtit la Maison d’une parure de pierres précieuses. L’or était de l’or de Parwaïm !
###### 07
Il recouvrit d’or la Maison : les poutres, les seuils, les murs et les portes. Il fit graver des kéroubim sur les murs.
###### 08
Puis, il fit la salle du Saint des saints. Elle était longue de vingt coudées dans le sens de la largeur de la Maison, et large de vingt coudées. Il la recouvrit d’or pur, d’un poids de six cents lingots.
###### 09
Le poids des clous était celui de cinquante pièces d’or. Il recouvrit d’or les chambres hautes.
###### 10
Dans la salle du Saint des saints, Salomon fit deux kéroubim, ouvrage de métal fondu, et on les plaqua d’or.
###### 11
Les ailes des kéroubim avaient une longueur de vingt coudées ; l’une des ailes du premier kéroub, d’une longueur de cinq coudées, touchait le mur de la Maison ; l’autre, également de cinq coudées, touchait celle du second kéroub.
###### 12
Une aile du second kéroub, de cinq coudées, touchait le mur de la Maison ; l’autre, également de cinq coudées, rejoignait l’aile de l’autre kéroub.
###### 13
Déployées, les ailes de ces kéroubim mesuraient vingt coudées. Ils se tenaient debout sur leurs pieds, la face tournée vers la Maison.
###### 14
Salomon fit le rideau de pourpre violette et de pourpre rouge, de carmin et de lin ; et il le rehaussa de kéroubim.
###### 15
Il fit devant la Maison deux colonnes de trente-cinq coudées de haut ; à leur sommet, le chapiteau avait cinq coudées.
###### 16
Il fit aussi des chaînettes en collier et les plaça au sommet des colonnes. Il fit encore cent grenades et les plaça sur les chaînettes.
###### 17
Il dressa les colonnes sur le devant de la Grande Salle, l’une à droite et l’autre à gauche. Il donna à celle de droite le nom de Yakine (ce qui signifie : « Il rend stable »), à celle de gauche le nom de Boaz (ce qui signifie : « En lui la force »).
