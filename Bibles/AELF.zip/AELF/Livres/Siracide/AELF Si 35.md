---
aliases : 
- Siracide 35
- Siracide 35
- Si 35
- Ecclesiasticus 35
tags : 
- Bible/Si/35
- français
cssclass : français
---

# Siracide 35

###### 01
C’est présenter de multiples offrandes
que d’observer la Loi ;
###### 02
c’est offrir un sacrifice de paix
que s’attacher aux commandements.
###### 03
C’est apporter une offrande de fleur de farine
que se montrer reconnaissant ;
###### 04
c’est présenter un sacrifice de louange
que faire l’aumône.
###### 05
On obtient la bienveillance du Seigneur
en se détournant du mal ;
on offre un sacrifice d’expiation
en se détournant de l’injustice.
###### 06
Ne te présente pas devant le Seigneur les mains vides.
###### 07
Accomplis tout cela car tel est son commandement.
###### 08
L’offrande de l’homme juste
est comme la graisse des sacrifices sur l’autel,
son agréable odeur s’élève devant le Très-Haut.
###### 09
Le sacrifice de l’homme juste est agréé par Dieu
qui en gardera mémoire.
###### 10
Rends gloire au Seigneur sans être regardant :
ne retranche rien des prémices de ta récolte.
###### 11
Chaque fois que tu fais un don, montre un visage joyeux ;
consacre de bon cœur à Dieu le dixième de ce que tu gagnes.
###### 12
Donne au Très-Haut selon ce qu’il te donne,
et, sans être regardant, selon tes ressources.
###### 13
Car le Seigneur est celui qui paye de retour ;
il te rendra sept fois plus que tu n’as donné.
###### 14
N’essaye pas de l’influencer par des présents,
il ne les acceptera pas ;
###### 15
ne mets pas ta confiance dans un sacrifice injuste.
Car le Seigneur est un juge
qui se montre impartial envers les personnes.
###### 16
Il ne défavorise pas le pauvre,
il écoute la prière de l’opprimé.
###### 17
Il ne méprise pas la supplication de l’orphelin,
ni la plainte répétée de la veuve.
###### 18
Les larmes de la veuve ne coulent-elles pas sur ses joues,
###### 19
et son cri n’accuse-t-il pas celui qui la fait pleurer ?
###### 20
Celui dont le service est agréable à Dieu sera bien accueilli,
sa supplication parviendra jusqu’au ciel.
###### 21
La prière du pauvre traverse les nuées ;
tant qu’elle n’a pas atteint son but, il demeure inconsolable.
Il persévère tant que le Très-Haut n’a pas jeté les yeux sur lui,
###### 22
ni prononcé la sentence en faveur des justes et rendu justice.
Le Seigneur ne tardera pas,
il restera impatient,
jusqu’à ce qu’il ait brisé les reins des hommes sans pitié,
###### 23
tiré vengeance des nations,
supprimé la multitude des insolents
et brisé le sceptre des injustes,
###### 24
jusqu’à ce qu’il ait rendu à chacun selon ses œuvres
et rétribué les actions des hommes selon leurs intentions,
###### 25
jusqu’à ce qu’il ait jugé la cause de son peuple
et qu’il l’ait comblé de joie par sa miséricorde.
###### 26
Qu’elle sera bienvenue, sa miséricorde, au temps du malheur,
comme les nuages de pluie au temps de la sécheresse !
