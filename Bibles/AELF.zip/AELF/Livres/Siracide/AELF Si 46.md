---
aliases : 
- Siracide 46
- Siracide 46
- Si 46
- Ecclesiasticus 46
tags : 
- Bible/Si/46
- français
cssclass : français
---

# Siracide 46

###### 01
Josué, fils de Noun, fut un vaillant guerrier
et succéda, comme prophète, à Moïse.
Justifiant le nom qu’il portait,
il se montra grand sauveur des élus du Seigneur :
châtiant les ennemis dressés contre lui,
il fit entrer Israël dans son héritage.
###### 02
Qu’il était glorieux quand il levait les bras
pour brandir l’épée contre les villes !
###### 03
Qui donc, avant lui, avait eu cette fermeté ?
Il mena lui-même les combats du Seigneur.
###### 04
N’est-ce pas sa main qui arrêta le soleil
et fit qu’un seul jour en devint deux ?
###### 05
Il invoqua le Très-Haut, le Puissant,
quand les ennemis le pressaient de toute part,
et le souverain Seigneur l’exauça
en lançant des grêlons d’une force terrible.
###### 06
Il se précipita sur la nation ennemie
et fit périr les adversaires dans la descente de Beth-Horone,
pour faire connaître aux nations la force de ses armes
et qu’il se battait au nom du Seigneur,
car il marchait à la suite du Puissant.
###### 07
Aux jours de Moïse déjà, il avait montré sa fidélité,
– avec Caleb, fils de Yefounnè –,
en tenant tête à l’assemblée,
en détournant le peuple du péché
et en apaisant les récriminations malveillantes.
###### 08
Aussi, furent-ils épargnés tous les deux,
seuls sur six cent mille hommes,
pour faire entrer Israël dans son héritage,
dans un pays ruisselant de lait et de miel.
###### 09
Et le Seigneur donna à Caleb
une vigueur qui lui resta jusque dans sa vieillesse,
pour lui faire gravir les hauteurs d’un pays
dont sa descendance conserva l’héritage.
###### 10
C’est ainsi que tous les fils d’Israël virent
combien il est bon de marcher à la suite du Seigneur.
###### 11
Les Juges aussi ont laissé chacun leur nom :
aucun n’a eu le cœur idolâtre,
aucun ne s’est détourné du Seigneur.
Que leur souvenir soit en bénédiction !
###### 12
Du lieu où ils reposent, que leurs ossements refleurissent
et que leur nom se renouvelle
dans les fils de ces gens illustres !
###### 13
Samuel fut aimé de son Seigneur.
Comme prophète du Seigneur, il établit la royauté
et donna l’onction aux chefs de son peuple.
###### 14
Il fut juge dans l’assemblée selon la loi du Très-Haut,
et le Seigneur a visité Jacob.
###### 15
Par sa fidélité il s’est montré vrai prophète
et, par ses oracles, il fut reconnu digne de foi dans ses visions.
###### 16
Il invoqua le Seigneur, le Puissant,
quand les ennemis le pressaient de toute part
et il offrit un agneau de lait.
###### 17
Le Seigneur tonna du haut du ciel
et, dans un grand fracas, fit entendre sa voix ;
###### 18
il extermina les chefs ennemis
et tous les princes des Philistins.
###### 19
Avant le moment du repos éternel,
Samuel prit à témoin le Seigneur
et celui à qui il avait donné l’onction ;
il déclara :
« Je n’ai jamais pris le bien de qui que ce soit,
pas même une paire de sandales »,
et personne ne l’accusa.
###### 20
Même après s’être endormi, il prophétisa encore
pour annoncer au roi sa fin prochaine ;
du sein de la terre, il éleva une voix prophétique
afin que soit effacée la faute du peuple.
