---
aliases : 
- Siracide 28
- Siracide 28
- Si 28
- Ecclesiasticus 28
tags : 
- Bible/Si/28
- français
cssclass : français
---

# Siracide 28

###### 01
Celui qui se venge
éprouvera la vengeance du Seigneur ;
celui-ci tiendra un compte rigoureux de ses péchés.
###### 02
Pardonne à ton prochain le tort qu’il t’a fait ;
alors, à ta prière, tes péchés seront remis.
###### 03
Si un homme nourrit de la colère contre un autre homme,
comment peut-il demander à Dieu la guérison ?
###### 04
S’il n’a pas de pitié pour un homme, son semblable,
comment peut-il supplier pour ses péchés à lui ?
###### 05
Lui qui est un pauvre mortel, il garde rancune ;
qui donc lui pardonnera ses péchés ?
###### 06
Pense à ton sort final et renonce à toute haine,
pense à ton déclin et à ta mort,
et demeure fidèle aux commandements.
###### 07
Pense aux commandements
et ne garde pas de rancune envers le prochain,
pense à l’Alliance du Très-Haut
et sois indulgent pour qui ne sait pas.
###### 08
Reste à l’écart des querelles, et tu pécheras moins,
car un homme emporté attise les querelles.
###### 09
Le pécheur sème le trouble entre les amis
et jette la division parmi ceux qui vivent en paix.
###### 10
Le feu brûle pour autant qu’on l’alimente,
une querelle s’échauffe pour autant qu’on s’entête.
La fureur d’un homme est à la mesure de sa force,
et il gonfle sa colère en proportion de sa richesse.
###### 11
Une dispute soudaine allume un feu,
une querelle subite fait couler le sang.
###### 12
Souffle sur une braise, elle s’enflamme,
crache dessus, elle s’éteint ;
l’un comme l’autre vient de ta bouche.
###### 13
Maudits soient le diffamateur et la langue fourbe :
ils ont perdu bien des gens qui vivaient en paix.
###### 14
La langue calomniatrice en a fait tomber beaucoup
et les a chassés de nation en nation ;
elle a détruit des villes fortes
et renversé la maison de gens puissants.
###### 15
La langue calomniatrice a fait répudier des femmes courageuses,
les privant du fruit de leurs travaux.
###### 16
Celui qui l’écoute ne trouvera jamais de repos
et ne pourra pas habiter en paix.
###### 17
Un coup de fouet laisse une meurtrissure,
un coup donné par la langue brise les os.
###### 18
Beaucoup sont tombés sous le tranchant de l’épée,
combien plus sont tombés victimes de la langue !
###### 19
Heureux qui est à l’abri de ses atteintes,
qui n’a pas été exposé à sa fureur,
ni soumis à son joug,
ni lié par ses chaînes.
###### 20
Car son joug est un joug de fer
et ses chaînes sont des chaînes de bronze.
###### 21
La mort qu’elle inflige est une mort terrible,
mieux vaut encore le séjour d’en-bas.
###### 22
Mais elle n’a pas d’emprise sur les gens religieux,
et sa flamme ne les brûlera pas.
###### 23
Ceux qui abandonnent le Seigneur tomberont en son pouvoir :
elle les consumera sans s’éteindre ;
elle s’élancera sur eux comme un lion,
comme une panthère, elle les déchirera.
###### 24
Vois : tu entoures ton domaine d’une haie d’épines,
tu mets sous clé ton argent et ton or,
###### 25
eh bien, pèse aussi tes mots sur une balance
et mets à ta bouche porte et verrou.
###### 26
Prends garde que la langue ne te fasse trébucher,
tu tomberais devant celui qui te guette.
