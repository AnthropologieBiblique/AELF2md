---
aliases : 
- Siracide 8
- Siracide 8
- Si 8
- Ecclesiasticus 8
tags : 
- Bible/Si/8
- français
cssclass : français
---

# Siracide 8

###### 01
N’entre pas en conflit avec un homme puissant,
de peur de tomber entre ses mains.
###### 02
Ne te querelle pas avec un homme riche,
de peur de ne pas faire le poids,
car avec de l’or on a perdu bien des gens,
il a même fait fléchir le cœur des rois.
###### 03
Ne te dispute pas avec un bavard :
tu ne ferais qu’entasser du bois sur son feu.
###### 04
Ne plaisante pas avec quelqu’un de mal élevé,
de peur d’entendre insulter tes parents.
###### 05
Ne fais pas de reproches au pécheur repentant :
souviens-toi que nous sommes tous passibles de châtiment.
###### 06
Ne méprise pas un vieillard,
car certains d’entre nous prennent de l’âge.
###### 07
Ne te réjouis pas de la mort de quelqu’un :
souviens-toi que tous nous devrons mourir.
###### 08
Ne néglige pas la conversation des sages,
reviens souvent à leurs proverbes,
car auprès d’eux tu acquerras l’instruction
et l’art de servir les grands.
###### 09
Ne fuis pas la conversation des vieillards
– eux-mêmes ont appris de leurs pères –
car auprès d’eux tu acquerras l’intelligence
et l’art de répondre en temps voulu.
###### 10
N’attise pas les ardeurs du pécheur,
de peur de te brûler au feu de sa flamme.
###### 11
Ne tiens pas tête à l’effronté :
il pourrait te prendre au piège de ton propre discours.
###### 12
Ne prête pas à plus fort que toi,
et si tu le fais, considère ton bien comme perdu.
###### 13
Ne te porte pas garant au-delà de tes moyens,
et si tu le fais, prépare-toi à payer.
###### 14
Ne sois pas en procès avec un juge,
car on s’en remettra à son jugement.
###### 15
Ne fais pas route avec l’aventurier,
de peur qu’il ne t’épuise,
car il n’en fera qu’à sa tête
et sa folie vous perdra tous les deux.
###### 16
Ne te dispute pas avec un coléreux,
et ne t’engage pas avec lui dans un lieu désert,
car le sang compte pour rien à ses yeux ;
là où il n’y a plus de secours, il t’abattra.
###### 17
Ne prends pas conseil d’un insensé,
car il ne pourra tenir sa langue.
###### 18
Devant un étranger, ne fais rien qui doive rester caché,
car tu ignores ce qu’il en tirera.
###### 19
N’ouvre pas ton cœur au premier venu,
il ne t’en saurait aucun gré.
