---
aliases : 
- Siracide 49
- Siracide 49
- Si 49
- Ecclesiasticus 49
tags : 
- Bible/Si/49
- français
cssclass : français
---

# Siracide 49

###### 01
Le souvenir de Josias est comme un mélange aromatique,
préparé par les soins du parfumeur.
Il est doux comme le miel dans la bouche,
il est une musique dans un banquet bien arrosé.
###### 02
C’est lui qui réussit à convertir le peuple,
il supprima le culte abominable des idoles.
###### 03
Il tourna son cœur vers le Seigneur
et, dans ces temps d’abandon de la Loi, il raffermit la religion.
###### 04
Hormis David, Ézékias et Josias,
tous ne firent que faute sur faute.
Ayant abandonné la loi du Très-Haut,
les rois de Juda furent eux-mêmes abandonnés.
###### 05
Ils durent céder leur pouvoir à d’autres,
et leur gloire à une nation étrangère.
###### 06
La ville élue, la ville du sanctuaire, fut incendiée,
ses rues furent désertées,
###### 07
selon la parole de Jérémie, qu’ils avaient maltraité,
lui, le prophète consacré dès le sein de sa mère
pour arracher, démolir et détruire,
comme aussi pour bâtir et planter.
###### 08
Ézékiel eut une vision de la Gloire :
elle lui fut montrée sur le char des Kéroubim.
###### 09
Il a prophétisé l’anéantissement des ennemis par des pluies torrentielles ;
il a encouragé ceux qui suivent le droit chemin.
###### 10
Quant aux douze prophètes,
que refleurissent leurs ossements, depuis le lieu où ils reposent !
Ils ont consolé Jacob
et l’ont racheté par leur fidélité à l’espérance.
###### 11
Comment dire la grandeur de Zorobabel,
lui qui fut comme l’anneau à cacheter,
le sceau que l’on porte à la main droite ?
###### 12
Ou encore Josué, fils de Josédeq ?
En leur temps, ils rebâtirent la Maison de Dieu,
ils relevèrent le Temple consacré au Seigneur
et destiné à une gloire éternelle.
###### 13
De même, Néhémie a laissé un souvenir éclatant,
lui qui redressa nos murailles en ruines,
rétablit portes et verrous
et reconstruisit nos habitations.
###### 14
Nul sur terre n’a été créé l’égal d’Hénok,
lui qui fut enlevé de ce monde.
###### 15
Et l’on n’a pas vu naître d’homme semblable à Joseph,
chef de ses frères, soutien de son peuple ;
ses ossements furent entourés d’honneurs.
###### 16
Sem et Seth furent glorieux parmi les hommes,
mais, dans la création, Adam surpasse tout être vivant.
