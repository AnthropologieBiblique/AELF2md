---
aliases : 
- Siracide 2
- Siracide 2
- Si 2
- Ecclesiasticus 2
tags : 
- Bible/Si/2
- français
cssclass : français
---

# Siracide 2

###### 01
Mon fils,
si tu viens te mettre au service du Seigneur,
prépare-toi à subir l’épreuve ;
###### 02
fais-toi un cœur droit, et tiens bon ;
ne t’agite pas à l’heure de l’adversité.
###### 03
Attache-toi au Seigneur, ne l’abandonne pas,
afin d’être comblé dans tes derniers jours.
###### 04
Toutes les adversités, accepte-les ;
dans les revers de ta pauvre vie, sois patient ;
###### 05
car l’or est vérifié par le feu,
et les hommes agréables à Dieu, par le creuset de l’humiliation.
Dans les maladies comme dans le dénuement, aie foi en lui.
###### 06
Mets ta confiance en lui, et il te viendra en aide ;
rends tes chemins droits, et mets en lui ton espérance.
###### 07
Vous qui craignez le Seigneur, comptez sur sa miséricorde,
ne vous écartez pas du chemin, de peur de tomber.
###### 08
Vous qui craignez le Seigneur, ayez confiance en lui,
et votre récompense ne saurait vous échapper.
###### 09
Vous qui craignez le Seigneur, espérez le bonheur,
la joie éternelle et la miséricorde :
ce qu’il donne en retour est un don éternel, pour la joie.
###### 10
Considérez les générations passées et voyez :
Celui qui a mis sa confiance dans le Seigneur,
a-t-il été déçu ?
Celui qui a persévéré dans la crainte du Seigneur,
a-t-il été abandonné ?
Celui qui l’a invoqué,
a-t-il été méprisé ?
###### 11
Car le Seigneur est tendre et miséricordieux,
il pardonne les péchés,
et il sauve au moment de la détresse.
###### 12
Malheur aux cœurs lâches et aux mains négligentes,
au pécheur qui suit deux sentiers.
###### 13
Malheur au cœur négligent, qui ne fait pas confiance :
il ne sera pas protégé.
###### 14
Malheur à vous qui avez perdu la persévérance :
que ferez-vous lors de la visite du Seigneur ?
###### 15
Ceux qui craignent le Seigneur ne désobéiront pas à ses paroles,
ceux qui l’aiment suivront ses chemins.
###### 16
Ceux qui craignent le Seigneur chercheront à lui plaire,
ceux qui l’aiment se rassasieront de sa loi.
###### 17
Ceux qui craignent le Seigneur prépareront leur cœur
et s’humilieront devant lui, disant :
###### 18
« Nous voulons tomber dans les mains du Seigneur,
et non dans celles des hommes.
Car telle est sa grandeur,
telle est aussi sa miséricorde. »
