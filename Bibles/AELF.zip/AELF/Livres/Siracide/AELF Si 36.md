---
aliases : 
- Siracide 36
- Siracide 36
- Si 36
- Ecclesiasticus 36
tags : 
- Bible/Si/36
- français
cssclass : français
---

# Siracide 36

###### 01
Prends pitié de nous, Maître et Dieu de tout ;
###### 02
répands la crainte sur toutes les nations.
###### 03
Lève la main sur les pays étrangers,
et qu’ils voient ta puissance !
###### 04
À nos dépens, tu leur montras ta sainteté ;
à leurs dépens, montre-nous ta grandeur.
###### 05
Qu’ils l’apprennent, comme nous l’avons appris :
il n’est pas de dieu hors de toi, Seigneur.
###### 06
Renouvelle les prodiges, recommence les merveilles,
###### 07
glorifie ta main et ton bras droit.
###### 08
[Réveille ta colère, déverse ta fureur,
###### 09
détruis l’adversaire, arrache l’ennemi.
###### 10
Hâte le temps, rappelle-toi le terme,
et que soient racontées tes merveilles !
###### 11
Qu’un feu vengeur dévore le survivant,
et que périssent les bourreaux de ton peuple !
###### 12
Brise les têtes des princes ennemis
qui disent : « Il n’est rien hors de nous ! »]
###### 13
Rassemble les tribus de Jacob ;
###### 16
comme aux premiers jours, donne-leur ton héritage.
###### 17
Prends pitié du peuple porteur de ton nom,
Israël qui est pour toi un premier-né.
###### 18
Prends compassion de ta ville sainte,
Jérusalem, le lieu de ton repos.
###### 19
Remplis Sion de ta louange,
et ton sanctuaire, de ta gloire.
###### 20
Rends témoignage à tes créatures des premiers jours ;
réveille les prophéties faites en ton nom.
###### 21
Donne la récompense à ceux qui t’attendent ;
que tes prophètes soient reconnus dignes de foi.
###### 22
Écoute la prière de tes serviteurs,
selon ta bienveillance à l’égard de ton peuple.
Et tous, sur la terre, le sauront :
tu es « Le Seigneur », le Dieu des siècles !
###### 23
L’estomac absorbe toute sorte d’aliments,
mais tel aliment est meilleur que l’autre.
###### 24
Comme le palais reconnaît une viande faisandée,
le cœur avisé reconnaît les paroles mensongères.
###### 25
Un cœur pervers cause du chagrin,
mais l’homme d’expérience saura lui rendre la pareille.
###### 26
Une femme doit accepter n’importe quel mari,
mais telle fille est préférable à telle autre.
###### 27
La beauté d’une femme est joie pour les yeux ;
il n’y a rien de plus désirable pour un homme.
###### 28
Si elle a sur les lèvres douceur et bonté,
son mari n’appartient plus au commun des mortels !
###### 29
Pour qui prend femme, c’est déjà la fortune :
elle est une aide semblable à lui, une colonne où s’appuyer.
###### 30
Faute de clôture, un domaine est livré aux pillards ;
faute d’avoir une femme, on erre à l’aventure en gémissant.
###### 31
Qui ferait confiance à un agile escroc
passant de ville en ville ?
Il en va de même pour l’homme qui n’a pas de nid
et qui s’arrête là où le soir le surprend.
