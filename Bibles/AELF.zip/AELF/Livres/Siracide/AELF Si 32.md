---
aliases : 
- Siracide 32
- Siracide 32
- Si 32
- Ecclesiasticus 32
tags : 
- Bible/Si/32
- français
cssclass : français
---

# Siracide 32

###### 01
On t’a choisi pour présider un banquet ?
Ne prends pas de grands airs.
Sois un simple convive parmi les autres,
occupe-toi d’eux, et alors seulement tu iras t’asseoir.
###### 02
Quand tu auras rempli tout ton office, va prendre place
afin de te réjouir avec eux
et recevoir la couronne pour ta parfaite organisation.
###### 03
Si tu es âgé, prends la parole, car cela te revient,
mais mesure bien ce que tu dis, ne retarde pas la musique
###### 04
et, pendant qu’on l’écoute, ne te répands pas en bavardages :
n’étale pas ta sagesse à contretemps.
###### 05
Une pierre de grenat enchâssée dans un bijou en or,
tel est un concert dans un banquet bien arrosé.
###### 06
Une émeraude enchâssée dans une monture d’or,
tel est un air de musique sur un bon vin.
###### 07
Si tu es jeune, ne prends la parole que si tu dois le faire,
mais pas plus de deux fois, et seulement si on t’interroge.
###### 08
Résume ton propos : en quelques mots on peut dire beaucoup ;
montre-toi instruit et discret à la fois.
###### 09
Avec de grands personnages, ne fais pas l’important ;
quand un autre a la parole, ne bavarde pas.
###### 10
Aussi sûr qu’un éclair devance le tonnerre,
la faveur est d’avance acquise à une personne réservée.
###### 11
Quand c’est l’heure, lève-toi, ne t’attarde pas,
rentre chez toi sans flâner.
###### 12
Là, tu pourras te divertir et faire ce qui te plaît,
sans risque de pécher par vantardise.
###### 13
Et, pour tout cela, bénis ton Créateur,
lui qui t’enivre de ses biens.
###### 14
Qui craint le Seigneur recevra son enseignement,
ceux qui le cherchent dès l’aurore obtiendront sa faveur.
###### 15
Qui scrute la Loi en sera comblé,
mais l’hypocrite y trouvera une occasion de chute.
###### 16
Ceux qui craignent le Seigneur découvriront ce qui est juste
et feront briller leurs jugements comme la lumière.
###### 17
Le pécheur n’accepte pas les remarques
et trouve toujours à justifier ce qui lui plaît.
###### 18
Un homme réfléchi ne néglige aucun avis,
l’insolent et l’orgueilleux n’ont peur de rien.
###### 19
Ne fais rien sans avoir réfléchi,
et tu n’auras pas à regretter tes actes.
###### 20
Le chemin accidenté, ne le prends pas,
de peur de buter sur les pierres.
###### 21
Ne te fie pas à un chemin uni,
###### 22
et même avec tes enfants sois sur tes gardes.
###### 23
En tous tes actes, fie-toi à ta conscience,
car cela aussi est observance des commandements.
###### 24
Qui se fie à la Loi est attentif aux commandements,
qui met sa confiance dans le Seigneur ne connaîtra pas le déclin.
