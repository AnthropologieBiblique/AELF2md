---
aliases : 
- Siracide 0
- Siracide 0
- Si 0
- Ecclesiasticus 0
tags : 
- Bible/Si/0
- français
cssclass : français
---

# Siracide 0

###### 0
(1) LA LOI, les Prophètes et les livres qui leur font suite nous ont transmis de nombreuses et grandes leçons, et il faut, à ce sujet, louer Israël pour son enseignement et sa sagesse. Or, il ne suffit pas d’acquérir le savoir par la lecture ;
(5) il faut encore, une fois gagné par la passion d’apprendre, se rendre utile aux autres tant par la parole que par l’écrit. Aussi, mon grand-père Jésus, après s’être adonné sans réserve à la lecture de la Loi, des Prophètes
(10) et des autres livres de nos Pères, et avoir acquis en ce domaine une grande compétence, a-t-il été amené à écrire lui-même sur l’enseignement et la sagesse. De la sorte, ceux qui ont la passion d’apprendre s’y appliqueront à leur tour et progresseront plus encore dans la vie selon la Loi.
(15) Vous êtes donc invités à faire la lecture de cet ouvrage avec une bienveillante attention et à vous montrer indulgents s’il vous semble que,
(20) en dépit de nos efforts de traduction, nous avons échoué à rendre telle ou telle expression. En effet, ce qui est exprimé à l’origine en hébreu n’a plus la même force une fois traduit dans une autre langue. D’ailleurs, non seulement pour cet ouvrage, mais aussi pour la Loi elle-même, les Prophètes
(25) et les autres livres, la traduction présente des différences considérables avec l’original.
C’est la trente-huitième année du règne de Ptolémée Évergète que je me suis rendu en Égypte. Au cours de mon séjour, j’ai trouvé une copie de cette importante instruction.
(30) J’ai jugé alors qu’il était de la plus haute nécessité de mettre tout mon zèle et tous mes efforts à traduire ce livre. J’ai donc consacré beaucoup de veilles et de science, pendant cette période, pour mener à terme cet ouvrage et le publier à l’intention de ceux qui, à l’étranger, ont la passion d’apprendre
(35) et veulent réformer leurs mœurs afin de vivre selon la Loi.
