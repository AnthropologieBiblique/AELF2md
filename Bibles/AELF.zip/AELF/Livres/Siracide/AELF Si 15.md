---
aliases : 
- Siracide 15
- Siracide 15
- Si 15
- Ecclesiasticus 15
tags : 
- Bible/Si/15
- français
cssclass : français
---

# Siracide 15

###### 01
Ainsi agit celui qui craint le Seigneur.
Celui qui est maître de la Loi atteindra la Sagesse.
###### 02
Elle vient à sa rencontre comme une mère ;
comme une épouse vierge, elle l’accueillera.
###### 03
Elle-même le nourrit du pain de l’intelligence
et lui donne à boire l’eau de la sagesse.
###### 04
Il s’appuie sur elle et ne chancelle pas ;
il s’attache à elle et n’en rougit pas.
###### 05
C’est elle qui l’élève au-dessus de ses proches ;
au milieu de l’assemblée, il ouvrira la bouche.
###### 06
Il trouvera la joie et recevra une couronne d’allégresse,
il aura pour héritage une renommée éternelle.
###### 07
Jamais les insensés n’atteindront la Sagesse,
les pécheurs ne la verront pas.
###### 08
Elle se tient loin de l’orgueil,
et les menteurs ne songent pas à elle.
###### 09
La louange sonne faux dans la bouche du pécheur,
parce que le Seigneur ne l’y a pas placée.
###### 10
C’est la Sagesse qui fait jaillir la louange,
et le Seigneur la mène à bien.
###### 11
Ne dis pas : « C’est le Seigneur qui m’a dévoyé »,
car il ne fait pas ce qu’il a en horreur.
###### 12
Ne dis pas : « C’est lui qui m’a égaré »,
car il n’a que faire du pécheur.
###### 13
Tout ce qui est abominable est détesté du Seigneur
et ne peut être aimé de ceux qui le craignent.
###### 14
C’est lui qui, au commencement, a créé l’homme
et l’a laissé à son libre arbitre.
###### 15
Si tu le veux, tu peux observer les commandements,
il dépend de ton choix de rester fidèle.
###### 16
Le Seigneur a mis devant toi l’eau et le feu :
étends la main vers ce que tu préfères.
###### 17
La vie et la mort sont proposées aux hommes,
l’une ou l’autre leur est donnée selon leur choix.
###### 18
Car la sagesse du Seigneur est grande,
fort est son pouvoir, et il voit tout.
###### 19
Ses regards sont tournés vers ceux qui le craignent,
il connaît toutes les actions des hommes.
###### 20
Il n’a commandé à personne d’être impie,
il n’a donné à personne la permission de pécher.
