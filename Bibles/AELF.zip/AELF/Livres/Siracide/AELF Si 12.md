---
aliases : 
- Siracide 12
- Siracide 12
- Si 12
- Ecclesiasticus 12
tags : 
- Bible/Si/12
- français
cssclass : français
---

# Siracide 12

###### 01
Si tu fais le bien, sache à qui tu le fais,
et l’on te saura gré de ton geste.
###### 02
Fais du bien à qui est religieux, et tu seras payé de retour,
sinon par lui, du moins par le Très-Haut.
###### 03
Pas de bonheur possible pour qui s’obstine dans le mal
et refuse de faire l’aumône.
###### 04
Donne à qui est religieux,
mais ne viens pas en aide au pécheur.
###### 05
À celui qui est humble fais du bien, mais ne donne pas à l’impie :
refuse-lui son pain, ne lui donne rien ;
il pourrait devenir plus fort que toi,
et tu recevrais alors double mal
pour tout le bien que tu lui aurais fait.
###### 06
Car le Très-Haut lui-même déteste les pécheurs,
il rendra aux impies ce qu’ils méritent,
il se les réserve pour le jour du châtiment.
###### 07
Donne à l’homme de bien,
mais ne viens pas en aide au pécheur.
###### 08
Dans le bonheur on ne peut pas reconnaître l’ami,
dans le malheur l’ennemi ne sera plus masqué.
###### 09
Quand un homme est heureux, ses ennemis sont dépités ;
quand il est malheureux, même l’ami s’éloigne.
###### 10
Ne fais jamais confiance à ton ennemi,
car sa méchanceté se cache comme le bronze sous l’oxyde.
###### 11
Même s’il se fait humble et s’avance avec un air penché,
prends garde, méfie-toi de lui.
Traite-le comme un miroir qu’il faut polir,
sache que la rouille ne le dissimulera pas toujours.
###### 12
Ne le mets pas près de toi :
il te renverserait pour prendre ta place.
Ne le fais pas asseoir à ta droite,
il convoiterait ton siège.
Tu comprendrais enfin mes paroles
et, plein de regrets, tu te rappellerais mes conseils.
###### 13
Qui aura pitié du charmeur mordu par un serpent
et de ceux qui vont au-devant des fauves ?
###### 14
Ainsi pour qui se lie à un pécheur
et se rend complice de ses péchés.
###### 15
Il restera un moment à tes côtés,
mais dès que tu auras le dos tourné, il ne se contiendra plus.
###### 16
L’ennemi n’a que douceur sur les lèvres,
mais dans son cœur il cherche à te précipiter à la fosse.
L’ennemi peut avoir les larmes aux yeux,
mais s’il en a l’occasion, il sera insatiable de ton sang.
###### 17
S’il t’arrive malheur, il sera le premier auprès de toi,
et, sous prétexte de t’aider, il te fera un croc-en-jambe.
###### 18
Il hochera la tête, se frottera les mains
et ne fera que ricaner, laissant voir son vrai visage.
