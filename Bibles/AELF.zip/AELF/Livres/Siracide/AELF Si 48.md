---
aliases : 
- Siracide 48
- Siracide 48
- Si 48
- Ecclesiasticus 48
tags : 
- Bible/Si/48
- français
cssclass : français
---

# Siracide 48

###### 01
Le prophète Élie surgit comme un feu,
sa parole brûlait comme une torche.
###### 02
Il fit venir la famine sur Israël,
et, dans son ardeur, les réduisit à un petit nombre.
###### 03
Par la parole du Seigneur, il retint les eaux du ciel,
et à trois reprises il en fit descendre le feu.
###### 04
Comme tu étais redoutable, Élie, dans tes prodiges !
Qui pourrait se glorifier d’être ton égal ?
###### 05
Toi qui as réveillé un mort
et, par la parole du Très-Haut, l’as fait revenir du séjour des morts ;
###### 06
toi qui as précipité des rois vers leur perte,
et jeté à bas de leur lit de glorieux personnages ;
###### 07
toi qui as entendu au Sinaï des reproches,
au mont Horeb des décrets de châtiment ;
###### 08
toi qui as donné l’onction à des rois pour exercer la vengeance,
et à des prophètes pour prendre ta succession ;
###### 09
toi qui fus enlevé dans un tourbillon de feu
par un char aux coursiers de feu ;
###### 10
toi qui fus préparé pour la fin des temps,
ainsi qu’il est écrit,
afin d’apaiser la colère avant qu’elle n’éclate,
afin de ramener le cœur des pères vers les fils
et de rétablir les tribus de Jacob…
###### 11
heureux ceux qui te verront,
heureux ceux qui, dans l’amour, se seront endormis ;
nous aussi, nous posséderons la vraie vie.
###### 12
Quand Élie fut enveloppé dans le tourbillon,
Élisée fut rempli de son esprit,
et pendant toute sa vie aucun prince ne l’a intimidé,
personne n’a pu le faire fléchir.
###### 13
Rien ne lui résista,
et, jusque dans la tombe,
son corps manifesta son pouvoir de prophète.
###### 14
Pendant sa vie, il a fait des prodiges ;
après sa mort, des œuvres merveilleuses.
###### 15
Malgré tout cela, le peuple ne se repentit pas
et ne renonça pas à ses péchés,
jusqu’à ce qu’il soit emmené captif hors de son pays
et dispersé par toute la terre.
Il ne resta qu’un peuple très peu nombreux,
avec un prince de la maison de David.
###### 16
Quelques-uns d’entre eux firent ce qui plaît au Seigneur,
d’autres multiplièrent les péchés.
###### 17
Ézékias fortifia sa capitale,
il amena l’eau à l’intérieur de la ville ;
il fit creuser à coups de pic un tunnel dans le roc
et construire des réservoirs pour les eaux.
###### 18
De son temps, Sennakérib monta l’attaquer
et envoya contre lui Rabsakès,
qui leva la main contre Sion
et se montra d’une grande arrogance.
###### 19
Alors le cœur et les mains des assiégés tremblèrent,
ils souffraient les douleurs d’une femme en travail.
###### 20
Ils invoquèrent le Seigneur, le Miséricordieux,
et tendirent les mains vers lui ;
et le Saint, du haut des cieux, les exauça aussitôt,
il les délivra selon la parole d’Isaïe.
###### 21
Il frappa le camp des Assyriens,
son ange les extermina.
###### 22
Car Ézékias avait fait ce qui plaît au Seigneur,
il était resté ferme dans les voies de son père David,
comme l’avait ordonné le grand prophète Isaïe,
digne de foi dans ses visions.
###### 23
En ses jours, le soleil recula
pour prolonger la vie du roi.
###### 24
Par la puissance de l’esprit, Isaïe vit les derniers temps
et consola les affligés de Sion.
###### 25
Il révéla ce qui arriverait jusqu’à la fin des temps
et les choses cachées avant qu’elles n’adviennent.
