---
aliases : 
- Siracide 5
- Siracide 5
- Si 5
- Ecclesiasticus 5
tags : 
- Bible/Si/5
- français
cssclass : français
---

# Siracide 5

###### 01
Ne t’appuie pas sur tes richesses,
ne dis pas : « Elles me suffisent. »
###### 02
Ne te laisse pas entraîner par ton instinct et ta force
à suivre les désirs de ton cœur.
###### 03
Ne dis pas : « Qui m’en imposera ? »,
car le Seigneur ne manquerait pas de te châtier.
###### 04
Ne dis pas : « J’ai péché, et rien ne m’est arrivé »,
car le Seigneur sait attendre longtemps.
###### 05
Ne sois pas assuré du pardon
au point d’entasser péché sur péché.
###### 06
Ne dis pas : « Sa miséricorde est grande,
il pardonnera bien tous mes péchés »,
car, en lui, il y a pitié mais aussi colère ;
son indignation s’abattra sur les pécheurs.
###### 07
Ne tarde pas à te retourner vers le Seigneur,
ne remets pas ta décision de jour en jour ;
car brusquement éclatera la colère du Seigneur,
et à l’heure du châtiment, tu seras anéanti.
###### 08
Ne t’appuie pas sur des richesses injustement acquises :
elles ne te serviront de rien au jour de l’adversité.
###### 09
Ne disperse pas à tous les vents
et ne t’engage pas dans tous les sentiers,
comme fait le pécheur à la langue double.
###### 10
Tiens fermement tes convictions
et n’aie qu’une parole.
###### 11
Sois prompt à écouter,
mais pour donner ta réponse, prends ton temps.
###### 12
Si tu as quelque compétence, réponds à ton prochain ;
sinon, que ta main soit sur ta bouche.
###### 13
La gloire comme le déshonneur sont dans la parole ;
la langue de l’homme peut être sa ruine.
###### 14
Ne te fais pas traiter de médisant
et ne tends pas de pièges avec ta langue :
comme le voleur est couvert de honte,
la langue double sera durement condamnée.
###### 15
Ne te mets en faute ni dans les grandes ni dans les petites choses,
