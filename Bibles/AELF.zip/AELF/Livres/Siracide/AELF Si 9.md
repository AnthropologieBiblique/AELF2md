---
aliases : 
- Siracide 9
- Siracide 9
- Si 9
- Ecclesiasticus 9
tags : 
- Bible/Si/9
- français
cssclass : français
---

# Siracide 9

###### 01
Ne sois pas jaloux de la femme de ton cœur :
tu lui donnerais l’idée de te faire du mal.
###### 02
Ne livre pas ton âme au pouvoir d’une femme :
elle prendrait de l’ascendant sur toi.
###### 03
Ne va pas voir une femme de mauvaise vie :
tu tomberais dans ses filets.
###### 04
Ne fréquente pas une chanteuse,
de peur de te laisser prendre à ses artifices.
###### 05
Ne fixe pas ton regard sur une jeune fille,
de peur d’être puni à cause d’elle.
###### 06
Ne te livre pas aux prostituées :
tu y perdrais ton patrimoine.
###### 07
Ne promène pas tes regards dans les rues de la ville
et ne rôde pas dans les coins déserts.
###### 08
Détourne les yeux d’une jolie femme,
ne fixe pas ton regard sur une belle étrangère.
La beauté féminine en a égaré beaucoup,
et l’amour s’y enflamme comme un feu.
###### 09
Ne t’assieds jamais près d’une femme mariée,
et dans un banquet ne t’enivre pas avec elle,
de peur que tu t’en éprennes
et que ta passion entraîne ta perte.
###### 10
N’abandonne pas un vieil ami,
car un nouvel ami ne le vaudra pas.
Ami nouveau, vin nouveau :
qu’il vieillisse, tu le boiras avec plaisir.
###### 11
N’envie pas la réussite du pécheur,
tu ne sais pas comment il finira.
###### 12
Ne te réjouis pas, avec les impies, de leur succès,
souviens-toi qu’ils ne mourront pas impunis.
###### 13
Tiens-toi loin de l’homme capable de tuer,
et tu n’auras pas à craindre la mort.
Mais si tu viens à lui, évite tout faux pas,
de peur qu’il ne t’enlève la vie :
sache que tu t’avances au milieu de pièges,
et que tu t’exposes aux créneaux d’une ville assiégée.
###### 14
Fréquente tes voisins autant que tu le peux,
et demande conseil aux sages.
###### 15
Aime à t’entretenir avec les gens intelligents,
et consacre tes conversations à la loi du Très-Haut.
###### 16
Recherche des hommes justes pour prendre avec eux ton repas,
mets ta fierté dans la crainte du Seigneur.
###### 17
Pour son ouvrage on loue la main de l’artiste,
et le chef d’un peuple pour la sagesse de sa parole.
###### 18
Le bavard est redouté dans la ville,
l’homme emporté par ses discours se fait détester.
