---
aliases : 
- Philémon 1
- Philémon 1
- Phm 1
- Philemon 1
tags : 
- Bible/Phm/1
- français
cssclass : français
---

# Philémon 1

###### 01
PAUL, EN PRISON pour le Christ Jésus,
et Timothée notre frère,
à toi, Philémon, notre collaborateur bien-aimé,
###### 02
ainsi qu’à notre sœur, Aphia,
à notre compagnon de combat, Archippe,
et à l’Église qui se rassemble dans ta maison.
###### 03
À vous, la grâce et la paix
de la part de Dieu notre Père
et du Seigneur Jésus Christ.
###### 04
À tout moment je rends grâce à mon Dieu, en faisant mémoire de toi dans mes prières,
###### 05
car j’entends parler de ton amour et de la foi que tu as pour le Seigneur Jésus et à l’égard de tous les fidèles.
###### 06
Je prie pour que ta communion dans la foi devienne efficace par la pleine connaissance de tout le bien qui est en nous, pour le Christ.
###### 07
En effet, ta charité m’a déjà apporté beaucoup de joie et de réconfort, car grâce à toi, frère, les cœurs des fidèles ont trouvé du repos.
###### 08
Certes, j’ai dans le Christ toute liberté de parole pour te prescrire ce qu’il faut faire,
###### 09
mais je préfère t’adresser une demande au nom de la charité : moi, Paul, tel que je suis, un vieil homme et, qui plus est, prisonnier maintenant à cause du Christ Jésus,
###### 10
j’ai quelque chose à te demander pour Onésime, mon enfant à qui, en prison, j’ai donné la vie dans le Christ.
###### 11
Cet Onésime (dont le nom signifie « avantageux ») a été, pour toi, inutile à un certain moment, mais il est maintenant bien utile pour toi comme pour moi.
###### 12
Je te le renvoie, lui qui est comme mon cœur.
###### 13
Je l’aurais volontiers gardé auprès de moi, pour qu’il me rende des services en ton nom, à moi qui suis en prison à cause de l’Évangile.
###### 14
Mais je n’ai rien voulu faire sans ton accord, pour que tu accomplisses ce qui est bien, non par contrainte mais volontiers.
###### 15
S’il a été éloigné de toi pendant quelque temps, c’est peut-être pour que tu le retrouves définitivement,
###### 16
non plus comme un esclave, mais, mieux qu’un esclave, comme un frère bien-aimé : il l’est vraiment pour moi, combien plus le sera-t-il pour toi, aussi bien humainement que dans le Seigneur.
###### 17
Si donc tu estimes que je suis en communion avec toi, accueille-le comme si c’était moi.
###### 18
S’il t’a fait du tort ou s’il te doit quelque chose, mets cela sur mon compte.
###### 19
Moi, Paul, j’écris ces mots de ma propre main : c’est moi qui te rembourserai. Je n’ajouterai pas que toi aussi, tu as une dette envers moi, et cette dette, c’est toi-même.
###### 20
Oui, frère, donne-moi cette satisfaction dans le Seigneur, fais que mon cœur trouve du repos dans le Christ.
###### 21
Confiant dans ton obéissance, je t’écris en sachant que tu feras plus encore que je ne dis.
###### 22
En même temps, prévois aussi mon logement, car j’espère que, grâce à vos prières, je vous serai rendu.
###### 23
Épaphras, mon compagnon de captivité dans le Christ Jésus, te salue,
###### 24
ainsi que Marc, Aristarque, Démas et Luc, mes collaborateurs.
###### 25
Que la grâce du Seigneur Jésus Christ soit avec votre esprit.
