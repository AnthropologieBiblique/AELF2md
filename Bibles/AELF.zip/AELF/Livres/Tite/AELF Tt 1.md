---
aliases : 
- Tite 1
- Tite 1
- Tt 1
- Titus 1
tags : 
- Bible/Tt/1
- français
cssclass : français
---

# Tite 1

###### 01
PAUL, SERVITEUR DE DIEU,
apôtre de Jésus Christ
au service de la foi de ceux que Dieu a choisis
et de la pleine connaissance de la vérité
qui est en accord avec la piété.
###### 02
Nous avons l’espérance de la vie éternelle,
promise depuis toujours par Dieu qui ne ment pas.
###### 03
Aux temps fixés, il a manifesté sa parole
dans la proclamation de l’Évangile
qui m’a été confiée par ordre de Dieu notre Sauveur.
###### 04
Je m’adresse à toi, Tite, mon véritable enfant
selon la foi qui nous est commune :
à toi, la grâce et la paix
de la part de Dieu le Père
et du Christ Jésus notre Sauveur.
###### 05
Si je t’ai laissé en Crète, c’est pour que tu finisses de tout organiser et que, dans chaque ville, tu établisses des Anciens comme je te l’ai commandé moi-même.
###### 06
L’Ancien doit être quelqu’un qui soit sans reproche, époux d’une seule femme, ayant des enfants qui soient croyants et ne soient pas accusés d’inconduite ou indisciplinés.
###### 07
Il faut en effet que le responsable de communauté soit sans reproche, puisqu’il est l’intendant de Dieu ; il ne doit être ni arrogant, ni coléreux, ni buveur, ni brutal, ni avide de profits malhonnêtes ;
###### 08
mais il doit être accueillant, ami du bien, raisonnable, juste, saint, maître de lui.
###### 09
Il doit être attaché à la parole digne de foi, celle qui est conforme à la doctrine, pour être capable d’exhorter en donnant un enseignement solide, et aussi de réfuter les opposants.
###### 10
Car il y a beaucoup de réfractaires, des gens au discours inconsistant, des marchands d’illusion, surtout parmi ceux qui viennent du judaïsme.
###### 11
Il faut fermer la bouche à ces gens qui, pour faire des profits malhonnêtes, bouleversent des maisons entières, en enseignant ce qu’il ne faut pas.
###### 12
Car l’un d’entre eux, un de leurs prophètes, l’a bien dit : Crétois toujours menteurs, mauvaises bêtes, gloutons fainéants !
###### 13
Ce témoignage est vrai. Pour cette raison, réfute-les vigoureusement, afin qu’ils retrouvent la santé de la foi,
###### 14
au lieu de s’attacher à des récits légendaires du judaïsme et à des préceptes de gens qui se détournent de la vérité.
###### 15
Tout est pur pour les purs ; mais pour ceux qui sont souillés et qui refusent de croire, rien n’est pur : leur intelligence, aussi bien que leur conscience, est souillée.
###### 16
Ils proclament qu’ils connaissent Dieu, mais, par leurs actes, ils le rejettent, abominables qu’ils sont, révoltés, totalement inaptes à faire le bien.
