---
aliases : 
- Tite 2
- Tite 2
- Tt 2
- Titus 2
tags : 
- Bible/Tt/2
- français
cssclass : français
---

# Tite 2

###### 01
Quant à toi, dis ce qui est conforme à l’enseignement de la saine doctrine.
###### 02
Que les hommes âgés soient sobres, dignes de respect, pondérés, et solides dans la foi, la charité et la persévérance.
###### 03
De même, que les femmes âgées mènent une vie sainte, ne soient pas médisantes ni esclaves de la boisson, et qu’elles soient de bon conseil,
###### 04
pour apprendre aux jeunes femmes à aimer leur mari et leurs enfants,
###### 05
à être raisonnables et pures, bonnes maîtresses de maison, aimables, soumises à leur mari, afin que la parole de Dieu ne soit pas exposée au blasphème.
###### 06
Les jeunes aussi, exhorte-les à être raisonnables
###### 07
en toutes choses. Toi-même, sois un modèle par ta façon de bien agir, par un enseignement sans défaut et digne de respect,
###### 08
par la solidité inattaquable de ta parole, pour la plus grande confusion de l’adversaire, qui ne trouvera aucune critique à faire sur nous.
###### 09
Que les esclaves soient soumis à leur maître en toutes choses, qu’ils se rendent agréables, qu’ils ne soient pas contestataires,
###### 10
qu’ils ne dérobent rien, mais qu’ils montrent une parfaite fidélité, pour faire honneur en tout à l’enseignement de Dieu notre Sauveur.
###### 11
Car la grâce de Dieu s’est manifestée pour le salut de tous les hommes.
###### 12
Elle nous apprend à renoncer à l’impiété et aux convoitises de ce monde, et à vivre dans le temps présent de manière raisonnable, avec justice et piété,
###### 13
attendant que se réalise la bienheureuse espérance : la manifestation de la gloire de notre grand Dieu et Sauveur, Jésus Christ.
###### 14
Car il s’est donné pour nous afin de nous racheter de toutes nos fautes, et de nous purifier pour faire de nous son peuple, un peuple ardent à faire le bien.
###### 15
Voilà comment tu dois parler, exhorter et réfuter, en toute autorité. Que personne n’ait lieu de te mépriser.
