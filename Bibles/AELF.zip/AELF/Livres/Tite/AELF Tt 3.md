---
aliases : 
- Tite 3
- Tite 3
- Tt 3
- Titus 3
tags : 
- Bible/Tt/3
- français
cssclass : français
---

# Tite 3

###### 01
Rappelle à tous qu’ils doivent être soumis aux gouvernants et aux autorités, qu’ils doivent leur obéir et être prêts à faire tout ce qui est bien ;
###### 02
qu’ils n’insultent personne, ne soient pas violents, mais bienveillants, montrant une douceur constante à l’égard de tous les hommes.
###### 03
Car nous aussi, autrefois, nous étions insensés, révoltés, égarés, esclaves de toutes sortes de convoitises et de plaisirs ; nous vivions dans la méchanceté et la jalousie, nous étions odieux et remplis de haine les uns pour les autres.
###### 04
Mais lorsque Dieu, notre Sauveur,
a manifesté sa bonté
et son amour pour les hommes,
###### 05
il nous a sauvés,
non pas à cause de la justice de nos propres actes,
mais par sa miséricorde.
Par le bain du baptême,
il nous a fait renaître
et nous a renouvelés
dans l’Esprit Saint.
###### 06
Cet Esprit, Dieu l’a répandu
sur nous en abondance,
par Jésus Christ notre Sauveur,
###### 07
afin que, rendus justes par sa grâce,
nous devenions en espérance
héritiers de la vie éternelle.
###### 08
Voilà une parole digne de foi, et je veux que tu t’en portes garant, afin que ceux qui ont mis leur foi en Dieu aient à cœur d’être les premiers pour faire le bien : c’est cela qui est bon et utile pour les hommes.
###### 09
Mais les recherches folles, les généalogies, les disputes et les polémiques sur la Loi, évite-les, car elles sont inutiles et vaines.
###### 10
Quant à l’hérétique, après un premier et un second avertissement, écarte-le,
###### 11
sachant qu’un tel homme est perverti et pécheur : il se condamne lui-même.
###### 12
Lorsque je t’aurai envoyé Artémas ou Tychique, efforce-toi de me rejoindre à Nicopolis : c’est là que j’ai décidé de passer l’hiver.
###### 13
Prends soin de fournir au juriste Zénas ainsi qu’à Apollos ce qu’il faut pour leur voyage, afin qu’ils ne manquent de rien.
###### 14
Que ceux de chez nous apprennent aussi à être les premiers pour faire le bien et répondre aux nécessités urgentes : ainsi ils ne manqueront pas de produire du fruit.
###### 15
Ceux qui sont avec moi te saluent tous. Salue nos amis dans la foi.
Que la grâce soit avec vous tous.
