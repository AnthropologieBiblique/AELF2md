---
aliases : 
- 2 Corinthiens
- 2 Corinthiens
- 2 Co
- 2 Corinthians
tags : 
- Bible/2Co
- français
cssclass : français
---

# 2 Corinthiens

[[AELF 2 Co 1|2 Corinthiens 1]]
[[AELF 2 Co 2|2 Corinthiens 2]]
[[AELF 2 Co 3|2 Corinthiens 3]]
[[AELF 2 Co 4|2 Corinthiens 4]]
[[AELF 2 Co 5|2 Corinthiens 5]]
[[AELF 2 Co 6|2 Corinthiens 6]]
[[AELF 2 Co 7|2 Corinthiens 7]]
[[AELF 2 Co 8|2 Corinthiens 8]]
[[AELF 2 Co 9|2 Corinthiens 9]]
[[AELF 2 Co 10|2 Corinthiens 10]]
[[AELF 2 Co 11|2 Corinthiens 11]]
[[AELF 2 Co 12|2 Corinthiens 12]]
[[AELF 2 Co 13|2 Corinthiens 13]]
