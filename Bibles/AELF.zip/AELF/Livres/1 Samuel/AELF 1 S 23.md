---
aliases : 
- 1 Samuel 23
- 1 Samuel 23
- 1 S 23
tags : 
- Bible/1S/23
- français
cssclass : français
---

# 1 Samuel 23

###### 01
On rapporta à David cette nouvelle : « Voici que les Philistins sont en guerre contre Qeïla ; ils pillent les aires à grain ! »
###### 02
David consulta le Seigneur : « Dois-je partir ? Est-ce que je battrai ces Philistins ? » Le Seigneur dit à David : « Pars, tu battras les Philistins et tu sauveras Qeïla. »
###### 03
Mais les hommes de David lui dirent : « Déjà, nous avons peur ici, en Juda : ce sera bien pire, si nous allons à Qeïla contre les lignes des Philistins ! »
###### 04
À nouveau, David consulta le Seigneur, et le Seigneur lui répondit : « Lève-toi ! Descends à Qeïla car je livre les Philistins entre tes mains. »
###### 05
David partit alors pour Qeïla avec ses hommes et attaqua les Philistins. Il emmena leurs troupeaux. Il leur porta un coup très dur. David sauva ainsi les habitants de Qeïla.
###### 06
Or quand Abiatar, fils d’Ahimélek, s’était enfui auprès de David à Qeïla, il avait emporté l’éphod avec lui.
###### 07
Saül fut averti de l’entrée de David à Qeïla et il dit : « Dieu l’a remis en mon pouvoir, car il s’est enfermé lui-même, en entrant dans une ville munie de portes et de verrous. »
###### 08
Saül appela donc à la guerre tout le peuple pour descendre à Qeïla assiéger David et ses hommes.
###### 09
Quand David sut que Saül préparait contre lui un mauvais coup, il dit au prêtre Abiatar : « Apporte l’éphod. »
###### 10
David dit alors : « Seigneur, Dieu d’Israël, ton serviteur vient d’apprendre que Saül projetait de venir à Qeïla pour détruire la ville à cause de moi.
###### 11
Les notables de Qeïla vont-ils me livrer entre ses mains ? Saül descendra-t-il, comme ton serviteur vient de l’apprendre ? Seigneur, Dieu d’Israël, daigne en informer ton serviteur ! » Et le Seigneur dit : « Saül descendra. »
###### 12
David dit : « Les notables de Qeïla vont-ils nous livrer, moi et mes hommes, entre les mains de Saül ? » Le Seigneur dit : « Ils vous livreront. »
###### 13
Alors David se leva, lui et ses hommes – ils étaient environ six cents. Ils sortirent de Qeïla et s’en allèrent à l’aventure. Mais on informa Saül que David s’était échappé de Qeïla, si bien qu’il renonça à son expédition.
###### 14
David alla demeurer au désert dans des refuges ; il demeura dans la montagne, au désert de Zif. Pendant tout ce temps, Saül ne cessa de rechercher David, mais Dieu ne le livra pas entre ses mains.
###### 15
David s’aperçut que Saül s’était mis en campagne pour lui ôter la vie. David était dans le désert de Zif, à Horesha.
###### 16
Jonathan, fils de Saül, se mit en route et alla trouver David à Horesha. Il l’encouragea au nom de Dieu,
###### 17
et lui dit : « Sois sans crainte : la main de mon père Saül ne te trouvera pas. C’est toi qui régneras sur Israël, et moi, je serai ton second ; d’ailleurs, Saül, mon père, le sait bien. »
###### 18
Ils conclurent tous deux une alliance devant le Seigneur. David demeura à Horesha, et Jonathan s’en alla chez lui.
###### 19
Des gens de Zif montèrent auprès de Saül à Guibéa pour lui dire : « Est-ce que David ne se cache pas chez nous, dans les refuges de Horesha, sur la colline de Hakila, au sud de la steppe ?
###### 20
Et maintenant, si tel est ton désir, ô roi, descends ; c’est à nous de le livrer aux mains du roi. »
###### 21
Saül leur dit : « Soyez bénis du Seigneur, vous qui avez eu pitié de moi !
###### 22
Allez donc, vérifiez bien, tâchez de savoir en quel endroit il est passé et si quelqu’un l’a vu là-bas. On me dit, en effet, qu’il est plein de ruse.
###### 23
Tâchez de reconnaître toutes les cachettes où il peut se cacher. Vous reviendrez me voir quand vous aurez vérifié, et j’irai avec vous. Alors, s’il est dans le pays, je le chercherai parmi tous les clans de Juda. »
###### 24
Précédant Saül, ils se mirent en route pour Zif. David et ses hommes étaient dans le désert de Maône, dans la plaine au sud de la steppe.
###### 25
Saül et ses hommes allèrent à sa recherche. David en fut informé ; il descendit à la Roche et demeura dans le désert de Maône. Mais Saül, apprenant cela, poursuivit David au désert de Maône.
###### 26
Saül marchait d’un côté de la montagne ; David et ses hommes, de l’autre côté. David précipita sa marche pour s’éloigner de Saül, mais Saül et ses hommes l’encerclaient déjà, lui et les siens, pour les capturer.
###### 27
C’est alors qu’un messager vint dire à Saül : « Viens vite, car les Philistins ont fait irruption dans le pays. »
###### 28
Abandonnant la poursuite de David, Saül fit demi-tour pour affronter les Philistins. C’est pourquoi on a appelé ce lieu la « Roche-de-la-Séparation ».
