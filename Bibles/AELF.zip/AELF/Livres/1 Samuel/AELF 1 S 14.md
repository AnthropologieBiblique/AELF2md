---
aliases : 
- 1 Samuel 14
- 1 Samuel 14
- 1 S 14
tags : 
- Bible/1S/14
- français
cssclass : français
---

# 1 Samuel 14

###### 01
Un jour, Jonathan, fils de Saül, dit à son écuyer : « Viens ! Passons vers le poste des Philistins qui est là, sur l’autre versant ! » Mais il n’avertit pas son père.
###### 02
Saül se tenait à la limite de Guibéa sous le grenadier de Migrone et, avec lui, il y avait environ six cents hommes.
###### 03
Ahiyya, fils d’Ahitoub frère d’Ikabod, fils de Pinhas, fils d’Éli, était prêtre du Seigneur à Silo : il portait l’éphod. Le peuple ne savait pas que Jonathan était parti.
###### 04
Parmi les passages que Jonathan avait recherchés pour passer vers le poste des Philistins, il en est un avec une dent de rocher sur un versant et une dent de rocher sur l’autre. L’une est appelée Boceç, et l’autre, Senné.
###### 05
L’une se dresse au nord, en face de Mikmas, l’autre au sud, en face de Guéba.
###### 06
Jonathan dit à son écuyer : « Viens ! Passons vers le poste de ces incirconcis. Peut-être le Seigneur agira-t-il en notre faveur, car rien n’empêche le Seigneur de donner le salut, que l’on soit peu ou beaucoup. »
###### 07
Son écuyer lui répondit : « Fais tout ce que tu as dans le cœur. Vas-y ! Et moi, je suis avec toi, selon ton cœur. »
###### 08
Jonathan reprit : « Voici que nous passons vers ces hommes : ils vont nous repérer.
###### 09
S’ils nous disent : “Halte ! Attendez que nous vous ayons rejoints”, alors nous resterons sur place, nous ne monterons pas vers eux.
###### 10
Mais s’ils nous disent : “Montez vers nous !”, alors nous monterons, car le Seigneur les aura livrés entre nos mains. Ce sera pour nous le signe. »
###### 11
Tous deux se firent repérer par le poste des Philistins, lesquels se dirent : « Voici des Hébreux qui sortent des trous où ils s’étaient cachés ! »
###### 12
Les hommes du poste interpellèrent Jonathan et son écuyer, en leur disant : « Montez vers nous ! Nous avons quelque chose à vous apprendre. » Jonathan dit à son écuyer : « Monte derrière moi : le Seigneur les a livrés au pouvoir d’Israël ! »
###### 13
Jonathan, suivi de son écuyer, monta en s’aidant des mains et des pieds. Alors les Philistins tombèrent devant Jonathan et, derrière lui, son écuyer les mettait à mort.
###### 14
Ce premier coup porté par Jonathan et son écuyer frappa une vingtaine d’hommes, sur l’étendue d’un demi-arpent.
###### 15
Ce fut la terreur dans le camp, dans la campagne et parmi tout le peuple. Le poste et les troupes de choc furent terrifiés eux aussi. La terre se mit à trembler, et ce fut une terreur de Dieu.
###### 16
À Guibéa de Benjamin, les guetteurs de Saül observaient, et voici que le tumulte se propageait çà et là.
###### 17
Alors Saül dit à la troupe qui était avec lui : « Faites donc l’appel et voyez qui est parti de chez nous. » On fit l’appel : Jonathan et son écuyer manquaient.
###### 18
Saül dit à Ahiyya : « Fais approcher l’arche de Dieu. » En effet l’arche de Dieu était, ce jour-là, avec les fils d’Israël.
###### 19
Mais pendant que Saül parlait au prêtre, le tumulte dans le camp des Philistins ne cessait d’augmenter. Alors Saül dit au prêtre : « Retire ta main, cesse de consulter Dieu. »
###### 20
Puis, sur un cri de ralliement, Saül et toute la troupe qui était avec lui marchèrent au combat. Or, les Philistins avaient tiré l’épée l’un contre l’autre, et c’était la panique la plus totale.
###### 21
Quant aux Hébreux qui appartenaient de longue date aux Philistins, qui étaient montés avec eux au camp et se tenaient tout autour, même ceux-là passèrent du côté d’Israël qui était avec Saül et Jonathan.
###### 22
Tous les hommes d’Israël qui s’étaient cachés dans la montagne d’Éphraïm apprirent la déroute des Philistins ; ils se mirent, eux aussi, à leur poursuite pour les combattre.
###### 23
Ce jour-là, le Seigneur donna le salut à Israël. Le combat s’étendit au-delà de Beth-Awen.
###### 24
Ce jour-là, les hommes d’Israël avaient été accablés parce que Saül avait proféré à l’adresse du peuple cette imprécation : « Maudit soit l’homme qui prendra de la nourriture avant le soir, avant que je me sois vengé de mes ennemis ! » Et personne dans le peuple n’avait goûté de nourriture.
###### 25
Tout le monde entra dans la forêt. Or il y avait du miel à la surface du sol.
###### 26
Quand le peuple entra dans la forêt, voici qu’il y coulait du miel ! Cependant, nul n’y toucha pour en manger, car le peuple avait peur du serment.
###### 27
Mais Jonathan n’avait pas entendu son père imposer au peuple le serment. Il tendit le bâton qu’il avait à la main et en trempa le bout dans ce miel végétal ; il ramena la main à sa bouche, et son regard s’éclaircit.
###### 28
Mais quelqu’un dans le peuple prit la parole et dit : « Ton père a imposé au peuple ce serment solennel : “Maudit soit l’homme qui prendra de la nourriture aujourd’hui !”, alors que le peuple est épuisé. »
###### 29
Jonathan répondit : « Mon père a porté malheur au pays. Voyez comme mon regard s’est éclairci parce que j’ai goûté un peu de ce miel !
###### 30
À plus forte raison, si le peuple s’était nourri aujourd’hui sur le butin trouvé chez l’ennemi, le coup porté aux Philistins n’aurait-il pas été plus rude encore ? »
###### 31
Ce jour-là, ils battirent les Philistins depuis Mikmas jusqu’à Ayyalone, et le peuple fut complètement épuisé.
###### 32
Il se jeta sur le butin. On prit du petit et du gros bétail, avec de jeunes bêtes ; on les égorgea à même le sol, et le peuple mangea au-dessus du sang.
###### 33
On rapporta la chose à Saül : « Voici que le peuple est en train de pécher contre le Seigneur en mangeant au-dessus du sang ! » Saül dit : « Vous avez trahi. Roulez vers moi une grosse pierre tant qu’il fait jour ! »
###### 34
Puis il déclara : « Dispersez-vous parmi le peuple et dites : Que chacun amène vers moi son bœuf ou son mouton. Vous les égorgerez et les mangerez ici. Mais vous ne pécherez pas contre le Seigneur en mangeant auprès du sang. » Alors, à la nuit tombée, tous les gens amenèrent le bœuf que chacun possédait et que l’on égorgea à cet endroit.
###### 35
Saül bâtit un autel au Seigneur. C’était la première fois qu’il bâtissait un autel au Seigneur.
###### 36
Saül dit : « Descendons à la poursuite des Philistins pendant la nuit, pillons chez eux jusqu’au lever du jour et n’en laissons subsister aucun. » Ils répondirent : « Fais tout ce qui te semble bon. » Le prêtre dit : « Ici, approchons-nous de Dieu. »
###### 37
Alors Saül consulta Dieu : « Dois-je descendre à la poursuite des Philistins ? Les livreras-tu aux mains d’Israël ? » Mais, ce jour-là, Dieu ne lui donna pas de réponse.
###### 38
Alors Saül dit : « Avancez ici, vous tous, les chefs du peuple ; comprenez et voyez en quoi consiste le péché commis aujourd’hui.
###### 39
Oui, par le Seigneur vivant, le sauveur d’Israël, même si Jonathan, mon fils, est en cause, il mourra ! » Mais dans tout le peuple, personne ne lui répondit.
###### 40
Puis il dit à tout Israël : « Vous serez d’un côté. Moi et mon fils Jonathan, nous serons de l’autre côté. » Le peuple répondit : « Fais ce qui te semble bon. »
###### 41
Alors Saül s’adressa au Seigneur : « Dieu d’Israël, fais connaître la vérité ! » Jonathan et Saül furent désignés par le sort, et le peuple fut mis hors de cause.
###### 42
Saül dit : « Jetez les sorts entre moi et mon fils Jonathan. » Et Jonathan fut désigné.
###### 43
Saül dit à Jonathan : « Révèle-moi ce que tu as fait. » Jonathan le lui révéla en disant : « Oui, j’ai goûté un peu de miel au bout du bâton que j’avais à la main. Me voici : que je meure ! »
###### 44
Saül déclara : « Que Dieu amène le malheur sur moi, et pire encore, si tu ne meurs pas, Jonathan ! »
###### 45
Mais le peuple dit à Saül : « Est-ce que Jonathan devrait mourir, lui qui a remporté cette grande victoire en Israël ? Quelle horreur ! Par le Seigneur vivant, il ne tombera pas à terre un seul cheveu de sa tête, car c’est avec Dieu qu’il a agi en ce jour. » Le peuple racheta Jonathan, et celui-ci ne mourut pas.
###### 46
Quant à Saül, il renonça à poursuivre les Philistins, et les Philistins s’en allèrent chez eux.
###### 47
Quand Saül se fut emparé de la royauté sur Israël, il mena la guerre contre tous ses ennemis alentour : Moab, les fils d’Ammone, Édom, les rois de Soba et les Philistins. De quelque côté qu’il se tournât, il leur faisait du mal.
###### 48
Il déploya sa force et battit Amalec. Il délivra Israël de la main de ceux qui le pillaient.
###### 49
Les fils de Saül étaient Jonathan, Yishwi et Malki-Shoua. Ses deux filles s’appelaient, l’aînée, Mérab et, la cadette, Mikal.
###### 50
La femme de Saül s’appelait Ahinoam, fille d’Ahimaaç. Le chef de son armée s’appelait Abner, fils de Ner qui était l’oncle de Saül.
###### 51
Kish, le père de Saül, et Ner, le père d’Abner, étaient fils d’Abiel.
###### 52
Il y eut une guerre acharnée contre les Philistins durant tous les jours de Saül. Aussi, quand Saül remarquait un homme de valeur ou quelqu’un de courageux, il se l’attachait.
