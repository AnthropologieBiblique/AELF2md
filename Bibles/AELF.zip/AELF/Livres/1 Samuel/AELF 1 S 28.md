---
aliases : 
- 1 Samuel 28
- 1 Samuel 28
- 1 S 28
tags : 
- Bible/1S/28
- français
cssclass : français
---

# 1 Samuel 28

###### 01
En ces jours-là, les Philistins rassemblèrent leurs armées et entrèrent en campagne pour combattre Israël. Akish dit à David : « Tu sais sûrement que tu vas partir avec moi à la guerre, toi et tes hommes. »
###### 02
David répondit à Akish : « Certes, tu sais, toi-même, ce que fera ton serviteur ! » Et Akish lui dit : « Eh bien, je te prends pour toujours comme garde du corps ! »
###### 03
Samuel était mort, tout Israël l’avait pleuré et l’avait enseveli dans sa ville, à Rama. Or Saül avait écarté du pays les nécromanciens et les devins.
###### 04
Les Philistins se rassemblèrent et vinrent camper à Shounem. Saül rassembla tout Israël. Ils campèrent à Gelboé.
###### 05
Quand Saül vit le camp des Philistins, il fut effrayé ; son cœur se mit à battre violemment.
###### 06
Saül interrogea le Seigneur, mais le Seigneur ne lui répondit ni par les songes, ni par les sorts, ni par les prophètes.
###### 07
Alors Saül dit à ses serviteurs : « Cherchez-moi une femme experte en nécromancie ; j’irai chez elle pour la consulter. » Ses serviteurs lui dirent : « Il y a une nécromancienne à Enn-Dor. »
###### 08
Saül se déguisa, mit d’autres vêtements et partit, accompagné de deux hommes. Ils arrivèrent, de nuit, chez la femme. Saül lui dit : « Interroge pour moi l’esprit des morts et fais monter pour moi celui que je te dirai. »
###### 09
La femme lui répondit : « Allons ! Tu sais toi-même ce que Saül a fait : il a supprimé du pays la nécromancie et la divination. Et toi, pourquoi veux-tu me tendre un piège qui me fera mourir ? »
###### 10
Mais Saül lui fit ce serment : « Par la vie du Seigneur, tu ne cours aucun risque dans cette affaire. »
###### 11
La femme lui dit : « Qui ferai-je monter pour toi du séjour des morts ? » Il répondit : « Fais monter pour moi Samuel. »
###### 12
La femme vit Samuel et poussa un grand cri. Elle dit à Saül : « Pourquoi m’as-tu trompée ? Tu es Saül ! »
###### 13
Le roi lui dit : « Ne crains pas. Mais que vois-tu ? » La femme dit à Saül : « Je vois comme un dieu montant de la terre. »
###### 14
Saül demanda : « Quelle est son apparence ? » Elle répondit : « Celui qui monte est un vieillard ; il est enveloppé d’un manteau. » Saül comprit alors que c’était Samuel. Il s’inclina, face contre terre, et se prosterna.
###### 15
Samuel dit à Saül : « Pourquoi as-tu troublé mon repos en me faisant monter ? » Saül dit : « Je suis dans une grande angoisse. Les Philistins me font la guerre, et Dieu s’est écarté de moi. Il ne me répond plus, ni par l’intermédiaire des prophètes, ni par les songes. Aussi t’ai-je appelé pour que tu m’indiques ce que je dois faire. »
###### 16
Samuel dit : « Et pourquoi m’interroges-tu, alors que le Seigneur s’est écarté de toi et qu’il est devenu ton adversaire ?
###### 17
Le Seigneur a fait comme il l’avait dit par mon intermédiaire : le Seigneur t’a arraché la royauté et l’a donnée à David, à ton prochain.
###### 18
Puisque tu n’as pas obéi à la voix du Seigneur et que tu n’as pas traité Amalec selon l’ardeur de sa colère, eh bien, le Seigneur te traite aujourd’hui de cette manière.
###### 19
Et avec toi le Seigneur livrera aussi Israël aux mains des Philistins. Demain, toi et tes fils, vous me rejoindrez. Même l’armée d’Israël, le Seigneur la livrera aux mains des Philistins. »
###### 20
Aussitôt, Saül s’effondra par terre, de toute sa hauteur, tant les paroles de Samuel l’avaient effrayé. Il était aussi sans force, n’ayant rien mangé de toute la journée ni de toute la nuit.
###### 21
La femme s’approcha de Saül et vit qu’il était tout bouleversé. Elle lui dit : « Tu le vois, ta servante t’a obéi : j’ai risqué ma vie et j’ai obéi aux ordres que tu m’as donnés.
###### 22
Mais maintenant, daigne écouter, toi aussi, la voix de ta servante : laisse-moi te servir un morceau de pain et mange ! Tu retrouveras des forces et tu pourras aller ton chemin. »
###### 23
Il refusa et dit : « Je ne mangerai pas. » Mais ses serviteurs insistèrent, ainsi que la femme. Alors, il leur obéit, se leva de terre et s’assit sur le divan.
###### 24
La femme avait chez elle un veau à l’engrais. Elle se hâta de l’abattre. Ensuite, elle prit de la farine, la pétrit et fit cuire des pains sans levain.
###### 25
Elle apporta le tout devant Saül et ses serviteurs. Ils mangèrent. Puis, s’étant levés, ils repartirent au cours de cette même nuit.
