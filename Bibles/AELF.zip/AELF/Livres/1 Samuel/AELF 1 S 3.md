---
aliases : 
- 1 Samuel 3
- 1 Samuel 3
- 1 S 3
tags : 
- Bible/1S/3
- français
cssclass : français
---

# 1 Samuel 3

###### 01
Le jeune Samuel assurait le service du Seigneur en présence du prêtre Éli. La parole du Seigneur était rare en ces jours-là, et la vision, peu répandue.
###### 02
Un jour, Éli était couché à sa place habituelle – sa vue avait baissé et il ne pouvait plus bien voir.
###### 03
La lampe de Dieu n’était pas encore éteinte. Samuel était couché dans le temple du Seigneur, où se trouvait l’arche de Dieu.
###### 04
Le Seigneur appela Samuel, qui répondit : « Me voici ! »
###### 05
Il courut vers le prêtre Éli, et il dit : « Tu m’as appelé, me voici. » Éli répondit : « Je n’ai pas appelé. Retourne te coucher. » L’enfant alla se coucher.
###### 06
De nouveau, le Seigneur appela Samuel. Et Samuel se leva. Il alla auprès d’Éli, et il dit : « Tu m’as appelé, me voici. » Éli répondit : « Je n’ai pas appelé, mon fils. Retourne te coucher. »
###### 07
Samuel ne connaissait pas encore le Seigneur, et la parole du Seigneur ne lui avait pas encore été révélée.
###### 08
De nouveau, le Seigneur appela Samuel. Celui-ci se leva. Il alla auprès d’Éli, et il dit : « Tu m’as appelé, me voici. » Alors Éli comprit que c’était le Seigneur qui appelait l’enfant,
###### 09
et il lui dit : « Va te recoucher, et s’il t’appelle, tu diras : “Parle, Seigneur, ton serviteur écoute.” » Samuel alla se recoucher à sa place habituelle.
###### 10
Le Seigneur vint, il se tenait là et il appela comme les autres fois : « Samuel ! Samuel ! » Et Samuel répondit : « Parle, ton serviteur écoute. »
###### 11
Le Seigneur dit à Samuel : « Voici que je vais accomplir une chose en Israël à faire tinter les deux oreilles de qui l’apprendra.
###### 12
Ce jour-là, je réaliserai contre Éli toutes les paroles prononcées au sujet de sa maison, du début à la fin.
###### 13
Je lui ai annoncé que j’allais juger sa maison pour toujours, à cause de cette faute : sachant que ses fils méprisaient Dieu, il ne les a pas repris !
###### 14
Voilà pourquoi, je le jure à la maison d’Éli : ni sacrifice, ni offrande, rien ne pourra jamais effacer la faute de la maison d’Éli. »
###### 15
Samuel resta couché jusqu’au matin, puis il ouvrit les portes de la Maison du Seigneur. Mais Samuel craignait de rapporter à Éli la vision.
###### 16
Éli appela Samuel et dit : « Samuel, mon fils ! » Il répondit : « Me voici. »
###### 17
Éli ajouta : « Quelle est la parole qu’il t’a adressée ? Ne me la cache pas, je t’en prie. Que Dieu amène le malheur sur toi, et pire encore, si tu me caches le moindre mot de toute la parole qu’il t’a adressée ! »
###### 18
Samuel lui rapporta toutes les paroles sans rien lui cacher. Alors Éli déclara : « C’est le Seigneur. Qu’il fasse ce qui est bon à ses yeux ! »
###### 19
Samuel grandit. Le Seigneur était avec lui, et il ne laissa aucune de ses paroles sans effet.
###### 20
Tout Israël, depuis Dane jusqu’à Bershéba, reconnut que Samuel était vraiment un prophète du Seigneur.
###### 21
Le Seigneur continua de se manifester dans le temple de Silo, car c’est à Silo que le Seigneur se révélait par sa parole à Samuel.
