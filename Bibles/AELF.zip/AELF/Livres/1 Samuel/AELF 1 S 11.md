---
aliases : 
- 1 Samuel 11
- 1 Samuel 11
- 1 S 11
tags : 
- Bible/1S/11
- français
cssclass : français
---

# 1 Samuel 11

###### 01
Nahash l’Ammonite monta prendre position contre Yabesh-de-Galaad. Alors tous les gens de Yabesh dirent à Nahash : « Conclus avec nous une alliance, et nous te servirons. »
###### 02
Mais Nahash l’Ammonite leur fit cette réponse : « Voici comment je la conclurai : en vous crevant à tous l’œil droit ! J’infligerai cette infamie à tout Israël. »
###### 03
Les anciens de Yabesh lui dirent : « Laisse-nous un répit de sept jours, que nous puissions envoyer des messagers dans tout le territoire d’Israël, et si personne ne vient à notre secours, nous nous rendrons à toi. »
###### 04
Les messagers arrivèrent à Guibéa de Saül et rapportèrent ces paroles aux oreilles du peuple. Alors tout le peuple éclata en sanglots.
###### 05
Or voici que Saül revenait des champs derrière ses bœufs et il demanda : « Qu’a donc le peuple ? Qu’a-t-il à pleurer ainsi ? » On lui répéta les paroles des gens de Yabesh.
###### 06
L’Esprit de Dieu s’empara de Saül quand il entendit ces paroles, et il s’enflamma d’une grande colère.
###### 07
Il prit une paire de bœufs, les dépeça et en envoya les morceaux dans tout le territoire d’Israël par l’entremise de messagers qui dirent : « Celui qui ne partira pas au combat derrière Saül et Samuel, voilà ce qui arrivera à ses bœufs ! » La terreur du Seigneur s’abattit sur le peuple, et ils marchèrent tous comme un seul homme.
###### 08
Saül les passa en revue à Bézèq : les fils d’Israël étaient trois cent mille, et les hommes de Juda, trente mille.
###### 09
On dit aux messagers qui étaient venus : « Transmettez ceci aux gens de Yabesh-de-Galaad : Demain, quand le soleil sera au plus chaud, vous aurez du secours. » Les messagers vinrent informer les gens de Yabesh, qui s’en réjouirent.
###### 10
Ceux-ci dirent aux Ammonites : « Demain, nous nous rendrons à vous, et vous nous traiterez comme bon vous semble. »
###### 11
Or, le lendemain, Saül disposa le peuple en trois colonnes. Ils pénétrèrent dans le camp aux dernières heures de la nuit et frappèrent les Ammonites jusqu’à l’heure la plus chaude du jour. Alors les survivants se dispersèrent, et il n’en resta pas deux ensemble.
###### 12
Le peuple dit à Samuel : « Qui donc disait : “Saül régnerait-il sur nous ?” Livrez-nous ces gens-là, que nous les mettions à mort ! »
###### 13
Mais Saül déclara : « On ne mettra personne à mort en un tel jour, car, aujourd’hui même, le Seigneur a réalisé le salut en Israël. »
###### 14
Samuel dit au peuple : « Venez, allons à Guilgal ! Nous y renouvellerons la royauté. »
###### 15
Tout le peuple alla donc à Guilgal. Là, à Guilgal, on fit roi Saül en présence du Seigneur ; on offrit des sacrifices de paix en présence du Seigneur. Et là, Saül et tous les gens d’Israël se livrèrent à de grandes réjouissances.
