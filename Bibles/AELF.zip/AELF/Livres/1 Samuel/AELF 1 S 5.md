---
aliases : 
- 1 Samuel 5
- 1 Samuel 5
- 1 S 5
tags : 
- Bible/1S/5
- français
cssclass : français
---

# 1 Samuel 5

###### 01
Les Philistins avaient donc pris l’arche de Dieu. Ils la firent venir d’Ébène-Ézèr à Ashdod.
###### 02
Ils prirent l’arche de Dieu pour l’introduire dans la maison du dieu Dagone ; ils la placèrent à côté de Dagone.
###### 03
Mais lorsque les gens d’Ashdod se levèrent tôt le lendemain, voici que Dagone était tombé face contre terre devant l’arche du Seigneur. Ils prirent Dagone et le remirent à sa place.
###### 04
Ils se levèrent tôt le lendemain matin, et voici que Dagone était tombé face contre terre devant l’arche du Seigneur ; la tête de Dagone et les deux paumes de ses mains, coupées, se trouvaient sur le seuil. De Dagone, seul le corps était resté à sa place.
###### 05
Voilà pourquoi, aujourd’hui encore, à Ashdod, les prêtres de Dagone et tous ceux qui entrent dans la maison de Dagone évitent de fouler le seuil.
###### 06
La main du Seigneur pesa lourdement sur les gens d’Ashdod. Il fit chez eux des ravages, il frappa de tumeurs Ashdod et son territoire.
###### 07
Lorsque les gens d’Ashdod virent ce qu’il en était, ils dirent : « Que l’arche du Dieu d’Israël ne reste pas chez nous, car sa main s’est faite dure contre nous et contre Dagone notre dieu ! »
###### 08
Ils invitèrent donc tous les princes des Philistins à se réunir chez eux et ils dirent : « Qu’allons-nous faire de l’arche du Dieu d’Israël ? » Les princes répondirent : « C’est dans la ville de Gath que doit être transférée l’Arche ! » Et l’on transféra l’arche du Dieu d’Israël.
###### 09
Or, après qu’on l’eut transférée, la main du Seigneur fut sur la ville, causant une très grande panique. Le Seigneur frappa les gens de la ville du plus petit au plus grand : ils eurent des éruptions de tumeurs.
###### 10
Ils envoyèrent l’arche de Dieu à Éqrone. Mais, dès que l’arche de Dieu y arriva, tous les gens d’Éqrone s’écrièrent : « Ils ont transféré chez moi l’arche du Dieu d’Israël pour me faire mourir, moi et mon peuple ! »
###### 11
Ils invitèrent tous les princes des Philistins à se réunir et ils dirent : « Renvoyez l’arche du Dieu d’Israël, qu’elle retourne à l’endroit où elle était et qu’elle ne me fasse pas mourir, moi et mon peuple ! » En effet, il y avait dans toute la ville une panique de mort : la main de Dieu pesait très lourdement sur elle.
###### 12
Les gens qui ne mouraient pas étaient affligés de tumeurs, et le cri de détresse de la ville monta vers le ciel.
