---
aliases : 
- 1 Samuel 30
- 1 Samuel 30
- 1 S 30
tags : 
- Bible/1S/30
- français
cssclass : français
---

# 1 Samuel 30

###### 01
Lorsque David et ses hommes arrivèrent à Ciqlag le troisième jour, des Amalécites venaient de faire une incursion dans le Néguev et à Ciqlag. Ils avaient dévasté Ciqlag et l’avaient incendiée.
###### 02
Ils avaient réduit en captivité les femmes qui s’y trouvaient, sans tuer personne, ni petit ni grand, et les avaient tous emmenés, en continuant leur chemin.
###### 03
David et ses hommes arrivèrent donc à la ville ; ils virent qu’elle était incendiée, et que leurs femmes, leurs fils et leurs filles étaient emmenés en captivité.
###### 04
Alors, David et les gens qui étaient avec lui poussèrent des cris et pleurèrent jusqu’à n’avoir plus la force de pleurer.
###### 05
Les deux femmes de David avaient été emmenées captives : Ahinoam de Yizréel, et Abigaïl, femme de Nabal de Carmel.
###### 06
David fut dans une grande angoisse car les gens parlaient de le lapider, tous étant remplis d’amertume à cause de leurs fils et de leurs filles. Mais David reprit courage par le Seigneur son Dieu.
###### 07
David dit au prêtre Abiatar, fils d’Ahimélek : « Apporte-moi donc l’éphod. » Abiatar apporta l’éphod à David.
###### 08
David interrogea le Seigneur : « Si je poursuis cette bande de pillards, pourrai-je les atteindre ? » Et il lui dit : « Poursuis ! Sûrement, tu atteindras ! Sûrement, tu délivreras ! »
###### 09
David partit, ainsi que les six cents hommes qui étaient avec lui, et ils arrivèrent au torrent de Besor. Les autres étaient restés à Ciqlag.
###### 10
David continua la poursuite avec quatre cents hommes, tandis que deux cents restaient sur place, étant trop fatigués pour traverser le torrent de Besor.
###### 11
On trouva dans la campagne un Égyptien. On l’amena auprès de David. Puis on lui donna du pain qu’il mangea, et on lui fit boire de l’eau.
###### 12
On lui donna encore du gâteau de figues et deux gâteaux de raisins secs. Après avoir mangé, il retrouva ses esprits. En effet, il n’avait rien mangé ni bu depuis trois jours et trois nuits.
###### 13
David lui demanda : « À qui appartiens-tu et d’où es-tu ? » Il répondit : « Je suis un jeune Égyptien, esclave d’un Amalécite. Mon maître m’a abandonné il y a trois jours, parce que j’étais malade.
###### 14
C’est nous qui avons fait une incursion au Néguev des Kerétiens, contre le Néguev de Juda et contre celui de Caleb, et nous avons incendié Ciqlag. »
###### 15
David lui dit : « Veux-tu me conduire jusqu’à cette bande ? » Il répondit : « Jure-moi par Dieu que tu ne me feras pas mourir et ne me livreras pas entre les mains de mon maître. Alors je te conduirai jusqu’à cette bande. »
###### 16
Il le conduisit donc. Voici que les Amalécites étaient éparpillés sur toute l’étendue du pays, mangeant, buvant, faisant la fête avec l’énorme butin qu’ils avaient pris au pays des Philistins et au pays de Juda.
###### 17
David les combattit depuis l’aube jusqu’au soir du lendemain. Aucun d’eux n’en réchappa, sinon quatre cents jeunes gens qui s’enfuirent à dos de chameau.
###### 18
David délivra tous ceux qu’Amalec avait pris ; il délivra ainsi ses deux femmes.
###### 19
Il ne manqua personne, ni petit ni grand, aucun fils ni aucune fille, ni la moindre chose du butin, de tout ce qui leur avait été pris. David ramena le tout.
###### 20
David prit tout le petit et le gros bétail. Ceux qui précédaient ce troupeau pour le conduire disaient : « Voilà le butin de David ! »
###### 21
David arriva près des deux cents hommes, trop fatigués pour le suivre et qui étaient restés au torrent de Besor. Ils se portèrent à la rencontre de David et de sa troupe. David s’avança avec sa troupe et les salua.
###### 22
Mais parmi les hommes qui avaient accompagné David, ce furent tous les méchants et les vauriens qui prirent la parole et dirent : « Puisqu’ils ne sont pas venus avec nous, on ne leur donnera rien du butin que nous avons récupéré, si ce n’est à chacun sa femme et ses enfants. Qu’ils les emmènent et qu’ils s’en aillent ! »
###### 23
Mais David déclara : « Non, vous ne ferez pas cela, mes frères, avec ce que le Seigneur nous a donné. Il nous a gardés, il a livré entre nos mains la bande qui nous avait attaqués.
###### 24
Qui pourrait vous écouter sur ce point ? En effet, comme est la part de celui qui descend au combat, ainsi est la part de celui qui reste aux bagages : ils partageront entre eux. »
###### 25
À partir de ce jour, David en fit pour Israël une règle, un droit, qui vaut encore aujourd’hui.
###### 26
Arrivé à Ciqlag, David envoya des parts de butin aux anciens de Juda, ses proches, avec ce message : « Pour vous, comme en bénédiction, voici une part du butin pris sur les ennemis du Seigneur. »
###### 27
Il en envoya aussi à ceux de Béthel, à ceux de Ramoth-du-Néguev, à ceux de Yattir,
###### 28
à ceux d’Aroër, à ceux de Sifemoth, à ceux d’Eshtemoa,
###### 29
à ceux de Rakal, à ceux des villes des Yerahmëélites, à ceux des villes des Qénites,
###### 30
à ceux de Horma, à ceux de Bor-Ashane, à ceux d’Atak,
###### 31
à ceux d’Hébron et de tous les lieux où David et ses hommes étaient passés.
