---
aliases : 
- 1 Samuel 9
- 1 Samuel 9
- 1 S 9
tags : 
- Bible/1S/9
- français
cssclass : français
---

# 1 Samuel 9

###### 01
Il y avait dans la tribu de Benjamin un homme appelé Kish, fils d’Abiel, fils de Ceror, fils de Becorath, fils d’Afiah, fils d’un Benjaminite. C’était un homme de valeur.
###### 02
Il avait un fils appelé Saül, qui était jeune et beau. Aucun fils d’Israël n’était plus beau que lui, et il dépassait tout le monde de plus d’une tête.
###### 03
Les ânesses appartenant à Kish, père de Saül, s’étaient égarées. Kish dit à son fils Saül : « Prends donc avec toi l’un des serviteurs, et pars à la recherche des ânesses. »
###### 04
Ils traversèrent la montagne d’Éphraïm, ils traversèrent le pays de Shalisha sans les trouver ; ils traversèrent le pays de Shaalim : elles n’y étaient pas ; ils traversèrent le pays de Benjamin sans les trouver.
###### 05
Comme ils arrivaient au pays de Souf, Saül dit au serviteur qui l’accompagnait : « Allons, retournons, de peur que mon père ne se fasse du souci pour nous et en oublie les ânesses. »
###### 06
L’autre lui dit : « Mais il y a justement dans cette ville un homme de Dieu. C’est un homme respecté. Tout ce qu’il dit se produit à coup sûr. Allons-y maintenant ! Peut-être nous renseignera-t-il sur le chemin que nous suivons. »
###### 07
Saül dit à son serviteur : « Soit, allons-y ! Mais qu’apporterons-nous à cet homme ? Il n’y a plus de pain dans nos sacs, ni rien de convenable à offrir à l’homme de Dieu. Qu’avons-nous au juste ? »
###### 08
Le serviteur reprit la parole et répondit à Saül : « Il se trouve que j’ai dans la main un peu d’argent ; je le donnerai à l’homme de Dieu, et il nous renseignera sur notre chemin. »
###### 09
– Autrefois en Israël, quand on allait consulter Dieu, on disait : « Venez, allons chez le voyant ! », car celui qu’on appelle aujourd’hui « prophète », on l’appelait alors « voyant ».
###### 10
Saül dit à son serviteur : « Tu as bien parlé. Viens, allons-y ! » Et ils allèrent à la ville où se trouvait l’homme de Dieu.
###### 11
Comme ils gravissaient la montée qui mène à la ville, ils trouvèrent des jeunes filles qui sortaient puiser de l’eau. Ils leur demandèrent : « Le voyant est-il par ici ? »
###### 12
Elles leur répondirent : « Oui, juste devant toi ! Mais maintenant dépêche-toi, car, s’il est venu aujourd’hui à la ville, c’est qu’il y a aujourd’hui un sacrifice pour le peuple sur le lieu sacré.
###### 13
À votre arrivée dans la ville, vous allez sûrement le trouver avant qu’il monte au lieu sacré pour manger, car le peuple ne mangera pas avant son arrivée. C’est lui en effet qui doit bénir le sacrifice ; après quoi, les invités pourront manger. Et maintenant, montez ! Car lui, vous le trouverez tout de suite. »
###### 14
Ils montèrent donc à la ville. Comme ils pénétraient à l’intérieur de la ville, voici que Samuel sortit à leur rencontre pour monter au lieu sacré.
###### 15
Or, un jour avant l’arrivée de Saül, le Seigneur avait révélé ceci à l’oreille de Samuel :
###### 16
« Demain, à la même heure, je t’enverrai un homme du pays de Benjamin. Tu lui donneras l’onction comme chef de mon peuple Israël : c’est lui qui sauvera mon peuple de la main des Philistins. Oui, j’ai vu mon peuple ; oui, son cri est parvenu jusqu’à moi. »
###### 17
Quand Samuel aperçut Saül, le Seigneur l’avertit : « Voilà l’homme dont je t’ai parlé ; c’est lui qui exercera le pouvoir sur mon peuple. »
###### 18
Saül aborda Samuel à l’entrée de la ville et lui dit : « Indique-moi, je t’en prie, où est la maison du voyant. »
###### 19
Samuel répondit à Saül : « C’est moi le voyant. Monte devant moi au lieu sacré. Vous mangerez aujourd’hui avec moi. Demain matin, je te laisserai partir et je te renseignerai sur tout ce qui te préoccupe.
###### 20
Tes ânesses égarées depuis trois jours, cesse de t’en préoccuper, car elles sont retrouvées. À qui donc appartient tout ce qu’il y a de précieux en Israël ? N’est-ce pas à toi et à toute la maison de ton père ? »
###### 21
Saül répondit : « Ne suis-je pas un Benjaminite, appartenant à l’une des plus petites tribus d’Israël ? Et ma famille n’est-elle pas la dernière de toutes les familles de la tribu de Benjamin ? Pourquoi donc me parles-tu ainsi ? »
###### 22
Samuel prit Saül et son serviteur, et les fit entrer dans la salle. Il leur donna une place en tête des invités qui étaient une trentaine.
###### 23
Samuel dit au cuisinier : « Donne la part que je t’ai donnée, celle dont je t’ai dit : Mets-la de côté ! »
###### 24
Le cuisinier présenta le gigot avec le morceau qui est au-dessus. Il déposa le tout devant Saül, en disant : « Voilà ! Ce qui a été réservé est devant toi : mange ! Cela t’a été gardé pour cette fête, quand on a dit : Je convoque le peuple. » Saül mangea donc avec Samuel ce jour-là.
###### 25
Puis ils descendirent du lieu sacré à la ville, et Samuel s’entretint avec Saül sur la terrasse.
###### 26
Le lendemain, ils se levèrent tôt. Dès que monta l’aurore, Samuel appela Saül sur la terrasse et lui dit : « Lève-toi ! Je vais te laisser partir. » Saül se leva, et ils sortirent tous deux au-dehors, lui et Samuel.
###### 27
Comme ils descendaient à la limite de la ville, Samuel dit à Saül : « Dis au serviteur de passer devant nous – et ce dernier passa devant – et toi, arrête-toi un instant, que je te fasse entendre la parole de Dieu. »
