---
aliases : 
- 1 Samuel 22
- 1 Samuel 22
- 1 S 22
tags : 
- Bible/1S/22
- français
cssclass : français
---

# 1 Samuel 22

###### 01
David partit de là et se sauva dans la grotte d’Adoullam. L’ayant appris, ses frères, avec toute la maison de son père, descendirent le rejoindre à cet endroit.
###### 02
Alors se rassemblèrent autour de lui tous les gens en détresse, tous les endettés et tous les mécontents, et il devint leur chef. Il y eut ainsi avec lui environ quatre cents hommes.
###### 03
David partit de là pour Mispé de Moab. Il dit au roi de Moab : « Permets que mon père et ma mère se retirent chez vous, en attendant que je sache ce que Dieu fera de moi. »
###### 04
Il les conduisit devant le roi de Moab, et ils restèrent chez le roi tout le temps que David se tint dans son refuge fortifié.
###### 05
Le prophète Gad dit à David : « Ne reste pas dans ce refuge. Va-t’en, rentre au pays de Juda ! » David s’en alla et parvint à la forêt de Hèreth.
###### 06
Saül apprit qu’on avait reconnu David et ceux qui l’accompagnaient. Saül se tenait sur la hauteur à Guibéa, sous le tamaris, la lance à la main, et tous ses serviteurs debout auprès de lui.
###### 07
Saül leur dit : « Écoutez bien, fils de Benjamin ! Le fils de Jessé vous donnerait-il, à vous tous, des champs et des vignes ? Vous nommerait-il, vous tous, officiers de millier ou officiers de centaine,
###### 08
pour que vous ayez tous conspiré contre moi, pour que personne ne m’ait averti quand mon fils faisait alliance avec le fils de Jessé ? Non, aucun de vous ne s’est tourmenté à mon sujet, et personne ne m’a averti quand mon fils dressait mon serviteur contre moi pour me tendre une embuscade, comme aujourd’hui. »
###### 09
Doëg l’Édomite prit la parole, lui qui se tenait là avec les serviteurs de Saül. Il dit : « J’ai vu le fils de Jessé : il est venu à Nob, chez Ahimélek, fils d’Ahitoub.
###### 10
Ahimélek a consulté pour lui le Seigneur, il lui a fourni des vivres et lui a donné l’épée de Goliath le Philistin. »
###### 11
Alors le roi fit convoquer le prêtre Ahimélek, fils d’Ahitoub, et toute la maison de son père, c’est-à-dire les prêtres qui étaient à Nob. Ils vinrent tous auprès du roi.
###### 12
Saül dit : « Écoute bien, fils d’Ahitoub ! » Et celui-ci déclara : « Me voici, mon seigneur. »
###### 13
Saül lui dit : « Pourquoi avez-vous conspiré contre moi, toi et le fils de Jessé, quand tu lui as fourni du pain et une épée, quand tu as consulté Dieu en sa faveur, pour qu’il se dresse contre moi et me tende une embuscade, comme aujourd’hui ? »
###### 14
Ahimélek répondit au roi : « Y a-t-il parmi tous tes serviteurs quelqu’un de sûr comme David, le gendre du roi, lui qui est affecté à ta garde personnelle et qui est honoré dans ta maison ?
###### 15
Est-ce aujourd’hui que j’ai commencé à consulter Dieu pour lui ? Quelle horreur ! Que le roi ne charge en rien son serviteur ni la maison de mon père, car ton serviteur ignorait absolument tout de cette affaire. »
###### 16
Mais le roi lui dit : « Tu vas mourir, Ahimélek, tu vas mourir, toi et toute la maison de ton père. »
###### 17
Le roi dit aux gardes qui étaient debout près de lui : « Tournez-vous et mettez à mort les prêtres du Seigneur, puisqu’ils prêtent main forte, eux aussi, à David : ils le savaient en fuite et ne m’ont pas averti ! » Mais les serviteurs du roi refusèrent de lever la main pour frapper les prêtres du Seigneur.
###### 18
Le roi dit alors à Doëg : « Tourne-toi et frappe les prêtres ! » Doëg l’Édomite se retourna, et c’est lui qui frappa les prêtres. Il fit mourir, ce jour-là, quatre-vingt-cinq hommes qui portaient l’éphod de lin.
###### 19
Et la ville des prêtres, Nob, on la passa au fil de l’épée : hommes et femmes, enfants et nourrissons, bœufs, ânes et moutons, au fil de l’épée !
###### 20
Un seul des fils d’Ahimélek, fils d’Ahitoub, put se sauver. Il s’appelait Abiatar. Il prit la fuite pour rejoindre David.
###### 21
Abiatar rapporta à David que Saül avait massacré les prêtres du Seigneur,
###### 22
et David lui dit : « Je savais, ce jour-là, que Doëg l’Édomite étant présent, il irait sûrement informer Saül. C’est à cause de moi que les événements ont tourné contre toute personne de la maison de ton père.
###### 23
Reste avec moi, ne crains rien : il en voudra à ma vie, celui qui en voudra à la tienne ! Tu es en sûreté auprès de moi. »
