---
aliases : 
- 1 Samuel 31
- 1 Samuel 31
- 1 S 31
tags : 
- Bible/1S/31
- français
cssclass : français
---

# 1 Samuel 31

###### 01
Les Philistins livraient bataille à Israël. Les hommes d’Israël s’enfuirent devant les Philistins et tombèrent, frappés à mort, sur le mont Gelboé.
###### 02
Les Philistins rattrapèrent Saül et ses fils. Ils frappèrent Jonathan, Abinadab et Malki-Shoua, les fils de Saül.
###### 03
Le poids du combat se porta vers Saül. Les tireurs d’arc le surprirent, et il fut gravement blessé par les tireurs.
###### 04
Saül dit à son écuyer : « Tire ton épée et transperce-moi, de peur que ces incirconcis ne viennent me transpercer et se jouer de moi. » Mais son écuyer refusa, tant il avait peur. Alors Saül prit son épée et se jeta sur elle.
###### 05
Quand l’écuyer vit que Saül était mort, il se jeta, lui aussi, sur son épée et mourut avec lui.
###### 06
Ainsi, ce jour-là, Saül, ses trois fils et son écuyer, avec tous ses hommes, moururent ensemble.
###### 07
Les hommes d’Israël qui se trouvaient de l’autre côté de la vallée, et ceux qui étaient de l’autre côté du Jourdain, virent que leurs troupes avaient pris la fuite et que Saül et ses fils étaient morts. Ils abandonnèrent leurs villes et s’enfuirent. Alors les Philistins vinrent s’y installer.
###### 08
Le lendemain, les Philistins, venus pour dépouiller les morts, trouvèrent Saül et ses trois fils, gisant sur le mont Gelboé.
###### 09
Ils lui coupèrent la tête et le dépouillèrent de ses armes. Puis ils envoyèrent, à la ronde, dans le pays des Philistins, porter la bonne nouvelle dans la maison de leurs idoles et parmi le peuple.
###### 10
Ils déposèrent ses armes dans la maison des Astartés et clouèrent son corps sur le rempart de Beth-Shéane.
###### 11
Les habitants de Yabesh-de-Galaad apprirent ce que les Philistins avaient fait à Saül.
###### 12
Alors tous les hommes de valeur se mirent en route et marchèrent toute la nuit. Ils enlevèrent du rempart de Beth-Shéane le corps de Saül et ceux de ses fils. Ils revinrent à Yabesh et y brûlèrent les corps.
###### 13
Ils prirent ensuite leurs ossements, les ensevelirent sous le tamaris de Yabesh et jeûnèrent pendant sept jours.
