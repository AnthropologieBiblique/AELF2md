---
aliases : 
- 1 Samuel 4
- 1 Samuel 4
- 1 S 4
tags : 
- Bible/1S/4
- français
cssclass : français
---

# 1 Samuel 4

###### 01
Et la parole de Samuel s’adressa à tout Israël.
Israël sortit pour aller combattre les Philistins. Israël campa près d’Ébène-Ézèr, tandis que les Philistins étaient campés à Apheq.
###### 02
Les Philistins se déployèrent contre Israël, et le combat s’engagea. Dans cette bataille rangée en rase campagne, Israël fut battu par les Philistins, qui tuèrent environ quatre mille hommes,
###### 03
et le peuple revint au camp. Les anciens d’Israël dirent alors : « Pourquoi le Seigneur nous a-t-il fait battre aujourd’hui par les Philistins ? Allons prendre à Silo l’arche de l’Alliance du Seigneur ; qu’elle vienne au milieu de nous, et qu’elle nous sauve de la main de nos ennemis. »
###### 04
Le peuple envoya des gens à Silo ; ils en rapportèrent l’arche de l’Alliance du Seigneur des armées qui siège sur les Kéroubim. Les deux fils du prêtre Éli, Hofni et Pinhas, étaient là auprès de l’arche de Dieu.
###### 05
Quand l’Arche arriva au camp, tout Israël poussa une grande ovation qui fit résonner la terre.
###### 06
Les Philistins entendirent le bruit et dirent : « Que signifie cette grande ovation dans le camp des Hébreux ? » Ils comprirent alors que l’arche du Seigneur était arrivée dans le camp.
###### 07
Alors ils eurent peur, car ils se disaient : « Dieu est arrivé au camp des Hébreux. » Puis ils dirent : « Malheur à nous ! Les choses ont bien changé depuis hier.
###### 08
Malheur à nous ! Qui nous délivrera de la main de ces dieux puissants ? Ce sont eux qui ont frappé les Égyptiens de toutes sortes de calamités dans le désert.
###### 09
Soyez forts, Philistins, soyez des hommes courageux, pour ne pas être asservis aux Hébreux comme ils vous ont été asservis : soyez courageux et combattez ! »
###### 10
Les Philistins livrèrent bataille, Israël fut battu et chacun s’enfuit à ses tentes. Ce fut un très grand désastre : en Israël trente mille soldats tombèrent.
###### 11
L’arche de Dieu fut prise, et les deux fils d’Éli, Hofni et Pinhas, moururent.
###### 12
Un homme de Benjamin quitta en courant le champ de bataille et parvint à Silo le jour même ; il avait les vêtements déchirés et la tête couverte de terre.
###### 13
Lorsqu’il arriva, Éli était assis sur son siège, près du chemin ; il était aux aguets, car son cœur tremblait pour l’arche de Dieu. L’homme arriva donc dans la ville pour annoncer la nouvelle, et toute la ville se mit à pousser des cris.
###### 14
Éli entendit la clameur et se demanda : « Que veut dire ce bruit de foule ? » Mais l’homme vint en toute hâte porter la nouvelle à Éli.
###### 15
Or celui-ci était âgé de quatre-vingt-dix-huit ans ; il avait le regard fixe et ne pouvait plus voir.
###### 16
L’homme dit à Éli : « C’est moi qui viens du champ de bataille, je me suis enfui du champ de bataille aujourd’hui même. » Éli demanda : « Que s’est-il passé, mon fils ? »
###### 17
Le messager répondit : « Israël a fui devant les Philistins ; de plus, le peuple a subi une grande défaite ; même tes deux fils, Hofni et Pinhas, sont morts, et l’arche de Dieu a été prise… »
###### 18
À cette mention de l’arche de Dieu, Éli tomba de son siège à la renverse, sur le côté de la porte ; il se brisa la nuque et mourut : l’homme, en effet, était âgé et lourd. C’est lui qui avait jugé Israël pendant quarante ans.
###### 19
Sa belle-fille, la femme de Pinhas, était enceinte et sur le point d’accoucher. En apprenant ces nouvelles : la prise de l’arche de Dieu, la mort de son beau-père et de son mari, elle s’accroupit et accoucha, car les douleurs l’avaient saisie.
###### 20
Comme elle était près de mourir, les femmes qui se tenaient auprès d’elle lui dirent : « Sois sans crainte, car c’est un fils que tu as mis au monde ! » Mais elle ne répondit pas et n’y prêta pas attention.
###### 21
Elle appela l’enfant Ikabod en disant : « La gloire est bannie d’Israël », par allusion à la prise de l’arche de Dieu, et à la mort de son beau-père et de son mari.
###### 22
Elle avait dit : « La gloire est bannie d’Israël », parce que l’arche de Dieu avait été prise.
