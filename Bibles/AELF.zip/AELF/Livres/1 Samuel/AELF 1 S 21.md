---
aliases : 
- 1 Samuel 21
- 1 Samuel 21
- 1 S 21
tags : 
- Bible/1S/21
- français
cssclass : français
---

# 1 Samuel 21

###### 01
David se leva et s’en alla, tandis que Jonathan rentrait dans la ville.
###### 02
David arriva à Nob chez le prêtre Ahimélek. Celui-ci vint en tremblant à la rencontre de David et lui dit : « Pourquoi es-tu seul, sans personne avec toi ? »
###### 03
David répondit au prêtre Ahimélek : « Le roi m’a donné un ordre et m’a dit : “Que personne ne sache rien de l’affaire pour laquelle je t’envoie et que je t’ai ordonnée.” Mes compagnons, je leur ai fixé un point de rencontre à tel endroit.
###### 04
Maintenant, qu’as-tu sous la main ? Donne-moi cinq pains ou bien ce que tu pourras trouver. »
###### 05
Le prêtre répondit à David : « Je n’ai pas de pain ordinaire sous la main, mais il y a le pain consacré. Les hommes pourront en manger s’ils se sont gardés de rapports avec les femmes. »
###### 06
David répondit au prêtre : « Assurément, les femmes nous ont été interdites, comme précédemment quand je partais en campagne ; sur ce point, les hommes étaient en état de sainteté. Cette expédition est profane, certes, mais aujourd’hui elle sera sanctifiée de ce fait. »
###### 07
Le prêtre lui donna alors du pain consacré. En effet, il n’y avait là pas d’autre pain que le pain disposé devant le Seigneur, celui que l’on retire, pour le remplacer, le jour même, par du pain chaud.
###### 08
Cependant, le même jour, un des serviteurs de Saül se trouvait là, retenu devant le Seigneur. Il s’appelait Doëg l’Édomite, et c’était le plus important des bergers de Saül.
###### 09
David dit à Ahimélek : « N’as-tu pas ici, sous la main, une lance ou une épée ? Je n’ai pris avec moi ni épée ni bagages, tant la mission du roi était urgente. »
###### 10
Le prêtre répondit : « Il y a l’épée de Goliath, le Philistin que tu as abattu dans le Val du Térébinthe : la voici, enveloppée dans le manteau, derrière l’éphod. Si tu veux la prendre, prends-la ; il n’y en a pas d’autre ici. » David lui dit : « Elle n’a pas sa pareille, donne-la-moi. »
###### 11
David se leva et s’enfuit, ce jour-là, loin de Saül. Il arriva chez Akish, roi de Gath.
###### 12
Les serviteurs d’Akish dirent à leur maître : « Cet homme n’est-il pas David, le roi du pays ? N’est-ce pas celui pour qui l’on dansait en se renvoyant ce refrain :
“Saül a tué ses milliers,
et David, ses dizaines de milliers” ? »
###### 13
David fut impressionné par ces paroles, si bien qu’il eut très peur d’Akish, roi de Gath.
###### 14
Alors, à leurs yeux, il fit semblant de perdre la raison ; il se mit à divaguer au milieu d’eux, à tracer des signes sur les battants de la porte, à baver dans sa barbe.
###### 15
Akish dit à ses serviteurs : « Vous voyez bien que cet homme est fou. Pourquoi me l’amenez-vous ?
###### 16
Est-ce que je manque de fous pour que vous ameniez celui-ci faire le fou devant moi ? Et cet individu entrerait dans ma maison ? »
