---
aliases : 
- 1 Samuel 17
- 1 Samuel 17
- 1 S 17
tags : 
- Bible/1S/17
- français
cssclass : français
---

# 1 Samuel 17

###### 01
Les Philistins rassemblèrent leurs armées pour la guerre ; ils se rassemblèrent à Soko de Juda et ils établirent leur camp entre Soko et Azéqa, à Éfès-Dammim.
###### 02
Saül et les hommes d’Israël se rassemblèrent et établirent leur camp dans le Val du Térébinthe, puis se rangèrent en ordre de bataille face aux Philistins.
###### 03
Les Philistins se tenaient sur la montagne d’un côté, Israël se tenait sur la montagne de l’autre côté ; entre eux il y avait la vallée.
###### 04
Alors sortit des rangs philistins un champion qui s’appelait Goliath. Originaire de Gath, il mesurait six coudées et un empan.
###### 05
Il avait un casque de bronze sur la tête, il était revêtu d’une cuirasse à écailles ; la cuirasse pesait cinq mille sicles de bronze.
###### 06
Il avait des jambières de bronze et un javelot de bronze entre les épaules.
###### 07
Le bois de sa lance était comme le rouleau d’un métier à tisser, et sa pointe pesait six cents sicles de fer. Et devant lui marchait le porte-bouclier.
###### 08
Il s’arrêta et cria vers les lignes d’Israël. Il leur dit : « À quoi bon sortir pour vous ranger en ordre de bataille ? Ne suis-je pas, moi, le Philistin, et vous, les esclaves de Saül ? Choisissez-vous un homme, et qu’il descende vers moi !
###### 09
S’il est le plus fort en luttant avec moi et qu’il m’abatte, nous deviendrons vos esclaves. Mais si je suis le plus fort et que je l’abatte, vous deviendrez nos esclaves, vous nous serez asservis. »
###### 10
Le Philistin ajouta : « Moi, aujourd’hui, je lance un défi aux lignes d’Israël : donnez-moi un homme, et nous lutterons l’un contre l’autre ! »
###### 11
Saül et tout Israël entendirent les paroles du Philistin ; ils en furent consternés, ils éprouvèrent une grande crainte.
###### 12
David était fils de cet Éphratéen de Bethléem en Juda, nommé Jessé et qui avait huit fils. Or, au temps de Saül, cet homme était un vieillard avancé en âge.
###### 13
Les trois fils aînés de Jessé s’en étaient allés : ils avaient suivi Saül à la guerre. Les trois fils de Jessé partis à la guerre se nommaient : le premier-né Éliab, le deuxième Abinadab, et le troisième Shamma.
###### 14
David était le plus jeune. Les trois aînés avaient donc suivi Saül ;
###### 15
quant à David, il allait chez Saül et en revenait pour faire paître le troupeau de son père à Bethléem.
###### 16
Le Philistin s’avançait matin et soir ; il se présenta ainsi pendant quarante jours.
###### 17
Jessé dit à son fils David : « Prends donc pour tes frères cette mesure d’épis grillés, avec les dix pains que voici, et cours les porter au camp à tes frères.
###### 18
Ces dix fromages, tu les porteras à l’officier de millier ; tu verras si tes frères sont en bonne santé, et tu m’en rapporteras le signe que tout va bien.
###### 19
Saül, tes frères et tous les hommes d’Israël sont en train de combattre les Philistins dans le Val du Térébinthe. »
###### 20
David se leva de bon matin, laissa le troupeau à un gardien, et partit avec les provisions, comme Jessé le lui avait ordonné. Il arriva au milieu du camp lorsque l’armée, sortant pour se mettre en ligne, poussait le cri de guerre.
###### 21
Israël et les Philistins se rangèrent ligne contre ligne.
###### 22
David se déchargea de ses bagages, les laissa aux mains du gardien des bagages et courut vers la ligne de front. Une fois arrivé, il demanda à ses frères s’ils étaient en bonne santé.
###### 23
Comme il parlait avec eux, voici que monta des lignes philistines le champion appelé Goliath, le Philistin de Gath, qui reprit les mêmes paroles, et David l’entendit.
###### 24
En voyant l’homme, tous ceux d’Israël s’enfuirent devant lui, terrifiés.
###### 25
Ils disaient : « Avez-vous vu cet homme qui monte contre nous ? C’est pour défier Israël qu’il monte ! Celui qui l’abattra, le roi le fera riche, très riche ; il lui donnera sa fille, et il affranchira sa famille de toute charge en Israël. »
###### 26
David demanda à ceux qui se tenaient près de lui : « Que fera-t-on pour récompenser l’homme qui abattra ce Philistin et relèvera le défi lancé à Israël ? Qui est-il, en effet, ce Philistin incirconcis, pour avoir défié les armées du Dieu vivant ? »
###### 27
Les gens répondirent avec les mêmes paroles : « Ainsi fera-t-on pour récompenser l’homme qui l’abattra… »
###### 28
Éliab, son frère aîné, l’entendit qui parlait avec les gens. Il se mit en colère contre David et dit : « Pourquoi donc es-tu descendu ? À qui as-tu laissé ton maigre troupeau dans le désert ? Je connais, moi, ton arrogance et la malice de ton cœur : c’est pour voir la bataille que tu es descendu ! »
###### 29
David répondit : « Qu’est-ce que j’ai fait encore ? On n’a plus le droit de parler ! »
###### 30
David se détourna de lui et s’adressa à un autre. Il répéta sa demande, et les gens lui firent la même réponse qu’auparavant.
###### 31
Mais les paroles de David attirèrent l’attention et furent rapportées à Saül qui le fit venir.
###### 32
David dit à Saül : « Que personne ne perde courage à cause de ce Philistin. Moi, ton serviteur, j’irai me battre avec lui. »
###### 33
Saül répondit à David : « Tu ne peux pas marcher contre ce Philistin pour lutter avec lui, car tu n’es qu’un enfant, et lui, c’est un homme de guerre depuis sa jeunesse. »
###### 34
David dit à Saül : « Quand ton serviteur était berger du troupeau de son père, si un lion ou bien un ours venait emporter une brebis du troupeau,
###### 35
je partais à sa poursuite, je le frappais et la délivrais de sa gueule. S’il m’attaquait, je le saisissais par la crinière et je le frappais à mort.
###### 36
Ton serviteur a frappé et le lion et l’ours. Eh bien ! ce Philistin incirconcis sera comme l’un d’eux puisqu’il a défié les armées du Dieu vivant ! »
###### 37
David insista : « Le Seigneur, qui m’a délivré des griffes du lion et de l’ours, me délivrera des mains de ce Philistin. » Alors Saül lui dit : « Va, et que le Seigneur soit avec toi ! »
###### 38
Saül revêtit David de ses propres vêtements. Il lui mit sur la tête un casque de bronze et le revêtit d’une cuirasse.
###### 39
David se mit à la ceinture l’épée de Saül par-dessus ses vêtements. Il fut incapable de marcher car il n’était pas entraîné. Et David dit à Saül : « Je ne peux pas marcher avec tout cela car je ne suis pas entraîné. » Et il s’en débarrassa.
###### 40
David prit en main son bâton, il se choisit dans le torrent cinq cailloux bien lisses et les mit dans son sac de berger, dans une poche ; puis, la fronde à la main, il s’avança vers le Philistin.
###### 41
Le Philistin se mit en marche et, précédé de son porte-bouclier, approcha de David.
###### 42
Lorsqu’il le vit, il le regarda avec mépris car c’était un jeune garçon ; il était roux et de belle apparence.
###### 43
Le Philistin lui dit : « Suis-je donc un chien, pour que tu viennes contre moi avec un bâton ? » Puis il le maudit en invoquant ses dieux.
###### 44
Il dit à David : « Viens vers moi, que je te donne en pâture aux oiseaux du ciel et aux bêtes sauvages ! »
###### 45
David lui répondit : « Tu viens contre moi avec épée, lance et javelot, mais moi, je viens contre toi avec le nom du Seigneur des armées, le Dieu des troupes d’Israël que tu as défié.
###### 46
Aujourd’hui le Seigneur va te livrer entre mes mains, je vais t’abattre, te trancher la tête, donner aujourd’hui même les cadavres de l’armée philistine aux oiseaux du ciel et aux bêtes de la terre. Toute la terre saura qu’il y a un Dieu pour Israël,
###### 47
et tous ces gens rassemblés sauront que le Seigneur ne donne la victoire ni par l’épée ni par la lance, mais que le Seigneur est maître du combat, et qu’il vous livre entre nos mains. »
###### 48
Goliath s’était dressé, s’était mis en marche et s’approchait à la rencontre de David. Celui-ci s’élança et courut vers les lignes des ennemis à la rencontre du Philistin.
###### 49
Il plongea la main dans son sac, et en retira un caillou qu’il lança avec sa fronde. Il atteignit le Philistin au front, le caillou s’y enfonça, et Goliath tomba face contre terre.
###### 50
Ainsi David triompha du Philistin avec une fronde et un caillou : quand il frappa le Philistin et le mit à mort, il n’avait pas d’épée à la main.
###### 51
Mais David courut ; arrivé près du Philistin, il lui prit son épée, qu’il tira du fourreau, et le tua en lui coupant la tête. Quand les Philistins virent que leur héros était mort, ils prirent la fuite.
###### 52
Les hommes d’Israël et de Juda se levèrent en poussant le cri de guerre ; ils poursuivirent les Philistins jusqu’à l’entrée de la vallée et jusqu’aux portes d’Éqrone. Des Philistins, blessés à mort, tombèrent sur la route de Shaaraïm, jusqu’à Gath et jusqu’à Éqrone.
###### 53
Puis, les fils d’Israël revinrent de leur poursuite acharnée contre les Philistins et se mirent à piller leur camp.
###### 54
David saisit la tête du Philistin et l’apporta à Jérusalem. Quant à ses armes, il les déposa dans sa propre tente.
###### 55
Lorsque Saül avait vu David sortir à la rencontre du Philistin, il avait demandé au chef de l’armée, Abner : « De qui ce garçon est-il le fils, Abner ? » Et Abner lui avait répondu : « Par ta vie, ô roi, je ne le sais pas. »
###### 56
Le roi lui avait dit : « Informe-toi : de qui ce jeune homme est-il le fils ? »
###### 57
Quand David fut de retour, après avoir abattu le Philistin, Abner le retint et le fit venir devant Saül ; David avait à la main la tête du Philistin.
###### 58
Saül lui demanda : « Mon garçon, de qui es-tu le fils ? » Et David lui répondit : « Je suis le fils de ton serviteur Jessé, de Bethléem. »
