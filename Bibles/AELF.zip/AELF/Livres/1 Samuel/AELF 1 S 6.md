---
aliases : 
- 1 Samuel 6
- 1 Samuel 6
- 1 S 6
tags : 
- Bible/1S/6
- français
cssclass : français
---

# 1 Samuel 6

###### 01
L’arche du Seigneur demeura en territoire philistin pendant sept mois.
###### 02
Puis les Philistins convoquèrent prêtres et devins, en disant : « Qu’allons-nous faire de l’arche du Seigneur ? Indiquez-nous comment la renvoyer à l’endroit où elle était. »
###### 03
Ils répondirent : « Si vous renvoyez l’arche du Dieu d’Israël, ne la renvoyez pas sans rien, mais ne manquez pas d’y joindre une offrande de réparation. Alors, vous serez guéris et vous saurez pourquoi sa main ne s’écartait pas de vous. »
###### 04
Ils demandèrent : « Quelle offrande de réparation faut-il y joindre ? » Ils répondirent : « D’après le nombre des princes Philistins : cinq tumeurs en or et cinq rats en or, car c’est un même fléau qui vous a tous atteints, vous et vos princes.
###### 05
Vous ferez donc des images de vos tumeurs et des images des rats qui dévastent votre pays, et vous rendrez gloire au Dieu d’Israël. Peut-être sa main se fera-t-elle plus légère sur vous, sur vos dieux et sur votre pays.
###### 06
À quoi bon alourdir votre cœur, comme l’ont fait les Égyptiens et Pharaon ? Quand Dieu se fut joué d’eux, n’ont-ils pas renvoyé les fils d’Israël ? Et ils sont partis.
###### 07
Maintenant, prenez et préparez un chariot neuf ainsi que deux vaches qui allaitent et qui n’ont pas encore porté le joug ; vous attellerez les vaches au chariot et vous les séparerez de leurs petits que vous ramènerez à l’étable.
###### 08
Puis, vous prendrez l’arche du Seigneur et vous la placerez sur le chariot. Quant aux objets d’or que vous lui remettrez en offrande de réparation, vous les déposerez dans le coffre, à côté de l’Arche. Vous la renverrez, et elle partira.
###### 09
Vous verrez alors : si elle prend la route de son territoire en montant vers Beth-Shèmesh, c’est bien Dieu qui nous a fait ce grand mal. Sinon, nous saurons que ce n’est pas sa main qui nous a touchés : c’est par accident que cela nous est arrivé. »
###### 10
Ainsi firent les gens. Ils prirent deux vaches qui allaitaient, ils les attelèrent au chariot et retinrent leurs petits à l’étable.
###### 11
Puis ils déposèrent l’arche du Seigneur sur le chariot, ainsi que le coffre avec les rats en or et les images de leurs tumeurs.
###### 12
Les vaches allèrent droit leur chemin sur la route de Beth-Shèmesh. Elles avançaient en meuglant, mais gardèrent le même chemin sans se détourner ni à droite ni à gauche, les princes des Philistins marchant derrière elles jusqu’à la limite de Beth-Shèmesh.
###### 13
Les gens de Beth-Shèmesh faisaient la moisson des blés dans la vallée. Levant les yeux, ils aperçurent l’Arche et se réjouirent de la voir.
###### 14
Le chariot arriva dans le champ de Josué de Beth-Shèmesh et il s’y arrêta. Il y avait là une grande pierre. On fendit le bois du chariot et on offrit les vaches en holocauste au Seigneur.
###### 15
Les lévites avaient descendu l’arche du Seigneur avec le coffre contenant les objets en or et placé à côté d’elle ; ils déposèrent le tout sur la grande pierre. Ce jour-là, les gens de Beth-Shèmesh offrirent des holocaustes et firent des sacrifices pour le Seigneur.
###### 16
Et ce même jour, les cinq princes des Philistins, ayant vu cela, s’en retournèrent à Éqrone.
###### 17
Voici quelles étaient les tumeurs en or remises par les Philistins en offrande de réparation au Seigneur : une pour Ashdod, une pour Gaza, une pour Ascalon, une pour Gath, une pour Éqrone ;
###### 18
et les rats en or, selon le nombre de toutes les villes des Philistins relevant des cinq princes – depuis la ville fortifiée jusqu’au village sans murailles. La Grande Pierre en est témoin, sur laquelle on avait déposé l’arche du Seigneur ; elle se trouve, aujourd’hui encore, dans le champ de Josué de Beth-Shèmesh.
###### 19
Le Seigneur frappa les gens de Beth-Shèmesh, parce qu’ils avaient regardé dans l’arche du Seigneur. Il en frappa soixante-dix parmi le peuple. Et le peuple prit le deuil, parce que le Seigneur l’avait durement frappé.
###### 20
Les gens de Beth-Shèmesh dirent : « Qui pourra se tenir devant le Seigneur, ce Dieu saint ? » et : « Chez qui le Seigneur montera-t-il, loin de nous ? »
###### 21
Alors, ils envoyèrent des messagers aux habitants de Qiryath-Yearim pour leur dire : « Les Philistins ont ramené l’arche du Seigneur. Descendez ! Faites-la monter chez vous ! »
