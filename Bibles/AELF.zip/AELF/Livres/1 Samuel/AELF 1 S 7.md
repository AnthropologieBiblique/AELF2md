---
aliases : 
- 1 Samuel 7
- 1 Samuel 7
- 1 S 7
tags : 
- Bible/1S/7
- français
cssclass : français
---

# 1 Samuel 7

###### 01
Les gens de Qiryath-Yearim vinrent donc et firent monter l’arche du Seigneur. Ils la firent entrer dans la maison d’Abinadab, sur la colline, et ils consacrèrent son fils Éléazar pour qu’il garde l’arche du Seigneur.
###### 02
Depuis le jour où l’Arche s’installa à Qiryath-Yearim, de nombreux jours s’étaient écoulés, vingt ans déjà, lorsque toute la maison d’Israël se mit à soupirer après le Seigneur.
###### 03
Alors Samuel, s’adressant à toute la maison d’Israël, déclara : « Si c’est de tout votre cœur que vous revenez au Seigneur, écartez du milieu de vous les dieux de l’étranger et les Astartés, attachez vos cœurs au Seigneur, servez-le, lui seul, et il vous délivrera de la main des Philistins. »
###### 04
Alors les fils d’Israël écartèrent les Baals et les Astartés ; ils ne servirent plus que le Seigneur seul.
###### 05
Samuel dit : « Rassemblez tout Israël à Mispa, et je prierai pour vous auprès du Seigneur. »
###### 06
Ils se rassemblèrent donc à Mispa. Ils puisèrent de l’eau qu’ils répandirent devant le Seigneur. Ce jour-là, ils jeûnèrent, et ils déclarèrent en ce lieu : « Nous avons péché contre le Seigneur. » Et Samuel jugea les fils d’Israël à Mispa.
###### 07
Les Philistins apprirent que les fils d’Israël s’étaient rassemblés à Mispa, et les princes des Philistins montèrent pour attaquer Israël. Les fils d’Israël, en l’apprenant, eurent peur des Philistins.
###### 08
Ils dirent à Samuel : « Ne reste pas muet, ne nous abandonne pas, et ne cesse pas de crier vers le Seigneur notre Dieu, pour qu’il nous sauve de la main des Philistins ! »
###### 09
Samuel prit un agneau de lait et l’offrit tout entier en holocauste au Seigneur. Samuel cria vers le Seigneur en faveur d’Israël, et le Seigneur lui répondit.
###### 10
Pendant que Samuel offrait l’holocauste, les Philistins s’approchèrent pour combattre Israël. Mais, ce jour-là, le Seigneur tonna d’une grande voix contre les Philistins ; il les frappa de panique, et ils furent battus devant Israël.
###### 11
Alors les hommes d’Israël sortirent de Mispa et poursuivirent les Philistins de leurs coups jusqu’au-dessous de Beth-Kar.
###### 12
Samuel prit une pierre et la plaça entre Mispa et le lieu-dit « La Dent ». Il lui donna le nom d’Ébène-Ézèr (c’est-à-dire : Pierre du Secours), en disant : « Le Seigneur nous a secourus jusqu’ici. »
###### 13
Les Philistins durent s’incliner. Ils ne recommencèrent plus à envahir le territoire d’Israël. La main du Seigneur fut contre eux durant toute la vie de Samuel.
###### 14
Alors les villes d’Israël dont les Philistins s’étaient emparés lui furent restituées, d’Éqrone à Gath, et Israël délivra leurs territoires de la main des Philistins. Il y eut la paix entre Israël et les Amorites.
###### 15
Samuel jugea Israël tous les jours de sa vie.
###### 16
Il allait d’année en année faire le tour des villes de Béthel, Guilgal et Mispa ; en tous ces lieux, il jugeait Israël.
###### 17
Il revenait ensuite à Rama, où il avait sa maison. C’est là qu’il jugea Israël, et là qu’il bâtit un autel au Seigneur.
