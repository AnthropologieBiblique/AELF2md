---
aliases : 
- 1 Samuel 1
- 1 Samuel 1
- 1 S 1
tags : 
- Bible/1S/1
- français
cssclass : français
---

# 1 Samuel 1

###### 01
IL Y AVAIT UN HOMME de la ville de Rama, dans la montagne d’Éphraïm ; il s’appelait Elcana, fils de Yéroham, fils d’Éliou, fils de Tohou, fils de Souf ; c’était un Éphratéen.
###### 02
Cet homme avait deux femmes. L’une s’appelait Anne, l’autre Peninna. Peninna avait des enfants, mais Anne n’en avait pas.
###### 03
Chaque année, Elcana montait de sa ville au sanctuaire de Silo pour se prosterner devant le Seigneur de l’univers et lui offrir un sacrifice. C’est à Silo que résidaient, comme prêtres du Seigneur, les deux fils d’Éli, Hofni et Pinhas.
###### 04
Un jour, Elcana offrait le sacrifice ; il distribua des parts de la victime à sa femme Peninna, à tous ses fils et à toutes ses filles.
###### 05
Mais à Anne, il donna une part de choix car il aimait Anne, que pourtant le Seigneur avait rendue stérile.
###### 06
Sa rivale cherchait, par des paroles blessantes, à la mettre en colère parce que le Seigneur l’avait rendue stérile.
###### 07
Cela recommençait tous les ans, quand Anne montait au sanctuaire du Seigneur : Peninna cherchait à la mettre en colère. Anne pleura et ne voulut rien manger.
###### 08
Son mari Elcana lui dit : « Anne, pourquoi pleures-tu ? Pourquoi ne manges-tu pas ? Pourquoi ton cœur est-il triste ? Et moi, est-ce que je ne compte pas à tes yeux plus que dix fils ? »
###### 09
Anne se leva, après qu’ils eurent mangé et bu. Le prêtre Éli était assis sur son siège, à l’entrée du sanctuaire du Seigneur.
###### 10
Anne, pleine d’amertume, se mit à prier le Seigneur et pleura abondamment.
###### 11
Elle fit un vœu en disant : « Seigneur de l’univers ! Si tu veux bien regarder l’humiliation de ta servante, te souvenir de moi, ne pas m’oublier, et me donner un fils, je le donnerai au Seigneur pour toute sa vie, et le rasoir ne passera pas sur sa tête. »
###### 12
Tandis qu’elle prolongeait sa prière devant le Seigneur, Éli observait sa bouche.
###### 13
Anne parlait dans son cœur : seules ses lèvres remuaient, et l’on n’entendait pas sa voix. Éli pensa qu’elle était ivre
###### 14
et lui dit : « Combien de temps vas-tu rester ivre ? Cuve donc ton vin ! »
###### 15
Anne répondit : « Non, mon seigneur, je ne suis qu’une femme affligée, je n’ai bu ni vin ni boisson forte ; j’épanche mon âme devant le Seigneur.
###### 16
Ne prends pas ta servante pour une vaurienne : c’est l’excès de mon chagrin et de mon dépit qui m’a fait prier aussi longtemps. »
###### 17
Éli lui répondit : « Va en paix, et que le Dieu d’Israël t’accorde ce que tu lui as demandé. »
###### 18
Anne dit alors : « Que ta servante trouve grâce devant toi ! » Elle s’en alla, elle se mit à manger, et son visage n’était plus le même.
###### 19
Le lendemain, Elcana et les siens se levèrent de bon matin. Après s’être prosternés devant le Seigneur, ils s’en retournèrent chez eux, à Rama. Elcana s’unit à Anne sa femme, et le Seigneur se souvint d’elle.
###### 20
Anne conçut et, le temps venu, elle enfanta un fils ; elle lui donna le nom de Samuel (c’est-à-dire : Dieu exauce) car, disait-elle : « Je l’ai demandé au Seigneur. »
###### 21
Elcana, son mari, monta au sanctuaire avec toute sa famille pour offrir au Seigneur le sacrifice annuel et s’acquitter du vœu pour la naissance de l’enfant.
###### 22
Mais Anne n’y monta pas. Elle dit à son mari : « Quand l’enfant sera sevré, je l’emmènerai : il sera présenté au Seigneur, et il restera là pour toujours. »
###### 23
Son mari Elcana lui répondit : « Fais ce qui est bon à tes yeux ; reste ici jusqu’à ce que tu l’aies sevré. Toutefois, que le Seigneur réalise sa parole ! » La femme resta donc et allaita son fils jusqu’à ce qu’elle l’eût sevré.
###### 24
Lorsque Samuel fut sevré, Anne, sa mère, le conduisit à la Maison du Seigneur, à Silo ; l’enfant était encore tout jeune. Anne avait pris avec elle un taureau de trois ans, un sac de farine et une outre de vin.
###### 25
On offrit le taureau en sacrifice, et on amena l’enfant au prêtre Éli.
###### 26
Anne lui dit alors : « Écoute-moi, mon seigneur, je t’en prie ! Aussi vrai que tu es vivant, je suis cette femme qui se tenait ici près de toi pour prier le Seigneur.
###### 27
C’est pour obtenir cet enfant que je priais, et le Seigneur me l’a donné en réponse à ma demande.
###### 28
À mon tour je le donne au Seigneur pour qu’il en dispose. Il demeurera à la disposition du Seigneur tous les jours de sa vie. » Alors ils se prosternèrent devant le Seigneur.
