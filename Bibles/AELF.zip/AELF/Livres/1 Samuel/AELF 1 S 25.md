---
aliases : 
- 1 Samuel 25
- 1 Samuel 25
- 1 S 25
tags : 
- Bible/1S/25
- français
cssclass : français
---

# 1 Samuel 25

###### 01
Samuel mourut. Tout Israël se rassembla pour le pleurer. On l’ensevelit chez lui, à Rama. David se mit en route et descendit au désert de Parane.
###### 02
Il y avait à Maône quelqu’un dont l’exploitation se trouvait à Carmel. Cet homme, très riche, possédait trois mille moutons et un millier de chèvres. Il se trouvait à Carmel pour la tonte de son troupeau.
###### 03
L’homme s’appelait Nabal, et sa femme, Abigaïl. La femme était intelligente et belle, tandis que l’homme était dur et malfaisant. Il était du clan de Caleb.
###### 04
David, au désert, apprit que Nabal faisait tondre son troupeau.
###### 05
Il envoya dix serviteurs en leur disant : « Montez à Carmel. Vous entrerez chez Nabal et vous le saluerez de ma part.
###### 06
Vous direz : “Pour l’année qui vient, paix à toi, paix à ta maison, paix à tout ce qui t’appartient !
###### 07
J’ai appris que l’on faisait la tonte chez toi. Sache maintenant ceci : tes bergers étaient avec nous, et nous ne les avons pas molestés ; rien n’a disparu de chez eux, tout le temps de leur séjour à Carmel.
###### 08
Interroge-les : ils t’informeront. Que mes serviteurs trouvent grâce à tes yeux, puisque nous sommes venus en ce jour de fête ! Alors, je t’en prie, donne à tes serviteurs et à ton fils David ce que ta main trouvera.” »
###### 09
Les serviteurs de David entrèrent chez Nabal et lui répétèrent toutes ces paroles de la part de David, puis restèrent en silence.
###### 10
Nabal répondit aux serviteurs de David : « Qui est David et qui est le fils de Jessé ? Ils sont nombreux aujourd’hui, les serviteurs évadés de chez leur maître !
###### 11
Et je prendrais de mon pain, de mon eau, de mes bêtes que j’ai fait abattre pour mes tondeurs, et je les donnerais à des gens dont je ne sais même pas d’où ils viennent ? »
###### 12
Les serviteurs de David rebroussèrent chemin ; ils s’en retournèrent et, arrivés auprès de David, lui rapportèrent toutes ces paroles.
###### 13
David dit à ses hommes : « Que chacun de vous prenne son épée. » Et chacun d’eux prit son épée. David aussi prit la sienne. Quatre cents hommes environ montèrent à la suite de David ; deux cents restèrent près des bagages.
###### 14
Cependant, Abigaïl, la femme de Nabal, avait été avertie. L’un des bergers lui avait dit : « Voici que David a envoyé des messagers depuis le désert, pour saluer notre maître ; mais lui s’est emporté contre eux.
###### 15
Et pourtant, ces hommes étaient très bons pour nous : nous n’avons pas été molestés, et rien n’a disparu de chez nous, tout le temps où nous avons parcouru avec eux la campagne.
###### 16
Ils étaient pour nous un rempart, de nuit comme de jour, tout le temps où nous avons été avec eux à faire paître les troupeaux.
###### 17
Maintenant, tâche de voir ce que tu dois faire, car le malheur est décidé contre notre maître Nabal et toute sa maison. C’est un vaurien : on ne peut même pas lui parler ! »
###### 18
Abigaïl se dépêcha de prendre deux cents pains, deux outres de vin, cinq moutons tout préparés, cinq boisseaux d’épis grillés, cent gâteaux de raisins secs et deux cents gâteaux de figues qu’elle chargea sur des ânes.
###### 19
Elle dit aux serviteurs : « Passez devant moi, je vous suis. » Cependant, elle n’avertit pas Nabal, son mari.
###### 20
Alors que, sur son âne, elle descendait à l’abri de la montagne, voici que David et ses hommes descendaient dans sa direction : elle les rencontra.
###### 21
Or, David s’était dit : « C’est donc en pure perte que j’ai protégé tout ce que possédait ce Nabal dans le désert, et que rien n’a disparu de ce qu’il possédait ! Il m’a rendu le mal pour le bien.
###### 22
Que Dieu amène le malheur sur David – ou plutôt sur ses ennemis –, et pire encore, si je laisse subsister parmi tous les siens, d’ici demain matin, un seul mâle ! »
###### 23
Apercevant David, Abigaïl descendit vite de son âne, elle se jeta devant David, face contre terre, et se prosterna.
###### 24
S’étant jetée à ses pieds, elle dit : « C’est moi, c’est ma faute, mon seigneur ! Permets à ta servante de te parler ! Écoute donc les paroles de ta servante.
###### 25
De grâce, que mon seigneur ne prête pas attention à ce vaurien de Nabal : il porte bien son nom ! Son nom est “le Fou”, et la folie l’accompagne. Mais moi, ta servante, je n’avais pas vu les serviteurs de mon seigneur, ceux que tu avais envoyés.
###### 26
Et maintenant, par la vie du Seigneur et par ta propre vie, puisque le Seigneur t’a empêché d’en venir au sang et de te sauver par ta propre main, qu’ils deviennent comme Nabal, tes ennemis et ceux qui veulent du mal à mon seigneur !
###### 27
Et maintenant, ce présent que ta servante apporte à mon seigneur, qu’il soit remis aux serviteurs qui t’accompagnent.
###### 28
Pardonne, je te prie, l’offense de ta servante. Nul doute, en effet : le Seigneur fera à mon seigneur une maison stable, parce que toi, mon seigneur, tu as mené les combats du Seigneur et que, de toute ta vie, on ne trouvera pas de mal en toi.
###### 29
Un homme s’est levé pour te poursuivre et s’en prendre à ta vie, mais la vie de mon seigneur sera gardée précieusement avec celles des vivants, auprès du Seigneur ton Dieu, tandis que la vie de tes ennemis, le Seigneur la placera dans le creux de sa fronde pour la lancer au loin.
###### 30
Aussi, lorsque le Seigneur aura fait à mon seigneur tout le bien qu’il a prédit à ton sujet et qu’il t’aura institué chef sur Israël,
###### 31
ce ne sera pas un obstacle pour toi, ni un remords au cœur de mon seigneur, d’avoir versé le sang inutilement, en voulant te sauver par ta propre main. Et quand le Seigneur aura fait du bien à mon seigneur, tu te souviendras de ta servante. »
###### 32
David dit à Abigaïl : « Béni soit le Seigneur, Dieu d’Israël, qui t’a envoyée en ce jour à ma rencontre.
###### 33
Bénie soit ton intelligence, et bénie sois-tu, toi qui m’as retenu aujourd’hui d’en venir au sang et de me sauver par ma propre main !
###### 34
Mais, par le Seigneur vivant, par le Dieu d’Israël qui m’a empêché de te faire du mal, si tu n’étais pas venue aussi vite à ma rencontre, il ne serait pas resté à Nabal un seul mâle, avant que le matin se lève ! »
###### 35
David reçut de la main d’Abigaïl ce qu’elle lui avait apporté. Puis il lui dit : « Remonte en paix chez toi. Tu le vois : je t’ai écoutée, je t’ai fait grâce. »
###### 36
Quand Abigaïl revint chez Nabal, celui-ci donnait un festin dans sa maison, un vrai festin de roi. Nabal avait le cœur en joie, mais comme il était complètement ivre, Abigaïl ne l’informa de rien avant que le matin se lève.
###### 37
Le lendemain matin, après que Nabal eut cuvé son vin, sa femme l’informa de ce qui s’était passé. Alors le cœur de Nabal défaillit dans sa poitrine, et lui-même fut comme pétrifié.
###### 38
Au bout d’une dizaine de jours, le Seigneur frappa Nabal qui mourut.
###### 39
David apprit que Nabal était mort et il dit : « Béni soit le Seigneur qui a défendu ma cause, après l’insulte reçue de Nabal, et qui a empêché son serviteur de faire le mal. Quant à la méchanceté de Nabal, le Seigneur l’a fait retomber sur sa tête. » Puis David envoya dire à Abigaïl qu’il la prendrait pour femme.
###### 40
Les serviteurs de David vinrent donc chez Abigaïl à Carmel et lui dirent : « David nous a envoyés chez toi afin de te prendre pour sa femme. »
###### 41
Elle se leva, puis se prosterna face contre terre et dit : « Voici ta servante, comme une esclave prête à laver les pieds des serviteurs de mon seigneur. »
###### 42
Se relevant en toute hâte, Abigaïl monta sur son âne et, accompagnée de cinq de ses servantes, elle suivit les messagers de David et devint sa femme.
###### 43
David avait aussi épousé Ahinoam de Yizréel. Elles furent toutes les deux ses femmes.
###### 44
Or Saül avait donné sa fille Mikal, femme de David, en mariage à Palti, fils de Laïsh, qui était de Gallim.
