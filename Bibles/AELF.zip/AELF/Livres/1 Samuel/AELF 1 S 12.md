---
aliases : 
- 1 Samuel 12
- 1 Samuel 12
- 1 S 12
tags : 
- Bible/1S/12
- français
cssclass : français
---

# 1 Samuel 12

###### 01
Samuel déclara à tout Israël : « Voyez comme j’ai écouté jusqu’au bout votre appel : j’ai fait régner sur vous un roi.
###### 02
Et maintenant, voici que le roi marche devant vous. Quant à moi, je suis devenu vieux, j’ai blanchi, et mes fils que voici sont avec vous. Moi qui ai marché devant vous depuis ma jeunesse jusqu’à ce jour,
###### 03
me voici ! Témoignez contre moi en face du Seigneur et de son messie : De qui ai-je pris le bœuf ? De qui ai-je pris l’âne ? Qui ai-je exploité ? Qui ai-je maltraité ? De la main de qui ai-je reçu un pot-de-vin pour fermer les yeux sur son cas ? – Je restituerai. »
###### 04
Ils répondirent : « Tu ne nous as pas exploités, tu ne nous as pas maltraités et tu n’as rien pris de la main de personne. »
###### 05
Il leur dit : « Le Seigneur est témoin contre vous, et son messie est témoin aujourd’hui, que vous n’avez rien trouvé en ma main. » Ils dirent : « Il est témoin… »
###### 06
Et Samuel dit au peuple : « Il est témoin, le Seigneur, lui qui a suscité Moïse et Aaron, et qui a fait monter vos pères du pays d’Égypte !
###### 07
Et maintenant, tenez-vous prêts : que j’entre en jugement avec vous, devant le Seigneur, pour toutes les justes actions que le Seigneur a accomplies envers vous et vos pères.
###### 08
Alors que Jacob était venu en Égypte, vos pères ont crié vers le Seigneur, et le Seigneur envoya Moïse et Aaron qui les ont fait sortir d’Égypte et les ont installés en ce lieu où nous sommes.
###### 09
Mais ils ont oublié le Seigneur leur Dieu, et lui les a vendus au pouvoir de Sissera, chef de l’armée du roi de Haçor, au pouvoir des Philistins et au pouvoir du roi de Moab, qui leur ont fait la guerre.
###### 10
Alors, ils ont crié vers le Seigneur : “Nous avons péché en abandonnant le Seigneur pour servir les Baals et les Astartés. Maintenant, délivre-nous de la main de nos ennemis, et nous te servirons !”
###### 11
Le Seigneur envoya Yeroubbaal, Baraq, Jephté et Samuel ; il vous a délivrés de la main de vos ennemis d’alentour, et vous avez pu habiter le pays en sécurité.
###### 12
Mais quand vous avez vu Nahash, roi des fils d’Ammone, venir vous attaquer, vous m’avez dit : “Non, c’est un roi qui doit régner sur nous” – alors que votre roi, c’est le Seigneur votre Dieu.
###### 13
Et maintenant, voici le roi que vous avez choisi, celui que vous avez demandé, et voici que le Seigneur vous l’a donné.
###### 14
Puissiez-vous craindre le Seigneur, le servir, écouter sa voix, sans vous révolter contre les ordres du Seigneur et, vous-mêmes avec le roi qui règne sur vous, puissiez-vous suivre le Seigneur votre Dieu !
###### 15
Mais si vous n’écoutez pas la voix du Seigneur, si vous vous révoltez contre les ordres du Seigneur, la main du Seigneur sera contre vous, comme elle fut contre vos pères.
###### 16
Maintenant donc, tenez-vous prêts et voyez cette grande chose que le Seigneur va accomplir sous vos yeux.
###### 17
N’est-ce pas aujourd’hui la moisson des blés ? Je vais invoquer le Seigneur, et il fera tonner et pleuvoir. Comprenez donc et voyez à quel point vous avez mal agi aux yeux du Seigneur en demandant pour vous-mêmes un roi. »
###### 18
Samuel invoqua le Seigneur, et le Seigneur fit tonner et pleuvoir ce jour-là. Tout le peuple éprouva une grande crainte à l’égard du Seigneur et de Samuel.
###### 19
Tout le peuple dit à Samuel : « Prie le Seigneur ton Dieu en faveur de tes serviteurs, afin que nous ne mourions pas. Oui, nous avons ajouté à tous nos péchés ce mal de demander pour nous un roi. »
###### 20
Samuel répondit au peuple : « Ne craignez pas ! Certes, vous avez fait tout ce mal. Mais cessez de vous écarter du Seigneur ; servez-le de tout votre cœur.
###### 21
Ne vous écartez pas du Seigneur : ce serait suivre les idoles de néant qui ne servent à rien et ne délivrent pas, car elles ne sont que néant.
###### 22
Le Seigneur, lui, ne rejettera pas son peuple, à cause de son grand nom ; en effet, il a voulu faire de vous son peuple.
###### 23
Et moi-même, quelle horreur pour moi si je péchais contre le Seigneur, si je cessais de prier en votre faveur ! Je vous enseignerai le chemin du bien et de la droiture.
###### 24
Seulement, vous, craignez le Seigneur et servez-le en vérité, de tout votre cœur : voyez ce qu’il a fait de grand parmi vous.
###### 25
Mais si vous persistez à faire le mal, vous et votre roi, vous périrez. »
