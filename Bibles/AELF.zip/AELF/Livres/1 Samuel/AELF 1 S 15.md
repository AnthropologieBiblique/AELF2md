---
aliases : 
- 1 Samuel 15
- 1 Samuel 15
- 1 S 15
tags : 
- Bible/1S/15
- français
cssclass : français
---

# 1 Samuel 15

###### 01
Samuel dit à Saül : « C’est moi que le Seigneur a envoyé pour te donner l’onction comme roi sur son peuple, sur Israël. Et maintenant, écoute la voix, écoute les paroles du Seigneur.
###### 02
Ainsi parle le Seigneur des armées : Je vais demander compte à Amalec de ce qu’il a fait à Israël en lui barrant la route, lorsqu’il montait d’Égypte.
###### 03
Maintenant donc, va ! Tu frapperas Amalec ; et vous devrez vouer à l’anathème tout ce qui lui appartient. Tu ne l’épargneras pas. Tu mettras tout à mort : l’homme comme la femme, l’enfant comme le nourrisson, le bœuf comme le mouton, le chameau comme l’âne. »
###### 04
Saül convoqua le peuple et le passa en revue à Telaïm. Il y avait deux cent mille fantassins et, en plus, dix mille hommes de Juda.
###### 05
Parvenu à la ville d’Amalec, Saül se mit en embuscade dans le lit du torrent.
###### 06
Il dit aux Qénites : « Allez, écartez-vous, sortez du milieu des Amalécites, de peur que je ne vous traite comme eux, alors que vous, vous avez agi avec fidélité envers tous les fils d’Israël quand ils montaient d’Égypte. » Et les Qénites s’écartèrent du milieu d’Amalec.
###### 07
Saül frappa Amalec depuis Havila jusqu’à l’entrée de Shour qui est en face de l’Égypte.
###### 08
Il captura vivant Agag, le roi d’Amalec, et voua à l’anathème tout le peuple qu’il passa au fil de l’épée.
###### 09
Mais Saül et le peuple épargnèrent Agag, ainsi que le meilleur du petit et du gros bétail, les bêtes grasses, les agneaux et tout ce qu’il y avait de bon : ils ne voulurent pas les vouer à l’anathème. Par contre, tout ce qui était sans valeur et de mauvaise qualité, c’est cela qu’ils vouèrent à l’anathème.
###### 10
La parole du Seigneur fut adressée à Samuel :
###### 11
« Je me repens d’avoir fait régner Saül comme roi car il s’est détourné de moi et n’a pas accompli mes paroles. » Alors Samuel fut bouleversé et cria vers le Seigneur toute la nuit.
###### 12
Samuel se leva de bon matin pour rencontrer Saül. On vint lui annoncer : « Saül est allé au village de Carmel, il s’est dressé une stèle, il a fait demi-tour et, poussant plus loin, il est descendu à Guilgal. »
###### 13
Samuel arriva auprès de Saül, et Saül lui dit : « Sois béni du Seigneur ! J’ai accompli la parole du Seigneur. »
###### 14
Mais Samuel dit : « Quels sont ces bêlements qui frappent mes oreilles, et ces beuglements que j’entends ? »
###### 15
Saül répondit : « On a ramené ces animaux de chez les Amalécites : c’est que le peuple a épargné le meilleur du petit et du gros bétail en vue de le sacrifier au Seigneur ton Dieu, et ce qui restait, nous l’avons voué à l’anathème. »
###### 16
Samuel dit à Saül : « Assez ! Je vais t’apprendre ce que le Seigneur m’a dit pendant la nuit. » Saül lui dit : « Parle. »
###### 17
Alors Samuel déclara : « Toi qui reconnaissais ta petitesse, n’es-tu pas devenu le chef des tribus d’Israël, puisque le Seigneur t’a donné l’onction comme roi sur Israël ?
###### 18
Il t’a envoyé en campagne et t’a donné cet ordre : “Va, et voue à l’anathème ces impies d’Amalécites, fais-leur la guerre jusqu’à l’extermination.”
###### 19
Pourquoi n’as-tu pas obéi à la voix du Seigneur ? Pourquoi t’es-tu jeté sur le butin. Pourquoi as-tu fait ce qui est mal aux yeux du Seigneur ? »
###### 20
Saül répondit à Samuel : « Mais j’ai obéi à la voix du Seigneur ! Je suis allé là où il m’envoyait, j’ai ramené Agag, roi d’Amalec, et j’ai voué Amalec à l’anathème.
###### 21
Dans le butin, le peuple a choisi le meilleur de ce qui était voué à l’anathème, petit et gros bétail, pour l’offrir en sacrifice au Seigneur ton Dieu, à Guilgal. »
###### 22
Samuel répliqua :
« Le Seigneur aime-t-il les holocaustes et les sacrifices
autant que l’obéissance à sa parole ?
Oui, l’obéissance vaut mieux que le sacrifice,
la docilité vaut mieux que la graisse des béliers.
###### 23
La révolte est un péché comme la divination ;
la rébellion est une faute comme la consultation des idoles.
Parce que tu as rejeté la parole du Seigneur,
lui aussi t’a rejeté : tu ne seras plus roi ! »
###### 24
Saül dit à Samuel : « J’ai péché en transgressant l’ordre du Seigneur et tes paroles : c’est que j’ai eu peur du peuple et je lui ai obéi.
###### 25
Maintenant, je t’en prie, enlève mon péché, reviens avec moi, que je me prosterne devant le Seigneur. »
###### 26
Mais Samuel répondit à Saül : « Je ne reviendrai pas avec toi. Puisque tu as rejeté la parole du Seigneur, le Seigneur t’a rejeté pour que tu ne sois plus roi sur Israël. »
###### 27
Comme Samuel se détournait pour partir, Saül saisit le pan de son manteau, qui fut arraché.
###### 28
Alors Samuel lui dit : « Aujourd’hui, le Seigneur t’a arraché la royauté sur Israël et il l’a donnée à ton prochain qui vaut mieux que toi. »
###### 29
Pourtant, celui qui est la Splendeur d’Israël ne se dément pas ni ne se repent : n’étant pas un homme, il n’a pas à se repentir.
###### 30
Saül dit : « J’ai péché, mais daigne pourtant m’honorer devant les anciens de mon peuple et devant Israël. Reviens avec moi, pour que je me prosterne devant le Seigneur ton Dieu. »
###### 31
Samuel revint à la suite de Saül qui se prosterna devant le Seigneur.
###### 32
Samuel dit : « Amenez-moi Agag, roi d’Amalec. » Agag vint à lui, tout heureux ; il se disait : « Vraiment, l’amertume de la mort s’est écartée. »
###### 33
Mais Samuel lui dit : « De même que, par ton épée, des femmes ont été privées de leurs enfants, de même, parmi les femmes, ta mère sera privée de son enfant ! » Et Samuel exécuta Agag devant le Seigneur, à Guilgal.
###### 34
Samuel s’en alla à Rama, et Saül remonta chez lui à Guibéa de Saül.
###### 35
Samuel ne revit plus Saül jusqu’au jour de sa mort. En effet, Samuel avait pris le deuil à cause de Saül, et le Seigneur s’était repenti d’avoir fait régner Saül sur Israël.
