---
aliases : 
- 1 Samuel 2
- 1 Samuel 2
- 1 S 2
tags : 
- Bible/1S/2
- français
cssclass : français
---

# 1 Samuel 2

###### 01
Et Anne fit cette prière :
Mon cœur exulte à cause du Seigneur ;
mon front s’est relevé grâce à mon Dieu !
Face à mes ennemis, s’ouvre ma bouche :
oui, je me réjouis de ton salut !
###### 02
Il n’est pas de Saint pareil au Seigneur.
– Pas d’autre Dieu que toi !
Pas de Rocher pareil à notre Dieu !
###### 03
Assez de paroles hautaines,
pas d’insolence à la bouche.
Le Seigneur est le Dieu qui sait,
qui pèse nos actes.
###### 04
L’arc des forts est brisé,
mais le faible se revêt de vigueur.
###### 05
Les plus comblés s’embauchent pour du pain,
et les affamés se reposent.
Quand la stérile enfante sept fois,
la femme aux fils nombreux dépérit.
###### 06
Le Seigneur fait mourir et vivre ;
il fait descendre à l’abîme et en ramène.
###### 07
le Seigneur rend pauvre et riche ;
il abaisse et il élève.
###### 08
De la poussière, il relève le faible,
il retire le malheureux de la cendre
pour qu’il siège parmi les princes,
et reçoive un trône de gloire.
Au Seigneur, les colonnes de la terre :
sur elles, il a posé le monde.
###### 09
Il veille sur les pas de ses fidèles,
et les méchants périront dans les ténèbres.
La force ne rend pas l’homme vainqueur :
###### 10
les adversaires du Seigneur seront brisés.
Le Très-Haut tonnera dans les cieux ;
le Seigneur jugera la terre entière.
Il donnera la puissance à son roi,
il relèvera le front de son messie.
###### 11
Elcana repartit chez lui à Rama, tandis que l’enfant demeurait au service du Seigneur, en présence du prêtre Éli.
###### 12
Or les fils d’Éli étaient des vauriens qui ne connaissaient pas le Seigneur.
###### 13
À l’égard du peuple, la manière d’agir de ces prêtres-là était la suivante : chaque fois que l’on offrait un sacrifice, le servant du prêtre arrivait au moment où l’on faisait cuire la viande, ayant en main la fourchette à trois dents.
###### 14
Il piquait dans la cuve, le pot, le chaudron ou la marmite, et tout ce que ramenait la fourchette, le prêtre le prenait pour lui. C’est ainsi qu’ils procédaient envers tous ceux d’Israël qui venaient là-bas, à Silo.
###### 15
De surcroît, avant même que l’on fasse fumer la graisse, le servant du prêtre venait dire à l’homme qui offrait le sacrifice : « Donne pour le prêtre de la viande à rôtir ! Il n’acceptera pas de toi de la viande cuite mais seulement de la viande crue. »
###### 16
Si l’homme lui disait : « Qu’on fasse d’abord fumer la graisse, et ensuite prends ce que tu désires », alors il répondait : « Non ! tu dois me le donner maintenant, sinon je le prendrai de force. »
###### 17
Le péché des jeunes gens était très grand devant le Seigneur car ces hommes traitaient avec mépris l’offrande destinée au Seigneur.
###### 18
Samuel assurait le service en présence du Seigneur ; l’enfant portait un pagne de lin.
###### 19
Sa mère lui faisait chaque année un petit manteau qu’elle lui apportait quand elle montait avec son mari pour offrir le sacrifice annuel.
###### 20
Éli bénissait Elcana et sa femme en disant : « Que le Seigneur t’accorde par cette femme une descendance, en échange de l’enfant qu’elle a mis à la disposition du Seigneur ! » Puis ils s’en retournaient chez Elcana.
###### 21
Et le Seigneur intervint en faveur d’Anne : elle devint enceinte et elle enfanta trois fils et deux filles. Quant au jeune Samuel, il grandissait auprès du Seigneur.
###### 22
Éli était devenu très vieux. Il entendait raconter tout ce que faisaient ses fils à l’égard de tout Israël et aussi qu’ils couchaient avec les femmes qui étaient en fonction à l’entrée de la tente de la Rencontre.
###### 23
Il leur dit : « Pourquoi faites-vous de pareilles choses, ces mauvaises choses que j’entends dire par tout le peuple ?
###### 24
Non, mes fils, elle n’est pas belle, la rumeur que j’entends colporter par le peuple du Seigneur.
###### 25
Si un homme pèche contre un autre homme, Dieu sera l’arbitre. Mais si c’est contre le Seigneur qu’un homme pèche, qui interviendra pour lui ? » Ils n’écoutèrent pas la voix de leur père – en effet, le Seigneur voulait les faire mourir.
###### 26
Quant au jeune Samuel, il continuait de grandir en taille, aussi agréable au Seigneur qu’aux hommes.
###### 27
Un homme de Dieu vint trouver Éli. Il lui dit : « Ainsi parle le Seigneur : Ne me suis-je donc pas révélé à la maison de ton père lorsqu’en Égypte elle appartenait à la maison de Pharaon ?
###### 28
J’ai choisi ton père parmi toutes les tribus d’Israël pour qu’il soit mon prêtre, pour qu’il monte à mon autel, fasse brûler l’encens et porte l’éphod en ma présence. J’ai donné à la maison de ton père toutes les nourritures offertes par les fils d’Israël.
###### 29
Pourquoi piétinez-vous mon sacrifice et mon offrande que j’ai prescrits dans la Demeure ? Pourquoi honores-tu tes fils plus que moi, au point de vous engraisser avec le meilleur de toutes les offrandes d’Israël, mon peuple ?
###### 30
C’est pourquoi – oracle du Seigneur, le Dieu d’Israël – certes, j’avais bien dit : “Ta maison et la maison de ton père marcheront en ma présence pour toujours”, mais maintenant – oracle du Seigneur –, quelle horreur ! Oui, j’honore seulement ceux qui m’honorent, mais ceux qui me dédaignent tombent dans le mépris.
###### 31
Voici venir des jours où je briserai ton bras et le bras de la maison de ton père, si bien qu’il n’y aura plus de vieillard dans ta maison.
###### 32
Tu contempleras un rival dans la Demeure et tout le bien qu’il fera à Israël ; mais dans ta maison, il n’y aura plus jamais de vieillard.
###### 33
Cependant, je laisserai l’un des tiens auprès de mon autel, pour que tes yeux se consument, et que ton âme languisse, alors que tous ceux qui auront proliféré dans ta maison mourront dans la force de l’âge.
###### 34
Le signe en sera pour toi ce qui va arriver à tes deux fils Hofni et Pinhas : ils mourront tous deux le même jour.
###### 35
Puis, je susciterai pour moi un prêtre fidèle qui agira selon mon cœur et mon désir. Je bâtirai pour lui une maison stable, et il marchera en présence de mon messie pour toujours.
###### 36
Alors, tout ce qui subsistera de ta maison viendra se prosterner devant lui pour une piécette d’argent et une couronne de pain. Il dira : “Attache-moi, je t’en prie, à une fonction sacerdotale, pour que j’aie un morceau de pain à manger !” »
