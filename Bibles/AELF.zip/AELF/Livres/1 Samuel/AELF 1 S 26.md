---
aliases : 
- 1 Samuel 26
- 1 Samuel 26
- 1 S 26
tags : 
- Bible/1S/26
- français
cssclass : français
---

# 1 Samuel 26

###### 01
Les gens de Zif vinrent trouver Saül à Guibéa pour lui dire : « Est-ce que David ne se cache pas sur la colline de Hakila, en face de la steppe ? »
###### 02
Saül se mit en route, il descendit vers le désert de Zif avec trois mille hommes, l’élite d’Israël, pour y traquer David.
###### 03
Saül campa sur la colline de Hakila qui est en face de la steppe, au bord de la route. David, qui se tenait dans le désert, s’aperçut que Saül le poursuivait jusqu’au désert.
###### 04
Il envoya des espions et fut certain de l’arrivée de Saül.
###### 05
David se mit en route et parvint à l’endroit où campait Saül. Il vit l’endroit où étaient couchés Saül et Abner, fils de Ner, le chef de son armée. Saül était couché au milieu du camp, et la troupe campait autour de lui.
###### 06
David prit la parole et dit à Ahimélek le Hittite ainsi qu’à Abishaï, fils de Cerouya, le frère de Joab : « Qui veut descendre avec moi au camp, jusqu’à Saül ? » Abishaï répondit : « Moi, je descendrai avec toi. »
###### 07
David et Abishaï arrivèrent de nuit, près de la troupe. Or, Saül était couché, endormi, au milieu du camp, sa lance plantée en terre près de sa tête ; Abner et ses hommes étaient couchés autour de lui.
###### 08
Alors Abishaï dit à David : « Aujourd’hui Dieu a livré ton ennemi entre tes mains. Laisse-moi donc le clouer à terre avec sa propre lance, d’un seul coup, et je n’aurai pas à m’y reprendre à deux fois. »
###### 09
Mais David dit à Abishaï : « Ne le tue pas ! Qui pourrait demeurer impuni après avoir porté la main sur celui qui a reçu l’onction du Seigneur ? »
###### 10
Puis David ajouta : « Par la vie du Seigneur ! C’est le Seigneur seul qui le frappera, soit que son jour arrive et qu’il meure, soit qu’il descende au combat et qu’il y périsse.
###### 11
Que le Seigneur me préserve de porter la main sur lui, le messie du Seigneur ! Et maintenant, prends donc la lance qui est près de sa tête avec la gourde d’eau, et allons-nous en. »
###### 12
David prit la lance et la gourde d’eau qui étaient près de la tête de Saül, et ils s’en allèrent. Personne ne vit rien, personne ne le sut, personne ne s’éveilla : ils dormaient tous, car le Seigneur avait fait tomber sur eux un sommeil mystérieux.
###### 13
David passa sur l’autre versant de la montagne et s’arrêta sur le sommet, au loin, à bonne distance.
###### 14
Alors David cria en direction de la troupe et d’Abner, fils de Ner : « Ne vas-tu pas répondre, Abner ? » Celui-ci répondit : « Qui es-tu, toi qui appelles le roi ? »
###### 15
David dit à Abner : « N’es-tu pas un homme, toi qui es sans égal en Israël ? Alors pourquoi n’as-tu pas veillé sur le roi, ton maître ? Quelqu’un du peuple est venu pour tuer le roi, ton maître.
###### 16
Ce n’est pas bien, ce que tu as fait là. Par la vie du Seigneur, vous méritez la mort pour n’avoir pas veillé sur votre maître, le messie du Seigneur. Maintenant, regarde où sont la lance du roi et la gourde d’eau qui étaient près de sa tête. »
###### 17
Saül reconnut la voix de David et dit : « Est-ce bien ta voix, mon fils David ? » David répondit : « C’est ma voix, mon seigneur le roi. »
###### 18
Et il continua : « Pourquoi mon seigneur poursuit-il son serviteur ? Qu’ai-je donc fait et quel mal ai-je commis ?
###### 19
Que mon seigneur le roi daigne écouter maintenant les paroles de son serviteur. Si c’est le Seigneur qui t’a excité contre moi, qu’il soit apaisé par l’agréable odeur d’une offrande ! Mais si ce sont des êtres humains, maudits soient-ils devant le Seigneur ! Aujourd’hui ils m’ont expulsé, dépossédé de l’héritage du Seigneur, en disant : “Va servir d’autres dieux !”
###### 20
Et maintenant, que mon sang ne soit pas répandu sur la terre, loin de la face du Seigneur. En effet, le roi d’Israël s’est mis en campagne pour chercher une simple puce, comme on chasse la perdrix dans les montagnes. »
###### 21
Saül dit : « J’ai péché. Reviens, mon fils David ! Je ne te ferai plus de mal, puisque ma vie a été aujourd’hui si précieuse à tes yeux. Oui, j’ai agi comme un fou et je me suis lourdement trompé. »
###### 22
David répondit : « Voici la lance du roi. Qu’un jeune garçon traverse et vienne la prendre !
###### 23
Le Seigneur rendra à chacun selon sa justice et sa fidélité. Aujourd’hui, le Seigneur t’avait livré entre mes mains, mais je n’ai pas voulu porter la main sur le messie du Seigneur.
###### 24
Et de même que ta vie aujourd’hui a eu beaucoup de valeur à mes yeux, de même ma vie en aura beaucoup aux yeux du Seigneur, qui me délivrera de toute angoisse. »
###### 25
Saül dit à David : « Béni sois-tu, mon fils David ! Oui, quoi que tu entreprennes, tu réussiras. » Puis David reprit son chemin, et Saül retourna chez lui.
