---
aliases : 
- 1 Samuel 13
- 1 Samuel 13
- 1 S 13
tags : 
- Bible/1S/13
- français
cssclass : français
---

# 1 Samuel 13

###### 01
On ignore l’âge de Saül lorsqu’il devint roi, et il régna deux ans sur Israël.
###### 02
Saül choisit trois mille hommes en Israël : il y en eut deux mille avec Saül à Mikmas et dans la montagne de Béthel, et mille avec Jonathan, son fils, à Guibéa de Benjamin. Quant au reste du peuple, il le renvoya, chacun à ses tentes.
###### 03
Jonathan détruisit le poste de garde des Philistins, qui était à Guéba, et les Philistins l’apprirent. Alors Saül fit sonner du cor dans tout le pays pour dire : « Que les Hébreux l’apprennent ! »
###### 04
Tout Israël l’apprit et disait : « Saül a détruit le poste de garde des Philistins ; et même, Israël est devenu odieux aux Philistins ! » Alors le peuple se regroupa derrière Saül, à Guilgal.
###### 05
Les Philistins se rassemblèrent en vue de combattre Israël : trente mille chars, six mille cavaliers et une troupe aussi nombreuse que les grains de sable au bord de la mer. Ils montèrent établir leur camp à Mikmas, à l’est de Beth-Awen.
###### 06
Les hommes d’Israël virent le danger, tant le peuple était menacé de près. Ils se cachèrent dans les grottes, les trous, les rochers, les souterrains et les citernes.
###### 07
Des Hébreux passèrent aussi le Jourdain pour gagner le pays de Gad et de Galaad.
Saül était encore à Guilgal, et tout le peuple qui était derrière lui tremblait de peur.
###### 08
Il attendit sept jours le rendez-vous de Samuel, mais Samuel ne vint pas à Guilgal. Le peuple, quittant Saül, commençait à se disperser.
###### 09
Alors Saül dit : « Amenez-moi les animaux pour l’holocauste et les sacrifices de paix ! » Et il offrit l’holocauste.
###### 10
Or, comme il achevait d’offrir l’holocauste, voici que Samuel arriva. Saül sortit à sa rencontre pour le saluer.
###### 11
Samuel lui dit : « Qu’as-tu fait ? » Saül répondit : « Quand j’ai vu que le peuple se dispersait en me quittant, que toi-même tu ne venais pas au rendez-vous et que les Philistins étaient rassemblés à Mikmas,
###### 12
je me suis dit : Maintenant, les Philistins vont descendre pour m’attaquer à Guilgal, sans que j’aie apaisé le Seigneur ! Alors, me faisant violence, j’ai offert l’holocauste. »
###### 13
Samuel dit à Saül : « Tu as agi comme un insensé ! Tu n’as pas observé le commandement du Seigneur ton Dieu, ce qu’il t’avait ordonné. Autrement, le Seigneur aurait établi ta royauté sur Israël pour toujours.
###### 14
Mais maintenant ta royauté ne tiendra pas. Le Seigneur a cherché un homme selon son cœur et l’a institué chef de son peuple, puisque tu n’as pas observé ce que t’avait ordonné le Seigneur. »
###### 15
Puis Samuel se leva pour monter de Guilgal à Guibéa de Benjamin, et le reste du peuple monta derrière Saül à la rencontre de la troupe en armes.
Quand ils furent arrivés de Guilgal à Guibéa de Benjamin, Saül passa en revue les gens qui se trouvaient avec lui : environ six cents hommes.
###### 16
Saül, son fils Jonathan et les gens qui se trouvaient avec eux étaient restés à Guéba de Benjamin, tandis que les Philistins avaient dressé leur camp à Mikmas.
###### 17
Les troupes de choc sortirent du camp des Philistins en trois groupes. Le premier prit la direction d’Ofra, au pays de Shoual,
###### 18
le deuxième, la direction de Beth-Horone, le troisième, la direction de la frontière qui surplombe le Val des Hyènes, du côté du désert.
###### 19
On ne trouvait pas de forgeron dans tout le pays d’Israël, car les Philistins s’étaient dit : « Il ne faut pas que les Hébreux fabriquent des épées ou des lances. »
###### 20
Tout le monde en Israël descendait donc chez les Philistins pour affûter chacun son soc, sa houe, sa hache ou son pic.
###### 21
Le prix imposé était : deux tiers de sicle pour les socs, les houes, les haches et la remise en état des aiguillons.
###### 22
Il arriva donc qu’au jour du combat, personne, dans la troupe qui était avec Saül et Jonathan, n’avait en main ni épée ni lance. On en trouva cependant pour Saül et pour son fils Jonathan.
###### 23
Un poste de Philistins vint s’établir au passage de Mikmas.
