---
aliases : 
- 1 Samuel 24
- 1 Samuel 24
- 1 S 24
tags : 
- Bible/1S/24
- français
cssclass : français
---

# 1 Samuel 24

###### 01
De là, David monta aux refuges d’Enn-Guèdi où il s’établit.
###### 02
Or, quand Saül revint de la poursuite des Philistins, on l’en informa : « Voici que David est au désert d’Enn-Guèdi. »
###### 03
Saül prit trois mille hommes, choisis dans tout Israël, et partit à la recherche de David et de ses gens en face du Rocher des Bouquetins.
###### 04
Il arriva aux parcs à moutons qui sont en bordure de la route ; il y a là une grotte, où Saül entra pour se soulager. Or, David et ses hommes se trouvaient au fond de la grotte.
###### 05
Les hommes de David lui dirent : « Voici le jour dont le Seigneur t’a dit : “Je livrerai ton ennemi entre tes mains, tu en feras ce que tu voudras.” » David vint couper furtivement le pan du manteau de Saül.
###### 06
Alors le cœur lui battit d’avoir coupé le pan du manteau de Saül.
###### 07
Il dit à ses hommes : « Que le Seigneur me préserve de faire une chose pareille à mon maître, qui a reçu l’onction du Seigneur : porter la main sur lui, qui est le messie du Seigneur. »
###### 08
Par ses paroles, David retint ses hommes. Il leur interdit de se jeter sur Saül. Alors Saül quitta la grotte et continua sa route.
###### 09
David se leva, sortit de la grotte, et lui cria : « Mon seigneur le roi ! » Saül regarda derrière lui. David s’inclina jusqu’à terre et se prosterna,
###### 10
puis il lui cria : « Pourquoi écoutes-tu les gens qui te disent : “David te veut du mal” ?
###### 11
Aujourd’hui même, tes yeux ont vu comment le Seigneur t’avait livré entre mes mains dans la grotte ; pourtant, j’ai refusé de te tuer, je t’ai épargné et j’ai dit : “Je ne porterai pas la main sur mon seigneur le roi qui a reçu l’onction du Seigneur.”
###### 12
Regarde, père, regarde donc : voici dans ma main le pan de ton manteau. Puisque j’ai pu le couper, et que pourtant je ne t’ai pas tué, reconnais qu’il n’y a en moi ni méchanceté ni révolte. Je n’ai pas commis de faute contre toi, alors que toi, tu traques ma vie pour me l’enlever.
###### 13
C’est le Seigneur qui sera juge entre toi et moi, c’est le Seigneur qui me vengera de toi, mais ma main ne te touchera pas !
###### 14
Comme dit le vieux proverbe : “Des méchants sort la méchanceté.” C’est pourquoi ma main ne te touchera pas.
###### 15
Après qui donc le roi d’Israël s’est-il mis en campagne ? Après qui cours-tu donc ? Après un chien crevé, après une puce ?
###### 16
Que le Seigneur soit notre arbitre, qu’il juge entre toi et moi, qu’il examine et défende ma cause, et qu’il me rende justice, en me délivrant de ta main ! »
###### 17
Lorsque David eut fini de parler, Saül s’écria : « Est-ce bien ta voix que j’entends, mon fils David ? » Et Saül se mit à crier et à pleurer.
###### 18
Puis il dit à David : « Toi, tu es juste, et plus que moi : car toi, tu m’as fait du bien, et moi, je t’ai fait du mal.
###### 19
Aujourd’hui tu as montré toute ta bonté envers moi : le Seigneur m’avait livré entre tes mains, et tu ne m’as pas tué !
###### 20
Quand un homme surprend son ennemi, va-t-il le laisser partir tranquillement ? Que le Seigneur te récompense pour le bien que tu m’as fait aujourd’hui.
###### 21
Je sais maintenant que tu régneras certainement, et que la royauté d’Israël tiendra bon en ta main.
###### 22
Alors, jure-moi par le Seigneur que tu ne supprimeras pas ma descendance après moi, que tu ne feras pas disparaître mon nom de la maison de mon père. »
###### 23
David le jura à Saül. Puis Saül rentra chez lui, tandis que David et ses hommes remontaient à leur refuge.
