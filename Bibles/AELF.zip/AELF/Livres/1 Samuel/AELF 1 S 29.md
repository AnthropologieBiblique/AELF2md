---
aliases : 
- 1 Samuel 29
- 1 Samuel 29
- 1 S 29
tags : 
- Bible/1S/29
- français
cssclass : français
---

# 1 Samuel 29

###### 01
Les Philistins rassemblèrent toutes leurs armées à Apheq, tandis qu’Israël campait à la source qui est dans la plaine de Yizréel.
###### 02
Les princes des Philistins défilaient avec leurs troupes de centaines et de milliers ; David et ses hommes, avec Akish, défilaient en dernier.
###### 03
Les princes des Philistins demandèrent : « Ces Hébreux, qui sont-ils ? » Akish leur dit alors : « C’est David, le serviteur de Saül, roi d’Israël : il est avec moi depuis un an ou deux, et je n’ai pas trouvé la moindre chose à lui reprocher, du jour de son ralliement jusqu’à maintenant ! »
###### 04
Mais les princes des Philistins s’emportèrent contre lui. Ils lui dirent : « Renvoie cet homme ! Et qu’il retourne dans le lieu que tu lui as assigné ! Mais qu’il ne descende pas avec nous au combat : il se changerait en adversaire. Avec quoi celui-là pourrait-il regagner la faveur de son maître, sinon avec les têtes des hommes que voici ?
###### 05
N’est-il pas ce David pour qui l’on dansait en se renvoyant ce refrain :
“Saül a tué ses milliers,
et David, ses dizaines de milliers” ? »
###### 06
Akish appela David et lui dit : « Par la vie du Seigneur, tu es un homme droit. Je prends plaisir à partir en campagne et à revenir avec toi, car depuis le jour où tu es venu chez moi jusqu’à maintenant, je n’ai rien trouvé de mauvais en toi. Mais tu déplais aux princes.
###### 07
Retourne donc et va en paix : ainsi tu ne feras rien qui soit mauvais aux yeux des princes des Philistins. »
###### 08
David dit à Akish : « Mais qu’ai-je donc fait ? Qu’as-tu trouvé en ton serviteur depuis le jour où je me suis présenté à toi jusqu’à maintenant ? Pourquoi ne puis-je aller combattre les ennemis de mon seigneur le roi ? »
###### 09
Akish répondit à David : « À mes yeux, tu es bon comme un ange de Dieu, je le sais. Seulement, les princes des Philistins ont dit : “Il ne montera pas avec nous au combat !”
###### 10
Alors, lève-toi de bon matin, toi et les serviteurs de ton maître qui sont venus avec toi. Oui, levez-vous de bon matin et, dès qu’il fera jour, partez ! »
###### 11
David se leva tôt, lui et ses hommes, pour partir de bon matin et retourner au pays des Philistins. Quant aux Philistins, ils se dirigèrent vers la plaine de Yizréel.
