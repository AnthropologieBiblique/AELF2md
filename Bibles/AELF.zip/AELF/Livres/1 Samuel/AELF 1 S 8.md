---
aliases : 
- 1 Samuel 8
- 1 Samuel 8
- 1 S 8
tags : 
- Bible/1S/8
- français
cssclass : français
---

# 1 Samuel 8

###### 01
Quand Samuel fut devenu vieux, il établit ses fils juges en Israël.
###### 02
Son fils aîné s’appelait Joël, et le second, Abiya ; ils jugeaient à Bershéba.
###### 03
Mais ses fils ne marchèrent pas sur ses traces. Attirés par le gain, ils acceptèrent des cadeaux et firent dévier le droit.
###### 04
Tous les anciens d’Israël se réunirent et vinrent trouver Samuel à Rama.
###### 05
Ils lui dirent : « Tu es devenu vieux, et tes fils ne marchent pas sur tes traces. Maintenant donc, établis, pour nous gouverner, un roi comme en ont toutes les nations. »
###### 06
Samuel fut mécontent parce qu’ils avaient dit : « Donne-nous un roi pour nous gouverner », et il se mit à prier le Seigneur.
###### 07
Or, le Seigneur lui répondit : « Écoute la voix du peuple en tout ce qu’ils te diront. Ce n’est pas toi qu’ils rejettent, c’est moi qu’ils rejettent : ils ne veulent pas que je règne sur eux.
###### 08
Tout comme ils ont agi depuis le jour où je les ai fait monter d’Égypte jusqu’à aujourd’hui, m’abandonnant pour servir d’autres dieux, de même agissent-ils envers toi.
###### 09
Maintenant donc, écoute leur voix, mais avertis-les solennellement et fais-leur connaître les droits du roi qui régnera sur eux. »
###### 10
Samuel rapporta toutes les paroles du Seigneur au peuple qui lui demandait un roi.
###### 11
Et il dit : « Tels seront les droits du roi qui va régner sur vous. Vos fils, il les prendra, il les affectera à ses chars et à ses chevaux, et ils courront devant son char.
###### 12
Il les utilisera comme officiers de millier et comme officiers de cinquante hommes ; il les fera labourer et moissonner à son profit, fabriquer ses armes de guerre et les pièces de ses chars.
###### 13
Vos filles, il les prendra pour la préparation de ses parfums, pour sa cuisine et pour sa boulangerie.
###### 14
Les meilleurs de vos champs, de vos vignes et de vos oliveraies, il les prendra pour les donner à ses serviteurs.
###### 15
Sur vos cultures et vos vignes il prélèvera la dîme, pour la donner à ses dignitaires et à ses serviteurs.
###### 16
Les meilleurs de vos serviteurs, de vos servantes et de vos jeunes gens, ainsi que vos ânes, il les prendra et les fera travailler pour lui.
###### 17
Sur vos troupeaux, il prélèvera la dîme, et vous-mêmes deviendrez ses esclaves.
###### 18
Ce jour-là, vous pousserez des cris à cause du roi que vous aurez choisi, mais, ce jour-là, le Seigneur ne vous répondra pas ! »
###### 19
Le peuple refusa d’écouter Samuel et dit : « Non ! il nous faut un roi !
###### 20
Nous serons, nous aussi, comme toutes les nations ; notre roi nous gouvernera, il marchera à notre tête et combattra avec nous. »
###### 21
Samuel écouta toutes les paroles du peuple et les répéta aux oreilles du Seigneur.
###### 22
Et le Seigneur lui dit : « Écoute-les, et qu’un roi règne sur eux ! » Alors Samuel dit aux hommes d’Israël : « Allez ! chacun dans sa ville ! »
