---
aliases : 
- 1 Samuel 18
- 1 Samuel 18
- 1 S 18
tags : 
- Bible/1S/18
- français
cssclass : français
---

# 1 Samuel 18

###### 01
Or dès que David eut fini de parler à Saül, Jonathan s’attacha de toute son âme à David et il l’aima comme lui-même.
###### 02
Ce jour-là, Saül retint David et ne lui permit pas de retourner chez son père.
###### 03
Et Jonathan conclut une alliance avec David, car il l’aimait comme lui-même.
###### 04
Jonathan se dépouilla du manteau qu’il portait et le donna à David, ainsi que ses vêtements, et même son épée, son arc et son ceinturon.
###### 05
Dans ses expéditions, David réussissait partout où l’envoyait Saül, et Saül le mit à la tête des hommes de guerre. Il était bien vu de tout le peuple et même des serviteurs de Saül.
###### 06
Au retour de l’armée, lorsque David revint après avoir tué le Philistin, les femmes sortirent de toutes les villes d’Israël à la rencontre du roi Saül pour chanter et danser au son des tambourins, des cris de joie et des cymbales.
###### 07
Les femmes dansaient en se renvoyant ce refrain :
« Saül a tué ses milliers,
et David, ses dizaines de milliers. »
###### 08
Saül le prit très mal et fut très irrité. Il disait : « À David on attribue les dizaines de milliers, et à moi les milliers ; il ne lui manque plus que la royauté ! »
###### 09
Depuis ce jour-là, Saül regardait David avec méfiance.
###### 10
Le lendemain, un mauvais esprit envoyé par Dieu s’empara de Saül qui fut saisi de transe prophétique au milieu de la maison. David jouait de son instrument comme chaque jour, et Saül avait sa lance à la main.
###### 11
Saül la lança en se disant : « Je vais clouer David au mur ! » Mais par deux fois David échappa à Saül.
###### 12
Saül eut peur de David. En effet, le Seigneur était avec David et s’était écarté de Saül.
###### 13
Quant à Saül, il écarta David de sa présence en le nommant officier de millier. David partait en campagne et revenait à la tête du peuple.
###### 14
Il réussissait dans toutes ses expéditions : le Seigneur était avec lui.
###### 15
En voyant à quel point il réussissait, Saül le redouta.
###### 16
Mais tous, en Israël et Juda, aimaient David, car c’était lui qui partait en campagne et revenait à leur tête.
###### 17
Saül dit à David : « Voici ma fille aînée Mérab. C’est elle que je te donnerai pour femme. Seulement, sois pour moi un bon guerrier, menant les combats du Seigneur. » Saül s’était dit : « Ne portons pas la main sur lui, mais que des Philistins le fassent ! »
###### 18
David dit à Saül : « Qui suis-je, quel est mon lignage, quel est le clan de mon père en Israël, pour que je devienne le gendre du roi ? »
###### 19
Mais au moment de donner à David Mérab, fille de Saül, on la donna pour femme à Adriël de Mehola.
###### 20
Or Mikal, fille de Saül, aimait David. Saül en fut informé, et cela lui parut une bonne chose.
###### 21
Il se disait : « Je la lui donnerai, elle sera pour lui un piège, et la main des Philistins sera contre lui. » Saül déclara donc à David une deuxième fois : « Aujourd’hui, tu deviendras mon gendre. »
###### 22
Saül donna cet ordre à ses serviteurs : « Parlez à David en secret. Dites-lui : Voici que tu plais au roi, et tous ses serviteurs t’aiment. Deviens donc le gendre du roi ! »
###### 23
Les serviteurs de Saül redirent ces paroles à l’oreille de David qui déclara : « Est-ce peu de chose, à vos yeux, de devenir le gendre du roi ? Or, moi, je suis quelqu’un de pauvre et de peu d’importance. »
###### 24
Les serviteurs de Saül lui rapportèrent ces paroles en disant : « Voilà comment David a parlé. »
###### 25
Alors Saül reprit : « Vous direz ceci à David : Pour sa fille, le roi ne veut pas d’autre paiement que cent prépuces de Philistins, afin de tirer vengeance de ses ennemis. » Saül comptait ainsi faire tomber David aux mains des Philistins.
###### 26
Les serviteurs rapportèrent ces paroles à David, et la chose lui parut bonne pour devenir le gendre du roi. Le délai n’était pas encore accompli
###### 27
que David se mettait en route, lui et ses hommes, et qu’il abattait deux cents Philistins. David rapporta leurs prépuces, il les remit tous au roi, afin de pouvoir devenir le gendre du roi. Alors Saül lui donna pour femme sa fille Mikal.
###### 28
Voyant et comprenant que le Seigneur était avec David et que Mikal, sa propre fille, l’aimait,
###### 29
Saül eut encore plus peur de David et il éprouva contre lui une hostilité de tous les jours.
###### 30
Les princes des Philistins repartirent en campagne. Mais, à chacune de leurs campagnes, David remportait plus de succès que tous les serviteurs de Saül. Son nom devint très célèbre.
