---
aliases : 
- 1 Samuel 20
- 1 Samuel 20
- 1 S 20
tags : 
- Bible/1S/20
- français
cssclass : français
---

# 1 Samuel 20

###### 01
David s’enfuit de Nayoth-de-Rama et vint dire devant Jonathan : « Qu’ai-je fait ? Quel est mon péché ? Quelle est ma faute à l’égard de ton père, pour qu’il en veuille à ma vie ? »
###### 02
Jonathan lui répondit : « Quelle horreur ! Non, tu ne mourras pas. Il se trouve que mon père ne fait aucune chose, importante ou non, sans m’en informer. Alors, pourquoi m’aurait-il caché celle-là ? C’est impossible. »
###### 03
Mais David reprit, en faisant un serment : « Ton père sait très bien que j’ai trouvé grâce à tes yeux. Il s’est dit : “Que Jonathan ne sache rien, de peur qu’il ne soit affligé.” Mais, par le Seigneur vivant et par ta propre vie, il n’y a qu’un seul pas entre la mort et moi ! »
###### 04
Jonathan dit à David : « À quoi penses-tu ? Je le ferai pour toi. »
###### 05
David répondit à Jonathan : « Demain, ce sera la nouvelle lune, et moi, je devrais prendre place auprès du roi pour le repas. Mais tu me laisseras partir et, après-demain, je me cacherai dans la campagne jusqu’au soir.
###### 06
Si ton père remarque mon absence, tu diras : “David a insisté auprès de moi pour faire un saut à Bethléem, sa ville, car on y célèbre le sacrifice annuel pour tout le clan.”
###### 07
S’il dit : “C’est bien”, je suis en paix, moi, ton serviteur. Mais s’il s’enflamme de colère, sache qu’il est résolu au pire.
###### 08
Agis avec fidélité envers ton serviteur, puisque tu m’as fait entrer dans une alliance du Seigneur avec toi. Mais si je suis coupable, fais-moi mourir toi-même. Pourquoi m’obliger à venir devant ton père ? »
###### 09
Jonathan répondit : « Quelle horreur pour toi ! Mais si vraiment j’apprenais que mon père est résolu au pire, comment ne pas t’en informer ? »
###### 10
David dit à Jonathan : « Qui m’informera si ton père te répond avec dureté ? »
###### 11
Jonathan lui répondit : « Viens ! Sortons dans la campagne. » Et tous deux sortirent dans la campagne.
###### 12
Alors, Jonathan dit à David : « Par le Seigneur, le Dieu d’Israël ! Demain et après-demain, à cette heure-ci, je sonderai les intentions de mon père. Si tout va bien pour David, et si je n’envoie pas de message pour te le révéler,
###### 13
que le Seigneur amène le malheur sur Jonathan, et pire encore ! Mais s’il fait trouver bon à mon père de te mettre à mal, je te le révélerai et je te laisserai aller en paix. Que le Seigneur soit avec toi comme il fut avec mon père !
###### 14
Tant que je vivrai, puisses-tu agir envers moi avec fidélité, comme le Seigneur, pour que je ne meure pas !
###### 15
Puisses-tu ne jamais retirer ta fidélité de ma maison, même quand le Seigneur retranchera de la surface du sol chacun des ennemis de David. »
###### 16
Ainsi Jonathan conclut-il une alliance avec la maison de David, en disant : « Le Seigneur demandera des comptes à David – ou plutôt à ses ennemis. »
###### 17
Puis Jonathan fit encore prêter serment à David, par l’amitié qu’il lui portait, car il l’aimait comme lui-même.
###### 18
Jonathan lui dit : « Demain, c’est la nouvelle lune ; on remarquera ton absence à cause de ta place inoccupée.
###### 19
Après-demain, tu descendras vite. Tu arriveras à l’endroit où tu étais caché l’autre jour et tu te placeras à côté de la butte.
###### 20
Quant à moi, je tirerai trois flèches de ce côté, comme pour viser une cible.
###### 21
J’enverrai le garçon en disant : “Va, retrouve les flèches !” Puis, si je lui dis : “Les flèches sont en arrière de toi ; ramasse-les”, alors tu pourras revenir, tu seras en paix ; par le Seigneur vivant, tout ira bien.
###### 22
Mais si je dis au jeune homme : “Les flèches sont au-devant de toi”, alors tu t’en iras, car c’est le Seigneur qui te fait partir.
###### 23
La parole que nous venons d’échanger, toi et moi, le Seigneur en est le garant pour toujours, entre toi et moi. »
###### 24
David se cachait donc dans la campagne. Quand arriva la nouvelle lune, le roi prit place à table pour le repas.
###### 25
Le roi s’assit à sa place, comme les autres fois, sur le siège placé contre le mur. Jonathan se mit en face, Abner s’assit à côté de Saül, mais la place de David resta inoccupée.
###### 26
Saül n’en parla pas, ce jour-là, car il se disait : « Quelque chose est arrivé qui l’aura rendu impur. Sans doute, n’est-il pas pur. »
###### 27
Or, le lendemain de la nouvelle lune, le deuxième jour, la place de David restait inoccupée. Saül dit à son fils Jonathan : « Pourquoi le fils de Jessé n’est-il pas venu à table, ni hier, ni aujourd’hui ? »
###### 28
Jonathan répondit à Saül : « David m’a demandé avec insistance de le laisser aller jusqu’à Bethléem.
###### 29
Il m’a dit : “Laisse-moi partir, je t’en prie, car nous avons, dans la ville, un sacrifice pour le clan. Mon frère lui-même m’a ordonné de m’y rendre. Maintenant, si j’ai trouvé grâce à tes yeux, laisse-moi m’échapper pour que j’aille voir mes frères !” Voilà pourquoi il n’est pas venu à la table du roi. »
###### 30
Saül s’enflamma de colère contre Jonathan. Il lui dit : « Fils rebelle et dévoyé ! Je sais bien, moi, que tu as pris parti pour le fils de Jessé, à ta honte et à la honte de la nudité de ta mère.
###### 31
Oui, aussi longtemps que le fils de Jessé sera vivant sur la terre, ni toi, ni ta royauté ne tiendront. Et maintenant, envoie quelqu’un pour le prendre : qu’on me l’amène, car il mérite la mort ! »
###### 32
Jonathan répondit à Saül son père. Il lui dit : « Pourquoi le mettre à mort ? Qu’a-t-il fait ? »
###### 33
Saül jeta sa lance contre lui pour le frapper. Alors Jonathan comprit que son père avait résolu de mettre à mort David.
###### 34
Jonathan se leva de table, enflammé de colère. Il ne mangea rien, ce deuxième jour de la nouvelle lune, car il était affligé au sujet de David et parce que son père l’avait insulté, lui, Jonathan.
###### 35
Au matin, Jonathan sortit dans la campagne pour la rencontre avec David. Un jeune garçon l’accompagnait.
###### 36
Il dit au garçon : « Cours, retrouve-moi les flèches que je vais tirer ! » Le garçon courut. Or Jonathan avait tiré une flèche de manière à le dépasser.
###### 37
Le garçon parvint à l’endroit où se trouvait la flèche qu’avait tirée Jonathan, et celui-ci cria en direction du garçon : « Est-ce que la flèche n’est pas au-devant de toi ? »
###### 38
Puis Jonathan cria au garçon : « Vite, dépêche-toi, ne t’arrête pas ! » Le garçon de Jonathan ramassa la flèche et revint auprès de son maître.
###### 39
Le garçon ne savait rien, mais David et Jonathan, eux, savaient de quoi il s’agissait.
###### 40
Jonathan confia ses armes à son garçon et lui dit : « Va les reporter à la ville. »
###### 41
Le garçon étant parti, David, à côté de la butte, se leva. Il tomba face contre terre et se prosterna trois fois. Ils s’embrassèrent et pleurèrent l’un avec l’autre, jusqu’à ce que David eût dominé ses larmes.
###### 42
Alors Jonathan dit à David : « Va en paix, puisque nous avons tous deux prêté serment au nom du Seigneur en disant : Que le Seigneur soit entre toi et moi, entre ta descendance et la mienne, pour toujours ! »
