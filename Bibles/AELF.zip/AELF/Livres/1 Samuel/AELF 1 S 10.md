---
aliases : 
- 1 Samuel 10
- 1 Samuel 10
- 1 S 10
tags : 
- Bible/1S/10
- français
cssclass : français
---

# 1 Samuel 10

###### 01
Alors, Samuel prit la fiole d’huile et la répandit sur la tête de Saül ; puis il l’embrassa et lui dit : « N’est-ce pas le Seigneur qui te donne l’onction comme chef sur son héritage ?
###### 02
Aujourd’hui, quand tu m’auras quitté, tu trouveras deux hommes près du tombeau de Rachel, sur la frontière de Benjamin, à Cilçah, et ils te diront : “Elles sont retrouvées, les ânesses que tu étais allé chercher. Mais maintenant ton père a oublié l’affaire des ânesses, il se fait du souci pour vous et se dit : Que faire pour mon fils ?”
###### 03
De là, poussant plus loin, tu arriveras au chêne de Tabor, où viendront te trouver trois hommes montant vers Dieu à Béthel, l’un portant trois chevreaux, l’autre portant trois couronnes de pain, le troisième une outre de vin.
###### 04
Ils te salueront et te donneront deux pains que tu recevras de leurs mains.
###### 05
Après cela, tu arriveras à Guibéa de Dieu, où il y a des postes de garde philistins. Et là, en entrant dans la ville, tu tomberas sur un groupe de prophètes qui descendent du lieu sacré, précédés de harpes, tambourins, flûtes et cithares ; ils seront en état de transe prophétique.
###### 06
Alors l’Esprit du Seigneur s’emparera de toi, tu seras saisi de transe prophétique avec eux et tu seras changé en un autre homme.
###### 07
Quand se produiront pour toi de tels signes, agis selon ce qui se présentera, car Dieu est avec toi.
###### 08
Tu descendras avant moi à Guilgal. Et moi, je descendrai te rejoindre pour offrir des holocaustes et faire des sacrifices de paix. Pendant sept jours tu attendras, jusqu’à ce que je vienne te rejoindre. Alors je te ferai savoir comment tu dois agir. »
###### 09
Or, dès que Saül eut tourné le dos en quittant Samuel, Dieu changea son cœur, et tous ces signes se produisirent le jour même.
###### 10
À l’entrée de Guibéa, voici qu’un groupe de prophètes vint à sa rencontre. L’Esprit de Dieu s’empara de lui, et il fut saisi de transe prophétique au milieu d’eux.
###### 11
Alors tous ceux qui le connaissaient de longue date virent qu’il prophétisait avec les prophètes. Et les gens se dirent l’un à l’autre : « Qu’est-il donc arrivé au fils de Kish ? Saül aussi est-il parmi les prophètes ? »
###### 12
Un homme de cet endroit intervint pour dire : « Et qui est leur père ? ». Voilà comment est né le proverbe : « Saül aussi est-il parmi les prophètes ? »
###### 13
Lorsqu’il fut sorti de sa transe prophétique, il se rendit au lieu sacré.
###### 14
L’oncle de Saül lui demanda, ainsi qu’à son serviteur : « Où êtes-vous allés ? » Il répondit : « À la recherche des ânesses. Mais nous n’avons rien vu et nous nous sommes rendus chez Samuel. »
###### 15
L’oncle de Saül dit : « Raconte-moi donc ce que Samuel vous a dit. »
###### 16
Saül répondit à son oncle : « Il nous a simplement annoncé que les ânesses étaient retrouvées. » Cependant, à propos de la royauté, il ne lui raconta pas ce qu’avait dit Samuel.
###### 17
Samuel convoqua le peuple auprès du Seigneur, à Mispa.
###### 18
Il dit aux fils d’Israël : « Ainsi parle le Seigneur, le Dieu d’Israël : C’est moi qui ai fait monter Israël d’Égypte, qui vous ai délivrés de la main des Égyptiens et de tous les royaumes qui vous opprimaient.
###### 19
Mais vous, aujourd’hui, vous avez rejeté votre Dieu, lui qui vous a sauvés de tous vos malheurs et de toutes vos angoisses, et vous lui avez dit : “C’est un roi que tu établiras sur nous ! Et maintenant, présentez-vous devant le Seigneur par tribus et par clans. »
###### 20
Samuel fit approcher toutes les tribus d’Israël, et la tribu de Benjamin fut désignée par le sort.
###### 21
Il fit approcher la tribu de Benjamin par familles, et la famille de Matri fut désignée. Puis Saül fils de Kish fut désigné. On le chercha, mais sans le trouver.
###### 22
On interrogea encore le Seigneur : « Y a-t-il encore quelqu’un qui soit venu ici ? » Et le Seigneur dit : « Voici qu’il est caché parmi les bagages ! »
###### 23
On courut le tirer de là, et il se présenta au milieu du peuple ; il dépassait tout le monde de plus d’une tête.
###### 24
Samuel dit à tout le peuple : « Avez-vous vu celui que le Seigneur a choisi ? Il n’a pas son pareil dans tout le peuple. » Et tout le peuple fit une ovation, en criant : « Vive le roi ! »
###### 25
Samuel exposa au peuple le droit de la royauté ; il l’écrivit dans un livre qu’il déposa devant le Seigneur. Puis Samuel renvoya tout le peuple, chacun chez soi.
###### 26
Saül aussi s’en alla chez lui, à Guibéa. Les hommes de valeur, dont Dieu avait touché le cœur, partirent avec lui.
###### 27
Quant aux vauriens, ils dirent : « Comment celui-là nous sauverait-il ? » Ils le méprisèrent et ne lui apportèrent pas d’offrandes. Mais Saül fit comme s’il n’avait rien entendu.
