---
aliases : 
- 1 Samuel 19
- 1 Samuel 19
- 1 S 19
tags : 
- Bible/1S/19
- français
cssclass : français
---

# 1 Samuel 19

###### 01
Saül dit à son fils Jonathan et à tous ses serviteurs son intention de faire mourir David. Mais Jonathan, le fils de Saül, aimait beaucoup David
###### 02
et il alla le prévenir : « Mon père Saül cherche à te faire mourir. Demain matin, sois sur tes gardes, mets-toi à l’abri, dissimule-toi.
###### 03
Moi, je sortirai et je me tiendrai à côté de mon père dans le champ où tu seras. Je parlerai de toi à mon père, je verrai ce qu’il en est et je te le ferai savoir. »
###### 04
Jonathan fit à son père Saül l’éloge de David ; il dit : « Que le roi ne commette pas de faute contre son serviteur David, car lui n’a commis aucune faute envers toi. Au contraire, ses exploits sont une très bonne chose pour toi.
###### 05
Il a risqué sa vie, il a frappé à mort Goliath le Philistin, et le Seigneur a donné une grande victoire à tout Israël : tu l’as vu et tu en as été heureux. Pourquoi donc commettre une faute contre la vie d’un innocent, en faisant mourir David sans motif ? »
###### 06
Saül écouta Jonathan et fit ce serment : « Par le Seigneur vivant, il ne sera pas mis à mort ! »
###### 07
Alors Jonathan appela David et lui répéta tout ce que le roi avait dit. Puis il le conduisit à Saül, et David reprit sa place comme avant.
###### 08
La guerre avait repris. David partit combattre les Philistins. Il leur porta un coup très dur, et ils s’enfuirent devant lui.
###### 09
Un mauvais esprit envoyé par le Seigneur vint sur Saül, alors qu’il était assis dans sa maison. Il tenait sa lance à la main, et David jouait de son instrument.
###### 10
Saül chercha à clouer David au mur avec sa lance, mais David esquiva le coup de Saül, qui ficha sa lance dans le mur. David prit la fuite et fut sauvé cette nuit-là.
###### 11
Saül envoya des émissaires à la maison de David, pour le surveiller et le mettre à mort au matin. Mais Mikal, la femme de David, l’avertit : « Si tu ne te sauves pas cette nuit, demain tu seras mis à mort ! »
###### 12
Et Mikal fit descendre David par la fenêtre. Il partit, prit la fuite et fut sauvé.
###### 13
Mikal saisit l’idole domestique, la plaça sur le lit ; elle mit à l’endroit de la tête une touffe de poils de chèvre et recouvrit le reste d’un vêtement.
###### 14
Saül envoya des émissaires pour se saisir de David, mais elle dit : « Il est malade. »
###### 15
Alors Saül renvoya les émissaires voir David, en leur disant : « Apportez-le-moi, dans son lit, pour qu’il soit mis à mort. »
###### 16
Mais quand les émissaires furent entrés, il n’y avait, sur le lit, que l’idole, avec une touffe de poils de chèvre à l’endroit de la tête !
###### 17
Saül dit à Mikal : « Pourquoi m’as-tu ainsi trompé ? Tu as laissé partir mon ennemi, et il est sauvé ! » Mikal répondit à Saül : « C’est lui qui m’a dit : “Laisse-moi partir. Pourquoi faudrait-il que je sois la cause de ta mort ?” »
###### 18
David prit donc la fuite et fut sauvé. Il arriva chez Samuel à Rama et lui rapporta tout ce que Saül lui avait fait subir. Puis ils allèrent, lui et Samuel, habiter à Nayoth.
###### 19
On rapporta à Saül : « Voici que David est à Nayoth-de-Rama ! »
###### 20
Saül envoya des émissaires pour se saisir de David. Ils virent le groupe des prophètes, en état de transe prophétique, avec Samuel debout, à leur tête. Un esprit de Dieu vint sur les émissaires de Saül, et ils entrèrent en transe, eux aussi.
###### 21
On le rapporta à Saül qui envoya d’autres émissaires ; ils entrèrent en transe, eux aussi. Une troisième fois, Saül envoya des émissaires qui entrèrent en transe à leur tour.
###### 22
Alors il se rendit lui-même à Rama et parvint à la grande citerne qui est à Sèkou. Il demanda : « Où se trouvent Samuel et David ? » On lui répondit : « À Nayoth-de-Rama ! »
###### 23
Comme il se rendait là-bas, à Nayoth-de-Rama, sur lui aussi vint un esprit de Dieu. Saisi de transe prophétique, il continua à marcher jusqu’à ce qu’il parvienne à Nayoth-de-Rama.
###### 24
Lui aussi, il retira ses vêtements, lui aussi fut en transe devant Samuel ; puis il s’écroula, nu, restant ainsi toute la journée et toute la nuit. Voilà pourquoi l’on dit : « Saül est-il aussi parmi les prophètes ? »
