---
aliases : 
- 1 Samuel 27
- 1 Samuel 27
- 1 S 27
tags : 
- Bible/1S/27
- français
cssclass : français
---

# 1 Samuel 27

###### 01
David se dit en lui-même : « C’est sûr, un jour ou l’autre, je périrai par la main de Saül. Mieux vaut donc pour moi m’échapper définitivement dans le pays des Philistins. Saül renoncera désormais à me chercher dans tout le territoire d’Israël ; ainsi j’échapperai à sa main ! »
###### 02
David se mit en route avec les six cents hommes qui l’accompagnaient et passa chez Akish, fils de Maok, roi de Gath.
###### 03
David s’installa auprès d’Akish, à Gath, lui et ses hommes, chacun avec sa famille. David y était avec ses deux femmes : Ahinoam de Yizréel et Abigaïl de Carmel – la femme de Nabal.
###### 04
On avertit Saül que David s’était enfui à Gath, et Saül cessa de le chercher.
###### 05
David dit à Akish : « Si j’ai trouvé grâce à tes yeux, qu’on me donne un lieu où je puisse habiter, dans une ville à l’écart. Pourquoi ton serviteur habiterait-il auprès de toi, dans la ville royale ? »
###### 06
Aussitôt, Akish lui donna Ciqlag. C’est pourquoi Ciqlag a appartenu aux rois de Juda, jusqu’à ce jour.
###### 07
La durée du séjour de David en territoire philistin fut d’un an et quatre mois.
###### 08
David entreprit, avec ses hommes, des incursions chez les Gueshourites, les Guirzites et les Amalécites, ces peuplades qui, depuis toujours, occupent le territoire jusqu’à l’entrée de Shour et jusqu’au pays d’Égypte.
###### 09
David dévastait le pays, ne laissant en vie ni homme ni femme, s’emparant du petit et du gros bétail, des ânes, des chameaux, ainsi que des vêtements. Puis, à son retour, il se rendait chez Akish.
###### 10
Quand Akish demandait : « Où avez-vous fait une incursion aujourd’hui ? », David répondait : « Contre le Néguev de Juda » ou « Contre le Néguev des Yerahmëélites » ou « Dans le Néguev des Qénites ».
###### 11
David ne laissait ramener vivant à Gath ni homme ni femme. Il se disait : « Ils pourraient parler contre nous et dire : “Voilà ce que David a fait”. » Telle fut sa manière d’agir tout le temps qu’il séjourna dans le pays philistin.
###### 12
Akish faisait confiance à David. Il se disait : « David s’est rendu vraiment trop odieux à son peuple Israël : il restera mon serviteur à jamais. »
