---
aliases : 
- Osée 6
- Osée 6
- Os 6
- Hosea 6
tags : 
- Bible/Os/6
- français
cssclass : français
---

# Osée 6

###### 01
Venez, retournons vers le Seigneur !
  il a blessé, mais il nous guérira ;
il a frappé, mais il nous soignera.
###### 02
Après deux jours, il nous rendra la vie ;
il nous relèvera le troisième jour :
alors, nous vivrons devant sa face.
###### 03
Efforçons-nous de connaître le Seigneur :
son lever est aussi sûr que l’aurore ;
il nous viendra comme la pluie,
l’ondée qui arrose la terre.
###### 04
– Que ferai-je de toi, Éphraïm ?
Que ferai-je de toi, Juda ?
Votre fidélité, une brume du matin,
une rosée d’aurore qui s’en va.
###### 05
Voilà pourquoi j’ai frappé par mes prophètes,
donné la mort par les paroles de ma bouche :
mon jugement jaillit comme la lumière.
###### 06
Je veux la fidélité, non le sacrifice,
la connaissance de Dieu plus que les holocaustes.
###### 07
Mais, dans la ville d’Adame, eux, ils ont transgressé l’alliance,
et là, ils m’ont trahi.
###### 08
Galaad, cité de malfaiteurs,
est tachée de sang.
###### 09
Sur la route de Sichem,
une bande de prêtres assassinent
comme des brigands en embuscade :
voilà les horreurs qu’ils commettent !
###### 10
Dans la maison d’Israël,
j’ai vu des choses monstrueuses,
là où se prostitue Éphraïm,
où Israël se rend impur.
###### 11
Pour toi aussi, Juda, je prépare une moisson :
je changerai le sort de mon peuple.
