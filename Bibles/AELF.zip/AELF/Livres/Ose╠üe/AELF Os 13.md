---
aliases : 
- Osée 13
- Osée 13
- Os 13
- Hosea 13
tags : 
- Bible/Os/13
- français
cssclass : français
---

# Osée 13

###### 01
Quand Éphraïm parlait, c’était la terreur,
car lui, il était chef en Israël.
Mais il s’est compromis avec Baal
et il en est mort.
###### 02
À présent, ils continuent de pécher,
ils se font des images de métal fondu,
des idoles avec leur argent et par habileté :
œuvre d’artisans que tout cela !
C’est à leur propos que l’on dit :
« Eux qui sacrifient des hommes,
ils vénèrent des veaux. »
###### 03
C’est pourquoi ils seront comme la brume du matin
et comme la rosée d’aurore qui s’en va,
comme la paille emportée loin de l’aire à grain
et comme la fumée qui sort de la cheminée.
###### 04
Et moi, je suis le Seigneur, ton Dieu
depuis la sortie du pays d’Égypte ;
tu ne connaîtras pas d’autre dieu que moi,
hors moi, pas de sauveur.
###### 05
Moi, je t’ai connu au désert,
au pays de l’aridité.
###### 06
Arrivés au pâturage, ils se sont rassasiés ;
ils se sont rassasiés, et leur cœur s’est enorgueilli ;
aussi m’ont-ils oublié.
###### 07
Je serai pour eux comme un lion ;
comme un léopard sur le chemin, je serai à l’affût.
###### 08
Je vais les attaquer comme une ourse
à qui l’on a ravi ses petits,
je vais déchirer l’enveloppe de leur cœur,
comme une lionne je vais les dévorer sur place,
une bête sauvage les mettra en pièces.
###### 09
Te voilà détruit, Israël,
alors que ton secours est en moi !
###### 10
Où donc est ton roi,
pour qu’il te sauve dans toutes tes villes ?
Où sont tes juges, à qui tu as dit :
« Donne-moi un roi et des princes » ?
###### 11
Je te donne un roi dans ma colère
et, dans ma fureur, je le reprends.
###### 12
La faute d’Éphraïm est tenue en lieu sûr,
son péché est mis en réserve.
###### 13
Les douleurs de celle qui enfante lui viendront ;
mais lui, c’est un fils stupide :
le moment venu, il ne quitte pas le sein maternel !
###### 14
Vais-je les libérer de l’emprise des enfers,
les racheter de la mort ?
Mort, où est ta pestilence ?
Enfers, où est votre fléau ?
Toute consolation se dérobe à mes yeux.
###### 15
Éphraïm a beau prospérer au milieu de ses frères,
un vent d’est viendra,
souffle du Seigneur montant du désert.
Il tarira sa source, desséchera sa fontaine,
il pillera le trésor, tous les objets précieux.
