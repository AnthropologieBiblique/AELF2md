---
aliases : 
- Osée 10
- Osée 10
- Os 10
- Hosea 10
tags : 
- Bible/Os/10
- français
cssclass : français
---

# Osée 10

###### 01
Israël était une vigne luxuriante,
qui portait beaucoup de fruit.
Mais plus ses fruits se multipliaient,
plus Israël multipliait les autels ;
plus sa terre devenait belle,
plus il embellissait les stèles des faux dieux.
###### 02
Son cœur est partagé ;
maintenant il va expier :
le Seigneur renversera ses autels ;
les stèles, il les détruira.
###### 03
Maintenant Israël va dire :
« Nous sommes privés de roi,
car nous n’avons pas craint le Seigneur.
Et si nous avions un roi,
que pourrait-il faire pour nous ? »
###### 04
On parle, on parle,
on fait de faux serments,
on conclut des alliances ;
le jugement fleurit comme l’herbe vénéneuse
sur les sillons des champs.
###### 05
Les habitants de Samarie tremblent
pour le veau de Beth-Awen :
pour lui son peuple est en deuil,
avec ses desservants qui pour lui exultaient,
car sa gloire a été déportée au loin.
###### 06
Lui-même sera transporté en Assour
comme offrande au Grand Roi ;
Éphraïm en aura de la honte,
et Israël rougira de son idole.
###### 07
Ils ont disparu, Samarie et son roi,
comme de l’écume à la surface de l’eau.
###### 08
Les lieux sacrés seront détruits,
ils sont le crime, le péché d’Israël ;
épines et ronces recouvriront leurs autels.
Alors on dira aux montagnes : « Cachez-nous ! »
et aux collines : « Tombez sur nous ! »
###### 09
Depuis les jours de Guibéa,
tu as péché, Israël !
C’est là qu’ils en sont restés !
Et le combat contre les fils du crime
ne les atteindrait pas à Guibéa ?
###### 10
Au gré de mes désirs, je vais les corriger :
les peuples se ligueront contre eux
et les corrigeront de leur double faute.
###### 11
Éphraïm était une génisse bien dressée,
qui aimait fouler le grain.
Et moi, j’ai passé le joug
sur la beauté de son encolure,
j’attellerai Éphraïm,
Juda labourera
et Jacob hersera.
###### 12
Faites des semailles de justice,
récoltez une moisson de fidélité,
défrichez vos terres en friche.
Il est temps de chercher le Seigneur,
jusqu’à ce qu’il vienne répandre sur vous
une pluie de justice.
###### 13
Vous avez labouré la méchanceté,
vous avez moissonné la perfidie,
vous avez mangé le fruit du mensonge.
Parce que tu as mis ta confiance dans tes chars,
dans tes nombreux guerriers,
###### 14
il s’élèvera du vacarme parmi ton peuple,
et toutes tes villes fortes seront dévastées,
comme Shalmane dévasta Beth-Arbel au jour du combat,
quand la mère fut écrasée sur ses enfants.
###### 15
Ainsi vous fera Béthel,
face à votre abominable méfait ;
à l’aurore, il sera vraiment perdu, le roi d’Israël.
