---
aliases : 
- Osée 9
- Osée 9
- Os 9
- Hosea 9
tags : 
- Bible/Os/9
- français
cssclass : français
---

# Osée 9

###### 01
Ne te réjouis pas, Israël,
ne jubile pas comme les peuples,
car tu as pratiqué la prostitution loin de ton Dieu,
et tu en aimes le salaire
sur toutes les aires à blé.
###### 02
L’aire à blé et le pressoir
ne nourriront pas tes fils,
et le vin nouveau les décevra.
###### 03
Ils n’habiteront plus le pays du Seigneur :
Éphraïm retournera en Égypte,
et en Assour ils mangeront des aliments impurs.
###### 04
Ils ne verseront plus de vin en libation pour le Seigneur,
leurs sacrifices ne lui plairont plus ;
ce sera pour eux comme un pain de deuil :
tous ceux qui le mangent deviendront impurs ;
ce pain-là ne sera que pour eux,
il n’entrera pas dans la Maison du Seigneur.
###### 05
Que ferez-vous alors au jour de la Rencontre,
au jour de la fête du Seigneur ?
###### 06
Car voilà qu’ils ont fui devant la destruction ;
l’Égypte les rassemble,
Memphis les enterre ;
l’ortie héritera de leurs trésors d’argent,
les ronces envahiront leurs tentes.
###### 07
Ils sont arrivés, les jours du châtiment,
ils sont arrivés, les jours de la rétribution :
qu’Israël le sache !
Le prophète devient fou,
l’homme inspiré délire ;
à cause de la grandeur de ta faute,
grande est l’hostilité contre toi.
###### 08
La sentinelle d’Éphraïm, le prophète, est avec mon Dieu ;
un filet d’oiseleur est sur tous ses chemins,
l’hostilité atteint la maison de Dieu.
###### 09
Ils ont touché le fond de la corruption,
comme aux jours de Guibéa.
Dieu se souviendra de leur crime,
il fera le compte de leurs péchés.
###### 10
Comme des raisins au désert,
j’avais trouvé Israël ;
comme un premier fruit sur un jeune figuier,
j’avais vu vos pères.
Mais eux, arrivés à Baal-Péor,
ils se sont voués à la Honte,
ils sont devenus aussi horribles
que l’objet de leur amour.
###### 11
Éphraïm ! Comme un oiseau s’envolera ta gloire,
dès la naissance, dès la grossesse et la conception.
###### 12
Même s’ils élèvent des fils,
je les en priverai avant qu’ils aient l’âge d’homme.
Oui, malheur à eux, quand je m’en éloignerai !
###### 13
Éphraïm, je le vois comme une autre Tyr
plantée dans un pâturage,
mais il fait partir ses fils au-devant du tueur.
###### 14
Donne-leur, Seigneur,
– et que vas-tu donner ? – 
donne-leur ventre stérile
et seins desséchés.
###### 15
Toute leur malice est à Guilgal :
c’est là que je les ai pris en haine.
À cause de la méchanceté de leurs actes,
je les chasserai de ma maison,
je cesserai de les aimer :
ils sont rebelles, tous leurs princes.
###### 16
Éphraïm a été frappé,
leur racine s’est desséchée,
ils ne feront pas de fruit !
Même s’ils enfantent,
je ferai mourir les trésors de leur ventre.
###### 17
Mon Dieu les rejettera,
car ils ne l’ont pas écouté :
ils s’en iront, errant parmi les nations.
