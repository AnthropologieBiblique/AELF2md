---
aliases : 
- Osée 3
- Osée 3
- Os 3
- Hosea 3
tags : 
- Bible/Os/3
- français
cssclass : français
---

# Osée 3

###### 01
Le Seigneur me dit :
« Va de nouveau,
aime une femme aimée d’un compagnon
et qui commet l’adultère.
Car tel est l’amour du Seigneur
pour les fils d’Israël,
eux qui se tournent vers d’autres dieux
et qui aiment les gâteaux de raisins. »
###### 02
Je m’achetai une femme pour quinze pièces d’argent
et une mesure et demie d’orge.
###### 03
Et je lui dis :
« Tu resteras chez moi de nombreux jours,
sans te prostituer et sans appartenir à un homme ;
et moi, je ferai de même à ton égard. »
###### 04
Car, pendant de nombreux jours,
les fils d’Israël resteront
sans roi ni prince,
sans sacrifice ni stèle,
sans éphod ni terafim.
###### 05
Après quoi, les fils d’Israël reviendront,
ils rechercheront le Seigneur, leur Dieu,
et David, leur roi ;
ils iront en tremblant vers le Seigneur et sa bonté,
pour la suite des temps.
