---
aliases : 
- Osée 12
- Osée 12
- Os 12
- Hosea 12
tags : 
- Bible/Os/12
- français
cssclass : français
---

# Osée 12

###### 01
Éphraïm m’encercle de mensonge
et la maison d’Israël, de tromperie.
Mais Juda marche encore avec Dieu
et reste fidèle au Très-Saint.
###### 02
Éphraïm se repaît de vent
et poursuit le vent d’est ;
tout le jour, il multiplie mensonge et ruine :
il conclut une alliance avec Assour,
il porte de l’huile à l’Égypte.
###### 03
Le Seigneur est en procès avec Juda,
il va sévir contre Jacob en raison de sa conduite,
lui rendre selon ses œuvres.
###### 04
Dans le sein de sa mère, il a supplanté son frère,
et, à l’âge mûr, il a lutté avec Dieu.
###### 05
Il a lutté avec un ange et il a eu le dessus ;
il a pleuré et l’a supplié.
À Béthel, il le trouva,
– c’est là que Dieu a parlé avec nous.
###### 06
« Seigneur, Dieu de l’univers » :
c’est ainsi qu’on fait mémoire du Seigneur.
###### 07
Toi, reviens à ton Dieu :
garde la fidélité et le droit,
et mets ton espoir en ton Dieu, toujours.
###### 08
Canaan, une balance trompeuse à la main,
aime frauder.
###### 09
Éphraïm dit :
« Oui, je me suis enrichi,
j’ai édifié une fortune. 
Tout cela est fruit de mon travail ;
on ne trouvera pas chez moi
de faute qui soit péché. »
###### 10
Mais moi, je suis le Seigneur ton Dieu
depuis le pays d’Égypte.
Je te ferai de nouveau habiter sous les tentes
comme au jour de la Rencontre.
###### 11
Je parlerai aux prophètes ;
moi, je multiplierai les visions,
et, par le moyen des prophètes,
je dirai des paraboles.
###### 12
Si Galaad est fausseté,
ils ne sont que néant,
ceux qui ont sacrifié des taureaux à Guilgal ;
aussi leurs autels seront-ils comme des galets
entassés sur les sillons des champs.
###### 13
Jacob a fui dans le champ d’Aram,
Israël a servi pour une femme,
pour une femme il a gardé les troupeaux.
###### 14
Mais par un prophète
le Seigneur fit monter Israël d’Égypte,
et, par un prophète, Israël a été gardé.
###### 15
Éphraïm a irrité le Seigneur jusqu’à l’amertume :
sur lui sera rejeté le sang versé,
et son Maître lui rendra ses outrages.
