---
aliases : 
- Osée 14
- Osée 14
- Os 14
- Hosea 14
tags : 
- Bible/Os/14
- français
cssclass : français
---

# Osée 14

###### 01
Elle s’est rendue coupable, Samarie,
car elle s’est rebellée contre son Dieu.
Ils tomberont par l’épée,
leurs nourrissons seront écrasés,
et leurs femmes enceintes, éventrées.
###### 02
Reviens, Israël, au Seigneur ton Dieu ;
car tu t’es effondré par suite de tes fautes.
###### 03
Revenez au Seigneur
en lui présentant ces paroles :
« Enlève toutes les fautes, et accepte ce qui est bon.
Au lieu de taureaux, nous t’offrons en sacrifice
les paroles de nos lèvres.
###### 04
Puisque les Assyriens ne peuvent pas nous sauver,
nous ne monterons plus sur des chevaux,
et nous ne dirons plus à l’ouvrage de nos mains :
“Tu es notre Dieu”,
car de toi seul l’orphelin reçoit de la tendresse. »
###### 05
Voici la réponse du Seigneur :
Je les guérirai de leur infidélité,
je les aimerai d’un amour gratuit,
car ma colère s’est détournée d’Israël.
###### 06
Je serai pour Israël comme la rosée,
il fleurira comme le lis,
il étendra ses racines comme les arbres du Liban.
###### 07
Ses jeunes pousses vont grandir,
sa parure sera comme celle de l’olivier,
son parfum, comme celui de la forêt du Liban.
###### 08
Ils reviendront s’asseoir à son ombre,
ils feront revivre le froment,
ils fleuriront comme la vigne,
ils seront renommés comme le vin du Liban.
###### 09
Éphraïm ! Peux-tu me confondre avec les idoles ?
C’est moi qui te réponds et qui te regarde.
Je suis comme le cyprès toujours vert,
c’est moi qui te donne ton fruit.
###### 10
Qui donc est assez sage
pour comprendre ces choses,
assez pénétrant pour les saisir ?
Oui, les chemins du Seigneur sont droits :
les justes y avancent,
mais les pécheurs y trébuchent.
