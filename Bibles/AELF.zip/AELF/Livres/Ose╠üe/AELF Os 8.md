---
aliases : 
- Osée 8
- Osée 8
- Os 8
- Hosea 8
tags : 
- Bible/Os/8
- français
cssclass : français
---

# Osée 8

###### 01
Sonne du cor !
  Un aigle plane sur la Maison du Seigneur !
Car ils ont transgressé mon alliance,
et contre ma loi ils se sont révoltés.
###### 02
Ils crient vers moi : « Mon Dieu,
nous t’avons connu, nous, Israël ! »
###### 03
Israël a rejeté le bien :
l’ennemi le poursuit !
###### 04
Les fils d’Israël ont établi des rois sans me consulter,
ils ont nommé des princes sans mon accord ;
avec leur argent et leur or, ils se sont fabriqué des idoles.
Ils seront anéantis.
###### 05
Je le rejette, ton veau, Samarie !
Ma colère s’est enflammée contre tes enfants.
Refuseront-ils toujours de retrouver l’innocence ?
###### 06
Ce veau est l’œuvre d’Israël,
un artisan l’a fabriqué,
ce n’est pas un dieu ;
ce veau de Samarie sera mis en pièces.
###### 07
Ils ont semé le vent,
ils récolteront la tempête.
L’épi ne donnera pas de grain ;
s’il y avait du grain,
il ne donnerait pas de farine ;
et, s’il en donnait,
elle serait dévorée par les étrangers.
###### 08
Israël est dévoré ;
les voici maintenant parmi les nations,
comme un objet de rebut.
###### 09
Quand ils montent vers Assour,
alors que l’âne sauvage vit à l’écart,
Éphraïm s’offre des amants.
###### 10
Même s’ils offrent des dons parmi les nations,
je vais maintenant les regrouper ;
ils trembleront bientôt
sous le joug du roi et des princes.
###### 11
Éphraïm a multiplié les autels pour expier le péché ;
et ces autels ne lui servent qu’à pécher.
###### 12
J’ai beau lui mettre par écrit tous les articles de ma loi,
il n’y voit qu’une loi étrangère.
###### 13
Ils offrent des sacrifices pour me plaire
et ils en mangent la viande,
mais le Seigneur n’y prend pas de plaisir.
Au contraire, il y trouve le rappel de toutes leurs fautes,
il fait le compte de leurs péchés.
Qu’ils retournent donc en Égypte !
###### 14
Israël a oublié Celui qui le fait,
il s’est construit des palais.
Quant à Juda, il a multiplié ses villes fortes,
mais j’enverrai le feu dans ses villes,
il en dévorera les citadelles.
