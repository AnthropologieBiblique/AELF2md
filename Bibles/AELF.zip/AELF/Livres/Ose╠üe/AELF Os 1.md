---
aliases : 
- Osée 1
- Osée 1
- Os 1
- Hosea 1
tags : 
- Bible/Os/1
- français
cssclass : français
---

# Osée 1

###### 01
PAROLE DU SEIGNEUR adressée à Osée, fils de Beéri, au temps d’Ozias, de Yotam, d’Acaz, d’Ézékias, rois de Juda, et au temps de Jéroboam, fils de Joas, roi d’Israël.
###### 02
Commencement de la parole que le Seigneur a dite par la bouche d’Osée.
Le Seigneur dit à Osée :
« Va, prends-toi pour femme une prostituée
et des enfants de prostitution,
car vraiment le pays se prostitue
en se détournant du Seigneur. »
###### 03
Il alla donc et prit Gomer, fille de Diblaïm ;
elle devint enceinte et lui enfanta un fils.
###### 04
Et le Seigneur dit à Osée :
« Donne-lui le nom de Yizréel,
car encore un peu de temps
et je sévis contre la maison de Jéhu
à cause du sang versé à Yizréel,
et je mets fin à la royauté de la maison d’Israël :
###### 05
il adviendra, en ce jour-là,
que je briserai l’arc d’Israël
dans la vallée de Yizréel. »
###### 06
Elle devint encore enceinte et enfanta une fille.
Et le Seigneur dit à Osée :
« Donne-lui le nom de Lô-Rouhama (c’est-à-dire “Pas-Aimée”),
car je n’aime plus la maison d’Israël
et ne veux plus lui pardonner.
###### 07
C’est la maison de Juda que j’aime :
je vais les sauver, par le Seigneur leur Dieu,
et non par l’arc, l’épée ou la guerre,
ni par les chevaux ni par les cavaliers. »
###### 08
Quand elle eut sevré Lô-Rouhama,
Gomer devint enceinte et enfanta un fils.
###### 09
Et le Seigneur dit :
« Donne-lui le nom de Lô-Ammi (c’est-à-dire “Pas-mon-Peuple”),
car vous n’êtes pas mon peuple,
et moi, je ne suis pas pour vous. »
