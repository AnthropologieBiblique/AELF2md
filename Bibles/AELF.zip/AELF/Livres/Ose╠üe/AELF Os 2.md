---
aliases : 
- Osée 2
- Osée 2
- Os 2
- Hosea 2
tags : 
- Bible/Os/2
- français
cssclass : français
---

# Osée 2

###### 01
Comme le sable de la mer
que l’on ne peut ni compter ni mesurer,
ainsi sera le nombre des fils d’Israël.
Au lieu de leur dire : « Vous n’êtes pas mon peuple »,
on leur dira : « Fils du Dieu vivant ».
###### 02
Les fils de Juda et les fils d’Israël se réuniront,
ils se donneront un seul chef
et ils sortiront du pays ;
oui, il est grand, le jour de Yizréel !
###### 03
Dites à vos frères : « Mon-Peuple »,
et à vos sœurs : « Tendrement-Aimée ».
###### 04
Accusez votre mère, accusez-la,
car elle n’est plus ma femme,
et moi, je ne suis plus son mari !
Qu’elle écarte de son visage ses prostitutions,
et d’entre ses seins, ses adultères ;
###### 05
sinon, je la déshabille toute nue,
je l’expose comme au jour de sa naissance,
je la rends pareille au désert,
je la réduis en terre aride
et je la fais mourir de soif.
###### 06
Pour ses fils je n’aurai pas de tendresse,
car ils sont des fils de prostitution.
###### 07
Oui, leur mère s’est prostituée,
celle qui les conçut s’est déshonorée
quand elle disait :
« Je veux courir après mes amants
qui me donnent mon pain et mon eau,
ma laine et mon lin,
mon huile et ma boisson. »
###### 08
C’est pourquoi
je vais obstruer son chemin avec des ronces,
le barrer d’une barrière :
elle ne trouvera plus ses sentiers.
###### 09
Elle poursuivra ses amants sans les atteindre,
elle les cherchera sans les trouver.
Alors elle dira :
« Je vais revenir à mon premier mari,
car j’étais autrefois plus heureuse que maintenant. »
###### 10
Elle ne savait donc pas
que c’est moi qui lui avais donné
le froment, le vin nouveau et l’huile fraîche,
moi qui lui avais prodigué de l’argent,
et l’or utilisé pour Baal !
###### 11
C’est pourquoi je reviendrai,
je reprendrai mon froment en sa saison
et mon vin nouveau en son temps ;
j’arracherai ma laine et mon lin
dont elle couvrait sa nudité.
###### 12
Alors je dévoilerai sa honte
aux yeux de ses amants,
et nul ne la délivrera de ma main.
###### 13
Je mettrai fin à toute sa gaieté,
à ses fêtes, ses nouvelles lunes, ses sabbats,
et à toutes ses solennités.
###### 14
Je dévasterai sa vigne et son figuier
dont elle disait :
« Ils sont à moi, c’est le salaire
que m’ont donné mes amants. »
Je les changerai en friche
et les bêtes sauvages les dévoreront.
###### 15
Je sévirai contre elle
à cause des jours des Baals,
quand elle brûlait pour eux de l’encens,
se parait de ses anneaux et de son collier,
et courait après ses amants.
Et moi, elle m’oubliait !
– oracle du Seigneur.
###### 16
C’est pourquoi, mon épouse infidèle,
je vais la séduire,
je vais l’entraîner jusqu’au désert,
et je lui parlerai cœur à cœur.
###### 17
Et là, je lui rendrai ses vignobles,
et je ferai du Val d’Akor (c’est-à-dire « de la Déroute »)
la porte de l’Espérance.
Là, elle me répondra
comme au temps de sa jeunesse,
au jour où elle est sortie du pays d’Égypte.
###### 18
En ce jour-là – oracle du Seigneur –,
voici ce qui arrivera :
Tu m’appelleras : « Mon époux »
et non plus : « Mon Baal » (c’est-à-dire « mon maître »).
###### 19
J’éloignerai de ses lèvres les noms des Baals,
on ne prononcera plus leurs noms.
###### 20
En ce jour-là je conclurai à leur profit
une alliance avec les bêtes sauvages,
avec les oiseaux du ciel et les bestioles de la terre ;
l’arc, l’épée et la guerre, je les briserai
pour en délivrer le pays ;
et ses habitants, je les ferai reposer en sécurité.
###### 21
Je ferai de toi mon épouse pour toujours,
je ferai de toi mon épouse
dans la justice et le droit,
dans la fidélité et la tendresse ;
###### 22
je ferai de toi mon épouse dans la loyauté,
et tu connaîtras le Seigneur.
###### 23
En ce jour-là je répondrai – oracle du Seigneur ;
oui, je répondrai aux cieux,
eux, ils répondront à l’appel de la terre ;
###### 24
la terre répondra au froment,
au vin nouveau et à l’huile fraîche,
eux, ils répondront à la « Vallée-de-la-fertilité ».
###### 25
Je m’en ferai une terre ensemencée,
J’aimerai celle qu’on appelait « Pas-Aimée »
et à celui qu’on appelait « Pas-mon-Peuple »,
je dirai : « Tu es mon peuple »,
et il dira : « Tu es mon Dieu ! »
