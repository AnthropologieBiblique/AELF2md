---
aliases : 
- Osée 7
- Osée 7
- Os 7
- Hosea 7
tags : 
- Bible/Os/7
- français
cssclass : français
---

# Osée 7

###### 01
Quand je voulais guérir Israël,
  alors s’est dévoilée la faute d’Éphraïm,
et les méfaits de Samarie,
car ils pratiquent le mensonge.
Le voleur s’introduit dans les maisons,
et au-dehors sévit le brigand.
###### 02
Ils ne disent pas dans leur cœur
que je me souviens de tous leurs méfaits ;
à présent leurs œuvres les encerclent,
elles sont là devant moi.
###### 03
Dans leur malice, ils amusent le roi,
et par leurs mensonges, les princes.
###### 04
Tous, ils sont adultères,
comme un four brûlant,
que le boulanger cesse d’attiser
depuis qu’il a pétri la pâte jusqu’à ce qu’elle ait levé.
###### 05
Au jour de notre roi,
les princes, embrasés par le vin,
se rendent malades ;
on tend la main aux railleurs.
###### 06
Par leur complot,
ils ont rendu leur cœur pareil au four
dont le boulanger sommeille toute la nuit
et qu’un feu violent fait brûler au matin.
###### 07
Tous, comme un four, ils sont embrasés :
ils dévorent leurs juges ;
tous leurs rois sont tombés,
pas un d’entre eux ne crie vers moi !
###### 08
Éphraïm se mêle aux autres peuples,
Éphraïm est une galette qu’on n’a pas retournée !
###### 09
Des étrangers dévorent sa force,
et lui n’en sait rien ;
ses cheveux ont blanchi,
et lui n’en sait rien.
###### 10
L’orgueil d’Israël témoigne contre lui,
ils ne reviennent pas au Seigneur, leur Dieu ;
malgré tout cela, ils ne le cherchent pas.
###### 11
Voici Éphraïm,
colombe naïve et sans cœur :
ils appellent l’Égypte,
ils s’en vont à Assour.
###### 12
Où qu’ils aillent, je jette sur eux mon filet,
je les fais descendre comme les oiseaux du ciel,
je les attrape dès que j’entends qu’ils se rassemblent.
###### 13
Malheur sur eux, car ils ont fui loin de moi !
Ruine sur eux, car ils se sont révoltés contre moi !
Moi, je veux les racheter ;
eux, ils disent des mensonges contre moi.
###### 14
Ce n’est pas du fond du cœur qu’ils crient vers moi,
quand ils se lamentent sur leurs couches ;
ils s’inquiètent pour du froment et du vin nouveau,
c’est de moi qu’ils s’éloignent.
###### 15
Alors que j’avais dirigé,
que j’avais fortifié leur bras,
ils méditent le mal envers moi.
###### 16
Ils reviennent, ils n’ont pas le dessus,
ils sont comme un arc trompeur ;
leurs chefs tomberont sous l’épée
pour l’insolence de leur langage :
on en rira au pays d’Égypte.
