---
aliases : 
- Osée 4
- Osée 4
- Os 4
- Hosea 4
tags : 
- Bible/Os/4
- français
cssclass : français
---

# Osée 4

###### 01
Écoutez la parole du Seigneur, fils d’Israël,
car le Seigneur est en procès avec les habitants du pays :
il n’y a, dans le pays, ni vérité ni fidélité,
ni connaissance de Dieu,
###### 02
mais parjure et mensonge,
assassinat et vol ;
on commet l’adultère, on se déchire :
le sang appelle le sang.
###### 03
C’est pourquoi le pays est en deuil,
tous ses habitants dépérissent,
ainsi que les bêtes sauvages et les oiseaux du ciel ;
même les poissons de la mer disparaissent.
###### 04
Mais que nul n’accuse, que nul ne réprimande :
Prêtre, c’est avec toi que je suis en procès !
###### 05
Tu trébuches le jour,
le prophète aussi trébuche avec toi la nuit ;
je réduirai ta mère au silence,
###### 06
et mon peuple, faute de connaissance,
sera, lui aussi, réduit au silence.
Puisque tu as rejeté la connaissance,
je te rejetterai et tu ne seras plus mon prêtre ;
puisque tu as oublié la loi de ton Dieu,
à mon tour, j’oublierai tes fils.
###### 07
Tous, tant qu’ils sont, ils ont péché contre moi :
je vais changer leur gloire en infamie.
###### 08
Ils se repaissent du péché de mon peuple
et vers leur faute ils portent leur désir.
###### 09
Il en sera du prêtre comme du peuple :
je sévirai contre lui à cause de sa conduite
et je lui revaudrai ses actions.
###### 10
Ils se repaissent, et ne sont pas rassasiés,
ils se prostituent, et ne s’accroissent pas,
car ils ont cessé de respecter le Seigneur.
###### 11
Prostitution, vin et vin nouveau
emprisonnent le cœur.
###### 12
Mon peuple consulte son idole de bois,
c’est son bâton qui le renseigne ;
car un esprit de prostitution l’égare :
ils se sont prostitués, éloignés de leur Dieu.
###### 13
Sur les sommets des montagnes, ils sacrifient,
sur les collines, ils brûlent des offrandes,
sous le chêne, le peuplier, le térébinthe,
dont l’ombrage est agréable !
C’est pourquoi vos filles se prostituent
et vos belles-filles sont adultères.
###### 14
Je ne sévirai pas contre vos filles
à cause de leurs prostitutions,
ni contre vos belles-filles
à cause de leurs adultères,
puisqu’eux-mêmes vont à l’écart avec les prostituées
et sacrifient avec les courtisanes sacrées.
Un peuple qui ne comprend pas court à sa perte.
###### 15
Si tu te prostitues, toi, Israël,
que Juda ne se rende pas coupable !
N’allez donc pas à Guilgal,
ne montez pas à Beth-Awen
et ne jurez pas par la vie du Seigneur.
###### 16
Puisqu’Israël a été rétif
comme une vache rétive,
le Seigneur le conduirait-il maintenant
comme un agneau dans une vaste prairie ?
###### 17
Éphraïm est l’allié des idoles :
laisse-le !
###### 18
Après les beuveries, c’est la prostitution ;
ils préfèrent l’ignominie à leur gloire.
###### 19
Le vent les enveloppera de ses ailes
et ils rougiront de leurs sacrifices.
