---
aliases : 
- Osée 5
- Osée 5
- Os 5
- Hosea 5
tags : 
- Bible/Os/5
- français
cssclass : français
---

# Osée 5

###### 01
Écoutez ceci, vous les prêtres ;
 sois attentive, maison d’Israël ;
maison du roi, prête l’oreille !
Oui, le jugement est contre vous,
car vous avez été un piège à Mispa,
un filet tendu sur le Tabor.
###### 02
Des infidèles ont creusé une fosse profonde,
et moi, je serai pour eux tous un châtiment.
###### 03
Moi, je connais Éphraïm,
et Israël ne m’est pas caché.
Oui, maintenant, tu t’es prostitué, Éphraïm,
tu t’es souillé, Israël.
###### 04
Leurs actions ne leur permettent pas
de retourner vers leur Dieu,
car un esprit de prostitution les habite,
et ils ne connaissent pas le Seigneur.
###### 05
L’orgueil d’Israël témoigne contre lui.
Israël et Éphraïm trébuchent à cause de leur faute,
et Juda, lui aussi, trébuche avec eux.
###### 06
Avec leurs brebis et leurs bœufs,
ils iront chercher le Seigneur,
mais ils ne le trouveront pas :
il s’est éloigné d’eux !
###### 07
Ils ont trahi le Seigneur :
ils ont engendré des bâtards ;
maintenant la nouvelle lune
va les dévorer, avec leur héritage.
###### 08
Sonnez du cor à Guibéa,
de la trompette à Rama ;
poussez des cris à Beth-Awen,
on te poursuit, Benjamin !
###### 09
Éphraïm sera une ruine
au jour du reproche ;
j’annonce une chose certaine
aux tribus d’Israël.
###### 10
Les chefs de Juda
sont comme des gens qui déplacent des bornes ;
sur eux, je déverserai,
comme des flots, ma colère.
###### 11
Éphraïm est exploité,
le droit est malmené,
car on se plaît
à poursuivre le néant.
###### 12
Et moi, je serai comme un abcès pour Éphraïm,
comme une carie pour la maison de Juda.
###### 13
Éphraïm a vu sa maladie,
et Juda, son ulcère ;
Éphraïm est allé vers Assour,
il a envoyé des messagers au Grand Roi ;
mais lui ne peut vous guérir
ni cicatriser votre ulcère.
###### 14
Car moi, je serai comme un lion pour Éphraïm,
comme un lionceau pour la maison de Juda.
Oui, moi, je déchire et je m’en vais,
j’emporte, et personne qui délivre.
###### 15
Je m’en irai, je retournerai en ma demeure,
jusqu’à ce qu’ils s’avouent coupables
et recherchent ma face,
et que dans leur détresse ils me cherchent.
