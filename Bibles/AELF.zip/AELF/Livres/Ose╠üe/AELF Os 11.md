---
aliases : 
- Osée 11
- Osée 11
- Os 11
- Hosea 11
tags : 
- Bible/Os/11
- français
cssclass : français
---

# Osée 11

###### 01
Oui, j’ai aimé Israël dès son enfance,
et, pour le faire sortir d’Égypte, j’ai appelé mon fils.
###### 02
Quand je l’ai appelé,
il s’est éloigné pour sacrifier aux Baals
et brûler des offrandes aux idoles.
###### 03
C’est moi qui lui apprenais à marcher,
en le soutenant de mes bras,
et il n’a pas compris que je venais à son secours.
###### 04
Je le guidais avec humanité,
par des liens d’amour ;
je le traitais comme un nourrisson
qu’on soulève tout contre sa joue ;
je me penchais vers lui pour le faire manger.
Mais ils ont refusé de revenir à moi :
vais-je les livrer au châtiment ?
###### 05
Il ne retournera pas au pays d’Égypte ;
Assour deviendra son roi,
car ils ont refusé de revenir à moi.
###### 06
L’épée frappera dans ses villes,
elle brisera les verrous de ses portes,
elle les dévorera à cause de leurs intrigues.
###### 07
Mon peuple s’accroche à son infidélité ;
on l’appelle vers le haut ;
aucun ne s’élève.
###### 08
Vais-je t’abandonner, Éphraïm,
et te livrer, Israël ?
Vais-je t’abandonner comme Adma,
et te rendre comme Seboïm ?
Non ! Mon cœur se retourne contre moi ;
en même temps, mes entrailles frémissent.
###### 09
Je n’agirai pas selon l’ardeur de ma colère,
je ne détruirai plus Israël,
car moi, je suis Dieu, et non pas homme :
au milieu de vous je suis le Dieu saint,
et je ne viens pas pour exterminer.
###### 10
Ils marcheront à la suite du Seigneur ;
comme un lion il rugira,
oui, il rugira, lui,
et, tout tremblants, ses fils viendront de l’Occident.
###### 11
Comme un oiseau, tout tremblants, ils viendront de l’Égypte,
et comme une colombe, du pays d’Assour ;
je les ferai habiter dans leurs maisons,
– oracle du Seigneur.
