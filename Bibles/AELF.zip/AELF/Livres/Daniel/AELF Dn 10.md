---
aliases : 
- Daniel 10
- Daniel 10
- Dn 10
tags : 
- Bible/Dn/10
- français
cssclass : français
---

# Daniel 10

###### 01
La troisième année du règne de Cyrus, roi de Perse, une parole fut révélée à Daniel, surnommé Beltassar : parole vraie et grand combat. Il comprit la parole : la compréhension lui vint dans une vision.
###### 02
En ces jours-là, moi, Daniel, je portai le deuil pendant trois semaines entières.
###### 03
Je ne mangeai pas de nourriture agréable ; ni viande ni vin ne passèrent par ma bouche, je m’abstins de tout parfum jusqu’au terme de ces trois semaines.
###### 04
Et le vingt-quatrième jour du premier mois, étant au bord du grand fleuve, le Tigre,
###### 05
je levai les yeux et regardai. Voici : il y avait un homme vêtu de lin, qui portait une ceinture d’or pur autour des reins ;
###### 06
son corps était comme de la chrysolithe, son visage comme un éclair, ses yeux comme des torches de feu, ses bras et ses jambes avaient l’éclat du bronze poli, et le son de ses paroles était comme la rumeur d’une multitude.
###### 07
Moi seul, Daniel, je vis cette apparition. Les hommes qui étaient avec moi ne voyaient pas l’apparition, mais une grande terreur s’abattit sur eux, et ils s’enfuirent pour se cacher.
###### 08
Je demeurai donc seul et regardai cette apparition impressionnante. J’étais sans force aucune, mes traits bouleversés se décomposèrent, ma force m’abandonna.
###### 09
J’entendis le bruit de ses paroles, et lorsque je l’entendis, je fus pris de torpeur et tombai face contre terre.
###### 10
Alors une main me toucha et me redressa sur les genoux et les paumes de mes mains.
###### 11
Il me dit : « Daniel, homme aimé de Dieu, comprends les paroles que je vais te dire, mets-toi debout. Oui, maintenant j’ai été envoyé vers toi. » Tandis qu’il me parlait, je me mis debout en tremblant.
###### 12
Il me dit : « N’aie pas peur, Daniel. Dès le premier jour où tu as eu à cœur de comprendre et de t’humilier devant ton Dieu, tes paroles ont été entendues : c’est à cause de tes paroles que je suis venu.
###### 13
L’ange du royaume de Perse m’a résisté pendant vingt et un jours, mais Michel, l’un des premiers anges, est venu à mon aide. Moi, je l’ai laissé avec l’ange des rois de Perse.
###### 14
Alors, je suis venu pour t’expliquer ce qui arrivera à ton peuple à la fin des jours. Voici une nouvelle vision pour ces jours-là. »
###### 15
Tandis qu’il me parlait, je me prosternai à terre en silence.
###### 16
Voici comme une forme de fils d’homme qui me toucha les lèvres. J’ouvris la bouche et parlai. Je dis à celui qui était devant moi : « Mon seigneur, à cause de l’apparition, l’angoisse me submerge et ma force m’abandonne.
###### 17
Comment le serviteur de mon seigneur pourra-t-il parler avec toi, mon seigneur, alors que je n’ai plus de force, et qu’il ne me reste pas de souffle ? »
###### 18
Celui qui avait l’apparence d’un homme me toucha de nouveau et me réconforta.
###### 19
Il me dit : « N’aie pas peur, homme aimé de Dieu ! La paix soit avec toi ! Sois très fort ! » Tandis qu’il parlait, je repris des forces et dis : « Que mon seigneur parle, car tu m’as rendu la force. »
###### 20
Il dit : « Sais-tu pourquoi je suis venu vers toi ? Maintenant, je vais retourner combattre l’ange de la Perse. À l’issue de ce combat, l’ange de la Grèce viendra.
###### 21
Personne ne me prête main-forte contre ceux-ci, sauf Michel, votre ange. Mais je t’annonce ce qui est inscrit dans le livre de vérité.
