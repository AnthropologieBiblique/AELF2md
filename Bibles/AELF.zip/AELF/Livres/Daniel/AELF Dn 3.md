---
aliases : 
- Daniel 3
- Daniel 3
- Dn 3
tags : 
- Bible/Dn/3
- français
cssclass : français
---

# Daniel 3

###### 01
Le roi Nabucodonosor fit une statue d’or : elle était haute de soixante coudées, large de six coudées. Il l’érigea dans la plaine de Doura, dans la province de Babylone.
###### 02
Le roi Nabucodonosor fit rassembler les satrapes, les préfets, les gouverneurs, les conseillers, les trésoriers, les juges, les magistrats et tous les fonctionnaires des provinces, pour qu’ils viennent à l’inauguration de la statue érigée par le roi Nabucodonosor.
###### 03
Alors, les satrapes, les préfets, les gouverneurs, les conseillers, les trésoriers, les juges, les magistrats et tous les fonctionnaires des provinces se rassemblèrent pour l’inauguration de la statue qu’avait érigée le roi Nabucodonosor. Ils se tenaient là, debout, devant la statue que le roi Nabucodonosor avait érigée.
###### 04
Le crieur public proclama avec force : « Vous, peuples, nations et gens de toutes langues, on vous l’ordonne :
###### 05
Quand vous entendrez le son du cor, de la flûte, de la cithare, de la harpe, de la lyre, de la cornemuse et de toutes les sortes d’instruments, vous vous prosternerez et vous adorerez la statue d’or que le roi Nabucodonosor a érigée.
###### 06
Celui qui ne se prosternera pas et n’adorera pas sera jeté immédiatement au milieu d’une fournaise de feu ardent. »
###### 07
Alors, à l’instant même où tous entendirent le son du cor, de la flûte, de la cithare, de la harpe, de la lyre, de la cornemuse et de toutes les sortes d’instruments, tous les peuples, nations et gens de toutes langues se prosternèrent et adorèrent la statue d’or que le roi Nabucodonosor avait érigée.
###### 08
Là-dessus, à ce moment, des devins s’approchèrent pour dénoncer les Juifs.
###### 09
Prenant la parole, ils dirent à Nabucodonosor : « Ô roi, puisses-tu vivre à jamais !
###### 10
Toi, ô roi, tu as ordonné que tout homme qui entendrait le son du cor, de la flûte, de la cithare, de la harpe, de la lyre, de la cornemuse et de toutes les sortes d’instruments se prosternerait pour adorer la statue d’or.
###### 11
Celui qui ne se prosternerait pas et n’adorerait pas serait jeté au milieu d’une fournaise de feu ardent.
###### 12
Tu as confié l’administration de la province de Babylone à des Juifs : Sidrac, Misac et Abdénago. Eh bien, ô roi, ces hommes n’ont pas tenu compte de toi ! Ils ne servent pas tes dieux, ils n’adorent pas la statue d’or que tu as érigée. »
###### 13
Alors Nabucodonosor, pris d’une violente colère, ordonna qu’on lui amène Sidrac, Misac et Abdénago. Et ces hommes furent amenés devant le roi.
###### 14
Le roi Nabucodonosor leur parla ainsi : « Est-il vrai, Sidrac, Misac et Abdénago, que vous refusez de servir mes dieux et d’adorer la statue d’or que j’ai fait ériger ?
###### 15
Êtes-vous prêts, maintenant, à vous prosterner pour adorer la statue que j’ai faite, quand vous entendrez le son du cor, de la flûte, de la cithare, de la harpe, de la lyre, de la cornemuse et de toutes les sortes d’instruments ? Si vous n’adorez pas cette statue, vous serez immédiatement jetés dans la fournaise de feu ardent ; et quel est le dieu qui vous délivrera de ma main ? »
###### 16
Sidrac, Misac et Abdénago dirent au roi Nabucodonosor : « Ce n’est pas à nous de te répondre.
###### 17
Si notre Dieu, que nous servons, peut nous délivrer, il nous délivrera de la fournaise de feu ardent et de ta main, ô roi.
###### 18
Et même s’il ne le fait pas, sois-en bien sûr, ô roi : nous ne servirons pas tes dieux, nous n’adorerons pas la statue d’or que tu as érigée. »
###### 19
Alors Nabucodonosor fut rempli de fureur contre Sidrac, Misac et Abdénago, et son visage s’altéra. Il ordonna de chauffer la fournaise sept fois plus qu’à l’ordinaire.
###### 20
Puis il ordonna aux plus vigoureux de ses soldats de ligoter Sidrac, Misac et Abdénago et de les jeter dans la fournaise de feu ardent.
###### 21
Alors, on ligota ces hommes, vêtus de leurs manteaux, de leurs tuniques, de leurs bonnets et de leurs autres vêtements, et on les jeta dans la fournaise de feu ardent.
###### 22
Là-dessus, comme l’ordre du roi était strict et la fournaise extrêmement chauffée, la flamme brûla à mort les hommes qui y portaient Sidrac, Misac et Abdénago.
###### 23
Et ces trois hommes, Sidrac, Misac et Abdénago, tombèrent, ligotés, au milieu de la fournaise de feu ardent.
###### 24
Or ils marchaient au milieu des flammes, ils louaient Dieu et bénissaient le Seigneur.
###### 25
Azarias, debout, priait ainsi ; au milieu du feu, ouvrant la bouche, il dit :
###### 26
« Béni sois-tu, Seigneur, Dieu de nos pères,
loué sois-tu, glorifié soit ton nom pour les siècles !
###### 27
Oui, tu es juste
en tout ce que tu as fait !
[Toutes tes œuvres sont vraies ;
ils sont droits, tes chemins,
et tous tes jugements sont vérité.
###### 28
Tes sentences de vérité, tu les as exécutées
par tout ce que tu nous as infligé,
à nous et à Jérusalem, la ville sainte de nos pères.
Avec vérité et justice, tu as infligé tout cela
à cause de nos péchés.]
###### 29
Car nous avons péché ;
quand nous t’avons quitté, nous avons fait le mal :
en tout, nous avons failli.
[
###### 30
Nous n’avons pas écouté tes commandements,
nous n’avons pas observé ni accompli
ce qui nous était commandé pour notre bien.
###### 31
Oui, tout ce que tu nous as infligé,
tout ce que tu nous as fait,
tu l’as fait par un jugement de vérité.
###### 32
Tu nous as livrés aux mains de nos ennemis,
gens sans loi, les plus odieux des renégats,
à un roi injuste, le pire de toute la terre.
###### 33
Maintenant, nous ne pouvons plus ouvrir la bouche :
ceux qui te servent et qui t’adorent n’ont plus en partage
que la honte et l’injure.]
###### 34
À cause de ton nom, ne nous livre pas pour toujours
et ne romps pas ton alliance.
###### 35
Ne nous retire pas ta miséricorde,
à cause d’Abraham, ton ami,
d’Isaac, ton serviteur,
et d’Israël que tu as consacré.
###### 36
Tu as dit que tu rendrais leur descendance
aussi nombreuse que les astres du ciel,
que le sable au rivage des mers.
###### 37
Or nous voici, ô Maître,
le moins nombreux de tous les peuples,
humiliés aujourd’hui sur toute la terre,
à cause de nos péchés.
###### 38
Il n’est plus, en ce temps, ni prince ni chef ni prophète,
plus d’holocauste ni de sacrifice,
plus d’oblation ni d’offrande d’encens,
plus de lieu où t’offrir nos prémices
pour obtenir ta miséricorde.
###### 39
Mais, avec nos cœurs brisés,
nos esprits humiliés, reçois-nous,
###### 40
comme un holocauste de béliers, de taureaux,
d’agneaux gras par milliers.
Que notre sacrifice, en ce jour,
trouve grâce devant toi,
car il n’est pas de honte
pour qui espère en toi.
###### 41
Et maintenant, de tout cœur, nous te suivons,
nous te craignons et nous cherchons ta face.
###### 42
Ne nous laisse pas dans la honte,
agis envers nous selon ton indulgence
et l’abondance de ta miséricorde.
###### 43
Délivre-nous en renouvelant tes merveilles,
glorifie ton nom, Seigneur.
###### 44
Qu’ils soient tous confondus,
ceux qui causent du tort à tes serviteurs !
Qu’ils soient couverts de honte, privés de tout pouvoir,
et que leur force soit brisée !
###### 45
Qu’ils sachent que toi, tu es le Seigneur, le seul Dieu,
glorieux sur toute la terre ! »
###### 46
Les serviteurs du roi qui les avaient jetés dans la fournaise ne cessaient d’alimenter le feu avec du bitume, de la poix, de l’étoupe et des sarments,
###### 47
et la flamme s’élevait de quarante-neuf coudées au-dessus de la fournaise.
###### 48
En se propageant, elle brûla ceux des Chaldéens qu’elle trouva autour de la fournaise.
###### 49
Mais l’ange du Seigneur était descendu dans la fournaise en même temps qu’Azarias et ses compagnons ; la flamme du feu, il l’écarta de la fournaise
###### 50
et fit souffler comme un vent de rosée au milieu de la fournaise. Le feu ne les toucha pas du tout, et ne leur causa ni douleur ni dommage.
###### 51
Puis, d’une seule voix, les trois jeunes gens se mirent à louer, à glorifier et à bénir Dieu en disant :
###### 52
« Béni sois-tu, Seigneur, Dieu de nos pères :
à toi, louange et gloire éternellement !
Béni soit le nom très saint de ta gloire :
à toi, louange et gloire éternellement !
###### 53
Béni sois-tu dans ton saint temple de gloire :
à toi, louange et gloire éternellement !
###### 54
Béni sois-tu sur le trône de ton règne :
à toi, louange et gloire éternellement !
###### 55
Béni sois-tu, toi qui sondes les abîmes :
à toi, louange et gloire éternellement !
Toi qui sièges au-dessus des Kéroubim :
à toi, louange et gloire éternellement !
###### 56
Béni sois-tu au firmament, dans le ciel,
à toi, louange et gloire éternellement !
(
57) Toutes les œuvres du Seigneur, bénissez-le :
à toi, louange et gloire éternellement ! »
###### 57
« Toutes les œuvres du Seigneur,
bénissez le Seigneur :
À lui, haute gloire, louange éternelle !
###### 58
Vous, les anges du Seigneur,
bénissez le Seigneur :
À lui, haute gloire, louange éternelle !
###### 59
Vous, les cieux,
bénissez le Seigneur,
###### 60
et vous, les eaux par-dessus le ciel,
bénissez le Seigneur,
###### 61
et toutes les puissances du Seigneur,
bénissez le Seigneur !
###### 62
Et vous, le soleil et la lune,
bénissez le Seigneur,
###### 63
et vous, les astres du ciel,
bénissez le Seigneur,
###### 64
vous toutes, pluies et rosées,
bénissez le Seigneur !
###### 65
Vous tous, souffles et vents,
bénissez le Seigneur,
###### 66
et vous, le feu et la chaleur,
bénissez le Seigneur,
###### 67
et vous, la fraîcheur et le froid,
bénissez le Seigneur !
###### 68
Et vous, le givre et la rosée,
bénissez le Seigneur,
###### 69
et vous, le gel et le froid,
bénissez le Seigneur,
###### 70
et vous, la glace et la neige,
bénissez le Seigneur !
###### 71
Et vous, les nuits et les jours,
bénissez le Seigneur,
###### 72
et vous, la lumière et les ténèbres,
bénissez le Seigneur,
###### 73
et vous, les éclairs, les nuées,
bénissez le Seigneur !
À lui, haute gloire, louange éternelle !
###### 74
Que la terre bénisse le Seigneur :
À lui, haute gloire, louange éternelle !
###### 75
Et vous, montagnes et collines,
bénissez le Seigneur,
###### 76
et vous, les plantes de la terre,
bénissez le Seigneur,
###### 77
et vous, sources et fontaines,
bénissez le Seigneur !
###### 78
Et vous, océans et rivières,
bénissez le Seigneur,
###### 79
baleines et bêtes de la mer,
bénissez le Seigneur,
###### 80
vous tous, les oiseaux dans le ciel,
bénissez le Seigneur,
###### 81
vous tous, fauves et troupeaux,
bénissez le Seigneur
À lui, haute gloire, louange éternelle !
###### 82
Et vous, les enfants des hommes,
bénissez le Seigneur :
À lui, haute gloire, louange éternelle !
###### 83
Toi, Israël,
bénis le Seigneur,
###### 84
Et vous, les prêtres,
bénissez le Seigneur,
###### 85
vous, ses serviteurs,
bénissez le Seigneur !
###### 86
Les esprits et les âmes des justes,
bénissez le Seigneur,
###### 87
les saints et les humbles de cœur,
bénissez le Seigneur,
###### 88
Ananias, Azarias et Misaël,
bénissez le Seigneur :
À lui, haute gloire, louange éternelle !
Il nous a délivrés des enfers,
sauvés du pouvoir de la mort,
il nous a tirés de la fournaise ardente,
retirés du milieu du feu.
###### 89
Rendez grâce au Seigneur : il est bon,
éternel est son amour !
###### 90
Vous tous qui adorez le Seigneur,
bénissez le Dieu des dieux ;
chantez et rendez grâce :
éternel est son amour ! »
###### 91
(
24) Alors, le roi Nabucodonosor fut stupéfait. Il se leva précipitamment et dit à ses conseillers : « Nous avons bien jeté trois hommes, ligotés, au milieu du feu ? » Ils répondirent : « Assurément, ô roi. »
###### 92
(
25) Il reprit : « Eh bien moi, je vois quatre hommes qui se promènent librement au milieu du feu, ils sont parfaitement indemnes, et le quatrième ressemble à un être divin. »
###### 93
(
26) Alors Nabucodonosor s’approcha de l’ouverture de la fournaise de feu ardent. Il appela : « Sidrac, Misac et Abdénago, serviteurs du Dieu Très-Haut, sortez et venez ici ! » Alors Sidrac, Misac et Abdénago sortirent du milieu du feu.
###### 94
(
27) Les satrapes, les préfets, les gouverneurs et les conseillers du roi, s’étant rassemblés, regardèrent ces hommes : le feu n’avait pas eu de pouvoir sur leurs corps, leurs cheveux n’avaient pas été brûlés, leurs manteaux n’avaient pas été abîmés et l’odeur de feu ne les avait pas imprégnés.
###### 95
(
28) Et Nabucodonosor s’écria : « Béni soit le Dieu de Sidrac, Misac et Abdénago, qui a envoyé son ange et délivré ses serviteurs ! Ils ont mis leur confiance en lui, et ils ont désobéi à l’ordre du roi ; ils ont livré leur corps plutôt que de servir et d’adorer un autre dieu que leur Dieu.
###### 96
(
29) Voici ce que j’ordonne à tous les peuples, nations et gens de toutes langues : Si quelqu’un parle avec insolence du Dieu de Sidrac, Misac et Abdénago, qu’il soit mis en pièces et sa maison transformée en décombres. Car aucun autre dieu ne peut délivrer de cette manière. »
###### 97
(
30) Et le roi assura la prospérité de Sidrac, Misac et Abdénago, dans la province de Babylone.
###### 98
(
31) De Nabucodonosor, le roi, à tous les peuples, nations et gens de toutes langues qui habitent sur toute la terre : Paix en abondance !
###### 99
(
32) Je veux faire connaître les signes et les merveilles que le Dieu Très-Haut a faits pour moi.
###### 100
(
33) Ses signes, comme ils sont grands !
Ses merveilles, comme elles sont puissantes !
Son royaume est un royaume éternel,
son pouvoir s’étend d’âge en âge.
