---
aliases : 
- Daniel 14
- Daniel 14
- Dn 14
tags : 
- Bible/Dn/14
- français
cssclass : français
---

# Daniel 14

###### 01
Le roi Astyage fut réuni à ses pères, et Cyrus le Perse régna à sa place.
###### 02
Daniel vivait auprès du roi, comme le plus honoré de ses amis.
###### 03
Or, les Babyloniens avaient une idole appelée Bel. Chaque jour, ils dépensaient pour elle environ cinquante kilos de farine, quarante brebis et deux cent trente litres de vin.
###### 04
Le roi la vénérait et allait tous les jours l’adorer. Daniel, lui, adorait son Dieu.
###### 05
Le roi lui dit : « Pourquoi n’adores-tu pas le dieu Bel ? » Daniel répondit : « Je n’adore pas les idoles faites de main d’homme, mais le Dieu vivant, qui a créé le ciel et la terre et qui est le Seigneur de toute créature. »
###### 06
Le roi lui dit : « Penses-tu que Bel n’est pas un dieu vivant ? Ne vois-tu pas tout ce qu’il mange et boit chaque jour ? »
###### 07
Daniel se mit à rire et dit : « Ne te laisse pas abuser, ô roi ! Il est en argile au-dedans, en bronze au-dehors, et n’a jamais mangé ni bu. »
###### 08
Le roi se mit en colère, appela ses prêtres et leur dit : « Si vous ne me dites pas qui mange les provisions, vous mourrez.
###### 09
Mais si vous prouvez que c’est Bel qui les mange, alors Daniel mourra pour avoir blasphémé contre Bel. » Daniel dit au roi : « Qu’il soit fait selon ta parole ! »
###### 10
Les prêtres de Bel étaient au nombre de soixante-dix, sans compter les femmes et les enfants. Le roi se rendit avec Daniel au temple de Bel.
###### 11
Les prêtres de Bel dirent : « Nous, nous allons sortir. Toi, ô roi, présente la nourriture et le vin coupé. Puis, tu fermeras la porte et la scelleras de ton anneau.
###### 12
Demain matin, quand tu viendras, si tu ne trouves pas que tout a été mangé par Bel, nous mourrons. Sinon, ce sera Daniel, qui nous a calomniés. »
###### 13
Ils étaient arrogants, car ils avaient aménagé sous la table une entrée secrète, par laquelle ils avaient coutume de s’introduire pour enlever les offrandes.
###### 14
Quand ils furent sortis, le roi présenta la nourriture au dieu Bel. Puis, Daniel donna l’ordre à ses serviteurs d’apporter de la cendre et d’en saupoudrer tout le sanctuaire sans autre témoin que le roi. Alors, ils sortirent, fermèrent la porte et la scellèrent avec l’anneau du roi, puis ils partirent.
###### 15
Durant la nuit, comme à leur habitude les prêtres vinrent avec leurs femmes et leurs enfants. Ils mangèrent et burent tout.
###### 16
Le roi vint de bon matin, et Daniel était avec lui.
###### 17
Il dit : « Daniel, les sceaux sont-ils intacts ? » Il répondit : « Ils sont intacts, ô roi. »
###### 18
Dès qu’il eut ouvert la porte, le roi regarda la table et s’écria : « Tu es grand, ô dieu Bel, et il n’y a pas en toi de tromperie ! »
###### 19
Daniel se mit à rire et empêcha le roi d’avancer plus avant : « Regarde le sol, dit-il, et cherche à qui appartiennent ces traces de pas. »
###### 20
Le roi dit : « Je vois des traces de pas d’hommes, de femmes et d’enfants. »
###### 21
Alors le roi, pris de colère, fit arrêter les prêtres, leurs femmes et leurs enfants. Ils lui montrèrent la porte secrète par laquelle ils s’introduisaient pour consommer ce qui était sur la table.
###### 22
Le roi les fit tuer et il livra Bel à Daniel, qui renversa l’idole et son temple.
###### 23
Il y avait aussi un grand serpent, qui était vénéré par les Babyloniens.
###### 24
Le roi dit à Daniel : « Tu ne peux pas dire que celui-ci n’est pas un dieu vivant. Adore-le donc ! »
###### 25
Daniel répondit : « C’est le Seigneur mon Dieu que j’adore : c’est lui le Dieu vivant !
###### 26
Ô roi, donne-moi la permission, je tuerai le serpent sans épée ni bâton. » Le roi dit : « Je te la donne. »
###### 27
Daniel prit alors de la poix, de la graisse et des poils. Il fit bouillir le tout et en fit des galettes qu’il jeta dans la gueule du serpent. Le serpent les avala et en creva. Et Daniel dit : « Voyez ce que vous vénérez ! »
###### 28
À cette nouvelle, les Babyloniens, en proie à une vive indignation, s’ameutèrent contre le roi. Ils disaient : « Le roi s’est fait juif : il a renversé Bel, tué le serpent et massacré les prêtres. »
###### 29
Ils vinrent dire au roi : « Livre-nous Daniel, sinon nous allons te tuer, toi et ta famille. »
###### 30
Voyant qu’ils le menaçaient sérieusement, le roi fut contraint de leur livrer Daniel.
###### 31
Ils le jetèrent dans la fosse aux lions, où il resta six jours.
###### 32
Dans la fosse, il y avait sept lions, à qui l’on donnait chaque jour deux corps humains et deux moutons mais, pour qu’ils mangent Daniel, on ne leur donna rien.
###### 33
Il y avait alors en Judée le prophète Habacuc. Il venait de faire cuire une bouillie et de mettre des petits morceaux de pain dans une corbeille, pour aller les porter aux moissonneurs dans les champs.
###### 34
L’ange du Seigneur dit à Habacuc : « Le repas que tu tiens, porte-le à Babylone, à Daniel, dans la fosse aux lions. »
###### 35
Habacuc dit : « Seigneur, je n’ai jamais vu Babylone et je ne connais pas la fosse. »
###### 36
L’ange du Seigneur le saisit par le sommet de la tête, le porta par les cheveux et, dans la violence de son souffle, le déposa à Babylone au-dessus de la fosse.
###### 37
Habacuc cria : « Daniel, Daniel, prends le repas que Dieu t’envoie ! »
###### 38
Daniel dit alors : « Tu t’es souvenu de moi, mon Dieu ; tu n’abandonnes pas ceux qui t’aiment. »
###### 39
Il se leva et mangea. L’ange de Dieu ramena aussitôt Habacuc à l’endroit d’où il venait.
###### 40
Le septième jour, le roi vint pleurer Daniel. Il arriva à la fosse et regarda. Voici que Daniel s’y trouvait, assis.
###### 41
Alors le roi s’écria d’une voix forte : « Tu es grand, Seigneur, Dieu de Daniel ! Il n’est pas d’autre Dieu que toi ! »
###### 42
Puis il fit sortir Daniel de la fosse et y jeta ceux qui avaient voulu causer sa perte : ils furent aussitôt dévorés devant lui.
