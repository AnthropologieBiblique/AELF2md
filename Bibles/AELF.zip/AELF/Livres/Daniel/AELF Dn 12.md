---
aliases : 
- Daniel 12
- Daniel 12
- Dn 12
tags : 
- Bible/Dn/12
- français
cssclass : français
---

# Daniel 12

###### 01
En ce temps-là se lèvera Michel, le chef des anges,
celui qui se tient auprès des fils de ton peuple.
Car ce sera un temps de détresse
comme il n’y en a jamais eu
depuis que les nations existent,
jusqu’à ce temps-ci.
Mais en ce temps-ci, ton peuple sera délivré,
tous ceux qui se trouveront inscrits dans le Livre.
###### 02
Beaucoup de gens qui dormaient
dans la poussière de la terre
s’éveilleront, les uns pour la vie éternelle,
les autres pour la honte et la déchéance éternelles.
###### 03
Ceux qui ont l’intelligence resplendiront
comme la splendeur du firmament,
et ceux qui sont des maîtres de justice pour la multitude
brilleront comme les étoiles pour toujours et à jamais.
###### 04
Et toi, Daniel, tiens secrètes ces paroles, garde le Livre scellé jusqu’au temps de la fin. Beaucoup seront perplexes, mais la connaissance augmentera. »
###### 05
Et moi, Daniel, je regardai : Voici que deux autres hommes se tenaient, chacun sur une rive du fleuve.
###### 06
L’un d’eux dit à celui qui, vêtu de lin, se tenait au-dessus des eaux du fleuve : « À quand la fin de ces choses surprenantes ? »
###### 07
J’entendis l’homme vêtu de lin qui se tenait au-dessus des eaux du fleuve. Il leva la main droite et la main gauche vers le ciel et jura par Celui qui vit à jamais : « Pendant un temps, des temps, et la moitié d’un temps. Lorsque la force du peuple saint sera entièrement brisée, tout cela s’arrêtera. »
###### 08
Et moi, j’entendis sans comprendre. J’insistai : « Mon seigneur, quel sera le terme de tout cela ? »
###### 09
Il dit : « Va, Daniel, car ces paroles resteront secrètes et scellées jusqu’au temps de la fin. »
###### 10
Beaucoup seront purifiés, blanchis, épurés. Les méchants feront le mal, aucun d’entre eux ne comprendra, mais ceux qui ont l’intelligence comprendront.
###### 11
Depuis l’instant où le sacrifice perpétuel aura cessé, quand l’Abomination de la désolation sera installée, 1 290 jours passeront.
###### 12
Heureux celui qui attendra et parviendra à 1 335 jours !
###### 13
Et toi, va jusqu’à la fin. Tu te reposeras, puis tu te tiendras debout pour recevoir ta part à la fin des jours.
