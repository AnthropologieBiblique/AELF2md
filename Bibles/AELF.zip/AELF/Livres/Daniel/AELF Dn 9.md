---
aliases : 
- Daniel 9
- Daniel 9
- Dn 9
tags : 
- Bible/Dn/9
- français
cssclass : français
---

# Daniel 9

###### 01
La première année du règne de Darius, fils d’Assuérus, de la race des Mèdes, qui était devenu roi des Chaldéens,
###### 02
la première année de son règne, moi, Daniel, je déchiffrais dans les livres le nombre d’années qui, selon la parole adressée par le Seigneur au prophète Jérémie, devaient s’écouler avant que prenne fin la ruine de Jérusalem : soixante-dix ans.
###### 03
Tournant le visage vers le Seigneur Dieu, je lui offris mes prières et mes supplications dans le jeûne, le sac et la cendre.
###### 04
Je fis au Seigneur mon Dieu cette prière et cette confession :
« Ah ! toi Seigneur, le Dieu grand et redoutable, qui garde alliance et fidélité à ceux qui l’aiment et qui observent ses commandements,
###### 05
nous avons péché, nous avons commis l’iniquité, nous avons fait le mal, nous avons été rebelles, nous nous sommes détournés de tes commandements et de tes ordonnances.
###### 06
Nous n’avons pas écouté tes serviteurs les prophètes, qui ont parlé en ton nom à nos rois, à nos princes, à nos pères, à tout le peuple du pays.
###### 07
À toi, Seigneur, la justice ; à nous la honte au visage, comme on le voit aujourd’hui pour les gens de Juda, pour les habitants de Jérusalem et de tout Israël, pour ceux qui sont près et pour ceux qui sont loin, dans tous les pays où tu les as chassés, à cause des infidélités qu’ils ont commises envers toi.
###### 08
Seigneur, à nous la honte au visage, à nos rois, à nos princes, à nos pères, parce que nous avons péché contre toi.
###### 09
Au Seigneur notre Dieu, la miséricorde et le pardon, car nous nous sommes révoltés contre lui,
###### 10
nous n’avons pas écouté la voix du Seigneur, notre Dieu, car nous n’avons pas suivi les lois qu’il nous proposait par ses serviteurs les prophètes.
###### 11
Tout Israël a transgressé ta loi, il s’est détourné sans écouter ta voix. Alors, les malédictions et les menaces inscrites dans la loi de Moïse, le serviteur de Dieu, se sont répandues sur nous, parce que nous avons péché contre le Seigneur.
###### 12
Celui-ci a mis à exécution les paroles prononcées contre nous et contre nos gouvernants. Il a fait venir contre nous une calamité si grande que, nulle part, il ne s’en est produit de semblable sous les cieux, sauf à Jérusalem.
###### 13
Tout ce malheur est venu sur nous, selon ce qui est écrit dans la loi de Moïse. Mais nous n’avons pas apaisé la face du Seigneur notre Dieu, puisque nous ne sommes pas revenus de nos fautes en prêtant attention à la vérité.
###### 14
Le Seigneur a veillé à ce que le malheur nous atteigne, car le Seigneur notre Dieu est juste en tout ce qu’il accomplit, mais nous n’avons pas écouté sa voix.
###### 15
Et maintenant, Seigneur notre Dieu, toi qui, d’une main forte, as fait sortir ton peuple du pays d’Égypte, toi qui t’es fait un nom, comme on le voit aujourd’hui, nous avons péché et nous avons été coupables.
###### 16
Seigneur, en raison de toutes tes justes actions, que ta colère et ta fureur se détournent de Jérusalem, ta ville et ta montagne sainte ! Car à cause de nos péchés et des fautes de nos pères, Jérusalem et ton peuple sont objet d’insulte pour tous ceux qui nous environnent.
###### 17
Et maintenant, notre Dieu, écoute la prière de ton serviteur et ses supplications. Pour ta cause, Seigneur, fais briller ton visage sur ton Lieu saint dévasté.
###### 18
Mon Dieu, tends l’oreille et écoute, ouvre les yeux et regarde nos dévastations et la ville sur laquelle on invoque ton nom. Si nous déposons nos supplications devant toi, ce n’est pas au titre de nos œuvres de justice, mais de ta grande miséricorde.
###### 19
Seigneur, écoute ! Seigneur, pardonne ! Seigneur, sois attentif et agis ! Ne tarde pas ! C’est pour ta cause, mon Dieu, car c’est ton nom qui est invoqué sur ta ville et ton peuple ! »
###### 20
Je parlais encore, priant, confessant mon péché et le péché de mon peuple Israël, déposant ma supplication devant le Seigneur mon Dieu, pour la montagne sainte de mon Dieu ;
###### 21
je parlais encore dans ma prière quand Gabriel – l’être que j’avais vu au commencement de la vision – s’approcha de moi d’un vol rapide à l’heure de l’offrande du soir.
###### 22
Il m’instruisit, me parlant en ces termes : « Daniel, je suis sorti maintenant pour ouvrir ton intelligence.
###### 23
Dès le début de ta supplication, une parole a surgi, et je suis venu te l’annoncer, car toi, tu es aimé de Dieu. Comprends la parole et cherche à comprendre l’apparition.
###### 24
Soixante-dix semaines ont été fixées
à ton peuple et à ta ville sainte,
pour faire cesser la perversité
et mettre un terme au péché,
pour expier la faute
et amener la justice éternelle,
pour accomplir vision et prophétie,
et consacrer le Saint des saints.
###### 25
Sache et comprends ! Depuis l’instant où fut donné l’ordre de rebâtir Jérusalem jusqu’à l’avènement d’un messie, un chef, il y aura sept semaines. Pendant soixante-deux semaines, on rebâtira les places et les remparts, mais ce sera dans la détresse des temps.
###### 26
Et après les soixante-deux semaines, un messie sera supprimé. Le peuple d’un chef à venir détruira la ville et le Lieu saint. Puis, dans un déferlement, sa fin viendra. Jusqu’à la fin de la guerre, les dévastations décidées auront lieu.
###### 27
Durant une semaine, ce chef renforcera l’alliance avec une multitude ; pendant la moitié de la semaine, il fera cesser le sacrifice et l’offrande, et sur une aile du Temple il y aura l’Abomination de la désolation, jusqu’à ce que l’extermination décidée fonde sur l’auteur de cette désolation. »
