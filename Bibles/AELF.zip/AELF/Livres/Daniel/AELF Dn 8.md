---
aliases : 
- Daniel 8
- Daniel 8
- Dn 8
tags : 
- Bible/Dn/8
- français
cssclass : français
---

# Daniel 8

###### 01
La troisième année du règne du roi Balthazar, une vision m’est apparue, à moi, Daniel, après celle qui m’était apparue précédemment.
###### 02
Je regardai, et voici que, dans la vision, j’étais à Suse-la-Citadelle dans la province d’Élam, près de la rivière Oulaï.
###### 03
Je levai les yeux, et voici que je vis un bélier se tenant face à la rivière. Il avait deux cornes, deux hautes cornes, mais l’une plus haute que l’autre, et la plus haute se dressa en dernier.
###### 04
Je vis le bélier donner des coups de corne vers l’ouest, vers le nord, vers le sud. Aucune bête ne pouvait tenir debout devant lui, personne ne pouvait lui échapper. Il agissait selon son bon plaisir et ne cessait de grandir.
###### 05
Moi, j’étais en train de réfléchir, et voici qu’un bouc arriva de l’occident, survolant toute la terre sans toucher le sol. Il avait une corne imposante entre les yeux.
###### 06
Il s’approcha du bélier à deux cornes que j’avais vu dressé face à la rivière et se rua vers lui de toute sa force.
###### 07
Je le vis atteindre le bélier et se mettre en rage contre lui, puis le frapper et briser ses deux cornes. Le bélier n’avait pas la force de lui faire face. Il le jeta à terre et le piétina. Personne ne pouvait en délivrer le bélier.
###### 08
Le bouc ne cessait de croître mais, au sommet de sa puissance, la grande corne se brisa. Quatre cornes imposantes poussèrent à sa place, orientées vers les quatre points cardinaux.
###### 09
De l’une d’elle, une toute petite corne sortit, mais qui grandit vers le sud, vers l’est, et vers le Pays magnifique.
###### 10
Elle grandit jusqu’à l’armée du ciel, elle terrassa une partie de cette armée et des étoiles, elle les piétina.
###### 11
Elle grandit même jusqu’au chef de l’armée, le sacrifice perpétuel fut retiré à celui-ci, et les fondations de son Lieu saint furent renversées.
###### 12
Et une armée fut postée contre le sacrifice perpétuel de façon perverse. La corne jeta la vérité par terre. Ce qu’elle entreprit, elle le réussit.
###### 13
Un être saint parla, je l’entendis ; et un autre saint lui répondit : « Combien de temps verrons-nous le sacrifice perpétuel retiré, la perversité dévastatrice, le sanctuaire livré, l’armée piétinée ? »
###### 14
Il lui dit : « Encore deux mille trois cents soirs et matins, et le Lieu saint sera rétabli dans ses droits. »
###### 15
Tandis que moi, Daniel, je regardais la vision en cherchant à comprendre, voici que se tenait en face de moi quelqu’un ayant l’apparence d’un homme.
###### 16
Et j’entendis la voix de l’homme entre les rives de l’Oulaï. Il cria : « Gabriel, fais-lui comprendre la vision ! »
###### 17
Il s’avança vers le lieu où je me tenais. À son approche, je fus effrayé et je tombai face contre terre. Il me dit : « Fils d’homme, comprends ! La vision concerne le temps de la fin. »
###### 18
Tandis qu’il me parlait, je m’évanouis, la face contre terre. Il me toucha et me fit mettre debout à l’endroit où j’étais.
###### 19
Il dit : « Je vais te faire savoir ce qui arrivera au terme de la colère, car la fin est pour le moment fixé.
###### 20
Le bélier à deux cornes que tu as vu, ce sont les deux rois de Médie et de Perse.
###### 21
Le bouc velu, c’est le roi de Grèce, et la grande corne entre ses yeux, c’est le premier roi.
###### 22
Si elle s’est brisée et que quatre ont surgi à sa place, c’est que quatre royaumes surgiront de sa nation, mais sans avoir sa force.
###### 23
Au terme de leur règne, quand les pécheurs
auront atteint le comble de leur perversité,
se lèvera un roi au visage fier,
sachant pénétrer les énigmes.
###### 24
Sa puissance se renforcera
– mais non par sa propre puissance –,
il opérera des destructions prodigieuses,
il réussira dans ce qu’il entreprendra,
il détruira des puissants
et le peuple des saints.
###### 25
Par son habileté, il assurera le succès de ses tromperies ;
son cœur s’enflera d’orgueil
et, dans la tranquillité, il détruira une multitude.
Il se dressera contre le Prince des princes,
mais il sera brisé sans l’intervention de personne.
###### 26
Ce que tu as vu et ce qui a été dit
au sujet des soirs et des matins,
c’est la vérité.
Mais toi, garde secrète la vision,
car elle concerne des jours lointains. »
###### 27
Et moi, Daniel, je m’évanouis et je fus malade pendant plusieurs jours. Puis je me levai et accomplis mon office auprès du roi ; j’étais terrifié par ce que j’avais vu, mais personne ne comprenait.
