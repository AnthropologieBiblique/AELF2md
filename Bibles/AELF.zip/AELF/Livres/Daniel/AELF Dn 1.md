---
aliases : 
- Daniel 1
- Daniel 1
- Dn 1
tags : 
- Bible/Dn/1
- français
cssclass : français
---

# Daniel 1

###### 01
LA TROISIEME ANNEE du règne de Joakim, roi de Juda, Nabucodonosor, roi de Babylone, arriva devant Jérusalem et l’assiégea.
###### 02
Le Seigneur livra entre ses mains Joakim, roi de Juda, ainsi qu’une partie des objets de la Maison de Dieu. Il les emporta au pays de Babylone, et les déposa dans le trésor de ses dieux.
###### 03
Le roi ordonna à Ashpénaz, chef de ses eunuques, de faire venir quelques jeunes Israélites de race royale ou de famille noble.
###### 04
Ils devaient être sans défaut corporel, de belle figure, exercés à la sagesse, instruits et intelligents, pleins de vigueur, pour se tenir à la cour du roi et apprendre l’écriture et la langue des Chaldéens.
###### 05
Le roi leur assignait pour chaque jour une portion des mets royaux et du vin de sa table. Ils devaient être formés pendant trois ans, et ensuite ils entreraient au service du roi.
###### 06
Parmi eux se trouvaient Daniel, Ananias, Misaël et Azarias, qui étaient de la tribu de Juda.
###### 07
Le chef des eunuques leur imposa des noms : à Daniel celui de Beltassar, à Ananias celui de Sidrac, à Misaël celui de Misac, et à Azarias celui d’Abdénago.
###### 08
Daniel eut à cœur de ne pas se souiller avec les mets du roi et le vin de sa table, il supplia le chef des eunuques de lui épargner cette souillure.
###### 09
Dieu permit à Daniel de trouver auprès de celui-ci faveur et bienveillance.
###### 10
Mais il répondit à Daniel : « J’ai peur de mon Seigneur le roi, qui a fixé votre nourriture et votre boisson ; s’il vous voit le visage plus défait qu’aux jeunes gens de votre âge, c’est moi qui, à cause de vous, risquerai ma tête devant le roi. »
###### 11
Or, le chef des eunuques avait confié Daniel, Ananias, Azarias et Misaël à un intendant. Daniel lui dit :
###### 12
« Fais donc pendant dix jours un essai avec tes serviteurs : qu’on nous donne des légumes à manger et de l’eau à boire.
###### 13
Tu pourras comparer notre mine avec celle des jeunes gens qui mangent les mets du roi, et tu agiras avec tes serviteurs suivant ce que tu auras constaté. »
###### 14
L’intendant consentit à leur demande, et les mit à l’essai pendant dix jours.
###### 15
Au bout de dix jours, ils avaient plus belle mine et meilleure santé que tous les jeunes gens qui mangeaient des mets du roi.
###### 16
L’intendant supprima définitivement leurs mets et leur ration de vin, et leur fit donner des légumes.
###### 17
À ces quatre jeunes gens, Dieu accorda science et habileté en matière d’écriture et de sagesse. Daniel, en outre, savait interpréter les visions et les songes.
###### 18
Au terme fixé par le roi Nabucodonosor pour qu’on lui amenât tous les jeunes gens, le chef des eunuques les conduisit devant lui.
###### 19
Le roi s’entretint avec eux, et pas un seul n’était comparable à Daniel, Ananias, Misaël et Azarias. Ils entrèrent donc au service du roi.
###### 20
Sur toutes les questions demandant sagesse et intelligence que le roi leur posait, il les trouvait dix fois supérieurs à tous les magiciens et mages de tout son royaume.
###### 21
Et Daniel vécut jusqu’à la première année du roi Cyrus.
