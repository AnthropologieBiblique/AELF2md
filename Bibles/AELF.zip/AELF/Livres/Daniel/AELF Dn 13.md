---
aliases : 
- Daniel 13
- Daniel 13
- Dn 13
tags : 
- Bible/Dn/13
- français
cssclass : français
---

# Daniel 13

###### 01
Il y avait un habitant de Babylone qui se nommait Joakim.
###### 02
Il avait épousé une femme nommée Suzanne, fille d’Helkias. Elle était très belle et craignait le Seigneur.
###### 03
Ses parents étaient des justes, et ils avaient élevé leur fille selon la loi de Moïse.
###### 04
Joakim était très riche, et il possédait un jardin auprès de sa maison ; les Juifs affluaient chez lui, car il était le plus illustre d’entre eux.
###### 05
Deux anciens avaient été désignés dans le peuple pour être juges cette année-là ; ils étaient de ceux dont le Seigneur a dit : « Le crime est venu de Babylone par des anciens, par des juges qui prétendaient guider le peuple. »
###### 06
Ils fréquentaient la maison de Joakim, et tous ceux qui avaient des procès venaient les trouver.
###### 07
Lorsque le peuple s’était retiré, vers midi, Suzanne entrait dans le jardin de son mari, et s’y promenait.
###### 08
Les deux anciens la voyaient chaque jour entrer et se promener, et ils se mirent à la désirer :
###### 09
ils pervertirent leur pensée, ils détournèrent leurs yeux pour ne plus regarder vers le ciel et ne plus se rappeler ses justes décrets.
###### 10
Tous deux brûlaient de convoitise, mais ne se l’avouaient pas l’un à l’autre,
###### 11
car ils avaient honte d’avouer leur désir de s’unir à elle.
###### 12
Chaque jour, ils guettaient avidement l’occasion de la voir.
###### 13
Un jour, ils se dirent l’un à l’autre : « Rentrons chez nous, c’est l’heure de déjeuner », et ils se séparèrent.
###### 14
Mais chacun revint sur ses pas, et ils se retrouvèrent au même endroit. Se questionnant alors mutuellement, ils s’avouèrent leur désir. Et ils se mirent d’accord sur le moment où ils pourraient la trouver seule.
###### 15
Ils guettaient le jour favorable, lorsque Suzanne entra, comme la veille et l’avant-veille, accompagnée seulement de deux jeunes filles ; il faisait très chaud, et elle eut envie de prendre un bain dans le jardin.
###### 16
Il n’y avait personne, en dehors des deux anciens qui s’étaient cachés et qui l’épiaient.
###### 17
Suzanne dit aux jeunes filles : « Apportez-moi de quoi me parfumer et me laver, puis fermez les portes du jardin, pour que je puisse prendre mon bain. »
###### 18
Ainsi firent-elles : fermant la porte du jardin, elles entrèrent dans la maison par la porte de service pour y chercher ce que Suzanne leur avait demandé. Elles ne virent pas les anciens, qui étaient cachés.
###### 19
Dès que les jeunes filles furent sorties, les deux anciens surgirent, coururent vers Suzanne
###### 20
et lui dirent : « Les portes du jardin sont fermées, on ne nous voit pas ; nous te désirons, sois consentante et viens avec nous.
###### 21
Autrement nous porterons contre toi ce témoignage : il y avait un jeune homme avec toi, et c’est pour cela que tu as renvoyé les jeunes filles. »
###### 22
Suzanne dit en gémissant : « De tous côtés, je suis prise au piège : si je vous cède, c’est la mort pour moi ; et si je refuse de céder, je n’échapperai pas à vos mains.
###### 23
Mieux vaut pour moi tomber entre vos mains sans vous céder, plutôt que de pécher aux yeux du Seigneur. »
###### 24
Alors Suzanne poussa un grand cri, et les deux anciens se mirent à crier contre elle.
###### 25
L’un d’eux courut ouvrir les portes du jardin.
###### 26
Les gens de la maison, entendant crier dans le jardin, se précipitèrent par la porte de service pour voir ce qui arrivait à Suzanne.
###### 27
Quand les anciens eurent raconté leur histoire, les serviteurs furent remplis de honte, car jamais on n’avait dit pareille chose de Suzanne.
###### 28
Le lendemain, le peuple se rassembla chez Joakim son mari. Les deux anciens arrivèrent, remplis de pensées criminelles contre Suzanne, et décidés à la faire mourir. Ils dirent devant le peuple :
###### 29
« Envoyez chercher Suzanne, fille d’Helkias, épouse de Joakim. » On l’envoya chercher.
###### 30
Elle se présenta avec ses parents, ses enfants et tous ses proches.
###### 31
Suzanne avait les traits délicats et elle était belle à voir.
###### 32
Comme elle était voilée, ces misérables ordonnèrent qu’on la dévoile, pour pouvoir profiter de sa beauté.
###### 33
Tous les siens pleuraient, ainsi que tous ceux qui la voyaient.
###### 34
Les deux anciens se levèrent au milieu du peuple, et posèrent les mains sur sa tête.
###### 35
Tout en pleurs, elle leva les yeux vers le ciel, car son cœur était plein de confiance dans le Seigneur.
###### 36
Les anciens déclarèrent : « Comme nous nous promenions seuls dans le jardin, cette femme y est entrée avec deux servantes. Elle a fermé les portes et renvoyé les servantes.
###### 37
Alors un jeune homme qui était caché est venu vers elle, et a couché avec elle.
###### 38
Nous étions dans un coin du jardin, nous avons vu le crime, et nous avons couru vers eux.
###### 39
Nous les avons vus s’unir, mais nous n’avons pas pu nous emparer du jeune homme, car il était plus fort que nous : il a ouvert la porte et il s’est échappé.
###### 40
Mais elle, nous l’avons saisie, et nous lui avons demandé qui était ce jeune homme ;
###### 41
elle n’a pas voulu nous le dire. De tout cela, nous sommes témoins. »
L’assemblée les crut, car c’étaient des anciens du peuple et des juges, et Suzanne fut condamnée à mort.
###### 42
Alors elle cria d’une voix forte : « Dieu éternel, toi qui pénètres les secrets, toi qui connais toutes choses avant qu’elles n’arrivent,
###### 43
tu sais qu’ils ont porté contre moi un faux témoignage. Voici que je vais mourir, sans avoir rien fait de tout ce que leur méchanceté a imaginé contre moi. »
###### 44
Le Seigneur entendit sa voix.
###### 45
Comme on la conduisait à la mort, Dieu éveilla l’esprit de sainteté chez un tout jeune garçon nommé Daniel,
###### 46
qui se mit à crier d’une voix forte : « Je suis innocent de la mort de cette femme ! »
###### 47
Tout le peuple se tourna vers lui et on lui demanda : « Que signifie cette parole que tu as prononcée ? »
###### 48
Alors, debout au milieu du peuple, il leur dit : « Fils d’Israël, vous êtes donc fous ? Sans interrogatoire, sans recherche de la vérité, vous avez condamné une fille d’Israël.
###### 49
Revenez au tribunal, car ces gens-là ont porté contre elle un faux témoignage. »
###### 50
Tout le peuple revint donc en hâte, et le collège des anciens dit à Daniel : « Viens siéger au milieu de nous et donne-nous des explications, car Dieu a déjà fait de toi un ancien. »
###### 51
Et Daniel leur dit : « Séparez-les bien l’un de l’autre, je vais les interroger. »
###### 52
Quand on les eut séparés, Daniel appela le premier et lui dit : « Toi qui as vieilli dans le mal, tu portes maintenant le poids des péchés que tu as commis autrefois
###### 53
en jugeant injustement : tu condamnais les innocents et tu acquittais les coupables, alors que le Seigneur a dit : “Tu ne feras pas mourir l’innocent et le juste.”
###### 54
Eh bien ! si réellement tu as vu cette femme, dis-nous sous quel arbre tu les as vus se donner l’un à l’autre ? » Il répondit : « Sous un sycomore. »
###### 55
Daniel dit : « Voilà justement un mensonge qui te condamne : l’Ange de Dieu a reçu un ordre de Dieu, et il va te mettre à mort. »
###### 56
Daniel le renvoya, fit amener l’autre et lui dit : « Tu es de la race de Canaan et non de Juda ! La beauté t’a dévoyé et le désir a perverti ton cœur.
###### 57
C’est ainsi que vous traitiez les filles d’Israël, et, par crainte, elles se donnaient à vous. Mais une fille de Juda n’a pu consentir à votre crime.
###### 58
Dis-moi donc sous quel arbre tu les as vus se donner l’un à l’autre ? » Il répondit : « Sous un châtaignier. »
###### 59
Daniel lui dit : « Toi aussi, voilà justement un mensonge qui te condamne : l’Ange de Dieu attend, l’épée à la main, pour te châtier, et vous faire exterminer. »
###### 60
Alors toute l’assemblée poussa une grande clameur et bénit Dieu qui sauve ceux qui espèrent en lui.
###### 61
Puis elle se retourna contre les deux anciens que Daniel avait convaincus de faux témoignage par leur propre bouche. Conformément à la loi de Moïse, on leur fit subir la peine que leur méchanceté avait imaginée contre leur prochain :
###### 62
on les mit à mort. Et ce jour-là, une vie innocente fut épargnée.
###### 63
Helkias et sa femme louèrent Dieu au sujet de leur fille Suzanne, avec Joakim son mari et tous leurs proches, parce qu’il ne s’était trouvé en elle rien de répréhensible.
###### 64
À partir de ce jour, Daniel devint grand aux yeux du peuple.
