---
aliases : 
- Ecclésiaste 3
- Ecclésiaste 3
- Qo 3
- Ecclesiastes 3
tags : 
- Bible/Qo/3
- français
cssclass : français
---

# Ecclésiaste 3

###### 01
Il y a un moment pour tout,
et un temps pour chaque chose sous le ciel :
###### 02
un temps pour donner la vie,
et un temps pour mourir ;
un temps pour planter,
et un temps pour arracher.
###### 03
Un temps pour tuer,
et un temps pour guérir ;
un temps pour détruire
et un temps pour construire.
###### 04
Un temps pour pleurer,
et un temps pour rire ;
un temps pour gémir,
et un temps pour danser.
###### 05
Un temps pour jeter des pierres,
et un temps pour les amasser ;
un temps pour s’étreindre,
et un temps pour s’abstenir.
###### 06
Un temps pour chercher,
et un temps pour perdre ;
un temps pour garder,
et un temps pour jeter.
###### 07
Un temps pour déchirer,
et un temps pour coudre ;
un temps pour se taire,
et un temps pour parler.
###### 08
Un temps pour aimer,
et un temps pour ne pas aimer ;
un temps pour la guerre,
et un temps pour la paix.
###### 09
Quel profit le travailleur retire-t-il
de toute la peine qu’il prend ?
###### 10
J’ai vu la besogne que Dieu impose aux fils d’Adam
pour les tenir en haleine.
###### 11
Toutes les choses que Dieu a faites
sont bonnes en leur temps.
Dieu a mis toute la durée du temps dans l’esprit de l’homme,
mais celui-ci est incapable
d’embrasser l’œuvre que Dieu a faite
du début jusqu’à la fin.
###### 12
J’ai compris qu’il n’y a rien de bon pour les humains,
sinon se réjouir et prendre du bon temps durant leur vie.
###### 13
Bien plus, pour chacun, manger et boire
et trouver le bonheur dans son travail,
c’est un don de Dieu.
###### 14
Je le sais : tout ce que Dieu fait,
à jamais, demeurera.
À cela, il n’y a rien à ajouter,
rien à retrancher.
Dieu fait en sorte
que l’on craigne en sa présence.
###### 15
Ce qui est a déjà été,
ce qui sera a déjà existé.
Dieu fera revenir
ce qui a passé.
###### 16
J’ai vu encore sous le soleil
la corruption sur le siège du droit,
la corruption sur le siège de la justice.
###### 17
Je me suis dit :
le juste et l’injuste,
Dieu les jugera,
car il y a un temps pour chaque chose
et un jugement pour chaque action.
###### 18
Je me suis dit
à propos des fils d’Adam :
Dieu les met à l’épreuve
pour leur montrer qu’ils sont comme les bêtes.
###### 19
Car le sort des fils d’Adam et celui de la bête
sont un seul et même sort.
Comme est la mort de l’un,
ainsi la mort de l’autre :
ils ont tous un seul et même souffle.
L’homme n’a rien de plus que la bête :
tout est vanité.
###### 20
Tout va vers un même lieu :
tout est tiré de la poussière,
et tout retourne à la poussière.
###### 21
Qui sait où va le souffle des fils d’Adam ?
Monte-t-il vers le haut,
tandis que le souffle de la bête
descendrait vers la terre ?
###### 22
Je ne vois rien de mieux pour l’homme
que de jouir de son ouvrage, car tel est son lot.
Qui donc l’emmènera voir
ce qui, après lui, sera ?
