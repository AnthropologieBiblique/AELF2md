---
aliases : 
- Ecclésiaste 11
- Ecclésiaste 11
- Qo 11
- Ecclesiastes 11
tags : 
- Bible/Qo/11
- français
cssclass : français
---

# Ecclésiaste 11

###### 01
Risque ta fortune sur les mers :
après de longs jours, tu la retrouveras.
###### 02
Divise ton bien en sept ou même huit parts :
tu ne sais quel malheur peut arriver dans le pays.
###### 03
Quand les nuages sont gorgés d’eau,
ils déversent leur pluie sur la terre.
Qu’un arbre tombe au nord ou au midi,
là où il est tombé, il restera.
###### 04
Qui attend le bon vent, jamais ne sèmera ;
qui scrute les nuages, jamais ne moissonnera.
###### 05
De même que tu ignores les routes du vent
et comment se forment les os de l’enfant dans le ventre de la mère,
de même tu ne comprends pas l’œuvre de Dieu qui fait toute chose.
###### 06
Dès le matin, sème tes semences,
et jusqu’au soir n’arrête pas ton ouvrage,
car tu ignores ce qui réussira,
ceci ou cela,
ou si les deux ensemble seront bons.
###### 07
Oui, douce est la lumière !
Quel bonheur pour les yeux de voir le soleil !
###### 08
L’homme vivrait-il de longues années,
qu’il se réjouisse de chacune d’elles !
Qu’il songe aussi aux jours de ténèbres,
car ils seront nombreux.
Tout ce qui arrive n’est que vanité.
###### 09
Réjouis-toi, jeune homme, dans ton adolescence,
et sois heureux aux jours de ta jeunesse.
Suis les sentiers de ton cœur
et les désirs de tes yeux !
Mais sache que pour tout cela
Dieu t’appellera en jugement.
###### 10
Éloigne de ton cœur le chagrin,
écarte de ta chair la souffrance
car l’adolescence et le printemps de la vie
ne sont que vanité.
