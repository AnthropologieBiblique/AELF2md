---
aliases : 
- Ecclésiaste 1
- Ecclésiaste 1
- Qo 1
- Ecclesiastes 1
tags : 
- Bible/Qo/1
- français
cssclass : français
---

# Ecclésiaste 1

###### 01
PAROLES de Qohèleth,
  fils de David, roi de Jérusalem.
###### 02
Vanité des vanités disait Qohèleth.
Vanité des vanités, tout est vanité !
###### 03
Quel profit l’homme retire-t-il
de toute la peine qu’il se donne sous le soleil ?
###### 04
Une génération s’en va, une génération s’en vient,
et la terre subsiste toujours.
###### 05
Le soleil se lève, le soleil se couche ;
il se hâte de retourner à sa place,
et de nouveau il se lèvera.
###### 06
Le vent part vers le sud, il tourne vers le nord ;
il tourne et il tourne,
et recommence à tournoyer.
###### 07
Tous les fleuves vont à la mer,
et la mer n’est pas remplie ;
dans le sens où vont les fleuves,
les fleuves continuent de couler.
###### 08
Tout discours est fatigant,
on ne peut jamais tout dire.
L’œil n’a jamais fini de voir,
ni l’oreille d’entendre.
###### 09
Ce qui a existé, c’est cela qui existera ;
ce qui s’est fait, c’est cela qui se fera ;
rien de nouveau sous le soleil.
###### 10
Y a-t-il une seule chose dont on dise :
« Voilà enfin du nouveau ! »
– Non, cela existait déjà dans les siècles passés.
###### 11
Mais, il ne reste pas de souvenir d’autrefois ;
de même, les événements futurs
ne laisseront pas de souvenir après eux.
###### 12
Moi, Qohèleth,
j’étais roi d’Israël à Jérusalem.
###### 13
J’ai pris à cœur de rechercher et d’explorer,
grâce à la sagesse,
tout ce qui se fait sous le ciel ;
c’est là une rude besogne
que Dieu donne aux fils d’Adam
pour les tenir en haleine.
###### 14
J’ai vu tout ce qui se fait et se refait sous le soleil.
Eh bien ! Tout cela n’est que vanité et poursuite du vent.
###### 15
Ce qui est courbé ne se redresse pas
et ce qui manque ne peut être compté.
###### 16
J’ai réfléchi et je me disais :
C’est moi qui ai fait grandir et progresser la sagesse
plus que tous mes prédécesseurs à Jérusalem.
J’ai approfondi la sagesse et le savoir.
###### 17
J’avais à cœur de connaître la sagesse,
de connaître aussi la sottise et la folie,
et j’ai su que cela encore était tourment de l’esprit.
###### 18
Beaucoup de sagesse, c’est beaucoup de chagrin.
Qui augmente son savoir augmente sa douleur.
