---
aliases : 
- Ecclésiaste 9
- Ecclésiaste 9
- Qo 9
- Ecclesiastes 9
tags : 
- Bible/Qo/9
- français
cssclass : français
---

# Ecclésiaste 9

###### 01
Oui, j’ai réfléchi à tout cela,
afin de tout tirer au clair,
que les justes, les sages et leurs actions
sont dans la main de Dieu.
Même l’amour, même la haine,
l’homme ne les comprend pas :
pourtant tout est devant lui.
###### 02
Tout est pareil pour tous ;
il y a un même sort
pour le juste et l’injuste,
le bon et le mauvais,
le pur et l’impur,
pour qui sacrifie ou ne sacrifie pas.
Il en va du bon comme du pécheur,
de celui qui prête serment
et de celui qui craint de le faire.
###### 03
Le pire de ce qui advient sous le soleil
est que tous ont le même sort.
Alors le cœur des fils d’Adam
s’emplit de méchanceté,
la folie mène leur vie ;
puis, ils s’en vont chez les morts.
###### 04
Pour celui qui reste avec tous les vivants
il y a de l’espoir :
chien vivant vaut mieux que lion mort.
###### 05
Car les vivants savent qu’ils mourront,
mais les morts ne savent plus rien.
Pour eux, plus de récompense,
ils sont tombés dans l’oubli.
###### 06
Leurs amours, leurs haines, leurs jalousies
ont déjà disparu.
Plus jamais ils n’auront part
à tout ce qui se fait sous le soleil.
###### 07
Va, mange avec plaisir ton pain
et bois d’un cœur joyeux ton vin,
car Dieu, déjà, prend plaisir à ce que tu fais.
###### 08
Porte tes habits de fête en tout temps,
n’oublie pas de te parfumer la tête.
###### 09
Savoure la vie avec la femme que tu aimes,
chaque jour de cette vie de vanité
qui t’est donnée sous le soleil,
tous ces jours de vanité…
Voilà ton lot dans la vie
et dans la peine que tu prends sous le soleil.
###### 10
Tout ce que ta main trouve à faire,
fais-le avec la force dont tu disposes,
car il n’y a ni travaux, ni projets,
ni science, ni sagesse
au séjour des morts où tu vas.
###### 11
J’ai regardé encore,
et j’ai vu sous le soleil
que la course n’est pas donnée aux plus rapides,
ni aux braves la victoire,
ni aux sages le pain,
ni aux avisés la richesse,
ni aux intelligents la faveur,
car il y a pour chacun d’eux
des temps et des contretemps.
###### 12
L’homme ne connaît même pas son heure :
comme le poisson pris au filet fatal,
comme l’oiseau pris au piège,
ainsi en est-il des fils d’Adam
surpris par le moment fatal
qui tombe sur eux à l’improviste.
###### 13
J’ai vu aussi sous le soleil
un exemple de sagesse qui m’a frappé.
###### 14
Il y avait une petite ville, de peu d’habitants ;
un roi puissant marcha contre elle,
l’assiégea et l’encercla d’ouvrages fortifiés.
###### 15
Or, se trouvait là un homme pauvre et sage
qui sauva la ville par sa sagesse.
Mais ensuite, plus personne ne pensa à cet homme pauvre.
###### 16
Alors j’ai dit :
Mieux vaut la sagesse que la force.
Et pourtant, la sagesse du pauvre est méprisée,
sa parole n’est pas écoutée.
###### 17
La parole tranquille du sage est mieux écoutée
que les éclats de voix d’un chef parmi les sots.
###### 18
Mieux vaut la sagesse que les armes de guerre,
mais un seul incapable peut ruiner des fortunes.
