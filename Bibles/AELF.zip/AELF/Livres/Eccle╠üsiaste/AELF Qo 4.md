---
aliases : 
- Ecclésiaste 4
- Ecclésiaste 4
- Qo 4
- Ecclesiastes 4
tags : 
- Bible/Qo/4
- français
cssclass : français
---

# Ecclésiaste 4

###### 01
J’ai regardé encore et j’ai vu
toutes les oppressions pratiquées sous le soleil.
Voyez les pleurs des opprimés :
ils n’ont pas de consolateur ;
des oppresseurs leur font violence :
ils n’ont pas de consolateur.
###### 02
Les morts qui sont déjà morts,
je les déclare plus heureux
que les vivants encore en vie,
###### 03
et plus heureux que ceux-là
celui qui n’existe pas encore,
car il n’a pas connu le mal
qui se fait sous le soleil.
###### 04
J’ai vu aussi que toute la peine,
tout le succès d’un travail,
n’est que jalousie des uns envers les autres.
C’est encore vanité et poursuite de vent.
###### 05
Le fou se croise les bras :
il consume sa propre vie.
###### 06
Mieux vaut une pleine main de repos
que deux pleines poignées d’efforts
à la poursuite du vent.
###### 07
J’ai regardé encore et j’ai vu
une autre vanité sous le soleil :
###### 08
voici un homme seul,
sans personne, ni frère ni fils,
qui travaille à n’en plus finir,
toujours avide de plus de richesses.
Il ne se demande pas :
« Mais pour qui travailler ainsi
en me privant de bonheur ? »
C’est encore de la vanité,
une besogne de malheur.
###### 09
Mieux vaut être deux qu’un seul :
le salaire de leur peine sera meilleur.
###### 10
S’ils tombent, l’un relève l’autre.
Malheur à l’homme seul :
s’il tombe, personne ne le relève.
###### 11
De même, si l’on dort à deux,
on se tient chaud.
Mais tout seul,
comment se réchauffer ?
###### 12
L’agresseur terrasse un homme seul :
à deux, on lui résiste.
Une corde à trois brins
n’est pas facile à rompre.
###### 13
Mieux vaut un gamin pauvre et sage
qu’un vieux roi débile, refusant tout conseil,
###### 14
car il peut sortir de prison pour régner,
bien que né pauvre dans son royaume.
###### 15
J’ai vu tous les vivants qui vont sous le soleil
se joindre à ce gamin
prétendant à la succession du roi :
###### 16
innombrable était la foule
de ceux qu’il conduisait.
Mais ses futurs sujets n’en seront pas heureux.
Car cela aussi n’est que vanité,
tourment de l’esprit.
###### 17
Surveille tes pas
quand tu vas à la Maison de Dieu ;
approche-toi pour écouter
plutôt que pour offrir le sacrifice des sots :
ils ignorent le mal qu’ils font.
