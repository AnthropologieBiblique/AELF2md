---
aliases : 
- Ecclésiaste 6
- Ecclésiaste 6
- Qo 6
- Ecclesiastes 6
tags : 
- Bible/Qo/6
- français
cssclass : français
---

# Ecclésiaste 6

###### 01
Il est un autre mal que j’ai vu sous le soleil,
un grand mal pour la race humaine.
###### 02
Voilà un homme auquel Dieu a donné
d’être riche, nanti, considéré :
rien ne lui manque de tout ce qu’il souhaite.
Mais Dieu ne lui a pas laissé le temps d’en profiter :
un autre, un étranger, en profite.
Cela aussi n’est que vanité, mal cruel.
###### 03
Un homme peut avoir eu une centaine d’enfants
et avoir vécu de longues années :
aussi nombreux qu’aient été les jours de sa vie,
s’il n’a pas été heureux et comblé,
s’il n’a même pas eu de sépulture,
je dis que l’avorton a plus de chance ;
###### 04
lui qui est venu dans la vanité,
il a passé comme une ombre ;
son nom reste enfoui dans les ténèbres ;
###### 05
il n’a même pas vu le soleil,
il ne l’a pas connu ;
il est plus tranquille que l’autre.
###### 06
Même si un homme devait vivre deux fois mille ans,
sans connaître le bonheur,
tout ne va-t-il pas au même lieu ?
###### 07
Tout le travail de l’être humain est pour la bouche,
et pourtant son appétit n’est jamais comblé.
###### 08
Qu’est-ce qu’un sage a de plus qu’un fou ?
Qu’est-ce qu’un indigent a de plus
quand il se tire d’affaire ?
###### 09
Mieux vaut ce que l’on voit de ses yeux
qu’une bouffée de désirs.
Cela aussi n’est que vanité et poursuite de vent.
###### 10
Tout ce qui existe a déjà reçu son nom ;
on sait ce qu’est un homme :
il ne peut entrer en procès
contre un plus fort que lui.
###### 11
Beaucoup de paroles, c’est beaucoup de vanité :
et quel profit pour l’homme ?
###### 12
Qui sait ce qui est bon pour l’homme durant sa vie,
durant le peu de jours de cette vie de vanité
qu’il traverse comme une ombre ?
Qui donc peut lui révéler
ce qui, après lui, sera sous le soleil ?
