---
aliases : 
- 1 Timothée 4
- 1 Timothée 4
- 1 Tm 4
- 1 Timothy 4
tags : 
- Bible/1Tm/4
- français
cssclass : français
---

# 1 Timothée 4

###### 01
L’Esprit dit clairement qu’aux derniers temps certains abandonneront la foi, pour s’attacher à des esprits trompeurs, à des doctrines démoniaques ;
###### 02
ils seront égarés par le double jeu des menteurs dont la conscience est marquée au fer rouge ;
###### 03
ces derniers empêchent les gens de se marier, ils disent de s’abstenir d’aliments, créés pourtant par Dieu pour être consommés dans l’action de grâce par ceux qui sont croyants et connaissent pleinement la vérité.
###### 04
Or tout ce que Dieu a créé est bon, et rien n’est à rejeter si on le prend dans l’action de grâce,
###### 05
car alors, cela est sanctifié par la parole de Dieu et la prière.
###### 06
En exposant ces choses aux frères, tu seras un bon serviteur du Christ Jésus, nourri des paroles de la foi et de la bonne doctrine que tu as toujours suivie.
###### 07
Quant aux récits mythologiques, ces racontars de vieilles femmes, écarte-les. Exerce-toi, au contraire, à la piété.
###### 08
En effet, l’exercice physique n’a qu’une utilité partielle, mais la religion concerne tout, car elle est promesse de vie, de vie présente et de vie future.
###### 09
Voilà une parole digne de foi, et qui mérite d’être accueillie sans réserve :
###### 10
si nous nous donnons de la peine et si nous combattons, c’est parce que nous avons mis notre espérance dans le Dieu vivant, qui est le Sauveur de tous les hommes et, au plus haut point, des croyants.
###### 11
Voilà ce que tu dois prescrire et enseigner.
###### 12
Que personne n’ait lieu de te mépriser parce que tu es jeune ; au contraire, sois pour les croyants un modèle par ta parole et ta conduite, par ta charité, ta foi et ta pureté.
###### 13
En attendant que je vienne, applique-toi à lire l’Écriture aux fidèles, à les encourager et à les instruire.
###### 14
Ne néglige pas le don de la grâce en toi, qui t’a été donné au moyen d’une parole prophétique, quand le collège des Anciens a imposé les mains sur toi.
###### 15
Prends à cœur tout cela, applique-toi, afin que tous voient tes progrès.
###### 16
Veille sur toi-même et sur ton enseignement. Maintiens-toi dans ces dispositions. En agissant ainsi, tu obtiendras le salut, et pour toi-même et pour ceux qui t’écoutent.
