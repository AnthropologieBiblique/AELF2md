---
aliases : 
- 1 Timothée 3
- 1 Timothée 3
- 1 Tm 3
- 1 Timothy 3
tags : 
- Bible/1Tm/3
- français
cssclass : français
---

# 1 Timothée 3

###### 01
Voici une parole digne de foi : si quelqu’un aspire à la responsabilité d’une communauté, c’est une belle tâche qu’il désire.
###### 02
Le responsable doit être irréprochable, époux d’une seule femme, un homme sobre, raisonnable, équilibré, accueillant, capable d’enseigner,
###### 03
ni buveur ni brutal mais bienveillant, ni querelleur ni cupide.
###### 04
Il faut qu’il dirige bien les gens de sa propre maison, qu’il obtienne de ses enfants l’obéissance et se fasse respecter.
###### 05
Car si quelqu’un ne sait pas diriger sa propre maison, comment pourrait-il prendre en charge une Église de Dieu ?
###### 06
Il ne doit pas être un nouveau converti ; sinon, aveuglé par l’orgueil, il pourrait tomber sous la même condamnation que le diable.
###### 07
Il faut aussi que les gens du dehors portent sur lui un bon témoignage, pour qu’il échappe au mépris des hommes et au piège du diable.
###### 08
Les diacres, eux aussi, doivent être dignes de respect, n’avoir qu’une parole, ne pas s’adonner à la boisson, refuser les profits malhonnêtes,
###### 09
garder le mystère de la foi dans une conscience pure.
###### 10
On les mettra d’abord à l’épreuve ; ensuite, s’il n’y a rien à leur reprocher, ils serviront comme diacres.
###### 11
Les femmes, elles aussi, doivent être dignes de respect, ne pas être médisantes, mais sobres et fidèles en tout.
###### 12
Que le diacre soit l’époux d’une seule femme, qu’il mène bien ses enfants et sa propre famille.
###### 13
Les diacres qui remplissent bien leur ministère obtiennent ainsi une position estimable et beaucoup d’assurance grâce à leur foi au Christ Jésus.
###### 14
Je t’écris avec l’espoir d’aller te voir bientôt.
###### 15
Mais au cas où je tarderais, je veux que tu saches comment il faut se comporter dans la maison de Dieu, c’est-à-dire la communauté, l’Église du Dieu vivant, elle qui est le pilier et le soutien de la vérité.
###### 16
Assurément, il est grand, le mystère de notre religion :
c’est le Christ,
manifesté dans la chair,
justifié dans l’Esprit,
apparu aux anges,
proclamé dans les nations,
cru dans le monde,
enlevé dans la gloire !
