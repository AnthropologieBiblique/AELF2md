---
aliases : 
- 1 Timothée 5
- 1 Timothée 5
- 1 Tm 5
- 1 Timothy 5
tags : 
- Bible/1Tm/5
- français
cssclass : français
---

# 1 Timothée 5

###### 01
Avec un homme âgé, ne sois pas brutal, mais encourage-le comme un père, les jeunes gens comme des frères,
###### 02
les femmes âgées comme des mères, et les plus jeunes comme des sœurs, en toute pureté.
###### 03
Honore et assiste les veuves qui sont vraiment seules.
###### 04
Si une veuve a des enfants ou des petits-enfants, ils doivent apprendre que c’est à eux d’abord de s’acquitter de leurs devoirs filiaux et de rendre à leurs parents ce qu’ils ont reçu d’eux. Voilà une conduite agréable à Dieu.
###### 05
Mais la véritable veuve, celle qui reste seule, a mis son espérance en Dieu : elle ne cesse de faire des demandes et des prières nuit et jour.
###### 06
Quant à celle qui se livre aux plaisirs, elle a beau vivre, elle est morte.
###### 07
Insiste sur tout cela, pour qu’elles soient irréprochables.
###### 08
Si quelqu’un ne s’occupe pas des siens, surtout des plus proches, il a renié la foi, il est pire qu’un incroyant.
###### 09
Pour être inscrite comme veuve, une femme doit avoir au moins soixante ans, n’avoir eu qu’un seul mari,
###### 10
être connue pour le bien qu’elle a fait, avoir élevé des enfants, donné l’hospitalité aux voyageurs, rendu aux fidèles les plus humbles services, secouru les malheureux. Bref, il faut que, dans tous les domaines, elle se soit dévouée.
###### 11
Mais les veuves plus jeunes, ne les admets pas. En effet, quand la passion les détourne du Christ, elles veulent se remarier,
###### 12
et se condamnent ainsi en rejetant leur premier engagement.
###### 13
En même temps, n’ayant rien à faire, elles s’habituent à courir toutes les maisons, non seulement sans rien faire, mais bavardant, se mêlant de tout, parlant à tort et à travers.
###### 14
Je veux donc que les plus jeunes se remarient, qu’elles aient des enfants, qu’elles tiennent leur maison, sans donner aucune prise aux insultes de l’adversaire.
###### 15
Car déjà quelques-unes se sont détournées pour suivre Satan.
###### 16
Si une croyante a des veuves dans sa famille, qu’elle les assiste : ainsi l’Église ne sera pas surchargée et pourra assister les veuves qui sont vraiment seules.
###### 17
Les Anciens qui exercent bien la présidence méritent une double rémunération, surtout ceux qui se donnent de la peine pour la Parole et l’enseignement.
###### 18
Car l’Écriture dit : Le bœuf qui foule le grain, tu ne lui mettras pas de muselière, et encore : L’ouvrier mérite son salaire.
###### 19
Contre un Ancien n’accepte pas d’accusation, sauf s’il y a deux ou trois témoins.
###### 20
Ceux qui commettent des péchés, reprends-les devant tout le monde, afin que les autres aussi éprouvent de la crainte.
###### 21
Devant Dieu et le Christ Jésus et devant les anges que Dieu a choisis, je te le demande solennellement : garde ces règles sans parti pris, et ne fais rien par favoritisme.
###### 22
Ne décide pas trop vite d’imposer les mains à quelqu’un, ne te rends pas complice des péchés d’autrui, garde-toi pur.
###### 23
Cesse de ne boire que de l’eau, mais prends un peu de vin, à cause de ton estomac et de tes fréquents malaises.
###### 24
Il y a des gens dont les péchés sont manifestes avant même tout jugement ; chez d’autres, ils n’apparaissent que plus tard.
###### 25
De même, ce que l’on fait de bien est souvent manifeste, et s’il en va autrement, cela ne peut rester longtemps caché.
