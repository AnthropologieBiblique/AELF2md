---
aliases : 
- 1 Timothée 6
- 1 Timothée 6
- 1 Tm 6
- 1 Timothy 6
tags : 
- Bible/1Tm/6
- français
cssclass : français
---

# 1 Timothée 6

###### 01
Tous ceux qui sont sous le joug de l’esclavage doivent considérer leurs maîtres comme tout à fait dignes d’honneur, pour que le nom de Dieu et l’enseignement de la foi ne soient pas blasphémés.
###### 02
Et s’ils ont des maîtres croyants, qu’ils ne les respectent pas moins sous prétexte que ce sont des frères ; mais qu’ils les servent d’autant mieux que ceux qui bénéficient de leur activité sont des croyants bien-aimés.
Voilà ce que tu dois enseigner et recommander.
###### 03
Si quelqu’un donne un enseignement différent, et n’en vient pas aux paroles solides, celles de notre Seigneur Jésus Christ, et à l’enseignement qui est en accord avec la piété,
###### 04
un tel homme est aveuglé par l’orgueil, il ne sait rien, c’est un malade de la discussion et des querelles de mots. De tout cela, il ne sort que jalousie, rivalité, blasphèmes, soupçons malveillants,
###### 05
disputes interminables de gens à l’intelligence corrompue, qui sont coupés de la vérité et ne voient dans la religion qu’une source de profit.
###### 06
Certes, il y a un grand profit dans la religion si l’on se contente de ce que l’on a.
###### 07
De même que nous n’avons rien apporté dans ce monde, nous n’en pourrons rien emporter.
###### 08
Si nous avons de quoi manger et nous habiller, sachons nous en contenter.
###### 09
Ceux qui veulent s’enrichir tombent dans le piège de la tentation, dans une foule de convoitises absurdes et dangereuses, qui plongent les gens dans la ruine et la perdition.
###### 10
Car la racine de tous les maux, c’est l’amour de l’argent. Pour s’y être attachés, certains se sont égarés loin de la foi et se sont infligé à eux-mêmes des tourments sans nombre.
###### 11
Mais toi, homme de Dieu, fuis tout cela ; recherche la justice, la piété, la foi, la charité, la persévérance et la douceur.
###### 12
Mène le bon combat, celui de la foi, empare-toi de la vie éternelle ! C’est à elle que tu as été appelé, c’est pour elle que tu as prononcé ta belle profession de foi devant de nombreux témoins.
###### 13
Et maintenant, en présence de Dieu qui donne vie à tous les êtres, et en présence du Christ Jésus qui a témoigné devant Ponce Pilate par une belle affirmation, voici ce que je t’ordonne :
###### 14
garde le commandement du Seigneur, en demeurant sans tache, irréprochable jusqu’à la Manifestation de notre Seigneur Jésus Christ.
###### 15
Celui qui le fera paraître aux temps fixés, c’est Dieu,
Souverain unique et bienheureux,
Roi des rois et Seigneur des seigneurs ;
###### 16
lui seul possède l’immortalité,
habite une lumière inaccessible ;
aucun homme ne l’a jamais vu,
et nul ne peut le voir.
À lui, honneur et puissance éternelle. Amen.
###### 17
Quant aux riches de ce monde, ordonne-leur de ne pas céder à l’orgueil. Qu’ils mettent leur espérance non pas dans des richesses incertaines, mais en Dieu qui nous procure tout en abondance pour que nous en profitions.
###### 18
Qu’ils fassent du bien et deviennent riches du bien qu’ils font ; qu’ils donnent de bon cœur et sachent partager.
###### 19
De cette manière, ils amasseront un trésor pour bien construire leur avenir et obtenir la vraie vie.
###### 20
Timothée, garde le dépôt de la foi. Tourne le dos aux bavardages impies et aux objections de la pseudo-connaissance :
###### 21
en s’y engageant, certains se sont écartés de la foi.
Que la grâce soit avec vous.
