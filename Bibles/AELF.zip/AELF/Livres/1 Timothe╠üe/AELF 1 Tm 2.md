---
aliases : 
- 1 Timothée 2
- 1 Timothée 2
- 1 Tm 2
- 1 Timothy 2
tags : 
- Bible/1Tm/2
- français
cssclass : français
---

# 1 Timothée 2

###### 01
J’encourage, avant tout, à faire des demandes, des prières, des intercessions et des actions de grâce pour tous les hommes,
###### 02
pour les chefs d’État et tous ceux qui exercent l’autorité, afin que nous puissions mener notre vie dans la tranquillité et le calme, en toute piété et dignité.
###### 03
Cette prière est bonne et agréable à Dieu notre Sauveur,
###### 04
car il veut que tous les hommes soient sauvés et parviennent à la pleine connaissance de la vérité.
###### 05
En effet, il n’y a qu’un seul Dieu ;
il n’y a aussi qu’un seul médiateur entre Dieu et les hommes :
un homme, le Christ Jésus,
###### 06
qui s’est donné lui-même en rançon pour tous.
Aux temps fixés, il a rendu ce témoignage,
###### 07
pour lequel j’ai reçu la charge de messager et d’apôtre – je dis vrai, je ne mens pas – moi qui enseigne aux nations la foi et la vérité.
###### 08
Je voudrais donc qu’en tout lieu les hommes prient en élevant les mains, saintement, sans colère ni dispute.
###### 09
De même les femmes : qu’elles portent une tenue décente, avec pudeur et modestie, plutôt que de se parer de tresses, d’or ou de perles, ou de vêtements précieux ;
###### 10
ce qui convient à des femmes qui veulent exprimer leur piété envers Dieu, c’est de faire le bien.
###### 11
Que la femme reçoive l’instruction dans le calme, en toute soumission.
###### 12
Je ne permets pas à une femme d’enseigner, ni de dominer son mari ; mais qu’elle reste dans le calme.
###### 13
En effet, Adam a été modelé le premier, et Ève ensuite.
###### 14
Et ce n’est pas Adam qui a été trompé par le serpent, c’est la femme qui s’est laissé tromper, et qui est tombée dans la transgression.
###### 15
Mais la femme sera sauvée en devenant mère, à condition de rester avec modestie dans la foi, la charité et la recherche de la sainteté.
