---
aliases : 
- Baruch 4
- Baruch 4
- Ba 4
tags : 
- Bible/Ba/4
- français
cssclass : français
---

# Baruch 4

###### 01
Elle est le livre des préceptes de Dieu,
la Loi qui demeure éternellement :
tous ceux qui l’observent vivront,
ceux qui l’abandonnent mourront.
###### 02
Reviens, Jacob, saisis-la de nouveau ;
à sa lumière, marche vers la splendeur :
###### 03
ne laisse pas ta gloire à un autre,
tes privilèges à un peuple étranger.
###### 04
Heureux sommes-nous, Israël !
Car ce qui plaît à Dieu, nous le connaissons.
###### 05
Courage, mon peuple,
toi qui es la part d’Israël réservée à Dieu !
###### 06
Vous avez été vendus aux nations païennes,
mais ce n’était pas pour votre anéantissement ;
vous avez excité la colère de Dieu :
c’est pour cela que vous avez été livrés à vos adversaires.
###### 07
Car vous avez irrité votre Créateur
en offrant des sacrifices aux démons et non à Dieu.
###### 08
Vous avez oublié le Dieu éternel,
lui qui vous a nourris.
Vous avez aussi attristé Jérusalem,
elle qui vous a élevés,
###### 09
car elle a vu fondre sur vous la colère qui vient de Dieu,
et elle a dit :
« Écoutez, voisines de Sion,
Dieu m’a infligé un deuil cruel.
###### 10
J’ai vu la captivité
que l’Éternel a infligée à mes fils et à mes filles.
###### 11
Je les avais élevés dans la joie,
je les ai laissés partir dans les larmes et le deuil.
###### 12
Que nul ne se réjouisse de mon sort,
à moi qui suis veuve et délaissée par tout le monde.
J’ai été abandonnée
à cause des péchés de mes enfants,
parce qu’ils se sont détournés de la loi de Dieu.
###### 13
Ils n’ont pas reconnu ses jugements,
ni marché sur les chemins des commandements de Dieu,
ni suivi les sentiers de l’éducation
conforme à sa justice.
###### 14
Qu’elles viennent, les voisines de Sion !
Souvenez-vous de la captivité que l’Éternel a infligée
à mes fils et à mes filles.
###### 15
Car il a fait venir contre eux une nation lointaine,
une nation insolente et de langue étrangère,
sans respect pour le vieillard,
sans pitié pour le petit enfant.
###### 16
Ils ont emmené les fils bien-aimés de la veuve ;
ils l’ont rendue solitaire en la privant de ses filles.
###### 17
Et moi, comment pourrais-je vous aider ?
###### 18
Celui qui vous a infligé ces malheurs,
lui seul vous arrachera à la main de vos ennemis.
###### 19
Allez, mes enfants, allez votre chemin !
Moi, délaissée, je reste solitaire.
###### 20
J’ai quitté la robe de paix,
j’ai revêtu le sac du suppliant ;
vers l’Éternel je lancerai mon cri,
au long de mes jours.
###### 21
Courage, mes enfants, criez vers Dieu !
Il vous arrachera au pouvoir,
à la main des ennemis.
###### 22
Car moi, j’ai mis dans l’Éternel mon espérance,
pour qu’il vous accorde le salut.
Et il m’est venu une joie,
de la part du Dieu Saint,
en raison de la miséricorde qui bientôt vous sera envoyée
par l’Éternel, votre Sauveur.
###### 23
Dans le deuil et les larmes, je vous ai laissés partir ;
mais Dieu vous ramènera vers moi, pour toujours,
dans la joie et l’allégresse.
###### 24
Comme les voisines de Sion voient maintenant votre captivité,
ainsi verront-elles bientôt le salut que Dieu vous accordera,
qui viendra vers vous avec grande gloire,
dans la splendeur de l’Éternel.
###### 25
Mes enfants, supportez avec patience
la colère qui vous est venue de Dieu.
L’ennemi t’a poursuivi,
mais bientôt tu verras sa ruine,
tu mettras ton pied sur sa nuque.
###### 26
Mes tendres enfants ont marché par de rudes chemins ;
ils ont été enlevés comme un troupeau
emporté par l’ennemi.
###### 27
Courage, mes enfants, criez vers Dieu !
Celui qui vous a infligé l’épreuve se souviendra de vous.
###### 28
Votre pensée vous a égarés loin de Dieu ;
une fois convertis,
mettez dix fois plus d’ardeur à le chercher.
###### 29
Car celui qui a fait venir sur vous ces calamités
fera venir sur vous la joie éternelle,
en assurant votre salut. »
###### 30
Courage, Jérusalem !
Il te consolera, celui qui t’a donné un nom.
###### 31
Malheur à ceux qui t’ont maltraitée
et se sont réjouis de ta chute,
###### 32
malheur aux villes dont tes enfants furent esclaves,
malheur à celle qui reçut tes fils !
###### 33
Comme elle s’était réjouie de ta chute
et avait pris plaisir à ton effondrement,
ainsi sera-t-elle attristée par sa propre dévastation.
###### 34
Je lui ôterai sa fierté de ville populeuse,
je changerai son insolence en deuil.
###### 35
Un feu lui surviendra de la part de l’Éternel
pour de longs jours ;
elle sera la demeure des démons
pour plus longtemps encore.
###### 36
Regarde vers l’orient, Jérusalem,
et vois l’allégresse qui te vient de Dieu.
###### 37
Voici : ils reviennent, les fils que tu laissas partir ;
ils reviennent, rassemblés du levant au couchant
par la parole du Dieu Saint,
ils se réjouissent de la gloire de Dieu.
