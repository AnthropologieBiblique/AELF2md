---
aliases : 
- Baruch 5
- Baruch 5
- Ba 5
tags : 
- Bible/Ba/5
- français
cssclass : français
---

# Baruch 5

###### 01
Jérusalem, quitte ta robe de tristesse et de misère,
et revêts la parure de la gloire de Dieu pour toujours,
###### 02
enveloppe-toi dans le manteau de la justice de Dieu,
mets sur ta tête le diadème de la gloire de l’Éternel.
###### 03
Dieu va déployer ta splendeur partout sous le ciel,
###### 04
car Dieu, pour toujours, te donnera ces noms :
« Paix-de-la-justice »
et « Gloire-de-la-piété-envers-Dieu ».
###### 05
Debout, Jérusalem ! tiens-toi sur la hauteur,
et regarde vers l’orient :
vois tes enfants rassemblés du couchant au levant
par la parole du Dieu Saint ;
ils se réjouissent parce que Dieu se souvient.
###### 06
Tu les avais vus partir à pied,
emmenés par les ennemis,
et Dieu te les ramène, portés en triomphe,
comme sur un trône royal.
###### 07
Car Dieu a décidé
que les hautes montagnes et les collines éternelles seraient abaissées,
et que les vallées seraient comblées :
ainsi la terre sera aplanie,
afin qu’Israël chemine en sécurité
dans la gloire de Dieu.
###### 08
Sur l’ordre de Dieu,
les forêts et les arbres odoriférants
donneront à Israël leur ombrage ;
###### 09
car Dieu conduira Israël dans la joie,
à la lumière de sa gloire,
avec sa miséricorde et sa justice.
