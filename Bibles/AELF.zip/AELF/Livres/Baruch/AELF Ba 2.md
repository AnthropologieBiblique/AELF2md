---
aliases : 
- Baruch 2
- Baruch 2
- Ba 2
tags : 
- Bible/Ba/2
- français
cssclass : français
---

# Baruch 2

###### 01
Le Seigneur a donc accompli la parole qu’il avait prononcée contre nous, contre nos juges, qui gouvernèrent Israël, contre nos rois et nos chefs, contre les gens d’Israël et de Juda.
###### 02
Sous l’immensité du ciel, il ne se produisit jamais rien de semblable à ce que le Seigneur fit advenir à Jérusalem, conformément à ce qui est écrit dans la Loi de Moïse,
###### 03
à savoir que nous mangerions l’un la chair de son fils, l’autre la chair de sa fille !
###### 04
Et le Seigneur a livré nos pères aux mains de tous les royaumes d’alentour, à l’outrage et à la désolation parmi tous les peuples d’alentour, où il les a dispersés.
###### 05
Ils ont été soumis, au lieu de dominer, car nous avons péché contre le Seigneur notre Dieu en n’écoutant pas sa voix.
###### 06
Au Seigneur notre Dieu appartient la justice, mais à nous et à nos pères la honte sur le visage, comme on le voit aujourd’hui.
###### 07
Ces malheurs que le Seigneur avait prononcés contre nous se sont tous abattus sur nous.
###### 08
Nous n’avons pas apaisé la face du Seigneur, nous ne nous sommes pas détournés chacun des pensées de son cœur mauvais.
###### 09
Aussi, dans sa vigilance, le Seigneur a déclenché contre nous ces malheurs. Oui, il est juste, le Seigneur, en tout ce qu’il nous a commandé de faire.
###### 10
Mais nous n’avons pas écouté sa voix qui nous disait de suivre les préceptes que le Seigneur nous avait mis sous les yeux.
###### 11
Et maintenant, Seigneur Dieu d’Israël, écoute, toi qui as fait sortir ton peuple du pays d’Égypte, par la force de ta main, avec signes et prodiges, par ta grande puissance et la vigueur de ton bras, toi qui t’es fait un nom, comme on le voit aujourd’hui.
###### 12
Nous avons péché, nous avons été impies, nous avons été injustes, Seigneur notre Dieu. En raison de tous tes jugements,
###### 13
que ta fureur se détourne de nous, car nous ne sommes plus qu’un petit nombre parmi les nations où tu nous as dispersés.
###### 14
Entends, Seigneur, notre prière et notre supplication ; délivre-nous à cause de toi-même ; fais-nous trouver grâce devant ceux qui nous ont déportés,
###### 15
afin que la terre entière sache que tu es le Seigneur notre Dieu, puisque ton nom a été invoqué sur Israël et sa descendance.
###### 16
Regarde, Seigneur, du haut de ta demeure sainte, et pense à nous. Incline ton oreille, Seigneur, écoute.
###### 17
Ouvre les yeux, Seigneur, et vois. Car ce ne sont pas les défunts dans le séjour des morts, eux dont le souffle est enlevé des entrailles, qui rendront gloire et justice au Seigneur,
###### 18
mais l’âme comblée de tristesse, l’homme qui marche courbé et sans force, les yeux défaillants et l’âme affamée, ceux-là te rendront gloire et justice, Seigneur.
###### 19
Non, ce n’est pas à cause des actions justes de nos pères et de nos rois, que nous déposons notre supplique devant ta face, Seigneur notre Dieu.
###### 20
Car tu as déchaîné sur nous ta fureur et ta colère, comme tu l’avais déclaré par tes serviteurs les prophètes, en disant :
###### 21
« Ainsi parle le Seigneur : Courbez les épaules et servez le roi de Babylone. Alors, vous resterez dans le pays que j’ai donné à vos pères.
###### 22
Mais si vous n’écoutez pas l’appel du Seigneur à servir le roi de Babylone,
###### 23
je ferai cesser dans les villes de Juda et dans les rues de Jérusalem le chant d’allégresse et le chant de joie, le chant de l’époux et le chant de l’épouse. Tout le pays sera désolé, vidé de ses habitants. »
###### 24
Or, nous n’avons pas écouté ton appel à servir le roi de Babylone, et tu as accompli les paroles que tu avais prononcées par tes serviteurs les prophètes, à savoir que les ossements de nos rois et de nos pères seraient arrachés à leur tombeau.
###### 25
Et voici qu’ils furent jetés dehors, à la brûlure du jour et au gel de la nuit. Nos rois et nos pères sont morts dans de cruelles souffrances, par la famine, l’épée et l’exil.
###### 26
Tu as établi la maison sur laquelle a été invoqué ton nom, comme elle est en ce jour, à cause de la méchanceté de la maison d’Israël et de la maison de Juda.
###### 27
Tu as agi envers nous selon ton entière bienveillance et ton immense tendresse, Seigneur notre Dieu,
###### 28
comme tu l’avais déclaré par ton serviteur Moïse, le jour où tu lui ordonnas de mettre par écrit ta Loi en présence des fils d’Israël, en disant :
###### 29
« Vraiment, si vous n’écoutez pas ma voix, cette grande, cette immense multitude elle-même sera réduite à un petit nombre parmi les nations où je les disperserai !
###### 30
Oui, je sais bien qu’ils ne m’écouteront pas, car c’est un peuple à la nuque raide. Mais dans le pays de leur exil, ils rentreront en eux-mêmes,
###### 31
et ils sauront que moi, je suis le Seigneur leur Dieu. Je leur donnerai un cœur et des oreilles qui entendent.
###### 32
Et là, dans le pays de leur exil, ils me loueront, ils se souviendront de mon nom,
###### 33
ils se repentiront de leur obstination et de leurs actions mauvaises, au souvenir du destin de leurs pères, qui avaient péché devant le Seigneur.
###### 34
Alors, je les ferai revenir dans le pays que j’ai promis par serment à leurs pères Abraham, Isaac et Jacob, et ils y seront maîtres. Je les multiplierai, ils ne diminueront plus !
###### 35
J’établirai pour eux une alliance éternelle : je serai leur Dieu et eux, ils seront mon peuple. Jamais plus, je ne déplacerai mon peuple Israël loin du pays que je leur ai donné. »
