---
aliases : 
- Baruch 1
- Baruch 1
- Ba 1
tags : 
- Bible/Ba/1
- français
cssclass : français
---

# Baruch 1

###### 01
VOICI LES PAROLES du document que Baruc, fils de Nérias, fils de Maasaias, fils de Sédécias, fils d’Asadias, fils de Helkias, écrivit à Babylone,
###### 02
la cinquième année, le septième jour du mois, à l’époque même où les Chaldéens avaient pris Jérusalem et l’avaient livrée au feu.
###### 03
Baruc donna lecture de ce document en présence de Jékonias, fils de Joakim, roi de Juda, et de tout le peuple venu pour entendre le Livre,
###### 04
en présence des notables et des fils des rois, en présence des anciens et de tout le peuple, du plus petit jusqu’au plus grand, tous ceux qui résidaient à Babylone, au bord de la rivière Soud.
###### 05
On pleurait, on jeûnait et on priait devant le Seigneur.
###### 06
On récolta de l’argent selon les possibilités de chacun
###### 07
et on l’envoya à Jérusalem, au prêtre Joakim, fils de Helkias, fils de Salom, ainsi qu’aux autres prêtres et à tout le peuple, ceux qui se trouvaient avec lui à Jérusalem.
###### 08
Joakim, en effet, avait récupéré les objets de la Maison du Seigneur, enlevés du Temple, pour les rapporter au pays de Juda, le dixième jour du mois nommé siwân. C’étaient les objets d’argent fabriqués sur l’ordre de Sédécias, fils de Josias, roi de Juda,
###### 09
après que Nabucodonosor, roi de Babylone, eut déporté Jékonias, les princes, les forgerons, les notables et le peuple du pays, de Jérusalem à Babylone.
###### 10
Ils dirent : Voici que nous vous envoyons de l’argent. Avec cette somme, achetez de quoi faire des holocaustes et des sacrifices pour le péché, achetez de l’encens, préparez des offrandes que vous déposerez sur l’autel du Seigneur notre Dieu.
###### 11
Priez pour la vie de Nabucodonosor, roi de Babylone, et pour celle de son fils Baltasar, afin que leurs jours se prolongent aussi longtemps que le ciel demeurera au-dessus de la terre.
###### 12
Alors, le Seigneur nous donnera la force et illuminera nos yeux ; nous vivrons sous la protection de Nabucodonosor, roi de Babylone, et de son fils Baltasar ; nous les servirons durant de nombreux jours et nous trouverons grâce devant eux.
###### 13
Priez aussi pour nous le Seigneur notre Dieu, car nous avons péché contre le Seigneur notre Dieu, et jusqu’à ce jour la fureur et la colère du Seigneur ne se sont pas détournées de nous.
###### 14
Vous lirez ce document, que nous vous envoyons pour le proclamer dans la Maison du Seigneur au jour de la Fête et aux jours appropriés.
###### 15
Vous direz :
Au Seigneur notre Dieu appartient la justice, mais à nous la honte sur le visage comme on le voit aujourd’hui : honte pour l’homme de Juda et les habitants de Jérusalem,
###### 16
pour nos rois et nos chefs, pour nos prêtres, nos prophètes et nos pères ;
###### 17
oui, nous avons péché contre le Seigneur,
###### 18
nous lui avons désobéi, nous n’avons pas écouté la voix du Seigneur notre Dieu, qui nous disait de suivre les préceptes que le Seigneur nous avait mis sous les yeux.
###### 19
Depuis le jour où le Seigneur a fait sortir nos pères du pays d’Égypte jusqu’à ce jour, nous n’avons pas cessé de désobéir au Seigneur notre Dieu ; dans notre légèreté, nous n’avons pas écouté sa voix.
###### 20
Aussi, comme on le voit aujourd’hui, le malheur s’est attaché à nous, avec la malédiction que le Seigneur avait fait prononcer par son serviteur Moïse, au jour où il a fait sortir nos pères du pays d’Égypte pour nous donner une terre ruisselant de lait et de miel.
###### 21
Nous n’avons pas écouté la voix du Seigneur notre Dieu, à travers toutes les paroles des prophètes qu’il nous envoyait.
###### 22
Chacun de nous, selon la pensée de son cœur mauvais, est allé servir d’autres dieux et faire ce qui est mal aux yeux du Seigneur notre Dieu.
