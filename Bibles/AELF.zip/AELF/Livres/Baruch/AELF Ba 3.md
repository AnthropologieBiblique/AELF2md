---
aliases : 
- Baruch 3
- Baruch 3
- Ba 3
tags : 
- Bible/Ba/3
- français
cssclass : français
---

# Baruch 3

###### 01
Seigneur, Souverain de l’univers, Dieu d’Israël, une âme angoissée, un esprit découragé crie vers toi.
###### 02
Écoute, Seigneur, et prends pitié, car nous avons péché contre toi.
###### 03
Toi, en effet, tu demeures à jamais ; nous, nous sommes à jamais perdus.
###### 04
Seigneur, Souverain de l’univers, Dieu d’Israël, écoute donc la prière des morts d’Israël, des fils de ceux qui ont péché contre toi, qui n’ont pas écouté la voix du Seigneur leur Dieu, de sorte que les malheurs se sont attachés à nous.
###### 05
Ne te souviens pas des injustices de nos pères, mais souviens-toi, en cette heure, de ta main et de ton nom.
###### 06
Car tu es le Seigneur notre Dieu, et nous voulons te louer, Seigneur.
###### 07
Oui, c’est pour cela que tu as mis ta crainte en notre cœur, pour que nous invoquions ton nom. Nous voulons te louer en notre exil, puisque nous avons détourné de notre cœur toute l’injustice de nos pères qui ont péché contre toi.
###### 08
Nous voici aujourd’hui dans cet exil, où tu nous as dispersés, pour y être objet d’outrage et de malédiction, et pour notre amendement, après toutes les fautes de nos pères, qui s’étaient éloignés du Seigneur notre Dieu.
###### 09
Écoute, Israël, les commandements de vie,
prête l’oreille pour acquérir la connaissance.
###### 10
Pourquoi donc, Israël,
pourquoi es-tu exilé chez tes ennemis,
vieillissant sur une terre étrangère,
###### 11
souillé par le contact des cadavres,
inscrit parmi les habitants du séjour des morts ?
###### 12
– Parce que tu as abandonné la Source de la Sagesse !
###### 13
Si tu avais suivi les chemins de Dieu,
tu vivrais dans la paix pour toujours.
###### 14
Apprends où se trouvent
et la connaissance, et la force, et l’intelligence ;
pour savoir en même temps où se trouvent
de longues années de vie,
la lumière des yeux et la paix.
###### 15
Mais qui donc a découvert la demeure de la Sagesse,
qui a pénétré jusqu’à ses trésors ?
###### 16
Où sont-ils, les chefs des nations,
ceux qui domptent les bêtes de la terre,
###### 17
qui se jouent des oiseaux du ciel,
et qui entassent l’argent et l’or,
– ces biens auxquels les hommes accordent leur confiance –
mais dont les possessions n’ont pas de fin ?
###### 18
Où sont-ils, ceux qui travaillent l’argent avec soin,
mais dont les œuvres ne laissent pas de traces ?
###### 19
Ils ont disparu, ils sont descendus dans le séjour des morts,
et d’autres se sont levés à leur place.
###### 20
De plus jeunes ont vu le jour,
se sont installés sur la terre,
mais le chemin du savoir, ils ne l’ont pas connu,
###### 21
ils n’ont pas compris ses sentiers,
ils ne l’ont pas saisi.
Même leurs fils sont restés loin de son chemin.
###### 22
De la Sagesse, on n’a rien entendu en Canaan ;
en Témane, nul ne l’a vue.
###### 23
Ni les fils d’Agar, recherchant l’intelligence sur la terre,
ni les marchands de Merrane et de Témane,
ni les conteurs de fables, ni les chercheurs d’intelligence
n’ont connu le chemin de la Sagesse.
Ils n’ont pas gardé mémoire de ses sentiers.
###### 24
Ô Israël, comme elle est grande, la maison de Dieu,
comme il est vaste, le domaine qui lui appartient !
###### 25
Grand et sans borne,
élevé, sans mesure !
###### 26
C’est là que naquirent les célèbres géants des origines,
de haute stature, experts à la guerre.
###### 27
Ce n’est pas eux que Dieu a choisis,
il ne leur a pas montré le chemin du savoir.
###### 28
Ils ont péri, par manque de connaissance,
ils ont péri à cause de leur imprudence.
###### 29
Qui est monté au ciel pour saisir la Sagesse
et la faire descendre des nuées ?
###### 30
Qui a traversé la mer pour la trouver
et la rapporter au prix d’un or très fin ?
###### 31
Nul ne connaît son chemin,
nul n’examine son sentier.
###### 32
Mais celui qui sait tout en connaît le chemin,
il l’a découvert par son intelligence.
Il a pour toujours aménagé la terre,
et l’a peuplée de troupeaux.
###### 33
Il lance la lumière, et elle prend sa course ;
il la rappelle, et elle obéit en tremblant.
###### 34
Les étoiles brillent, joyeuses, à leur poste de veille ;
###### 35
il les appelle, et elles répondent : « Nous voici ! »
Elles brillent avec joie pour celui qui les a faites.
###### 36
C’est lui qui est notre Dieu :
aucun autre ne lui est comparable.
###### 37
Il a découvert les chemins du savoir,
et il les a confiés à Jacob, son serviteur,
à Israël, son bien-aimé.
###### 38
Ainsi, la Sagesse est apparue sur la terre,
elle a vécu parmi les hommes.
