---
aliases : 
- Judith 3
- Judith 3
- Jdt 3
tags : 
- Bible/Jdt/3
- français
cssclass : français
---

# Judith 3

###### 01
Ils lui envoyèrent des messagers, porteurs de paroles de paix, pour dire :
###### 02
" Nous sommes esclaves du grand roi Nabucodonosor, et nous voici à tes pieds sous ton regard ; traite-nous comme bon te semble.
###### 03
Nos fermes, notre territoire tout entier, tous nos champs de blé, notre petit et gros bétail, tous les parcs à bétail de nos campements sont à ta disposition. Utilise-les comme il te plaira.
###### 04
Nos villes mêmes, et leurs habitants, te sont asservis ; marche à leur rencontre comme tu l'entends. "
###### 05
Ces hommes se présentèrent donc devant Holopherne et lui rapportèrent ces paroles.
###### 06
Holopherne descendit vers le littoral, lui et son armée ; il établit des garnisons dans les villes hautes et y leva des hommes d'élite pour lui prêter main-forte.
###### 07
Les habitants de ces villes et de la région d'alentour l'accueillirent avec des couronnes et des chœurs de danse, au son des tambourins.
###### 08
Mais il rasa tout leur territoire et abattit leurs bosquets sacrés, car on lui avait donné pour tâche d'exterminer tous les dieux de la terre, afin que toutes les nations rendent un culte à Nabucodonosor, à lui seul, et que toute langue et toute tribu l'invoquent comme un dieu.
###### 09
Ensuite, il se rendit en face d'Esdrelon, près de Dotaïa, localité située devant la grande chaîne de montagnes de Judée.
###### 10
Il établit son campement à mi-chemin entre Guéba et Scythopolis, et il resta là tout un mois afin de rassembler tout le bagage de son armée.
