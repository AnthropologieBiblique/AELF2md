---
aliases : 
- Judith 6
- Judith 6
- Jdt 6
tags : 
- Bible/Jdt/6
- français
cssclass : français
---

# Judith 6

###### 01
Quand fut calmé le tumulte des hommes qui entouraient le conseil, Holopherne, général en chef de l'armée d'Assour, dit à Akhior devant tout le peuple des tribus étrangères et tous les fils de Moab :
###### 02
" Qui es-tu, toi, Akhior, et qui sont les mercenaires d'Éphraïm, pour que tu fasses le prophète chez nous, comme aujourd'hui, et pour que tu nous dises de ne pas combattre la race d'Israël ? Tu prétends que leur Dieu les couvrira de son bouclier ? Qui donc est Dieu, sinon Nabucodonosor ? C'est lui qui enverra sa force et les exterminera de la face de la terre, et leur Dieu ne les délivrera pas !
###### 03
Mais nous, serviteurs de Nabucodonosor, nous les frapperons comme s'ils n'étaient qu'un seul homme, et ils ne résisteront pas à la force de nos chevaux.
###### 04
Nous les submergerons chez eux, leurs montagnes s'enivreront de leur sang, leurs plaines seront remplies de leurs cadavres ; loin de pouvoir tenir pied devant nous, ils périront du premier au dernier - parole du roi Nabucodonosor, seigneur de toute la terre. Car il a parlé, et les paroles de son discours ne resteront pas vaines.
###### 05
Toi, donc, Akhior, mercenaire d'Ammone, qui as tenu ce discours, en ce jour où tu manques à tes devoirs, tu ne verras plus mon visage à partir d'aujourd'hui, jusqu'à ce que j'aie châtié cette race venue d'Égypte.
###### 06
Alors, le fer de mon armée et la lance de mes officiers transperceront tes flancs et tu tomberas parmi les blessés, quand je me tournerai contre la race d'Israël.
###### 07
Mes serviteurs vont t'emmener dans la région montagneuse et te laisser dans une des villes contrôlant les cols.
###### 08
Tu périras mais pas avant d'être exterminé avec ces gens.
###### 09
Et si vraiment tu espères en ton cœur qu'ils ne seront pas pris, que ton visage n'ait pas l'air abattu ! J'ai parlé, et aucune de mes paroles ne sera sans effet. "
###### 10
Holopherne donna l'ordre aux serviteurs qui se tenaient près de lui dans sa tente de se saisir d'Akhior, de l'emmener à Béthulie et de le livrer aux mains des fils d'Israël.
###### 11
Les serviteurs le saisirent donc, le menèrent hors du camp vers la plaine, puis ils passèrent d'une région à l'autre, du centre de la plaine vers la montagne, et ils parvinrent près des sources en contrebas de Béthulie.
###### 12
Quand les hommes de la ville au sommet de la montagne les aperçurent, ils prirent leurs armes et firent une sortie à l'extérieur de la ville, et tous les hommes armés de frondes prirent le contrôle du col, en lançant leurs pierres sur les serviteurs d'Holopherne.
###### 13
Ceux-ci se glissèrent en contrebas de la montagne, ligotèrent Akhior et le laissèrent là, jeté au pied de la montagne. Puis ils s'en retournèrent vers leur seigneur.
###### 14
Les fils d'Israël descendirent alors de leur ville, s'arrêtèrent près d'Akhior, le délièrent, l'emmenèrent à Béthulie et le présentèrent devant les chefs de la ville,
###### 15
qui étaient en ce temps-là Ozias, fils de Michée, de la tribu de Siméon, Khabris, fils de Gothoniel, et Kharmis, fils de Melkhiel.
###### 16
Ceux-ci convoquèrent tous les anciens de la ville. Tous les jeunes gens et les femmes accoururent aussi à l'assemblée. On plaça Akhior au milieu de tout le peuple et Ozias l'interrogea sur ce qui était arrivé.
###### 17
Dans sa réponse, il leur rapporta les paroles dites au conseil d'Holopherne, toutes les paroles qu'il avait lui-même prononcées au milieu des chefs des fils d'Assour, ainsi que les paroles grandiloquentes d'Holopherne à l'encontre de la maison d'Israël.
###### 18
Le peuple se jeta sur le sol, se prosterna devant Dieu et s'écria :
###### 19
" Seigneur, Dieu du ciel, considère leur arrogance et prends en pitié l'humiliation de notre race. En ce jour, tourne ton regard vers le visage de ceux qui te sont consacrés. "
###### 20
On réconforta Akhior et on le félicita vivement.
###### 21
Au sortir de l'assemblée, Ozias le prit chez lui et offrit un banquet aux anciens. Durant toute cette nuit-là, on implora le secours du Dieu d'Israël.
