---
aliases : 
- Judith 11
- Judith 11
- Jdt 11
tags : 
- Bible/Jdt/11
- français
cssclass : français
---

# Judith 11

###### 01
Holopherne lui dit : " Courage, femme, que ton cœur ne craigne rien, car moi, je n'ai jamais fait de mal à quiconque choisit de servir Nabucodonosor, roi de toute la terre.
###### 02
Encore maintenant, si ton peuple, qui habite la région montagneuse, ne m'avait méprisé, je n'aurais pas brandi ma lance contre lui : ce sont eux qui l'ont voulu.
###### 03
Maintenant, dis-moi pour quelle raison tu t'es enfuie de chez eux pour venir à nous. À vrai dire, tu es venue trouver ton salut. Courage ! Tu resteras en vie cette nuit, ainsi qu'à l'avenir.
###### 04
Personne ne te fera de tort. Au contraire, tu seras bien traitée, comme il en va pour les serviteurs de mon seigneur, le roi Nabucodonosor. "
###### 05
Judith lui répondit : " Accueille les paroles de ta servante ; que ton esclave puisse s'exprimer en ta présence. Cette nuit, je ne proférerai aucun mensonge devant mon seigneur.
###### 06
Et si tu suis les conseils de ton esclave, Dieu mènera une action à bon terme avec toi, et mon seigneur n'échouera pas dans ses projets.
###### 07
Vive Nabucodonosor, roi de toute la terre ! Vive sa force ! Car il t'a envoyé pour corriger tous les vivants. Et non seulement les hommes le servent grâce à toi, mais encore les bêtes sauvages, les troupeaux et les oiseaux du ciel vivront, grâce à ta vigueur, pour Nabucodonosor et pour toute sa maison.
###### 08
Oui, nous avons entendu parler de ta sagesse et de la subtilité de ton esprit : on rapporte par toute la terre que tu es le seul héros de tout le royaume, puissant par ton savoir-faire et admirable dans la conduite de la guerre.
###### 09
Venons-en au discours prononcé par Akhior devant ton conseil ; nous en avons appris les termes, car les hommes de Béthulie ont épargné Akhior et celui-ci leur a communiqué tout ce qu'il avait dit en ta présence.
###### 10
Eh bien, maître et seigneur, ne néglige pas ce discours, mais garde-le dans ton cœur, car il est véridique. Oui vraiment, ceux de notre race ne sont jamais punis, l'épée n'a pas de pouvoir sur eux, à moins qu'ils ne pèchent contre leur Dieu.
###### 11
Or maintenant, afin que mon seigneur ne connaisse ni revers ni échec, la mort va fondre sur leurs têtes, car le péché s'est emparé d'eux, ce péché par lequel ils excitent la colère de leur Dieu chaque fois qu'ils commettent un écart.
###### 12
Comme les vivres leur manquent et que toute eau se fait rare, ils ont projeté d'abattre leurs troupeaux et résolu de consommer tout ce que Dieu, par ses lois, leur a défendu de manger.
###### 13
Même les prémices du blé et les dîmes du vin et de l'huile, consacrées et gardées pour les prêtres qui se tiennent à Jérusalem en présence de notre Dieu, ils ont jugé bon de les utiliser sans en rien laisser, alors qu'il n'est permis à personne dans le peuple d'y toucher, même de la main.
###### 14
Or, à Jérusalem, tout le monde l'a fait. C'est pourquoi ils y ont envoyé des gens pour en ramener la permission nécessaire de la part du Conseil des anciens.
###### 15
Lorsque cette permission leur sera communiquée et qu'ils passeront à l'acte, ce jour-là ils te seront livrés pour que tu les extermines.
###### 16
C'est pourquoi moi, ta servante, sachant tout cela, je me suis enfuie de chez eux et Dieu m'a envoyée pour réaliser avec toi des actions qui frapperont de stupeur toute la terre ainsi que tous ceux qui l'apprendront.
###### 17
En effet, ta servante est remplie de la crainte de Dieu, elle sert nuit et jour le Dieu du ciel. Dorénavant je resterai donc près de toi, mon seigneur. La nuit, ta servante sortira dans le ravin, je prierai Dieu, et il me dira quand les gens de mon peuple auront commis leurs péchés.
###### 18
Je reviendrai alors t'en faire le rapport, tu feras une sortie avec toute ton armée et nul d'entre eux ne te résistera.
###### 19
Ensuite, je te conduirai à travers la Judée jusqu'aux portes de Jérusalem. Je placerai ton char au milieu de la ville, tu conduiras ses habitants comme des brebis qui n'ont pas de berger, et pas un chien ne grognera contre toi. Tout cela m'a été dit et annoncé pour que je le sache à l'avance, et j'ai été envoyée pour te l'annoncer à mon tour. "
###### 20
Les paroles de Judith plurent à Holopherne et à tous ses officiers. Remplis d'admiration pour sa sagesse, ils s'exclamèrent :
###### 21
" D'une extrémité de la terre à l'autre, il ne se trouve pas de femme semblable à celle-ci par la beauté du visage et l'intelligence des paroles. "
###### 22
Holopherne lui dit : " Dieu a bien fait de t'envoyer en avant de ton peuple, pour que la force soit en nos mains, et la ruine sur ceux qui méprisent mon seigneur.
###### 23
Quant à toi, tu es aussi jolie à voir qu'habile en tes discours. Si tu agis comme tu l'as dit, ton Dieu sera mon Dieu, et toi, tu résideras dans la demeure du roi Nabucodonosor, ta renommée s'étendra sur toute la terre. "
