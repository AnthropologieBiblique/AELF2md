---
aliases : 
- Judith 1
- Judith 1
- Jdt 1
tags : 
- Bible/Jdt/1
- français
cssclass : français
---

# Judith 1

###### 01
C'ETAIT L'AN DOUZE du règne de Nabucodonosor, roi des Assyriens à Ninive la grande ville. En ce temps-là, Arphaxad, roi des Mèdes à Ecbatane,
###### 02
entoura cette ville d'un mur d'enceinte en pierres de taille larges de trois coudées et longues de six, donnant au rempart une hauteur de soixante-dix coudées et une largeur de cinquante.
###### 03
Sur les portes, il dressa des tours de cent coudées de haut sur soixante de large à leurs fondations ;
###### 04
les portes elles-mêmes s'élevaient à soixante-dix coudées sur quarante de large, pour permettre les sorties de ses forces d'élite et des fantassins en ordre de bataille.
###### 05
En ce temps-là, le roi Nabucodonosor fit la guerre au roi Arphaxad dans la Grande Plaine, c'est-à-dire la plaine située sur le territoire de Ragau.
###### 06
Tous les habitants de la région montagneuse se rallièrent à lui, ainsi que tous ceux des vallées de l'Euphrate, du Tigre et de l'Hydaspe, et ceux de la plaine soumise au roi d'Élam, Ariok ; de très nombreux peuples vinrent se ranger en ordre de bataille aux côtés des fils de Khéléoud.
###### 07
Nabucodonosor, roi des Assyriens, envoya aussi des messagers à tous les habitants de la Perside ; et à tous ceux qui habitaient vers l'ouest, aux habitants de Cilicie, de Damascène, du Liban et de l'Anti-Liban ; et à tous les habitants du littoral,
###### 08
aux peuples du Carmel et du Galaad, de la Haute-Galilée et de la grande plaine d'Esdrelon,
###### 09
à tous ceux de Samarie et de ses villes ; et au-delà du Jourdain jusqu'à Jérusalem, Batanée, Khélous, Cadès ; et au-delà du Torrent d'Égypte, jusqu'à Taphnès et Ramessès, tout le territoire de Guesèm,
###### 10
jusqu'au-dessus de Tanis et de Memphis, à tous les habitants de l'Égypte jusqu'aux abords du territoire de l'Éthiopie.
###### 11
Mais tous les habitants de toute la terre méprisèrent la parole de Nabucodonosor, roi des Assyriens, et ne se rangèrent pas à ses côtés pour combattre, car ils ne le craignaient pas, ils le considéraient comme un homme isolé. Ils renvoyèrent donc ses messagers les mains vides, et sans honneurs.
###### 12
Nabucodonosor fut pris d'une violente fureur contre toute cette partie de la terre. Il jura par son trône et son diadème de châtier et d'anéantir par l'épée tous les territoires de Cilicie, de Damascène et de Syrie, ainsi que tous les habitants de la région de Moab, les fils d'Ammone, toute la Judée et tous les habitants d'Égypte jusqu'aux abords du territoire des deux mers.
###### 13
En la dix-septième année, il se rangea en bataille, avec son armée, contre le roi Arphaxad, et fut le plus fort au combat. Il mit en déroute toute l'armée d'Arphaxad, toute sa cavalerie et tous ses chars.
###### 14
Il se rendit maître de ses villes, parvint jusqu'à Ecbatane, s'empara de ses fortins, pilla ses avenues, changea en objet de honte ce qui faisait sa splendeur.
###### 15
Il se saisit d'Arphaxad dans les montagnes de Ragau, l'abattit à coups de javelots et d'épieux, puis l'acheva.
###### 16
Ensuite, il s'en retourna à Ninive, lui, les siens et toute la troupe mêlée qui s'était jointe à lui, foule immense d'hommes de guerre. Il demeura là avec son armée, à se reposer et faire la fête pendant cent vingt jours.
