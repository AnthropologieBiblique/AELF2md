---
aliases : 
- Judith 10
- Judith 10
- Jdt 10
tags : 
- Bible/Jdt/10
- français
cssclass : français
---

# Judith 10

###### 01
Judith acheva de crier vers le Dieu d'Israël et de prononcer toutes ces paroles.
###### 02
Elle se releva de sa prostration, appela sa suivante et redescendit à l'intérieur de sa demeure, là où elle se tenait les jours de sabbats et de fêtes.
###### 03
Elle retira la toile à sac dont elle était revêtue et ôta ses habits de veuve. Elle prit de l'eau pour se baigner entièrement et elle s'enduisit d'une huile au lourd parfum. Elle coiffa sa chevelure. Elle ajusta sa ceinture, puis revêtit ses habits de fête, ceux qu'elle avait portés du vivant de son mari Manassé.
###### 04
Elle chaussa des sandales, mit ses anneaux de chevilles, ses bracelets, ses bagues, ses boucles d'oreilles, et toute sa parure. Elle se fit très belle afin de séduire les regards de tous les hommes qui la verraient.
###### 05
Puis, elle donna à sa suivante une outre de vin et un flacon d'huile. Elle remplit une besace de galettes de farine d'orge, de gâteaux de fruits secs et de pains blancs. Elle empaqueta tous ses paniers et en chargea sa suivante.
###### 06
Toutes deux sortirent alors et se rendirent à la porte de la ville de Béthulie. Elles y trouvèrent postés Ozias et les anciens de la ville, Khabris et Kharmis.
###### 07
Quand ils virent Judith le visage transformé, et portant d'autres vêtements, sa beauté les plongea dans la plus grande admiration. Ils lui dirent :
###### 08
" Que le Dieu de nos pères te tienne en grâce,
qu'il te donne de mener à bien ton projet,
pour l'orgueil des fils d'Israël,
l'exaltation de Jérusalem. "
###### 09
Judith se prosterna devant Dieu, puis elle leur dit : " Ordonnez que l'on ouvre pour moi la porte de la ville, et je sortirai pour mener à bien ce dont vous venez de parler avec moi. " Ils donnèrent l'ordre aux jeunes gens de lui ouvrir, comme elle l'avait dit.
###### 10
C'est ce qu'ils firent, et Judith sortit, accompagnée de sa jeune esclave. Les hommes de la ville la suivaient du regard, aussi longtemps qu'elle descendait la montagne et traversait le vallon, jusqu'à ce qu'il ne fût plus possible de l'observer.
###### 11
Toutes deux marchaient droit devant elles dans le vallon. Les Assyriens d'un avant-poste se portèrent à leur rencontre.
###### 12
Ils se saisirent de Judith et l'interrogèrent : " De quel peuple es-tu ? D'où viens-tu et où vas-tu ? " Elle répondit : " Je suis une fille des Hébreux et je m'enfuis de chez eux, car ils sont sur le point de vous être livrés en pâture.
###### 13
Quant à moi, je viens voir Holopherne, le général en chef de votre armée, pour lui donner des renseignements sûrs. Je lui montrerai le chemin par où passer pour se rendre maître de toute la région montagneuse, sans qu'un seul homme ne manque à l'appel, sans qu'une seule vie ne se perde. "
###### 14
En l'entendant parler ainsi, les hommes la dévisageaient, et sa beauté les plongeait dans une vive admiration. Ils lui dirent :
###### 15
" Tu auras sauvé ta vie en te hâtant de descendre au-devant de notre seigneur ! Maintenant, va vers sa tente. Quelques-uns d'entre nous t'escorteront pour te remettre entre ses mains.
###### 16
Lorsque tu te tiendras en face de lui, que ton cœur soit sans crainte. Répète-lui ce que tu viens de dire, et il te traitera bien. "
###### 17
Ils détachèrent alors cent de leurs hommes qui l'encadrèrent, elle et sa suivante, et les conduisirent jusqu'à la tente d'Holopherne.
###### 18
Il se fit un attroupement dans tout le camp, car la nouvelle de sa présence s'était répandue dans les tentes. On fit cercle autour d'elle, comme elle se tenait à l'extérieur de la tente d'Holopherne, en attendant de lui être annoncée.
###### 19
On admirait sa beauté, on admirait à travers elle les fils d'Israël, et l'on se disait l'un à l'autre : " Qui regardera de haut ce peuple où l'on trouve de telles femmes ? Vraiment, il n'est pas bon d'en laisser subsister un seul homme : les survivants seraient capables de subjuguer toute la terre. "
###### 20
Ceux qui étaient étendus auprès d'Holopherne ainsi que tous ses officiers sortirent enfin. Ils introduisirent Judith dans la tente.
###### 21
Holopherne se reposait sur son lit, sous un voile tissé de pourpre, d'or, d'émeraudes et de pierres précieuses.
###### 22
On la lui annonça, et il se présenta sur le seuil de la tente, précédé de flambeaux d'argent.
###### 23
Lorsque Judith s'approcha d'Holopherne et de ses officiers, tous admirèrent la beauté de son visage. Se jetant face contre terre, elle se prosterna devant lui, mais les serviteurs la relevèrent.
