---
aliases : 
- Judith 16
- Judith 16
- Jdt 16
tags : 
- Bible/Jdt/16
- français
cssclass : français
---

# Judith 16

###### 01
Elle dit :
Chantez pour mon Dieu sur les tambourins.
Jouez pour le Seigneur sur les cymbales.
Joignez pour lui l'hymne à la louange.
Exaltez-le ! Invoquez son nom !
###### 02
Le Seigneur est un Dieu briseur de guerres ;
son nom est " Le Seigneur ".
[Il a établi son camp au milieu de son peuple
pour m'arracher à la main de mes persécuteurs.
###### 03
Assour est venu des montagnes du nord,
son armée est venue par dizaines de milliers ;
leur multitude obstruait les torrents,
leurs chevaux recouvraient les collines.
###### 04
Il voulait incendier mon territoire,
faire périr mes jeunes gens par l'épée,
jeter à terre mes nourrissons,
livrer au rapt mes tout-petits
et m'enlever mes jeunes filles.
###### 05
Mais le Seigneur souverain de l'univers les a confondus
par la main d'une femme.
###### 06
Non, ce n'est pas devant des jeunes gens
que leur homme fort a succombé,
ce ne sont pas des fils de Titans qui l'ont frappé,
ni d'immenses Géants qui l'ont attaqué,
mais c'est Judith, fille de Merari :
par la beauté de son visage, elle l'a paralysé.
###### 07
Elle quitta ses habits de veuve
pour le relèvement des affligés d'Israël ;
elle parfuma son visage,
###### 08
retint ses cheveux d'un bandeau
et mit une robe de lin, pour le séduire.
###### 09
Sa sandale ravit son regard,
sa beauté captiva son âme
et le sabre lui trancha la gorge.
###### 10
Les Perses frémirent devant son audace ;
devant sa hardiesse, les Mèdes furent bouleversés.
###### 11
Alors, les humbles de mon peuple
poussèrent des cris retentissants.
Les faibles de mon peuple hurlèrent,
et l'ennemi fut terrifié ;
ils élevèrent la voix,
et l'ennemi tourna bride.
###### 12
Des fils de frêles jeunes filles les transpercèrent,
ils les blessèrent, comme rejetons de déserteurs,
et les voilà tués dans la bataille de mon Seigneur.]
###### 13
Je chanterai pour mon Dieu un chant nouveau. Seigneur, tu es grand, tu es glorieux,
admirable de force, invincible.
###### 14
Que ta création, tout entière, te serve !
Tu dis, et elle existe.
Tu envoies ton souffle : elle est créée.
Nul ne résiste à ta voix.
###### 15
Si les bases des montagnes croulent dans les eaux,
si les rochers, devant ta face, fondent comme cire,
tu feras grâce à ceux qui te craignent.
[
###### 16
Oui, tout sacrifice d'agréable odeur est peu de chose ;
encore moins, toute graisse pour l'holocauste en ton honneur ;
mais celui qui craint le Seigneur est grand, plus que tout.
###### 17
Malheur aux nations qui se dressent contre ma race :
le Seigneur souverain de l'univers
les châtiera au jour du jugement ;
qu'il livre leur chair au feu et aux vers :
dans cette épreuve, ils pleureront à jamais. "]
###### 18
En entrant à Jérusalem, tous se prosternèrent devant Dieu, et lorsque le peuple se fut purifié, ils présentèrent leurs holocaustes, leurs offrandes volontaires et leurs dons.
###### 19
Judith y ajouta tout le mobilier d'Holopherne que le peuple lui avait donné, et le voile qu'elle avait elle-même emporté de la chambre à coucher, elle le consacra totalement à Dieu.
###### 20
Pendant trois mois, le peuple fut en liesse à Jérusalem devant le Lieu saint. Et Judith demeura avec son peuple.
###### 21
Ces jours écoulés, chacun reprit la route vers la terre de son héritage et Judith revint à Béthulie où elle demeura dans son domaine. De son temps, elle devint célèbre dans tout le pays.
###### 22
Beaucoup d'hommes la désirèrent, mais aucun ne s'unit à elle, durant tous les jours de sa vie, depuis la mort de son mari Manassé, depuis qu'il avait été réuni aux siens.
###### 23
Elle atteignit un âge très avancé et vieillit dans la maison de son mari, jusqu'à l'âge de cent cinq ans. Après avoir affranchi sa suivante, elle mourut à Béthulie, et on l'ensevelit dans la grotte où reposait son mari Manassé.
###### 24
La maison d'Israël fit pour elle un deuil de sept jours. Avant de mourir, elle avait réparti ses biens entre tous les proches de son mari Manassé et ceux de sa famille à elle.
###### 25
Plus personne ne vint effrayer les fils d'Israël du vivant de Judith et longtemps après sa mort.
