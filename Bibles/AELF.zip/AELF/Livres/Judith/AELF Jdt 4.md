---
aliases : 
- Judith 4
- Judith 4
- Jdt 4
tags : 
- Bible/Jdt/4
- français
cssclass : français
---

# Judith 4

###### 01
Les fils d'Israël, habitants de la Judée, apprirent tout ce qu'Holopherne, le général en chef de Nabucodonosor, roi des Assyriens, avait fait aux nations, et la manière dont il avait dépouillé tous leurs sanctuaires et les avait livrés à l'anéantissement.
###### 02
Ils furent saisis d'une grande, très grande crainte devant lui, et ils furent bouleversés pour Jérusalem et pour le Temple du Seigneur leur Dieu.
###### 03
En effet, leur retour de captivité était encore tout récent ; le peuple entier de Judée venait à peine de se regrouper ; le mobilier, l'autel et la demeure de Dieu, qui avaient été profanés, venaient d'être à nouveau consacrés.
###### 04
Ils envoyèrent des messagers dans tout le territoire de Samarie et à Kona, Bethorone, Belmaïne, Jéricho, et jusqu'à Khoba, Ésora et le Val de Salem.
###### 05
Ils occupèrent tous les sommets des hautes montagnes, fortifièrent les villages qui s'y trouvaient et en firent des dépôts pour les provisions en vue de préparer la guerre, car leurs champs venaient d'être moissonnés.
###### 06
Le grand prêtre Joakim, qui résidait alors à Jérusalem, écrivit aux habitants de Béthulie et de Bétomesthaïm, ville située en face d'Esdrelon et de la plaine de Dothaïne,
###### 07
pour leur dire de bloquer les cols de la région montagneuse, seule voie d'accès vers la Judée. Il leur serait facile, en effet, d'arrêter ceux qui passeraient, car le passage étroit ne se laissait franchir que par deux hommes à la fois.
###### 08
Les fils d'Israël agirent selon les ordres du grand prêtre Joakim et du Conseil des anciens, qui représentait tout le peuple d'Israël et siégeait à Jérusalem.
###### 09
Avec une ardeur soutenue, tous les hommes d'Israël crièrent vers Dieu ; avec une ardeur soutenue, ils s'humilièrent.
###### 10
Eux-mêmes, leurs femmes, leurs tout-petits et leurs troupeaux, ainsi que tout immigré, journalier ou esclave acheté mirent des sacs sur leurs reins.
###### 11
Tous les Israélites de Jérusalem, hommes, femmes et enfants, se jetèrent sur le sol devant le Temple, la tête couverte de cendres, et déployèrent leurs sacs devant le Seigneur.
###### 12
Ils enveloppèrent d'un sac l'autel lui-même et crièrent d'un seul cœur vers le Dieu d'Israël, le suppliant ardemment de ne pas livrer leurs tout-petits à la razzia, leurs femmes au rapt, les villes de leur héritage à l'anéantissement, le Lieu saint à la profanation et à l'outrage pour la plus grande joie des nations.
###### 13
Et le Seigneur entendit leur voix, il regarda leur détresse. Le peuple observa un jeûne pendant de nombreux jours, dans toute la Judée et à Jérusalem, devant le Lieu saint du Seigneur souverain de l'univers.
###### 14
Le grand prêtre Joakim, tous les prêtres qui se tenaient devant le Seigneur, et ceux qui assuraient le service liturgique, les reins enveloppés de toile à sac, offraient l'holocauste perpétuel, les offrandes votives et les dons volontaires du peuple.
###### 15
Leurs bonnets étaient couverts de cendre ; de toutes leurs forces ils criaient vers le Seigneur, le suppliant de visiter avec bonté toute la maison d'Israël.
