---
aliases : 
- Judith 9
- Judith 9
- Jdt 9
tags : 
- Bible/Jdt/9
- français
cssclass : français
---

# Judith 9

###### 01
Judith se jeta face contre terre, répandit de la cendre sur sa tête et ne garda que le sac dont elle était revêtue. C'était précisément l'heure où, à Jérusalem, on présentait l'encens du soir dans la demeure de Dieu. Elle cria d'une voix forte vers le Seigneur :
###### 02
" Seigneur, Dieu de mon père Siméon,
tu as mis dans sa main l'épée
pour punir des étrangers
qui avaient souillé une vierge
en dénouant sa ceinture,
qui l'avaient déshonorée
en mettant sa cuisse à nu,
qui l'avaient outragée
en profanant son sein.
Toi, tu avais dit : "C'est inadmissible",
et pourtant, ils le firent.
###### 03
En représailles, tu as livré leurs chefs au massacre.
Par tromperie, tu as livré au sang
la couche qui avait rougi de leur tromperie.
Tu as frappé les esclaves à côté des princes
et les princes sur leurs trônes.
###### 04
Tu as livré leurs femmes au rapt,
leurs filles à la captivité
et tout leur butin en partage
aux fils que tu aimes,
eux qui, brûlant d'ardeur pour toi,
pris de dégoût pour la souillure de leur sang,
t'avaient appelé au secours.
Ô Dieu, mon Dieu,
moi, une veuve, exauce-moi aussi.
###### 05
Car c'est toi qui as fait le passé,
le présent et l'avenir ;
ce qui est maintenant et ce qui viendra,
ton esprit l'a conçu ;
ce que tu avais dans l'esprit
est advenu.
###### 06
Les œuvres que tu as voulues
se sont présentées en disant : "Nous voici !"
Car tous tes chemins sont préparés,
et ton jugement, c'est ta prescience qui le fonde.
###### 07
Car innombrable est devenue l'armée des Assyriens ;
de leurs chevaux et cavaliers, ils se sont prévalus ;
du bras de leurs fantassins, ils ont tiré orgueil ;
ils ont mis leur espoir dans le bouclier,
dans le javelot, l'arc et la fronde.
Ils n'ont pas reconnu que tu es le Seigneur,
le briseur de guerres.
###### 08
Ton nom est "Le Seigneur".
Toi, écrase leur vigueur par ta puissance,
rabaisse leur force dans ta fureur,
car ils ont décidé de profaner ton Lieu saint,
de souiller la Tente où repose ton nom de gloire,
d'abattre par le fer la puissance de ton autel.
###### 09
Regarde leur arrogance,
envoie ta colère sur leurs têtes,
mets dans ma main de veuve
la force d'accomplir ce que j'ai dans l'esprit.
###### 10
Par la tromperie de mes lèvres,
frappe l'esclave avec le chef,
le chef avec son officier.
Renverse leur superbe
par la main d'une femme.
###### 11
Car ce n'est pas dans le nombre
que réside ta force,
ni ton pouvoir en des hommes vigoureux.
Mais tu es le Dieu des humbles,
secours des opprimés,
protecteur des faibles,
refuge des délaissés,
sauveur des désespérés.
###### 12
Oui, toi, Dieu de mon père,
Dieu de l'héritage d'Israël,
maître du ciel et de la terre,
créateur des eaux,
roi de tout ce que tu as créé,
oui, exauce ma supplication !
###### 13
Donne-moi un langage trompeur
pour blesser et meurtrir
ceux qui ont tramé de cruels projets
contre ton alliance, ta Demeure consacrée,
le mont Sion et le domaine de tes fils.
###### 14
À ta nation entière, à toutes les tribus,
donne de reconnaître et de comprendre
que tu es, toi, le Dieu de toute puissance et force :
en dehors de toi, il n'en est pas d'autre
pour couvrir de son bouclier la race d'Israël. "
