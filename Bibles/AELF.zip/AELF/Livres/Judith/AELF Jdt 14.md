---
aliases : 
- Judith 14
- Judith 14
- Jdt 14
tags : 
- Bible/Jdt/14
- français
cssclass : français
---

# Judith 14

###### 01
Judith leur déclara : " Écoutez-moi donc, frères : prenez cette tête et suspendez-la aux créneaux de votre rempart.
###### 02
Ensuite, quand l'aurore brillera et que le soleil paraîtra sur la terre, vous prendrez chacun vos armes de combat ; et vous, tous les hommes vigoureux, vous ferez une sortie hors de la ville. Vous vous donnerez un guide, comme pour descendre dans la plaine, en direction de l'avant-poste des fils d'Assour. Mais vous ne descendrez pas.
###### 03
Les fils d'Assour saisiront leur armement, regagneront leur camp, éveilleront les généraux de l'armée et accourront autour de la tente d'Holopherne, mais ils ne le trouveront pas. La peur, alors, fondra sur eux et ils s'enfuiront devant vous.
###### 04
Vous les poursuivrez, vous-mêmes et les habitants de tout le territoire d'Israël, et vous les abattrez sur les chemins de leur fuite.
###### 05
Mais auparavant, appelez-moi Akhior, l'Ammonite, afin qu'il voie et reconnaisse celui qui a méprisé la maison d'Israël, celui par qui il avait été envoyé vers nous comme un homme voué à la mort. "
###### 06
On invita donc Akhior à sortir de chez Ozias. Sitôt arrivé, lorsqu'il vit la tête d'Holopherne dans la main d'un homme parmi l'assemblée du peuple, il tomba face contre terre, le souffle coupé.
###### 07
On le releva. Il se jeta aux pieds de Judith, se prosterna devant elle et lui dit : " Bénie sois-tu dans toutes les tentes de Juda et dans toutes les nations. Tous ceux qui entendront prononcer ton nom seront bouleversés.
###### 08
Informe-moi donc maintenant de tout ce que tu as fait durant ces jours-ci. " Et Judith lui fit, au milieu du peuple, le récit complet de ses actions depuis le jour de son départ jusqu'à ce moment où elle leur parlait.
###### 09
Quand elle eut terminé, le peuple poussa des cris retentissants et remplit la ville de cris de joie.
###### 10
En voyant tout ce que le Dieu d'Israël avait accompli, Akhior crut en Dieu, sans réserve. Il se fit circoncire, et fut admis définitivement dans la maison d'Israël.
###### 11
Au lever de l'aurore, on suspendit la tête d'Holopherne au rempart. Les hommes de Béthulie prirent chacun leurs armes et firent par cohortes une sortie en direction des cols de la montagne.
###### 12
Quand les fils d'Assour les virent, ils envoyèrent prévenir leurs chefs ; ceux-ci allèrent chercher les généraux, les commandants et tous les officiers.
###### 13
Ils parvinrent à la tente d'Holopherne et dirent à celui qui était préposé à toutes ses affaires : " Réveille donc notre seigneur, car les esclaves ont eu l'audace de descendre contre nous pour attaquer, et pour se faire exterminer jusqu'au dernier. "
###### 14
Bagoas entra donc et frappa à l'ouverture de la tente, supposant qu'Holopherne dormait avec Judith.
###### 15
Comme personne ne semblait rien entendre, il écarta le rideau, entra dans la chambre à coucher et trouva, jeté sur le marchepied, le cadavre sans la tête.
###### 16
Il poussa de grands cris, avec pleurs, gémissements, cris aigus, et déchira ses vêtements.
###### 17
Puis il entra dans la tente où logeait Judith, mais ne la trouva pas. Il bondit alors vers le peuple en hurlant :
###### 18
" Les esclaves se sont révoltés ! À elle seule, une femme de chez les Hébreux a couvert de honte la maison du roi Nabucodonosor. Voilà Holopherne à terre ! Sa tête a disparu ! "
###### 19
À ces mots, les chefs de l'armée d'Assour, l'âme toute bouleversée, déchirèrent leurs tuniques, ils poussèrent des hurlements et de grands cris au milieu du camp.
