---
aliases : 
- Judith 2
- Judith 2
- Jdt 2
tags : 
- Bible/Jdt/2
- français
cssclass : français
---

# Judith 2

###### 01
La dix-huitième année, le vingt-deuxième jour du premier mois, il fut question, dans la demeure de Nabucodonosor, roi des Assyriens, du châtiment qu'il exercerait sur toute la terre, comme il l'avait dit.
###### 02
Il convoqua tous les officiers de sa maison et les grands de sa cour, tint avec eux un conseil secret et, de sa propre bouche, il voua totalement la terre à la malédiction.
###### 03
Ils décidèrent d'exterminer tout être qui n'avait pas obéi à la parole de sa bouche.
###### 04
Lorsque le conseil fut terminé, Nabucodonosor, roi des Assyriens, fit appeler Holopherne, général en chef de son armée, le second du royaume après lui. Il lui dit :
###### 05
" Ainsi parle le grand roi, le seigneur de toute la terre : Toi, dès que tu te seras éloigné de ma présence, tu prendras avec toi des hommes conscients de leur vigueur, jusqu'à cent vingt mille fantassins et une multitude de chevaux avec douze mille hommes pour les monter.
###### 06
Tu partiras en expédition pour affronter toute la terre située à l'ouest, parce que ses habitants ont désobéi à la parole de ma bouche.
###### 07
Envoie des messagers pour qu'on prépare, en signe d'allégeance, la terre et l'eau, car, dans ma fureur, je vais partir en expédition contre eux. Toute la face de la terre, je la couvrirai des pieds de mes soldats, je la livrerai à leur razzia.
###### 08
Les blessés de ces pays rempliront les ravins ; tous les torrents et les fleuves déborderont, gorgés de cadavres.
###### 09
Leurs captifs, je les emmènerai jusqu'aux extrémités de la terre.
###### 10
Alors, pars ! Commence par occuper pour moi tous leurs territoires. Ils se rendront à toi et tu me les réserveras pour le jour de leur mise en accusation.
###### 11
Quant à ceux qui désobéiront, ils n'échapperont pas à ton regard : livre-les au massacre et à la razzia dans tout le territoire sous ton contrôle.
###### 12
Par ma vie et par la force de ma royauté, j'ai dit ! Et j'accomplirai tout cela de ma main.
###### 13
Et toi, ne transgresse en rien les paroles de ton seigneur, mais exécute-les rigoureusement, selon ce que je t'ai prescrit, et sans tarder. "
###### 14
Holopherne s'éloigna de la présence de son seigneur et il convoqua tous les princes, les généraux et les officiers de l'armée d'Assour.
###### 15
Il compta des hommes d'élite pour les mettre en ordre de bataille, comme le lui avait commandé son seigneur, jusqu'à concurrence de cent vingt mille hommes et de douze mille archers à cheval.
###### 16
Il les disposa de la manière dont on range une multitude pour la guerre.
###### 17
Il prit des chameaux, des ânes et des mulets en très grande quantité, pour porter leur bagage ; des brebis, des bœufs et des chèvres innombrables, pour le ravitaillement.
###### 18
Il prit aussi des provisions en quantité pour chaque homme, de l'or et de l'argent en abondance, provenant de la maison du roi.
###### 19
Puis il partit en expédition, lui et toute son armée, pour précéder le roi Nabucodonosor et couvrir de leurs chars, de leurs cavaliers et de leurs fantassins d'élite toute la face de la terre, à l'ouest.
###### 20
Une immense mêlée accompagnait leur expédition, nombreuse comme les sauterelles et comme la poussière de la terre : c'était une multitude impossible à dénombrer.
###### 21
Ils s'éloignèrent à trois jours de marche de Ninive, jusqu'en bordure de la plaine de Bektileth. Ils établirent leur camp hors de Bektileth, non loin de la montagne située au nord de la Haute-Cilicie.
###### 22
De là, avec toute son armée, fantassins, cavaliers et chars, Holopherne s'engagea dans la région montagneuse.
###### 23
Il pourfendit Phoud et Loud, pilla tous les fils de Rassis et les fils d'Ismaël qui vivaient en bordure du désert, au sud du pays de Khéleône.
###### 24
Il longea l'Euphrate, traversa la Mésopotamie jusqu'aux abords de la mer, en rasant toutes les villes hautes qui surplombaient le torrent d'Abrona.
###### 25
Il s'empara du territoire de la Cilicie, tailla en pièces tous ceux qui lui résistaient et parvint à la frontière méridionale de Japhet, en bordure de l'Arabie.
###### 26
Il encercla tous les fils de Madiane, mit le feu à leurs campements et pilla leurs parcs à bétail.
###### 27
Ensuite, il descendit dans la plaine de Damascène, à l'époque de la moisson des blés. Il mit le feu à tous leurs champs, fit exterminer le petit et le gros bétail, dépouilla leurs villes, écrasa les moissons de leurs plaines et frappa tous leurs jeunes gens du tranchant de l'épée.
###### 28
À son approche, crainte et tremblement fondirent sur les habitants du littoral, ceux de Tyr et de Sidon, les habitants de Sour et d'Okina, et tous les habitants de Jamnia ; les habitants d'Azôt et d'Ascalon étaient dans l'épouvante.
