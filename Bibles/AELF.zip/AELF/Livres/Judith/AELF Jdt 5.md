---
aliases : 
- Judith 5
- Judith 5
- Jdt 5
tags : 
- Bible/Jdt/5
- français
cssclass : français
---

# Judith 5

###### 01
On informa Holopherne, général en chef de l'armée d'Assour, que les fils d'Israël se préparaient au combat, qu'ils avaient fermé les défilés de la région montagneuse, fortifié tous les hauts sommets et mis des pièges dans les plaines.
###### 02
Il entra dans une violente colère et convoqua tous les chefs de Moab, les généraux d'Ammone et tous les gouverneurs du littoral.
###### 03
Il leur dit : " Fils de Canaan, informez-moi. Quel est ce peuple établi dans la région montagneuse et quelles sont les villes qu'il habite ? Quelle est l'importance de son armée et en quoi consistent sa force et sa vigueur ? Quel roi est à leur tête pour commander ses troupes ?
###### 04
Et pourquoi ont-ils dédaigné de venir à ma rencontre, à la différence de tous ceux qui habitent à l'ouest ? "
###### 05
Akhior, le commandant de tous les fils d'Ammone, répondit : " Que mon seigneur daigne écouter les paroles de la bouche de ton serviteur : je t'informerai de la vérité sur le peuple qui habite cette région montagneuse, non loin de toi. Il ne sortira pas de mensonge de la bouche de ton serviteur.
###### 06
Ce peuple, ce sont des gens qui descendent des Chaldéens.
###### 07
Ils allèrent d'abord s'établir en Mésopotamie, parce qu'ils ne voulaient pas suivre les dieux de leurs pères qui étaient nés en Chaldée.
###### 08
Ils s'étaient écartés, en effet, du chemin de leurs ancêtres et se prosternaient devant le Dieu du ciel, le Dieu qu'ils avaient appris à connaître. On les expulsa loin des dieux de Chaldée et ils s'exilèrent en Mésopotamie, où ils s'établirent pour de longs jours.
###### 09
Puis leur Dieu leur dit de quitter ce lieu où ils s'étaient établis et d'aller au pays de Canaan. Ils s'y installèrent et furent comblés d'or, d'argent et de troupeaux en surabondance.
###### 10
Ils descendirent ensuite en Égypte, car une famine avait recouvert la face de la terre de Canaan. Ils s'y établirent et y restèrent aussi longtemps qu'on assura leur subsistance. Là, ils devinrent une grande multitude, une race que nul ne pouvait dénombrer.
###### 11
Mais le roi d'Égypte se joua d'eux en les astreignant à la corvée des briques. On les humilia, on en fit des esclaves.
###### 12
Alors, ils crièrent vers leur Dieu, qui frappa tout le pays d'Égypte de fléaux incurables, si bien que les Égyptiens les expulsèrent loin de leur présence.
###### 13
Dieu assécha devant eux la mer Rouge
###### 14
et les conduisit sur la route du Sinaï et de Cadès-Barné. Ils expulsèrent tous les habitants du désert.
###### 15
Ils occupèrent le pays des Amorites et mirent leur vigueur à exterminer tous les Heshbonites. Après avoir traversé le Jourdain, ils reçurent en possession toute la région montagneuse,
###### 16
expulsant devant eux le Cananéen, le Perizzite et le Jébuséen, Sichem et tous les Guirgashites. C'est là qu'ils s'installèrent pour de longs jours.
###### 17
Aussi longtemps qu'ils ne commirent pas de péchés devant leur Dieu, la prospérité fut avec eux, car avec eux est un Dieu qui déteste l'injustice.
###### 18
Mais lorsqu'ils s'écartèrent du chemin qui leur était fixé, ils furent complètement exterminés en de nombreux combats ; ils furent aussi emmenés captifs sur une terre qui n'était pas la leur. Le temple de leur Dieu fut rasé et leurs villes tombèrent au pouvoir de leurs adversaires.
###### 19
Or, maintenant qu'ils sont revenus vers leur Dieu, ils sont remontés de la terre où ils avaient été dispersés, ils ont repris possession de Jérusalem où se trouve leur sanctuaire, ils se sont installés dans la région montagneuse, car elle était déserte.
###### 20
Maintenant donc, maître et seigneur, s'il y a dans ce peuple quelque égarement, s'ils pèchent contre leur Dieu, nous examinerons avec soin s'il y a bien chez eux cette occasion de chute, puis nous monterons et nous les combattrons.
###### 21
Mais si cette nation n'a pas transgressé sa Loi, que mon seigneur les évite, de peur que leur Seigneur et leur Dieu ne les couvre de son bouclier. Nous serions alors accablés d'outrages devant toute la terre. "
###### 22
Quand Akhior eut fini de prononcer ces paroles, toute la foule rassemblée en cercle autour de la tente se mit à récriminer. Les grands de l'entourage d'Holopherne et tous les habitants du littoral et de Moab parlaient de le mettre en pièces :
###### 23
" Non, nous n'avons rien à craindre des fils d'Israël. C'est un peuple sans puissance ni force, incapable de tenir dans une bataille un peu rude.
###### 24
Allons donc ! Montons, et ton armée n'en fera qu'une bouchée, ô notre maître Holopherne. "
