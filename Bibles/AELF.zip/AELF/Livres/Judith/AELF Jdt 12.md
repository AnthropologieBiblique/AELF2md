---
aliases : 
- Judith 12
- Judith 12
- Jdt 12
tags : 
- Bible/Jdt/12
- français
cssclass : français
---

# Judith 12

###### 01
Il ordonna de l'introduire là où se trouvait son argenterie et commanda de lui présenter des plats préparés pour lui, et de lui donner à boire de son vin.
###### 02
Mais Judith lui dit : " Je n'en mangerai pas, de peur qu'il n'y ait là pour moi une occasion de chute : ce que j'ai fait apporter subviendra à mes besoins. "
###### 03
Holopherne lui dit : " Et si tes provisions viennent à manquer, où pourrons-nous en chercher pour t'en procurer de semblables ? Car il n'y a personne de ta race parmi nous. "
###### 04
Judith lui répondit : " Par ta vie, mon seigneur, ta servante n'aura pas épuisé ses provisions, avant que le Seigneur ne réalise par ma main ce qu'il a projeté. "
###### 05
Les officiers d'Holopherne la conduisirent alors à sa tente. Elle dormit jusqu'au milieu de la nuit et se leva au moment du tour de garde du matin.
###### 06
Elle envoya dire à Holopherne : " Que mon seigneur donne des ordres afin de permettre à sa servante de sortir pour la prière. "
###### 07
Holopherne commanda donc à ses gardes de ne pas l'en empêcher.
Elle demeura trois jours dans le camp. La nuit, elle se rendait dans le ravin de Béthulie et se baignait à la source où se trouvait le poste de garde.
###### 08
Quand elle en remontait, elle priait le Seigneur Dieu d'Israël d'orienter son chemin pour le relèvement des fils de son peuple.
###### 09
Et une fois rentrée, elle demeurait dans sa tente en état de pureté, jusqu'à ce qu'on lui apporte sa nourriture, le soir.
###### 10
Le quatrième jour, Holopherne organisa un banquet réservé à ses propres serviteurs. Il n'adressa d'invitation à aucun de ses subordonnés.
###### 11
Il dit à Bagoas, le préposé à sa chambre et à toutes ses affaires : " Va donc convaincre la femme de chez les Hébreux, qui est auprès de toi, afin qu'elle vienne manger et boire avec nous.
###### 12
Car, pour nous, ce serait perdre la face que de laisser passer une telle femme sans avoir eu de relation avec elle. Si nous ne parvenons pas à l'attirer, elle se moquera de nous ! "
###### 13
Bagoas sortit de chez Holopherne et se rendit chez Judith. Il lui dit : " Que cette jolie esclave n'hésite pas à venir chez mon seigneur pour y être honorée en sa présence, pour boire du vin et se réjouir avec nous, et pour devenir aujourd'hui même comme l'une des filles des Assyriens qui se tiennent dans la demeure de Nabucodonosor. "
###### 14
Judith lui répondit : " Qui suis-je, moi, pour contredire mon seigneur ? Tout ce qui plaît à ses yeux, je me hâterai de le faire et ce sera pour moi un motif d'allégresse jusqu'au jour de ma mort. "
###### 15
Elle se leva, mit son plus beau vêtement et toute sa parure féminine. Sa servante la précéda et étendit par terre devant Holopherne les toisons que Judith avait reçues de Bagoas pour son usage quotidien, afin qu'elle puisse s'y étendre pour manger.
###### 16
Judith entra et s'allongea. Le cœur d'Holopherne en fut transporté, son âme troublée, et il fut pris d'un violent désir de s'unir à elle car, depuis le jour où il l'avait vue, il guettait l'occasion de la séduire.
###### 17
Il lui dit : " Bois donc ! Viens te réjouir avec nous ! "
###### 18
Elle dit : " Je boirai volontiers, seigneur, car depuis ma naissance, vivre n'a jamais été pour moi plus exaltant qu'en ce jour. "
###### 19
Elle prit ce que lui avait préparé sa servante, puis mangea et but en face de lui.
###### 20
Holopherne était sous son charme ; il but du vin en très grande quantité, comme il n'en avait jamais bu en un jour depuis sa naissance.
