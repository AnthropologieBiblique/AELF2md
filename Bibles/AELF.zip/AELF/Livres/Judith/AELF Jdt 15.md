---
aliases : 
- Judith 15
- Judith 15
- Jdt 15
tags : 
- Bible/Jdt/15
- français
cssclass : français
---

# Judith 15

###### 01
Lorsqu'ils les entendirent, ceux qui se trouvaient dans les tentes furent mis hors d'eux-mêmes par ce qui s'était passé.
###### 02
Crainte et tremblement fondirent sur eux. Plus personne ne resta en place : ce fut la débandade générale ; ils s'enfuirent par tous les chemins de la plaine et de la région montagneuse.
###### 03
Ceux qui se trouvaient dans les campements de cette région, encerclant Béthulie, prirent la fuite, eux aussi.
Alors tous ceux des fils d'Israël qui étaient capables de combattre foncèrent en bandes sur l'ennemi.
###### 04
Ozias envoya des messagers à Bétomasthaïm, à Khoba et à Kola et dans tout le territoire d'Israël pour leur annoncer l'issue des événements, afin qu'ils foncent tous sur l'adversaire et l'anéantissent.
###### 05
Lorsqu'ils entendirent les messagers, les fils d'Israël, tous ensemble, fondirent sur l'ennemi et le mirent en pièces, jusqu'à Khoba. Les habitants de Jérusalem survinrent également, ainsi que ceux de toute la région montagneuse, car on les avait informés de ce qui s'était passé dans le camp de leurs ennemis. Puis ce furent les gens de Galaad et de Galilée qui les prirent en tenaille et les frappèrent durement jusqu'à proximité de Damas et de sa région.
###### 06
Le reste des habitants de Béthulie fondit sur le camp d'Assour, le pilla et s'enrichit considérablement.
###### 07
De retour du carnage, les fils d'Israël se rendirent maîtres de ce qui restait. Ceux des villages et des fermes de la montagne, ainsi que de la plaine, s'emparèrent d'un large butin, car il y en avait une quantité vraiment considérable.
###### 08
Le grand prêtre Joakim et le Conseil des anciens des fils d'Israël qui habitaient à Jérusalem vinrent contempler les bienfaits du Seigneur en faveur d'Israël, voir Judith et la saluer.
###### 09
Lorsqu'ils entrèrent chez elle, tous la bénirent d'une seule voix et lui dirent :
" Tu es la gloire de Jérusalem,
tu es l'orgueil d'Israël,
tu es la fierté de notre race.
###### 10
Tout cela, tu l'as fait de ta main ;
en Israël, tu as fait ce qui est bien,
et Dieu y a trouvé sa joie.
Sois bénie par le Seigneur,
souverain de l'univers,
pour la durée des siècles. "
Et tout le peuple dit : " Amen. "
###### 11
Tout le peuple ramassa le butin du camp des Assyriens pendant trente jours. On donna à Judith la tente d'Holopherne, avec toute l'argenterie, les lits, les récipients et toutes ses affaires. Elle les prit, chargea elle-même sa mule, attela ses chariots, y entassa le tout.
###### 12
Les femmes d'Israël accoururent toutes pour voir Judith et la bénir. Certaines d'entre elles formèrent un chœur pour l'honorer. Judith prit dans ses mains des bâtons garnis de feuillage et les donna aux femmes de son cortège.
###### 13
Elle et ses compagnes se couronnèrent d'olivier. Judith précéda tout le peuple, menant la danse, en tête de toutes les femmes, et tous les hommes d'Israël l'accompagnaient, en armes et couronnés, chantant des hymnes.
###### 14
Au milieu de tout Israël, Judith entonna cette action de grâce, louange reprise par tout le peuple.
