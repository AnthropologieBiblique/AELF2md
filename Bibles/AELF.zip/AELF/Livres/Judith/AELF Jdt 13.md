---
aliases : 
- Judith 13
- Judith 13
- Jdt 13
tags : 
- Bible/Jdt/13
- français
cssclass : français
---

# Judith 13

###### 01
Quand il se fit tard, les serviteurs d'Holopherne se hâtèrent de partir. Bagoas ferma la tente de l'extérieur et renvoya de la présence de son seigneur tous ceux qui se tenaient là. Ils allèrent se coucher, brisés qu'ils étaient tous par les excès du banquet.
###### 02
Judith fut laissée seule dans la tente, avec Holopherne effondré sur son lit, noyé dans le vin.
###### 03
Elle dit à sa servante de se tenir prête à l'extérieur de la chambre à coucher et de guetter le moment où elle sortirait, comme chaque jour. Elle avait dit en effet qu'elle sortirait pour sa prière, et en avait également prévenu Bagoas.
###### 04
Tous s'étaient donc retirés et personne, du plus petit jusqu'au plus grand, n'était resté dans la chambre à coucher.
Debout près du lit, Judith se dit en son cœur : " Seigneur, Dieu de toute puissance, en cette heure, tourne ton regard vers les œuvres de mes mains, pour l'exaltation de Jérusalem.
###### 05
Car maintenant c'est le moment de ressaisir ton héritage et de réaliser mon projet pour écraser les ennemis qui se sont dressés contre nous. "
###### 06
Elle s'avança vers le montant du lit, proche de la tête d'Holopherne, elle en détacha son sabre,
###### 07
elle s'approcha du lit, empoigna la chevelure d'Holopherne et dit : " Rends-moi forte en ce jour, Seigneur, Dieu d'Israël. "
###### 08
Par deux fois, elle le frappa au cou, de toute sa vigueur, et en détacha la tête.
###### 09
Puis, elle fit rouler le corps en bas de la couche et détacha le voile des colonnes. Peu après, elle sortit, confia la tête d'Holopherne à sa suivante
###### 10
qui la mit dans sa besace à provisions, et elles sortirent toutes deux ensemble, comme elles avaient coutume de le faire, pour aller prier.
Les deux femmes traversèrent le camp, contournèrent le ravin, gravirent la montagne de Béthulie et parvinrent aux portes de la ville.
###### 11
De loin, Judith cria aux gardiens des portes : " Ouvrez, ouvrez donc la porte ! Il est avec nous, Dieu, notre Dieu, pour déployer encore sa vigueur en Israël et sa force contre ses ennemis, comme il l'a fait aujourd'hui aussi. "
###### 12
Dès que les hommes de la ville entendirent sa voix, ils se hâtèrent de descendre vers la porte et appelèrent les anciens de la ville.
###### 13
Tous les gens accoururent, du plus petit jusqu'au plus grand, car le retour de Judith leur paraissait incroyable ; ils ouvrirent la porte et accueillirent les deux femmes ; ils allumèrent un feu pour faire de la lumière et firent cercle autour d'elles.
###### 14
Judith leur dit d'une voix forte :
" Louez Dieu, louez-le,
louez Dieu car il n'a pas écarté sa miséricorde
de la maison d'Israël
mais cette nuit, par ma main,
il a écrasé nos ennemis. "
###### 15
Puis elle retira la tête de sa besace, la leur montra et dit : " Voici la tête d'Holopherne, général en chef de l'armée d'Assour, et voici le voile sous lequel il gisait dans son ivresse ! Le Seigneur l'a frappé par la main d'une femme.
###### 16
Oui, vive le Seigneur, qui m'a gardée dans le chemin où j'ai marché, car mon visage n'a séduit cet homme que pour sa perte : il n'a pas commis avec moi le péché qui m'aurait souillée et déshonorée. "
###### 17
Tout le peuple était transporté ; il s'inclina et se prosterna devant Dieu. Tous s'écrièrent, unanimes :
" Tu es béni, toi notre Dieu,
toi qui, en ce jour, as réduit à néant
les ennemis de ton peuple. "
###### 18
Et Ozias, l'un des chefs de la ville, dit à Judith :
" Bénie sois-tu, ma fille, par le Dieu Très-Haut,
plus que toutes les femmes de la terre ;
et béni soit le Seigneur Dieu,
Créateur du ciel et de la terre.
Car le Seigneur t'a dirigée
pour frapper à la tête le chef de nos ennemis.
###### 19
Jamais l'espérance dont tu as fait preuve
ne s'éloignera du cœur des hommes,
mais ils se rappelleront éternellement
la puissance de Dieu.
###### 20
Oui, Dieu fasse que tu sois exaltée à jamais,
qu'il te visite de ses bienfaits,
car tu n'as pas épargné ta propre vie
pour la cause de notre race humiliée,
tu es sortie pour empêcher notre ruine,
marchant avec droiture devant notre Dieu. "
Et tout le peuple dit : " Amen ! Amen ! "
