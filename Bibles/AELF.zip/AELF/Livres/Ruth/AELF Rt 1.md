---
aliases : 
- Ruth 1
- Ruth 1
- Rt 1
tags : 
- Bible/Rt/1
- français
cssclass : français
---

# Ruth 1

###### 01
À L’EPOQUE où gouvernaient les Juges, il y eut une famine dans le pays. Un homme de Bethléem de Juda émigra avec sa femme et ses deux fils pour s’établir dans la région appelée Champs-de-Moab.
###### 02
L’homme se nommait Élimélek (c’est-à-dire : Mon-Dieu-est-roi), sa femme : Noémi (c’est-à-dire : Ma-gracieuse) et ses deux fils : Mahlone (c’est-à-dire : Maladie) et Kilyone (c’est-à-dire : Épuisement). C’était des Éphratéens de Bethléem de Juda. Ils arrivèrent aux Champs-de-Moab et y restèrent.
###### 03
Élimélek, le mari de Noémi, mourut, et Noémi resta seule avec ses deux fils.
###### 04
Ceux-ci épousèrent deux Moabites ; l’une s’appelait Orpa (c’est-à-dire : Volte-face) et l’autre, Ruth (c’est-à-dire : Compagne). Ils demeurèrent là une dizaine d’années.
###### 05
Mahlone et Kilyone moururent à leur tour, et Noémi resta privée de ses deux fils et de son mari.
###### 06
Alors, avec ses belles-filles, elle se prépara à quitter les Champs-de-Moab et à retourner chez elle, car elle avait appris que le Seigneur avait visité son peuple et lui donnait du pain.
###### 07
Elle partit donc de l’endroit où elle habitait, accompagnée de ses deux belles-filles. Et elles prirent le chemin du retour vers le pays de Juda.
###### 08
Alors Noémi dit à ses deux belles-filles : « Allez, retournez chacune à la maison de votre mère. Que le Seigneur vous montre le même attachement que vous avez eu envers nos morts et envers moi !
###### 09
Que le Seigneur vous donne de trouver chacune un foyer stable, avec un mari. » Et Noémi les embrassa, mais elles élevèrent la voix et se mirent à pleurer.
###### 10
Elles lui dirent : « Nous voulons retourner avec toi vers ton peuple. »
###### 11
Mais Noémi reprit : « Retournez chez vous, mes filles ! Pourquoi venir avec moi ? Pourrais-je encore avoir des fils à vous donner comme maris ?
###### 12
Retournez, mes filles, allez ! Oui, je suis bien trop vieille pour avoir un mari. Quand bien même je dirais : “Il y a encore de l’espoir ; je vais appartenir à un homme cette nuit et j’aurai des fils”,
###### 13
même dans ce cas, auriez-vous la patience d’attendre qu’ils grandissent ? Pourriez-vous vous passer d’homme aussi longtemps ? Non, mes filles ! Mon sort est trop amer pour que vous le partagiez. Car c’est contre moi que la main du Seigneur s’est levée. »
###### 14
Alors les deux belles-filles, de nouveau, élevèrent la voix et se mirent à pleurer. Orpa embrassa sa belle-mère, mais Ruth restait attachée à ses pas.
###### 15
Noémi lui dit : « Tu vois, ta belle-sœur est retournée vers son peuple et vers ses dieux. Retourne, toi aussi, comme ta belle-sœur. »
###### 16
Ruth lui répondit : « Ne me force pas à t’abandonner et à m’éloigner de toi, car
où tu iras, j’irai ;
où tu t’arrêteras, je m’arrêterai ;
ton peuple sera mon peuple,
et ton Dieu sera mon Dieu.
###### 17
Où tu mourras, je mourrai ;
et là je serai enterrée.
Que le Seigneur me traite ainsi,
qu’il fasse pire encore,
si ce n’est pas la mort seule
qui nous sépare ! »
###### 18
Voyant qu’elle était résolue à l’accompagner, Noémi cessa de lui parler de cela.
###### 19
Ainsi, elles allaient leur chemin, toutes les deux, jusqu’à ce qu’elles arrivent à Bethléem. À leur arrivée à Bethléem, toute la ville fut en émoi. Les femmes disaient : « Est-ce bien là Noémi ? »
###### 20
Mais elle leur dit : « Ne m’appelez plus Noémi (Ma-gracieuse), appelez-moi Mara (Amertume). Car le Puissant m’a remplie d’amertume.
###### 21
J’étais partie comblée, mais le Seigneur me ramène les mains vides. Pourquoi m’appeler encore Noémi ? Le Seigneur m’a humiliée, le Puissant m’a fait du mal ! »
###### 22
Noémi revint donc des Champs-de-Moab avec sa belle-fille, Ruth la Moabite. Elles arrivèrent à Bethléem au début de la moisson de l’orge.
