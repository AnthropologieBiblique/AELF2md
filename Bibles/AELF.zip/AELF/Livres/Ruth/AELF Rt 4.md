---
aliases : 
- Ruth 4
- Ruth 4
- Rt 4
tags : 
- Bible/Rt/4
- français
cssclass : français
---

# Ruth 4

###### 01
Booz était monté à la porte de la ville, et il s’y était assis. Et voici que vint à passer celui dont Booz avait parlé, celui qui avait droit de rachat. Booz l’appela : « Hé, toi ! Arrête-toi un peu, viens t’asseoir ici ! » Il s’arrêta et il s’assit.
###### 02
Booz prit alors dix hommes parmi les anciens d’Israël et leur dit : « Venez vous asseoir ici pour siéger. » Et ils s’assirent.
###### 03
Puis il s’adressa à celui qui avait droit de rachat : « La parcelle du champ qui appartenait à notre frère Élimélek, Noémi, qui vient de revenir des Champs-de-Moab, la met en vente.
###### 04
Et moi, je me suis dit que j’allais t’en informer en disant : “Veux-tu, devant ceux qui siègent ici, devant les anciens du peuple, veux-tu acquérir ce champ ?” Si tu veux exercer ton droit de rachat, fais-le, mais si tu ne veux pas l’exercer, déclare-le moi, pour que je le sache. En effet, personne, sauf toi, ne peut exercer ce droit, sinon moi après toi. » Alors l’autre dit : « Moi, je veux l’exercer. »
###### 05
Booz reprit : « Le jour où, de la main de Noémi, tu prends possession du champ, tu prends également possession de Ruth la Moabite, la femme de celui qui est mort, afin que le nom du mort reste attaché à son héritage. »
###### 06
Alors, celui qui avait droit de rachat dit : « Je ne pourrais pas exercer mon droit de rachat sans détruire mon propre héritage. Toi, exerce donc le droit de rachat, puisque je ne le peux pas. »
###### 07
Or, jadis en Israël, pour le rachat ou pour l’échange, afin de conclure toute affaire, l’un enlevait sa sandale et la donnait à l’autre. En Israël, cela servait de témoignage.
###### 08
Celui qui avait droit de rachat dit alors à Booz : « À toi de te porter acquéreur ! » Et il enleva sa sandale.
###### 09
Booz dit aux anciens et à tout le peuple : « Aujourd’hui, vous en êtes témoins : de la main de Noémi, j’ai pris possession de tout ce qui appartenait à Élimélek ainsi qu’à Kilyone et Mahlone.
###### 10
J’ai également pris pour femme Ruth, la Moabite, la femme de Mahlone, afin que le nom du mort reste attaché à son héritage et ne soit pas effacé parmi ses frères ni à la porte de sa ville. Vous en êtes témoins, aujourd’hui. »
###### 11
Tout le peuple qui se trouvait à la porte de la ville, ainsi que les anciens, répondirent : « Nous en sommes témoins. Que le Seigneur rende la femme qui entre dans ta maison comme Rachel et comme Léa qui, à elles deux, ont bâti la maison d’Israël !
Fais fortune en Éphrata !
Fais-toi un nom à Bethléem !
###### 12
Puisse la descendance que le Seigneur te donnera par cette jeune femme rendre ta maison comme la maison de Pérès que Tamar enfanta à Juda ! »
###### 13
Booz prit donc Ruth comme épouse, elle devint sa femme et il s’unit à elle. Le Seigneur lui accorda de concevoir, et elle enfanta un fils.
###### 14
Les femmes de Bethléem dirent à Noémi : « Béni soit le Seigneur qui aujourd’hui ne t’a pas laissée sans quelqu’un pour te racheter ! Que son nom soit célébré en Israël !
###### 15
Cet enfant te fera revivre, il sera l’appui de ta vieillesse : il est né de ta belle-fille qui t’aime, et qui vaut mieux pour toi que sept fils. »
###### 16
Noémi prit l’enfant, le mit sur son sein, et se chargea de l’élever.
###### 17
Les voisines lui donnèrent son nom. Elles disaient : « Il est né un fils à Noémi. » Et elles le nommèrent Obed (c'est-à-dire : serviteur). Ce fut le père de Jessé, qui fut le père de David.
###### 18
Voici la descendance de Pérès :
Pérès engendra Esrone.
###### 19
Esrone engendra Ram,
Ram engendra Aminadab.
###### 20
Aminadab engendra Naassone,
Naassone engendra Salmone ;
###### 21
Salmone engendra Booz,
Booz engendra Obed ;
###### 22
Obed engendra Jessé,
et Jessé engendra David.
