---
aliases : 
- Ruth 3
- Ruth 3
- Rt 3
tags : 
- Bible/Rt/3
- français
cssclass : français
---

# Ruth 3

###### 01
Noémi, sa belle-mère, dit à Ruth : « Ma fille, ne devrais-je pas chercher à t’établir pour que tu sois heureuse ?
###### 02
Et maintenant, Booz n’est-il pas notre parent, lui dont tu as suivi les servantes ? Voici que, cette nuit, il vanne lui-même l’orge sur l’aire.
###### 03
Va te baigner, te parfumer et mettre ton manteau. Tu descendras sur l’aire. Ne te fais pas reconnaître de l’homme avant qu’il ait fini de manger et de boire.
###### 04
Quand il sera couché, tu sauras où il se couche. Alors, va, découvre-lui les pieds, et là, tu te coucheras. Lui t’indiquera ce que tu devras faire. »
###### 05
Et Ruth lui répondit : « Tout ce que tu me dis, je le ferai. »
###### 06
Elle descendit sur l’aire et fit tout ce que sa belle-mère lui avait ordonné.
###### 07
Booz mangea et but. Puis, le cœur content, il alla se coucher contre la meule. Alors, Ruth s’approcha discrètement, découvrit les pieds de Booz et se coucha.
###### 08
Or, au milieu de la nuit, l’homme frissonna, il se tourna pour voir : et voici qu’une femme était couchée à ses pieds !
###### 09
Il demanda : « Qui es-tu ? » Elle répondit : « C’est moi, Ruth ta servante. Étends sur ta servante le pan de ton manteau, car c’est toi qui as droit de rachat. »
###### 10
Alors, il dit : « Sois bénie du Seigneur, ma fille ! Ce geste d’attachement est encore plus beau que le premier : tu n’as pas recherché les jeunes gens, pauvres ou riches.
###### 11
Et maintenant, ma fille, n’aie pas peur ; tout ce que tu diras, je le ferai pour toi, car tout le monde ici sait que tu es une femme parfaite.
###### 12
C’est vrai que j’ai droit de rachat, mais il existe un plus proche parent que moi qui a droit de rachat.
###### 13
Passe donc la nuit ici, et demain matin, s’il veut te racheter, eh bien ! qu’il te rachète ! Mais s’il ne le veut pas, c’est moi qui te rachèterai, aussi vrai que le Seigneur est vivant ! Reste couchée jusqu’au matin ! »
###### 14
Elle resta donc couchée à ses pieds jusqu’au matin, mais elle se leva avant qu’on puisse reconnaître qui que ce soit. Car Booz se disait : « Il ne faut pas qu’on apprenne que cette femme est venue sur l’aire. »
###### 15
Il lui dit alors : « Présente le châle que tu portes et tiens-le bien. » Elle le tint donc ; il mesura six mesures d’orge et l’aida à s’en charger. Puis il rentra en ville.
###### 16
Ruth revint chez sa belle-mère qui lui demanda : « Que t’est-il arrivé, ma fille ? » Alors Ruth lui raconta tout ce que l’homme avait fait pour elle
###### 17
et elle ajouta : « Il m’a donné ces six mesures d’orge en me disant : “Ne rentre pas chez ta belle-mère les mains vides.” »
###### 18
Noémi lui dit : « Reste ici, ma fille, jusqu’à ce que tu saches comment l’affaire aboutira. Car cet homme n’aura de cesse qu’il n’ait conclu cette affaire, aujourd’hui même. »
