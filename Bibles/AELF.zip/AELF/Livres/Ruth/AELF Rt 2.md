---
aliases : 
- Ruth 2
- Ruth 2
- Rt 2
tags : 
- Bible/Rt/2
- français
cssclass : français
---

# Ruth 2

###### 01
Noémi avait un parent du côté de son mari Élimélek ; c’était un riche propriétaire du même clan ; il s’appelait Booz (c'est-à-dire : en-lui-la force).
###### 02
Ruth la Moabite dit à Noémi : « Laisse-moi aller glaner dans les champs, derrière celui aux yeux de qui je trouverai grâce. » Elle lui répondit : « Va, ma fille. »
###### 03
Ruth partit donc glaner dans les champs derrière les moissonneurs. Elle se trouva par bonheur dans la parcelle d’un champ appartenant à Booz, du clan d’Élimélek.
###### 04
Et voici que Booz arriva de Bethléem. Il dit aux moissonneurs : « Le Seigneur soit avec vous ! » Et ceux-ci lui répondirent : « Que le Seigneur te bénisse ! »
###### 05
Booz demanda à son serviteur, le chef des moissonneurs : « À qui appartient cette jeune femme ? »
###### 06
Celui-ci lui répondit : « Cette jeune femme est une Moabite. Elle est revenue avec Noémi des Champs-de-Moab.
###### 07
Elle a dit : “Laisse-moi glaner et ramasser ce qui tombe des gerbes, derrière les moissonneurs.” Depuis qu’elle est arrivée, elle est restée debout, depuis ce matin jusqu’à maintenant. C’est à peine si elle s’est reposée. »
###### 08
Booz dit à Ruth : « Tu m’entends bien, n’est-ce pas, ma fille ? Ne va pas glaner dans un autre champ. Ne t’éloigne pas de celui-ci, mais attache-toi aux pas de mes servantes.
###### 09
Regarde dans quel champ on moissonne, et suis-les. N’ai-je pas interdit aux serviteurs de te molester ? Si tu as soif, va boire aux cruches ce que les serviteurs auront puisé. »
###### 10
Alors Ruth se prosterna face contre terre et lui dit : « Pourquoi ai-je trouvé grâce à tes yeux, pourquoi t’intéresser à moi, moi qui suis une étrangère ? »
###### 11
Booz lui répondit : « On m’a dit et répété tout ce que tu as fait pour ta belle-mère après la mort de ton mari, comment tu as quitté ton père, ta mère et le pays de ta parenté, pour te rendre chez un peuple que tu n’avais jamais connu de ta vie.
###### 12
Que le Seigneur te rende en bien ce que tu as fait ! Qu’elle soit complète, la récompense dont te comblera le Seigneur, le Dieu d’Israël, sous les ailes de qui tu es venue t’abriter ! »
###### 13
Et Ruth lui dit : « Que je trouve toujours grâce à tes yeux, mon seigneur ! Oui, tu m’as consolée ; oui, tu as parlé au cœur de ta servante, à moi qui ne suis même pas comme l’une de tes servantes. »
###### 14
Au moment du repas, Booz lui dit : « Approche-toi ; mange de ce pain, trempe ton morceau dans la vinaigrette. » Elle s’assit à côté des moissonneurs, et Booz lui passa des épis grillés. Elle mangea, fut rassasiée et garda le reste.
###### 15
Alors elle se leva pour aller glaner, et Booz donna cet ordre à ses serviteurs : « Qu’elle glane aussi entre les gerbes. Ne la rabrouez pas !
###### 16
Et laissez même tomber des épis des brassées. Abandonnez-les, elle glanera. Ne la tracassez pas ! »
###### 17
Elle glana dans le champ jusqu’au soir ; puis elle égrena ce qu’elle avait glané : elle avait recueilli une quarantaine de mesures d’orge.
###### 18
Elle l’emporta et revint en ville. Elle montra à sa belle-mère ce qu’elle avait glané ; ce qu’elle avait gardé après s’être rassasiée, elle le sortit aussi pour le lui donner.
###### 19
Sa belle-mère lui dit : « Où donc as-tu glané aujourd’hui ? Où as-tu travaillé ? Béni soit celui qui s’est intéressé à toi ! » Elle raconta alors à sa belle-mère chez qui elle avait travaillé et lui dit : « L’homme chez qui j’ai travaillé aujourd’hui s’appelle Booz. »
###### 20
Noémi dit à sa belle-fille : « Il est béni du Seigneur, celui qui n’a pas oublié ses liens avec les vivants et les morts. » Et elle ajouta : « Cet homme est l’un de nos proches parents, l’un de ceux qui ont sur nous droit de rachat. »
###### 21
Ruth la Moabite dit : « Il m’a même déclaré : “Tu t’attacheras aux pas de mes serviteurs jusqu’à ce qu’ils aient terminé toute ma moisson.” »
###### 22
Noémi dit alors à Ruth, sa belle-fille : « C’est bien, ma fille, que tu ailles avec ses servantes ; ainsi tu ne seras pas maltraitée dans un autre champ. »
###### 23
Elle s’attacha donc aux pas des servantes de Booz pour glaner jusqu’à la fin de la moisson de l’orge et de la moisson du blé. Et elle habitait avec sa belle-mère.
