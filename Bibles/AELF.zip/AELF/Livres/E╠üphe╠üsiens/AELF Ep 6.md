---
aliases : 
- Éphésiens 6
- Éphésiens 6
- Ep 6
- Ephesians 6
tags : 
- Bible/Ep/6
- français
cssclass : français
---

# Éphésiens 6

###### 01
Vous, les enfants, obéissez à vos parents dans le Seigneur, car c’est cela qui est juste :
###### 02
Honore ton père et ta mère, c’est le premier commandement qui soit assorti d’une promesse :
###### 03
ainsi tu seras heureux et tu auras longue vie sur la terre.
###### 04
Et vous, les parents, ne poussez pas vos enfants à la colère, mais élevez-les en leur donnant une éducation et des avertissements inspirés par le Seigneur.
###### 05
Vous, les esclaves, obéissez à vos maîtres d’ici-bas comme au Christ, avec crainte et profond respect, dans la simplicité de votre cœur.
###### 06
Ne le faites pas seulement sous leurs yeux, par souci de plaire à des hommes, mais comme des esclaves du Christ qui accomplissent la volonté de Dieu de tout leur cœur,
###### 07
et qui font leur travail d’esclaves volontiers, comme pour le Seigneur et non pas pour des hommes.
###### 08
Car vous savez bien que chacun, qu’il soit esclave ou libre, sera rétribué par le Seigneur selon le bien qu’il aura fait.
###### 09
Et vous, les maîtres, agissez de même avec vos esclaves, laissez de côté les menaces. Car vous savez bien que, pour eux comme pour vous, le Maître est dans le ciel, et il est impartial envers les personnes.
###### 10
Enfin, puisez votre énergie dans le Seigneur et dans la vigueur de sa force.
###### 11
Revêtez l’équipement de combat donné par Dieu, afin de pouvoir tenir contre les manœuvres du diable.
###### 12
Car nous ne luttons pas contre des êtres de sang et de chair, mais contre les Dominateurs de ce monde de ténèbres, les Principautés, les Souverainetés, les esprits du mal qui sont dans les régions célestes.
###### 13
Pour cela, prenez l’équipement de combat donné par Dieu ; ainsi, vous pourrez résister quand viendra le jour du malheur, et tout mettre en œuvre pour tenir bon.
###### 14
Oui, tenez bon, ayant autour des reins le ceinturon de la vérité, portant la cuirasse de la justice,
###### 15
les pieds chaussés de l’ardeur à annoncer l’Évangile de la paix,
###### 16
et ne quittant jamais le bouclier de la foi, qui vous permettra d’éteindre toutes les flèches enflammées du Mauvais.
###### 17
Prenez le casque du salut et le glaive de l’Esprit, c’est-à-dire la parole de Dieu.
###### 18
En toute circonstance, que l’Esprit vous donne de prier et de supplier : restez éveillés, soyez assidus à la supplication pour tous les fidèles.
###### 19
Priez aussi pour moi : qu’une parole juste me soit donnée quand j’ouvre la bouche pour faire connaître avec assurance le mystère de l’Évangile
###### 20
dont je suis l’ambassadeur, dans mes chaînes. Priez donc afin que je trouve dans l’Évangile pleine assurance pour parler comme je le dois.
###### 21
Et vous, vous saurez ce que je deviens et ce que je fais, car Tychique, le frère bien-aimé, le fidèle ministre dans le Seigneur, vous informera de tout.
###### 22
Je l’envoie spécialement auprès de vous, afin que vous ayez de nos nouvelles et qu’il réconforte vos cœurs.
###### 23
Que la paix soit avec les frères, ainsi que l’amour et la foi, de la part de Dieu le Père et du Seigneur Jésus Christ.
###### 24
Que la grâce soit avec tous ceux qui aiment notre Seigneur Jésus Christ d’un amour impérissable.
