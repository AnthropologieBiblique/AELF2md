---
aliases : 
- Éphésiens 2
- Éphésiens 2
- Ep 2
- Ephesians 2
tags : 
- Bible/Ep/2
- français
cssclass : français
---

# Éphésiens 2

###### 01
Et vous, vous étiez des morts, par suite des fautes et des péchés
###### 02
qui marquaient autrefois votre conduite, soumise aux forces mauvaises de ce monde, au prince du mal qui s’interpose entre le ciel et nous, et dont le souffle est maintenant à l’œuvre en ceux qui désobéissent à Dieu.
###### 03
Et nous aussi, nous étions tous de ceux-là, quand nous vivions suivant les convoitises de notre chair, cédant aux caprices de la chair et des pensées, nous qui étions, de par nous-mêmes, voués à la colère comme tous les autres.
###### 04
Mais Dieu est riche en miséricorde ; à cause du grand amour dont il nous a aimés,
###### 05
nous qui étions des morts par suite de nos fautes, il nous a donné la vie avec le Christ : c’est bien par grâce que vous êtes sauvés.
###### 06
Avec lui, il nous a ressuscités et il nous a fait siéger aux cieux, dans le Christ Jésus.
###### 07
Il a voulu ainsi montrer, au long des âges futurs, la richesse surabondante de sa grâce, par sa bonté pour nous dans le Christ Jésus.
###### 08
C’est bien par la grâce que vous êtes sauvés, et par le moyen de la foi. Cela ne vient pas de vous, c’est le don de Dieu.
###### 09
Cela ne vient pas des actes : personne ne peut en tirer orgueil.
###### 10
C’est Dieu qui nous a faits, il nous a créés dans le Christ Jésus, en vue de la réalisation d’œuvres bonnes qu’il a préparées d’avance pour que nous les pratiquions.
###### 11
Vous qui autrefois étiez païens, traités de « non-circoncis » par ceux qui se disent circoncis à cause d’une opération pratiquée dans la chair, souvenez-vous donc
###### 12
qu’en ce temps-là vous n’aviez pas le Christ, vous n’aviez pas droit de cité avec Israël, vous étiez étrangers aux alliances et à la promesse, vous n’aviez pas d’espérance et, dans le monde, vous étiez sans Dieu.
###### 13
Mais maintenant, dans le Christ Jésus, vous qui autrefois étiez loin, vous êtes devenus proches par le sang du Christ.
###### 14
C’est lui, le Christ, qui est notre paix : des deux, le Juif et le païen, il a fait une seule réalité ; par sa chair crucifiée, il a détruit ce qui les séparait, le mur de la haine ;
###### 15
il a supprimé les prescriptions juridiques de la loi de Moïse. Ainsi, à partir des deux, le Juif et le païen, il a voulu créer en lui un seul Homme nouveau en faisant la paix,
###### 16
et réconcilier avec Dieu les uns et les autres en un seul corps par le moyen de la croix ; en sa personne, il a tué la haine.
###### 17
Il est venu annoncer la bonne nouvelle de la paix, la paix pour vous qui étiez loin, la paix pour ceux qui étaient proches.
###### 18
Par lui, en effet, les uns et les autres, nous avons, dans un seul Esprit, accès auprès du Père.
###### 19
Ainsi donc, vous n’êtes plus des étrangers ni des gens de passage, vous êtes concitoyens des saints, vous êtes membres de la famille de Dieu,
###### 20
car vous avez été intégrés dans la construction qui a pour fondations les Apôtres et les prophètes ; et la pierre angulaire, c’est le Christ Jésus lui-même.
###### 21
En lui, toute la construction s’élève harmonieusement pour devenir un temple saint dans le Seigneur.
###### 22
En lui, vous êtes, vous aussi, les éléments d’une même construction pour devenir une demeure de Dieu par l’Esprit Saint.
