---
aliases : 
- Éphésiens 3
- Éphésiens 3
- Ep 3
- Ephesians 3
tags : 
- Bible/Ep/3
- français
cssclass : français
---

# Éphésiens 3

###### 01
Moi, Paul, qui suis en prison à cause du Christ Jésus, je le suis pour vous qui venez des nations païennes.
###### 02
Vous avez appris, je pense, en quoi consiste la grâce que Dieu m’a donnée pour vous :
###### 03
par révélation, il m’a fait connaître le mystère, comme je vous l’ai déjà écrit brièvement.
###### 04
En me lisant, vous pouvez vous rendre compte de l’intelligence que j’ai du mystère du Christ.
###### 05
Ce mystère n’avait pas été porté à la connaissance des hommes des générations passées, comme il a été révélé maintenant à ses saints Apôtres et aux prophètes, dans l’Esprit.
###### 06
Ce mystère, c’est que toutes les nations sont associées au même héritage, au même corps, au partage de la même promesse, dans le Christ Jésus, par l’annonce de l’Évangile.
###### 07
De cet Évangile je suis devenu ministre par le don de la grâce que Dieu m’a accordée par l’énergie de sa puissance.
###### 08
À moi qui suis vraiment le plus petit de tous les fidèles, la grâce a été donnée d’annoncer aux nations l’insondable richesse du Christ,
###### 09
et de mettre en lumière pour tous le contenu du mystère qui était caché depuis toujours en Dieu, le créateur de toutes choses ;
###### 10
ainsi, désormais, les Puissances célestes elles-mêmes connaissent, grâce à l’Église, les multiples aspects de la Sagesse de Dieu.
###### 11
C’est le projet éternel que Dieu a réalisé dans le Christ Jésus notre Seigneur.
###### 12
Et notre foi au Christ nous donne l’assurance nécessaire pour accéder auprès de Dieu en toute confiance.
###### 13
Aussi, je vous demande de ne pas vous décourager devant les épreuves que j’endure pour vous : elles sont votre gloire.
###### 14
C’est pourquoi je tombe à genoux devant le Père,
###### 15
de qui toute paternité au ciel et sur la terre tient son nom.
###### 16
Lui qui est si riche en gloire, qu’il vous donne la puissance de son Esprit, pour que se fortifie en vous l’homme intérieur.
###### 17
Que le Christ habite en vos cœurs par la foi ; restez enracinés dans l'amour, établis dans l'amour.
###### 18
Ainsi vous serez capables de comprendre avec tous les fidèles quelle est la largeur, la longueur, la hauteur, la profondeur…
###### 19
Vous connaîtrez ce qui dépasse toute connaissance : l’amour du Christ. Alors vous serez comblés jusqu’à entrer dans toute la plénitude de Dieu.
###### 20
À Celui qui peut réaliser, par la puissance qu’il met à l’œuvre en nous, infiniment plus que nous ne pouvons demander ou même concevoir,
###### 21
gloire à lui dans l’Église et dans le Christ Jésus pour toutes les générations dans les siècles des siècles. Amen.
