---
aliases : 
- Éphésiens 4
- Éphésiens 4
- Ep 4
- Ephesians 4
tags : 
- Bible/Ep/4
- français
cssclass : français
---

# Éphésiens 4

###### 01
Moi qui suis en prison à cause du Seigneur, je vous exhorte donc à vous conduire d’une manière digne de votre vocation :
###### 02
ayez beaucoup d’humilité, de douceur et de patience, supportez-vous les uns les autres avec amour ;
###### 03
ayez soin de garder l’unité dans l’Esprit par le lien de la paix.
###### 04
Comme votre vocation vous a tous appelés à une seule espérance, de même il y a un seul Corps et un seul Esprit.
###### 05
Il y a un seul Seigneur, une seule foi, un seul baptême,
###### 06
un seul Dieu et Père de tous, au-dessus de tous, par tous, et en tous.
###### 07
À chacun d’entre nous, la grâce a été donnée selon la mesure du don fait par le Christ.
###### 08
C’est pourquoi l’Écriture dit :
Il est monté sur la hauteur, il a capturé des captifs,
il a fait des dons aux hommes.
###### 09
Que veut dire : Il est monté ? – Cela veut dire qu’il était d’abord descendu dans les régions inférieures de la terre.
###### 10
Et celui qui était descendu est le même qui est monté au-dessus de tous les cieux pour remplir l’univers.
###### 11
Et les dons qu’il a faits, ce sont les Apôtres, et aussi les prophètes, les évangélisateurs, les pasteurs et ceux qui enseignent.
###### 12
De cette manière, les fidèles sont organisés pour que les tâches du ministère soient accomplies et que se construise le corps du Christ,
###### 13
jusqu’à ce que nous parvenions tous ensemble à l’unité dans la foi et la pleine connaissance du Fils de Dieu, à l’état de l’Homme parfait, à la stature du Christ dans sa plénitude.
###### 14
Alors, nous ne serons plus comme des petits enfants, nous laissant secouer et mener à la dérive par tous les courants d’idées, au gré des hommes qui emploient la ruse pour nous entraîner dans l’erreur.
###### 15
Au contraire, en vivant dans la vérité de l’amour, nous grandirons pour nous élever en tout jusqu’à celui qui est la Tête, le Christ.
###### 16
Et par lui, dans l’harmonie et la cohésion, tout le corps poursuit sa croissance, grâce aux articulations qui le maintiennent, selon l’énergie qui est à la mesure de chaque membre. Ainsi le corps se construit dans l’amour.
###### 17
Je vous le dis, j’en témoigne dans le Seigneur : vous ne devez plus vous conduire comme les païens qui se laissent guider par le néant de leur pensée.
###### 18
Ils ont l’intelligence remplie de ténèbres, ils sont étrangers à la vie de Dieu, à cause de l’ignorance qui est en eux, à cause de l’endurcissement de leur cœur ;
###### 19
ayant perdu le sens moral, ils se sont livrés à la débauche au point de s’adonner sans retenue à toute sorte d’impureté.
###### 20
Mais vous, ce n’est pas ainsi que l’on vous a appris à connaître le Christ,
###### 21
si du moins l’annonce et l’enseignement que vous avez reçus à son sujet s’accordent à la vérité qui est en Jésus.
###### 22
Il s’agit de vous défaire de votre conduite d’autrefois, c’est-à-dire de l’homme ancien corrompu par les convoitises qui l’entraînent dans l’erreur.
###### 23
Laissez-vous renouveler par la transformation spirituelle de votre pensée.
###### 24
Revêtez-vous de l’homme nouveau, créé, selon Dieu, dans la justice et la sainteté conformes à la vérité.
###### 25
Débarrassez-vous donc du mensonge, et dites la vérité, chacun à son prochain, parce que nous sommes membres les uns des autres.
###### 26
Si vous êtes en colère, ne tombez pas dans le péché ; que le soleil ne se couche pas sur votre colère.
###### 27
Ne donnez pas prise au diable.
###### 28
Que le voleur cesse de voler ; qu’il prenne plutôt la peine de travailler honnêtement de ses mains, afin d’avoir de quoi partager avec celui qui est dans le besoin.
###### 29
Aucune parole mauvaise ne doit sortir de votre bouche ; mais, s’il en est besoin, que ce soit une parole bonne et constructive, profitable à ceux qui vous écoutent.
###### 30
N’attristez pas le Saint Esprit de Dieu, qui vous a marqués de son sceau en vue du jour de votre délivrance.
###### 31
Amertume, irritation, colère, éclats de voix ou insultes, tout cela doit être éliminé de votre vie, ainsi que toute espèce de méchanceté.
###### 32
Soyez entre vous pleins de générosité et de tendresse. Pardonnez-vous les uns aux autres, comme Dieu vous a pardonné dans le Christ.
