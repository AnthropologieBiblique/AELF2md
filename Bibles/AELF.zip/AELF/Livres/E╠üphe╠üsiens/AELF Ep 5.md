---
aliases : 
- Éphésiens 5
- Éphésiens 5
- Ep 5
- Ephesians 5
tags : 
- Bible/Ep/5
- français
cssclass : français
---

# Éphésiens 5

###### 01
Oui, cherchez à imiter Dieu, puisque vous êtes ses enfants bien-aimés.
###### 02
Vivez dans l’amour, comme le Christ nous a aimés et s’est livré lui-même pour nous, s’offrant en sacrifice à Dieu, comme un parfum d’agréable odeur.
###### 03
Comme il convient aux fidèles la débauche, l’impureté sous toutes ses formes et la soif de posséder sont des choses qu’on ne doit même plus évoquer chez vous ;
###### 04
pas davantage de propos grossiers, stupides ou scabreux – tout cela est déplacé – mais qu’il y ait plutôt des actions de grâce.
###### 05
Sachez-le bien : ni les débauchés, ni les dépravés, ni les profiteurs – qui sont de vrais idolâtres – ne reçoivent d’héritage dans le royaume du Christ et de Dieu ;
###### 06
ne laissez personne vous égarer par de vaines paroles. Tout cela attire la colère de Dieu sur ceux qui désobéissent.
###### 07
N’ayez donc rien de commun avec ces gens-là.
###### 08
Autrefois, vous étiez ténèbres ; maintenant, dans le Seigneur, vous êtes lumière ; conduisez-vous comme des enfants de lumière –
###### 09
or la lumière a pour fruit tout ce qui est bonté, justice et vérité –
###### 10
et sachez reconnaître ce qui est capable de plaire au Seigneur.
###### 11
Ne prenez aucune part aux activités des ténèbres, elles ne produisent rien de bon ; démasquez-les plutôt.
###### 12
Ce que ces gens-là font en cachette, on a honte même d’en parler.
###### 13
Mais tout ce qui est démasqué est rendu manifeste par la lumière,
###### 14
et tout ce qui devient manifeste est lumière. C’est pourquoi l’on dit :
Réveille-toi, ô toi qui dors,
relève-toi d’entre les morts,
et le Christ t’illuminera.
###### 15
Prenez bien garde à votre conduite : ne vivez pas comme des fous, mais comme des sages.
###### 16
Tirez parti du temps présent, car nous traversons des jours mauvais.
###### 17
Ne soyez donc pas insensés, mais comprenez bien quelle est la volonté du Seigneur.
###### 18
Ne vous enivrez pas de vin, car il porte à l’inconduite ; soyez plutôt remplis de l’Esprit Saint.
###### 19
Dites entre vous des psaumes, des hymnes et des chants inspirés, chantez le Seigneur et célébrez-le de tout votre cœur.
###### 20
À tout moment et pour toutes choses, au nom de notre Seigneur Jésus Christ, rendez grâce à Dieu le Père.
###### 21
Par respect pour le Christ, soyez soumis les uns aux autres ;
###### 22
les femmes, à leur mari, comme au Seigneur Jésus ;
###### 23
car, pour la femme, le mari est la tête, tout comme, pour l’Église, le Christ est la tête, lui qui est le Sauveur de son corps.
###### 24
Eh bien ! puisque l’Église se soumet au Christ, qu’il en soit toujours de même pour les femmes à l’égard de leur mari.
###### 25
Vous, les hommes, aimez votre femme à l’exemple du Christ : il a aimé l’Église, il s’est livré lui-même pour elle,
###### 26
afin de la rendre sainte en la purifiant par le bain de l’eau baptismale, accompagné d’une parole ;
###### 27
il voulait se la présenter à lui-même, cette Église, resplendissante, sans tache, ni ride, ni rien de tel ; il la voulait sainte et immaculée.
###### 28
C’est de la même façon que les maris doivent aimer leur femme : comme leur propre corps. Celui qui aime sa femme s’aime soi-même.
###### 29
Jamais personne n’a méprisé son propre corps : au contraire, on le nourrit, on en prend soin. C’est ce que fait le Christ pour l’Église,
###### 30
parce que nous sommes les membres de son corps. Comme dit l’Écriture :
###### 31
À cause de cela, l’homme quittera son père et sa mère, il s’attachera à sa femme, et tous deux ne feront plus qu’un.
###### 32
Ce mystère est grand : je le dis en référence au Christ et à l’Église.
###### 33
Pour en revenir à vous, chacun doit aimer sa propre femme comme lui-même, et la femme doit avoir du respect pour son mari.
