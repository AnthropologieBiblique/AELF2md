---
aliases : 
- Éphésiens 1
- Éphésiens 1
- Ep 1
- Ephesians 1
tags : 
- Bible/Ep/1
- français
cssclass : français
---

# Éphésiens 1

###### 01
PAUL, APOTRE du Christ Jésus
par la volonté de Dieu,
à ceux qui sont sanctifiés et habitent Éphèse,
eux qui croient au Christ Jésus.
###### 02
À vous, la grâce et la paix
de la part de Dieu notre Père
et du Seigneur Jésus Christ.
###### 03
Béni soit Dieu, le Père
de notre Seigneur Jésus Christ !
Il nous a bénis et comblés
des bénédictions de l’Esprit,
au ciel, dans le Christ.
###### 04
Il nous a choisis, dans le Christ,
avant la fondation du monde,
pour que nous soyons saints, immaculés
devant lui, dans l’amour.
###### 05
Il nous a prédestinés
à être, pour lui, des fils adoptifs
par Jésus, le Christ.
Ainsi l’a voulu sa bonté,
###### 06
à la louange de gloire de sa grâce,
la grâce qu’il nous donne
dans le Fils bien-aimé.
###### 07
En lui, par son sang,
nous avons la rédemption,
le pardon de nos fautes.
C’est la richesse de la grâce
###### 08
que Dieu a fait déborder jusqu’à nous
en toute sagesse et intelligence.
###### 09
Il nous dévoile ainsi le mystère de sa volonté,
selon que sa bonté l’avait prévu dans le Christ :
###### 10
pour mener les temps à leur plénitude,
récapituler toutes choses dans le Christ,
celles du ciel et celles de la terre.
###### 11
En lui, nous sommes devenus
le domaine particulier de Dieu,
nous y avons été prédestinés
selon le projet de celui qui réalise tout ce qu’il a décidé :
il a voulu
###### 12
que nous vivions
à la louange de sa gloire,
nous qui avons d’avance espéré dans le Christ.
###### 13
En lui, vous aussi,
après avoir écouté la parole de vérité,
l’Évangile de votre salut,
et après y avoir cru,
vous avez reçu la marque de l’Esprit Saint.
Et l’Esprit promis par Dieu
###### 14
est une première avance sur notre héritage,
en vue de la rédemption que nous obtiendrons,
à la louange de sa gloire.
###### 15
C’est pourquoi moi aussi, ayant entendu parler de la foi que vous avez dans le Seigneur Jésus, et de votre amour pour tous les fidèles,
###### 16
je ne cesse pas de rendre grâce, quand je fais mémoire de vous dans mes prières :
###### 17
que le Dieu de notre Seigneur Jésus Christ, le Père dans sa gloire, vous donne un esprit de sagesse qui vous le révèle et vous le fasse vraiment connaître.
###### 18
Qu’il ouvre à sa lumière les yeux de votre cœur, pour que vous sachiez quelle espérance vous ouvre son appel, la gloire sans prix de l’héritage que vous partagez avec les fidèles,
###### 19
et quelle puissance incomparable il déploie pour nous, les croyants : c’est l’énergie, la force, la vigueur
###### 20
qu’il a mise en œuvre dans le Christ quand il l’a ressuscité d’entre les morts et qu’il l’a fait asseoir à sa droite dans les cieux.
###### 21
Il l’a établi au-dessus de tout être céleste : Principauté, Souveraineté, Puissance et Domination, au-dessus de tout nom que l’on puisse nommer, non seulement dans le monde présent mais aussi dans le monde à venir.
###### 22
Il a tout mis sous ses pieds et, le plaçant plus haut que tout, il a fait de lui la tête de l’Église
###### 23
qui est son corps, et l’Église, c’est l’accomplissement total du Christ, lui que Dieu comble totalement de sa plénitude.
