---
aliases : 
- 1 Rois 8
- 1 Rois 8
- 1 R 8
- 1 Kings 8
tags : 
- Bible/1R/8
- français
cssclass : français
---

# 1 Rois 8

###### 01
Salomon rassembla auprès de lui à Jérusalem les anciens d’Israël et tous les chefs des tribus, les chefs de famille des fils d’Israël, pour aller chercher l’arche de l’Alliance du Seigneur dans la Cité de David, c’est-à-dire à Sion.
###### 02
Tous les hommes d’Israël se rassemblèrent auprès du roi Salomon au septième mois, durant la fête des Tentes.
###### 03
Quand tous les anciens d’Israël furent arrivés, les prêtres se chargèrent de l’Arche.
###### 04
Ils emportèrent l’arche du Seigneur et la tente de la Rencontre avec tous les objets sacrés qui s’y trouvaient ; ce sont les prêtres et les lévites qui les transportèrent.
###### 05
Le roi Salomon et, avec lui, toute la communauté d’Israël qu’il avait convoquée auprès de lui devant l’Arche offrirent en sacrifice des moutons et des bœufs : il y en avait un si grand nombre qu’on ne pouvait ni le compter ni l’évaluer.
###### 06
Puis les prêtres transportèrent l’Arche à sa place, dans la Chambre sainte que l’on appelle le Saint des saints, sous les ailes des kéroubim.
###### 07
Ceux-ci, en effet, étendaient leurs ailes au-dessus de l’emplacement de l’Arche : ils protégeaient l’Arche et ses barres.
###### 08
Les barres étaient si longues que l’on pouvait voir leurs extrémités depuis le sanctuaire, devant la Chambre sainte ; mais on ne les voyait pas de l’extérieur. Elles y sont encore à ce jour.
###### 09
Dans l’Arche, il n’y avait rien, sinon les deux tables de pierre que Moïse y avait placées au mont Horeb, quand le Seigneur avait conclu alliance avec les fils d’Israël, à leur sortie du pays d’Égypte.
###### 10
Quand les prêtres sortirent du sanctuaire, la nuée remplit la maison du Seigneur,
###### 11
et, à cause d’elle, les prêtres durent interrompre le service divin : la gloire du Seigneur remplissait la maison du Seigneur !
###### 12
Alors Salomon s’écria :
« Le Seigneur déclare demeurer dans la nuée obscure.
###### 13
Et maintenant, je t’ai construit, Seigneur,
une maison somptueuse,
un lieu où tu habiteras éternellement. »
###### 14
Puis le roi se retourna et bénit toute l’assemblée d’Israël ; or toute l’assemblée d’Israël se tenait debout.
###### 15
Il dit : « Béni soit le Seigneur, le Dieu d’Israël ! De sa bouche, il a parlé à David mon père et, de sa main, il a accompli ce qu’il avait dit :
###### 16
“Depuis le jour où j’ai fait sortir d’Égypte mon peuple Israël, je n’ai choisi aucune ville entre toutes les tribus d’Israël pour y construire une maison où serait mon nom. Mais j’ai choisi David pour qu’il soit le chef de mon peuple Israël.”
###### 17
Or David, mon père, avait pris à cœur de construire une maison pour le nom du Seigneur, le Dieu d’Israël.
###### 18
Mais le Seigneur a dit à David, mon père : “Tu as pris à cœur de construire une maison pour mon nom, et tu as bien fait de prendre cela à cœur.
###### 19
Cependant, ce n’est pas toi qui construiras la maison, mais ton fils, issu de toi : c’est lui qui construira la maison pour mon nom.”
###### 20
Le Seigneur a réalisé la parole qu’il avait dite, et j’ai succédé à David, mon père, je me suis assis sur le trône d’Israël, comme l’avait dit le Seigneur, et j’ai construit la maison pour le nom du Seigneur, le Dieu d’Israël.
###### 21
Là j’ai fixé un emplacement pour l’Arche où se trouve l’Alliance du Seigneur, l’Alliance qu’il a conclue avec nos pères lorsqu’il les fit sortir du pays d’Égypte. »
###### 22
Salomon se plaça devant l’autel du Seigneur, en face de toute l’assemblée d’Israël ; il étendit les mains vers le ciel
###### 23
et fit cette prière : « Seigneur, Dieu d’Israël, il n’y a pas de Dieu comme toi, ni là-haut dans les cieux, ni sur la terre ici-bas ; car tu gardes ton Alliance et ta fidélité envers tes serviteurs, quand ils marchent devant toi de tout leur cœur.
###### 24
Tu as gardé pour ton serviteur David, mon père, ce que tu lui avais dit ; et ce que tu lui avais dit de ta bouche, aujourd’hui tu l’as accompli de ta main.
###### 25
Et maintenant, Seigneur, Dieu d’Israël, par égard pour ton serviteur David, mon père, garde la parole que tu lui avais dite : “Tes descendants qui siégeront sur le trône d’Israël ne seront pas écartés de ma présence, pourvu que tes fils veillent à suivre leur chemin en marchant devant moi, comme tu as marché devant moi.”
###### 26
Maintenant donc, Dieu d’Israël, que se vérifie la parole que tu as dite à ton serviteur David, mon père !
###### 27
Est-ce que, vraiment, Dieu habiterait sur la terre ? Les cieux et les hauteurs des cieux ne peuvent te contenir : encore moins cette Maison que j’ai bâtie !
###### 28
Sois attentif à la prière et à la supplication de ton serviteur. Écoute, Seigneur mon Dieu, la prière et le cri qu’il lance aujourd’hui vers toi.
###### 29
Que tes yeux soient ouverts nuit et jour sur cette Maison, sur ce lieu dont tu as dit : “C’est ici que sera mon nom.” Écoute donc la prière que ton serviteur fera en ce lieu.
###### 30
Écoute la supplication de ton serviteur et de ton peuple Israël, lorsqu’ils prieront en ce lieu. Toi, dans les cieux où tu habites, écoute et pardonne.
###### 31
Lorsqu’un homme aura péché contre son prochain et qu’on lui imposera un serment qui peut se retourner contre lui, s’il vient à prêter ce serment devant ton autel dans cette Maison,
###### 32
toi, dans les cieux, écoute, agis et juge tes serviteurs. Déclare coupable le coupable : que sa conduite retombe sur sa tête ; déclare juste le juste : traite-le selon sa justice.
###### 33
Lorsque ton peuple Israël aura été battu devant l’ennemi, pour avoir péché contre toi, s’il revient à toi et célèbre ton nom, s’il prie et te supplie dans cette Maison,
###### 34
toi, dans les cieux, écoute, pardonne le péché de ton peuple Israël et fais-les revenir sur le sol que tu as donné à leurs pères.
###### 35
Lorsque les cieux seront fermés et qu’il n’y aura pas de pluie, parce que les fils d’Israël auront péché contre toi, s’ils prient vers ce lieu et célèbrent ton nom, s’ils se détournent de leur péché, parce que tu les auras humiliés,
###### 36
toi, dans les cieux, écoute, pardonne le péché de tes serviteurs et de ton peuple Israël. Tu leur enseigneras le bon chemin par où ils doivent marcher, et tu accorderas la pluie à ta terre, celle que tu as donnée à ton peuple en héritage.
###### 37
Lorsqu’il y aura la famine dans le pays, lorsqu’il y aura la peste, la rouille et la nigelle du blé, les sauterelles et les criquets, lorsque son ennemi assiégera une ville dans le pays, en tout fléau, en toute maladie,
###### 38
quel que soit le motif de la prière ou de la supplication émanant de tout homme ou de tout ton peuple Israël, dès l’instant où chacun reconnaît la plaie de son cœur et qu’il tend les mains vers cette Maison,
###### 39
toi, dans les cieux où tu habites, écoute, pardonne et agis. Traite chacun selon toute sa conduite, puisque tu connais son cœur – toi seul, en effet, connais le cœur de tout homme –,
###### 40
afin qu’ils te craignent, tous les jours qu’ils vivront devant toi sur le sol que tu as donné à nos pères.
###### 41
Si donc, à cause de ton nom, un étranger, qui n’est pas de ton peuple Israël, vient d’un pays lointain
###### 42
prier dans cette Maison,
###### 43
toi, dans les cieux où tu habites, écoute-le. Exauce toutes les demandes de l’étranger. Ainsi, tous les peuples de la terre, comme ton peuple Israël, vont reconnaître ton nom et te craindre. Et ils sauront que ton nom est invoqué sur cette Maison que j’ai bâtie.
###### 44
Lorsque ton peuple partira en guerre contre ses ennemis, dans la direction où tu l’auras envoyé, et qu’il priera le Seigneur, tourné vers la Ville que tu as choisie et vers la Maison que j’ai bâtie pour ton nom,
###### 45
toi, dans les cieux, écoute leur prière et leur supplication, et rends-leur justice.
###### 46
Lorsqu’ils pécheront contre toi – car il n’est pas d’être humain qui ne commette quelque péché – et que tu seras irrité contre eux, alors tu les livreras à la merci de leurs ennemis, et leurs vainqueurs les emmèneront captifs dans un pays ennemi, lointain ou proche.
###### 47
Si, au pays où ils auront été emmenés captifs, ils rentrent en eux-mêmes, s’ils se repentent, s’ils élèvent vers toi leur supplication dans le pays de ceux qui les ont faits prisonniers, en disant : “Nous avons péché, nous avons commis une faute, nous avons fait ce qui est mal” ;
###### 48
s’ils reviennent à toi de tout leur cœur et de toute leur âme, au pays de leurs ennemis qui les auront emmenés captifs, et s’ils prient vers toi, tournés vers le pays que tu as donné à leurs pères, vers la Ville que tu as choisie et vers la Maison que j’ai bâtie pour ton nom,
###### 49
toi, dans les cieux où tu habites, écoute leur prière et leur supplication, et rends-leur justice.
###### 50
Pardonne à ton peuple qui a péché contre toi, toutes les rebellions dont il s’est rendu coupable envers toi ; fais-le prendre en pitié par ses vainqueurs, que ceux-ci les prennent en pitié.
###### 51
Parce qu’ils sont ton peuple et ton héritage, eux que tu as fait sortir d’Égypte, de cette fournaise à fondre le fer,
###### 52
tes yeux sont ouverts à la supplication de ton serviteur et à la supplication de ton peuple Israël, et tu les écoutes toutes les fois qu’ils crient vers toi.
###### 53
Car c’est toi qui les as séparés de tous les peuples de la terre, pour qu’ils deviennent ton héritage, comme tu l’as dit par l’intermédiaire de Moïse ton serviteur, quand tu as fait sortir d’Égypte nos pères, Seigneur notre Dieu. »
###### 54
Quand Salomon eut achevé d’adresser au Seigneur toute cette prière et toute cette supplication, il se releva de devant l’autel du Seigneur, là où il s’était incliné et, les mains tendues vers le ciel,
###### 55
il se tint debout et bénit toute l’assemblée d’Israël d’une voix forte, en disant :
###### 56
« Béni soit le Seigneur ! Comme il l’avait dit, il a donné à son peuple Israël le pays de son repos ; aucune des promesses qu’il avait faites par l’intermédiaire de son serviteur Moïse n’est restée sans effet.
###### 57
Que le Seigneur notre Dieu soit avec nous, comme il a été avec nos pères, qu’il ne nous abandonne pas, qu’il ne nous rejette pas !
###### 58
Qu’il incline nos cœurs vers lui, pour que nous suivions tous ses chemins et que nous gardions les commandements, les décrets et les ordonnances qu’il a donnés à nos pères.
###### 59
Ces supplications que j’ai prononcées devant le Seigneur notre Dieu, qu’elles lui restent présentes jour et nuit, afin qu’il rende justice à moi son serviteur et à son peuple Israël, jour après jour.
###### 60
Tous les peuples de la terre sauront alors que c’est le Seigneur qui est Dieu, il n’y en a pas d’autre.
###### 61
Alors, en observant ses décrets et en gardant ses commandements, votre cœur sera tout entier au Seigneur notre Dieu, comme aujourd’hui. »
###### 62
Le roi et tout Israël avec lui offraient des sacrifices devant le Seigneur.
###### 63
Salomon offrit en sacrifice vingt-deux mille bœufs et cent vingt mille moutons, sacrifice de paix qu’il offrait au Seigneur. C’est ainsi que le roi et tous les fils d’Israël firent la dédicace de la maison du Seigneur.
###### 64
Ce jour-là, le roi consacra le milieu de la cour qui était devant la maison du Seigneur. C’est là, en effet, qu’il offrit l’holocauste, l’offrande de céréales et les graisses des sacrifices de paix, car l’autel de bronze qui était devant le Seigneur était trop petit pour contenir l’holocauste, l’offrande de céréales et les graisses des sacrifices de paix.
###### 65
En ce temps-là, Salomon – et tout Israël avec lui – célébra la fête des Tentes : ce fut un grand rassemblement, depuis l’Entrée-de-Hamath jusqu’au Torrent d’Égypte, en présence du Seigneur notre Dieu, durant sept jours.
###### 66
Le huitième jour, il renvoya le peuple. Les gens bénirent le roi et s’en allèrent à leurs tentes, joyeux et le cœur content pour tout le bien que le Seigneur avait accordé à David, son serviteur, et à Israël, son peuple.
