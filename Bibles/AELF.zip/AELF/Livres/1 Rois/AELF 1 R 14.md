---
aliases : 
- 1 Rois 14
- 1 Rois 14
- 1 R 14
- 1 Kings 14
tags : 
- Bible/1R/14
- français
cssclass : français
---

# 1 Rois 14

###### 01
En ce temps-là, Abiya, fils de Jéroboam, tomba malade.
###### 02
Jéroboam dit à sa femme : « Lève-toi, je te prie : déguise-toi, pour que l’on ne sache pas que tu es la femme de Jéroboam. Va à Silo : là se trouve le prophète Ahias, qui a dit de moi que je serais roi sur ce peuple.
###### 03
Emporte dix pains, des gâteaux secs, un pot de miel, et va le trouver chez lui. Il te révélera ce qui adviendra de l’enfant. »
###### 04
La femme de Jéroboam fit ainsi. Elle se leva, partit pour Silo et se présenta à la maison d’Ahias. Or Ahias ne pouvait plus voir ; il avait le regard fixe à cause de son grand âge.
###### 05
Mais le Seigneur avait dit au prophète Ahias : « Voici : la femme de Jéroboam est en route pour te consulter au sujet de son fils qui est malade. Tu lui parleras de telle et telle manière. Et lorsqu’elle se présentera, elle se fera passer pour une étrangère. »
###### 06
Dès que le prophète Ahias entendit le bruit de ses pas dans l’entrée, il dit : « Entre, femme de Jéroboam. Pourquoi te fais-tu passer pour une étrangère ? J’ai pour toi un dur message.
###### 07
Va dire à Jéroboam : “Ainsi parle le Seigneur, Dieu d’Israël : Je t’ai élevé du milieu du peuple, et je t’ai placé comme chef sur mon peuple Israël ;
###### 08
j’ai arraché la royauté à la maison de David et je te l’ai donnée. Mais tu n’as pas été comme mon serviteur David, qui gardait mes commandements et me suivait de tout son cœur, pour ne faire que ce qui est juste à mes yeux.
###### 09
Tu as agi plus mal encore que tous ceux qui t’ont précédé : tu es allé te fabriquer d’autres dieux, des idoles de métal fondu, pour provoquer mon indignation, et moi, tu m’as rejeté derrière ton dos.
###### 10
C’est pourquoi, voici que je fais venir le malheur sur la maison de Jéroboam. J’exterminerai tous les mâles de la famille de Jéroboam, esclaves ou hommes libres en Israël. Je balaierai les derniers restes de la maison de Jéroboam, comme on balaie à fond les ordures.
###### 11
Celui de la famille de Jéroboam qui mourra dans la ville, les chiens le mangeront ; celui qui mourra dans les champs, l’oiseau du ciel le mangera. Car le Seigneur a parlé.”
###### 12
Quant à toi, debout ! Retourne dans ta maison. Au moment où tu entreras dans la ville, l’enfant mourra.
###### 13
Tout Israël le pleurera, puis on l’ensevelira. Lui seul, en effet, de la famille de Jéroboam, sera mis dans un tombeau, car en lui seul a été trouvé quelque chose de bon pour le Seigneur, le Dieu d’Israël.
###### 14
Le Seigneur suscitera pour lui-même un roi sur Israël qui supprimera la maison de Jéroboam. – C’est pour aujourd’hui ! Et même pour maintenant ! –
###### 15
Le Seigneur frappera Israël, qui deviendra comme le roseau qui s’agite dans l’eau. Il extirpera Israël du sol fertile qu’il avait donné à leurs pères. Il les dispersera jusqu’au-delà de l’Euphrate, puisqu’en fabriquant leurs poteaux sacrés, ils ont provoqué l’indignation du Seigneur.
###### 16
Il livrera Israël à cause des péchés que Jéroboam a commis, et des péchés qu’il a fait commettre à Israël. »
###### 17
La femme de Jéroboam se leva ; elle partit et revint à Tirsa. Et comme elle arrivait au seuil de la maison, l’enfant mourut.
###### 18
On l’ensevelit, et tout Israël le pleura, conformément à la parole que le Seigneur avait dite par l’intermédiaire de son serviteur Ahias le prophète.
###### 19
Le reste des actions de Jéroboam,
ses combats et son règne,
tout cela est écrit dans le livre des Annales des rois d’Israël.
###### 20
Le temps que régna Jéroboam fut de vingt-deux ans ;
puis il reposa avec ses pères.
Son fils Nadab régna à sa place.
###### 21
Roboam, fils de Salomon, régna en Juda. Roboam avait quarante et un ans lorsqu’il devint roi, et il régna dix-sept ans à Jérusalem, la ville que le Seigneur avait choisie parmi toutes les tribus d’Israël pour y mettre son nom. Sa mère s’appelait Naama, l’Ammonite.
###### 22
Mais les gens de Juda firent ce qui est mal aux yeux du Seigneur, ils provoquèrent son ardeur jalouse plus que n’avaient fait leurs pères, par les péchés qu’ils avaient commis.
###### 23
Eux aussi, ils se construisirent des temples dans les lieux sacrés, des stèles, des poteaux sacrés, sur toute colline élevée et sous tout arbre vert.
###### 24
On pratiqua même la prostitution sacrée dans le pays. Ils imitèrent toutes les abominations des nations que le Seigneur avait dépossédées devant les fils d’Israël.
###### 25
La cinquième année du règne de Roboam, Shishaq, roi d’Égypte, monta contre Jérusalem.
###### 26
Il s’empara des trésors de la maison du Seigneur et des trésors de la maison du roi ; il s’empara de tout ; il s’empara aussi de tous les boucliers d’or qu’avait faits Salomon.
###### 27
Le roi Roboam fit, pour les remplacer, des boucliers de bronze, et les confia aux chefs des gardes, à la porte de la maison du roi.
###### 28
À chaque fois que le roi se rendait à la maison du Seigneur, les gardes prenaient ces boucliers ; puis ils les rapportaient dans la salle des gardes.
###### 29
Le reste des actions de Roboam, tout ce qu’il a fait,
cela n’est-il pas écrit dans le livre des Annales des rois de Juda ?
###### 30
Il y eut continuellement la guerre entre Roboam et Jéroboam.
###### 31
Roboam reposa avec ses pères.
Il fut enseveli avec eux, dans la Cité de David.
Sa mère s’appelait Naama, l’Ammonite.
Son fils Abiam régna à sa place.
