---
aliases : 
- 1 Rois 1
- 1 Rois 1
- 1 R 1
- 1 Kings 1
tags : 
- Bible/1R/1
- français
cssclass : français
---

# 1 Rois 1

###### 01
LE ROI DAVID était vieux, avancé en âge ; on le couvrait de vêtements, et cela ne le réchauffait pas.
###### 02
Ses serviteurs lui dirent : « Que l’on cherche pour mon seigneur le roi une jeune fille, une vierge. Elle se tiendra devant le roi et prendra soin de lui. Elle se couchera tout contre toi, et cela tiendra chaud à mon seigneur le roi. »
###### 03
On chercha une belle jeune fille dans tout le territoire d’Israël. On trouva Abishag la Sunamite, et on la fit venir chez le roi.
###### 04
La jeune fille était vraiment très belle ; elle prit soin du roi et fut à son service, mais le roi ne s’unit pas à elle.
###### 05
Or, Adonias, fils de Hagguith, cherchait à s’élever. Il disait : « C’est moi qui régnerai ». Il se fit préparer un char, des cavaliers, ainsi que cinquante hommes pour courir devant lui.
###### 06
De sa vie, jamais son père ne l’avait attristé en disant : « Pourquoi as-tu agi ainsi ? » De plus, il avait très belle apparence. C’est lui que sa mère avait enfanté après Absalom.
###### 07
Il entra en pourparlers avec Joab, fils de Cerouya, et le prêtre Abiatar : tous deux se rangèrent à la suite d’Adonias.
###### 08
Mais ni le prêtre Sadoc, ni Benaya, fils de Joad, ni le prophète Nathan, ni Shiméï et Réhi, ni les Braves de David ne furent avec Adonias.
###### 09
Adonias offrit en sacrifice des moutons, des bœufs et des veaux gras près de la « Pierre-Qui-Glisse », qui se trouve à côté de la source du Foulon. Il invita tous ses frères, les fils du roi, et tous les hommes de Juda qui étaient au service du roi.
###### 10
Mais le prophète Nathan, Benaya, les Braves et Salomon son frère, il ne les invita pas.
###### 11
Nathan dit à Bethsabée, la mère de Salomon : « N’as-tu pas appris qui est devenu roi ? Adonias, fils de Hagguith ! Et notre seigneur David ne le sait pas !
###### 12
Maintenant, va : laisse-moi te donner un conseil, ainsi tu préserveras ta vie et celle de ton fils Salomon !
###### 13
Va, entre chez le roi David et dis-lui : “N’est-ce pas toi, mon seigneur le roi, qui l’as juré à ta servante : Oui, Salomon ton fils régnera après moi et c’est lui qui s’assiéra sur mon trône ? Pourquoi donc Adonias est-il devenu roi ?”
###### 14
Tandis que tu seras là en train de parler avec le roi, moi-même, j’entrerai après toi et je confirmerai tes paroles. »
###### 15
Et Bethsabée entra chez le roi, jusque dans sa chambre. Le roi était très vieux, et Abishag la Sunamite accomplissait son service auprès du roi.
###### 16
Bethsabée se mit à genoux et se prosterna devant le roi. Le roi lui demanda : « Que désires-tu ? »
###### 17
Elle lui répondit : « Mon seigneur, c’est toi qui as juré à ta servante, par le Seigneur ton Dieu : “Oui, Salomon ton fils régnera après moi : et c’est lui qui s’assiéra sur mon trône.”
###### 18
Or, maintenant voici qu’Adonias est devenu roi ! Cependant, mon seigneur le roi, tu n’en sais rien.
###### 19
Il a offert en sacrifice des taureaux, des veaux gras, des moutons en grand nombre. Il a invité tous les fils du roi, ainsi que le prêtre Abiatar, et Joab, le chef de l’armée. Mais Salomon, ton serviteur, il ne l’a pas invité.
###### 20
Mon seigneur le roi, c’est sur toi que tout Israël a les yeux fixés, pour que tu leur annonces qui s’assiéra sur le trône de mon seigneur le roi, après lui !
###### 21
Lorsque mon seigneur le roi reposera avec ses pères, que deviendrons-nous, moi et mon fils Salomon ? Des coupables ! »
###### 22
Tandis qu’elle parlait avec le roi, voici que Nathan, le prophète, entra.
###### 23
On annonça au roi : « Voici Nathan, le prophète ! » Il entra chez le roi et se prosterna devant lui, visage contre terre.
###### 24
Nathan prit la parole : « Mon seigneur le roi, tu as donc décrété : “Adonias régnera après moi ; c’est lui qui s’assiéra sur mon trône” !
###### 25
Car il est descendu aujourd’hui, et il a offert en sacrifice des taureaux, des veaux gras, des moutons en grand nombre. Il a invité tous les fils du roi, les chefs de l’armée, et le prêtre Abiatar. Ils sont en train de boire et de manger en sa présence, et ils disent : “Vive le roi Adonias !”
###### 26
Mais moi, ton serviteur, le prêtre Sadoc, Benaya, fils de Joad, et Salomon ton serviteur, il ne nous a pas invités.
###### 27
Est-ce bien de mon seigneur le roi que provient cette affaire ? Pourtant tu n’as pas fait savoir à tes serviteurs qui doit s’asseoir sur le trône de mon seigneur le roi après lui ? »
###### 28
Le roi David répondit alors : « Appelez-moi Bethsabée ! » Elle entra donc chez le roi et se tint debout devant lui.
###### 29
Et le roi fit ce serment : « Par le Seigneur qui est vivant, lui qui a racheté mon âme de toute angoisse,
###### 30
oui, je l’ai juré par le Seigneur Dieu d’Israël : Salomon ton fils régnera après moi, et c’est lui qui s’assiéra sur mon trône à ma place. Cela, je le ferai aujourd’hui même ! »
###### 31
Bethsabée se mit à genoux, visage contre terre, et se prosterna devant le roi. Elle dit : « Que vive mon seigneur le roi David à jamais ! »
###### 32
Le roi David reprit : « Appelez-moi le prêtre Sadoc, le prophète Nathan, et Benaya, fils de Joad ». Ils entrèrent chez le roi.
###### 33
Et le roi leur dit : « Prenez avec vous les serviteurs de votre maître. Vous placerez mon fils Salomon sur ma propre mule, et vous le ferez descendre à Guihone.
###### 34
Là, le prêtre Sadoc et le prophète Nathan lui donneront l’onction comme roi sur Israël. Vous sonnerez du cor et vous direz : “Vive le roi Salomon !”
###### 35
Vous remonterez à sa suite, il viendra s’asseoir sur mon trône et c’est lui qui régnera à ma place. Car je l’ai établi comme chef sur Israël et sur Juda. »
###### 36
Benaya, fils de Joad, répondit au roi : « Amen ! Et qu’ainsi parle le Seigneur, Dieu de mon seigneur le roi !
###### 37
Comme le Seigneur était avec mon seigneur le roi, qu’il soit ainsi avec Salomon ! Et qu’il élève son trône plus haut que le trône de mon seigneur le roi David. »
###### 38
Alors descendirent le prêtre Sadoc, Benaya, fils de Joad, les Kerétiens et les Pelétiens. Ils placèrent Salomon sur la mule du roi et le conduisirent à Guihone.
###### 39
Le prêtre Sadoc prit dans la Tente la corne d’huile et donna l’onction à Salomon. On sonna du cor et tout le peuple dit : « Vive le roi Salomon ! »
###### 40
Tout le peuple remonta derrière lui. Le peuple jouait de la flûte et manifestait une joie débordante, au point que la terre se fendait à leurs voix.
###### 41
Adonias entendit, et tous ses invités avec lui. Ils finissaient de manger. Joab entendit le son du cor et demanda : « Pourquoi la cité résonne-t-elle de ce tumulte ? »
###### 42
Tandis qu’il parlait, arriva Jonathan, fils du prêtre Abiatar. Adonias lui dit : « Viens, car tu es un homme de valeur : ce sont de bonnes nouvelles que tu apportes ! »
###### 43
Mais Jonathan répondit à Adonias : « Au contraire ! Notre seigneur le roi David a fait roi Salomon !
###### 44
Le roi a envoyé avec lui le prêtre Sadoc et le prophète Nathan, Benaya, fils de Joad, les Kerétiens et les Pelétiens, et ils l’ont placé sur la mule du roi.
###### 45
Le prêtre Sadoc et le prophète Nathan lui ont donné l’onction comme roi à Guihone. Ils en sont remontés, tout joyeux ; la cité était en tumulte ! C’est là le bruit que vous avez entendu !
###### 46
Bien plus : Salomon s’est assis sur le trône royal !
###### 47
Et puis les serviteurs du roi sont venus présenter leurs vœux à notre seigneur le roi David en disant : “Que ton Dieu rende le nom de Salomon plus fameux que ton nom, et qu’il élève son trône au-dessus de ton trône !” Alors le roi s’est prosterné sur son lit.
###### 48
Et enfin, c’est ainsi qu’a parlé le roi : “Béni soit le Seigneur, le Dieu d’Israël, qui a donné aujourd’hui un homme pour s’asseoir sur mon trône, et qui a donné à mes yeux de le voir !” »
###### 49
Tous les invités d’Adonias tremblèrent et se levèrent. Et ils s’enfuirent chacun de son côté.
###### 50
Adonias eut peur de Salomon. Il se leva et s’en fut empoigner les cornes de l’autel.
###### 51
Cela fut rapporté à Salomon : « Voici qu’Adonias a peur du roi Salomon. Voici qu’il est allé saisir les cornes de l’autel, en disant : “Que le roi Salomon me jure dès aujourd’hui qu’il ne fera pas mourir son serviteur par l’épée !” »
###### 52
Salomon répondit : « S’il devient un homme de valeur, pas un de ses cheveux ne tombera à terre. Mais si du mal se trouve en lui, il mourra ! »
###### 53
Le roi Salomon envoya des gens le faire descendre de l’autel. Adonias vint se prosterner devant le roi Salomon, et Salomon lui dit : « Va dans ta maison ! »
