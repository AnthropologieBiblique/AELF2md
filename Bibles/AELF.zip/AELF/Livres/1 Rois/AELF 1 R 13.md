---
aliases : 
- 1 Rois 13
- 1 Rois 13
- 1 R 13
- 1 Kings 13
tags : 
- Bible/1R/13
- français
cssclass : français
---

# 1 Rois 13

###### 01
Voici qu’un homme de Dieu vint de Juda à Béthel, par ordre du Seigneur. Jéroboam se tenait à l’autel et brûlait de l’encens.
###### 02
L’homme interpella l’autel, par ordre du Seigneur, en ces termes : « Autel, autel, ainsi parle le Seigneur ! Voici : un fils va naître pour la Maison de David ; son nom sera Josias ; sur toi, il offrira en sacrifice les prêtres des lieux sacrés, qui, sur toi, brûlent de l’encens. On consumera sur toi des ossements humains. »
###### 03
Ce jour-là, il annonça qu’il y aurait un signe. Il dit : « Voici le signe montrant que le Seigneur a parlé : l’autel va se fendre et la cendre qui est dessus se répandra. »
###### 04
Dès que le roi entendit la parole que l’homme de Dieu avait proférée contre l’autel de Béthel, Jéroboam tendit la main de dessus l’autel, en disant : « Saisissez-le ! » Mais la main qu’il avait tendue contre l’homme sécha, et il ne pouvait plus la ramener à lui.
###### 05
L’autel se fendit, et la cendre se répandit de l’autel, conformément au signe qu’avait donné l’homme de Dieu par ordre du Seigneur.
###### 06
Prenant alors la parole, le roi dit à l’homme de Dieu : « Apaise, je te prie, le visage du Seigneur ton Dieu ; intercède pour moi : que ma main revienne à moi ! » L’homme de Dieu apaisa le visage du Seigneur. La main du roi revint à lui et elle fut comme auparavant.
###### 07
Le roi s’adressa à l’homme de Dieu : « Viens avec moi à la maison pour te restaurer, et je t’offrirai un cadeau. »
###### 08
L’homme de Dieu dit au roi : « Même si tu m’offrais la moitié de ta maison, je n’entrerais pas chez toi, je ne mangerais pas de pain et ne boirais pas d’eau en ce lieu.
###### 09
Car il m’a été ordonné par la parole du Seigneur :
Tu ne mangeras pas de pain,
tu ne boiras pas d’eau,
et tu ne retourneras pas
par le chemin que tu as pris pour venir. »
###### 10
Il prit donc un autre chemin, et ne retourna pas par le chemin qu’il avait pris pour venir à Béthel.
###### 11
Or à Béthel demeurait un vieux prophète. Ses fils vinrent lui raconter tout ce qu’avait fait l’homme de Dieu à Béthel ce jour-là ; tout ce qu’il avait dit au roi, ils le racontèrent à leur père.
###### 12
Leur père leur demanda : « Quel chemin a-t-il pris ? » Ses fils lui montrèrent le chemin qu’avait pris l’homme de Dieu venu de Juda.
###### 13
Il dit à ses fils : « Sellez-moi un âne. » Ils lui sellèrent l’âne, et il monta dessus.
###### 14
Il partit sur les traces de l’homme de Dieu et le trouva assis sous le térébinthe. Il lui dit : « Es-tu l’homme de Dieu venu de Juda ? » Il répondit : « C’est moi. »
###### 15
Il lui dit alors : « Viens avec moi, dans ma maison, manger un morceau de pain. »
###### 16
Mais l’autre répondit : « Je ne puis ni retourner avec toi, ni t’accompagner ; je ne mangerai pas de pain et ne boirai pas d’eau avec toi en ce lieu.
###### 17
Car il m’a été dit par ordre du Seigneur :
Tu ne mangeras pas de pain,
tu ne boiras pas d’eau là-bas,
tu ne prendras pas au retour le chemin de l’aller. »
###### 18
Le vieux prophète insista : « Je suis prophète, moi aussi, tout comme toi ! Un ange m’a parlé sur l’ordre du Seigneur. Il m’a dit : Ramène-le avec toi dans ta maison ; qu’il mange du pain et boive de l’eau. » Mais il lui mentait !
###### 19
L’homme de Dieu revint donc avec lui, mangea du pain dans sa maison et but de l’eau.
###### 20
Or, tandis qu’ils étaient à table, une parole du Seigneur fut adressée au prophète qui l’avait fait revenir.
###### 21
Il interpella l’homme de Dieu venu de Juda : « Ainsi parle le Seigneur : Puisque tu as bravé l’ordre du Seigneur, que tu n’as pas gardé le commandement du Seigneur ton Dieu,
###### 22
et puisque tu es revenu, que tu as mangé du pain et bu de l’eau en ce lieu dont il t’avait dit : “N’y mange pas de pain et n’y bois pas d’eau”, ton cadavre n’entrera pas dans le tombeau de tes pères. »
###### 23
Après qu’il eut mangé du pain et bu de l’eau, le vieux prophète sella son âne pour l’homme de Dieu qu’il avait fait revenir.
###### 24
Celui-ci partit. Un lion le rencontra en chemin et le tua. Son cadavre gisait sur le chemin ; l’âne se tenait à côté de lui, le lion se tenait aussi à côté du cadavre.
###### 25
Voici que des passants virent le cadavre qui gisait sur le chemin, et le lion qui se tenait à côté du cadavre. Ils allèrent en parler dans la ville où habitait le vieux prophète.
###### 26
Le prophète qui avait détourné l’homme de Dieu de son chemin apprit la nouvelle, et il dit : « C’est l’homme de Dieu qui a bravé l’ordre du Seigneur. Le Seigneur l’a livré au lion qui l’a broyé et l’a tué, conformément à la parole que le Seigneur lui avait dite. »
###### 27
Il dit à ses fils : « Sellez-moi un âne ». Ils le sellèrent.
###### 28
Il partit et trouva le cadavre gisant sur le chemin. L’âne et le lion se tenaient à côté du cadavre. Le lion n’avait pas dévoré le cadavre, ni rompu l’échine de l’âne.
###### 29
Le prophète releva le cadavre de l’homme de Dieu, le disposa sur l’âne et le ramena. Le vieux prophète revint à la ville pour le pleurer et l’ensevelir.
###### 30
Il déposa le cadavre dans son propre tombeau. Et on le pleura ainsi : « Hélas, mon frère ! »
###### 31
Après l’avoir enseveli, il dit à ses fils : « Quand je mourrai, vous m’ensevelirez dans le tombeau où est enseveli l’homme de Dieu. À côté de ses os, vous déposerez mes os.
###### 32
Car elle se réalisera, la parole qu’il a proférée par ordre du Seigneur contre l’autel de Béthel et contre tous les temples des lieux sacrés qui sont dans les villes de Samarie. »
###### 33
Après ces événements, Jéroboam persévéra dans sa mauvaise conduite ; il continua d’instituer n’importe qui comme prêtres des lieux sacrés : il donnait l’investiture à tous ceux qui le désiraient, pour en faire des prêtres des lieux sacrés.
###### 34
Tout cela fit tomber dans le péché la maison de Jéroboam, entraîna sa ruine et provoqua sa disparition de la surface de la terre.
