---
aliases : 
- 1 Rois 20
- 1 Rois 20
- 1 R 20
- 1 Kings 20
tags : 
- Bible/1R/20
- français
cssclass : français
---

# 1 Rois 20

###### 01
Ben-Hadad, roi d’Aram, réunit toute son armée. Il avait avec lui trente-deux rois, des chevaux et des chars. Il monta assiéger Samarie et l’attaqua.
###### 02
Il envoya dans la ville des messagers à Acab, roi d’Israël,
###### 03
pour lui dire : « Ainsi parle Ben-Hadad : “Ton argent et ton or sont à moi ! À moi, tes femmes et les meilleurs de tes fils !” »
###### 04
Le roi d’Israël répondit : « Selon tes ordres, mon seigneur le roi, je suis à toi, moi et tout ce qui m’appartient. »
###### 05
Les messagers revinrent et dirent à nouveau : « Ainsi parle Ben-Hadad. Je t’ai envoyé ce message : “Ton argent, ton or, tes femmes et tes fils, tu me les donneras !”
###### 06
Eh bien, demain à la même heure, je t’enverrai mes serviteurs ; ils fouilleront ta maison et les maisons de tes serviteurs. Ils mettront la main sur tout ce qui réjouit tes yeux et ils l’emporteront ! »
###### 07
Le roi d’Israël convoqua tous les anciens du pays et dit : « Reconnaissez-le ! Vous voyez bien que cet homme nous veut du mal. Quand il m’a réclamé mes femmes et mes fils, mon argent et mon or, je ne lui ai rien refusé ! »
###### 08
Tous les anciens et tout le peuple lui dirent : « Ne l’écoute pas ! N’accepte pas ! »
###### 09
Il répondit aux messagers de Ben-Hadad : « Dites à mon seigneur le roi : “Tout ce que tu as fait demander à ton serviteur la première fois, je le ferai. Mais cette exigence, je ne peux la satisfaire.” » Les messagers s’en allèrent et rapportèrent au roi la réponse.
###### 10
Ben-Hadad lui envoya dire : « Que les dieux amènent le malheur sur moi, et pire encore, s’il reste à Samarie assez de poussière pour que tous les gens qui me suivent en aient une poignée. »
###### 11
Le roi d’Israël lui fit répondre : « Dites-lui : “Celui qui boucle son ceinturon, qu’il ne crie pas victoire comme celui qui le détache !” »
###### 12
Quand il entendit cette parole, Ben-Hadad, qui était en train de boire avec les rois sous les tentes, dit à ses serviteurs : « À vos postes ! », et ils prirent position contre la ville.
###### 13
Voici qu’un prophète s’avança au-devant d’Acab, roi d’Israël, et lui dit : « Ainsi parle le Seigneur : As-tu vu cette grande multitude ? Voici que je la livre aujourd’hui dans ta main, et tu reconnaîtras que je suis le Seigneur ! »
###### 14
Acab demanda : « Par qui me la livres-tu ? » Il répondit : « Ainsi parle le Seigneur : Par l’élite des chefs de districts. » Acab reprit : « Qui engagera le combat ? » Le prophète répondit : « Toi ! »
###### 15
Acab passa en revue l’élite des chefs de districts : ils étaient deux cent quarante-deux. Après eux, il passa en revue tout le peuple, tous les fils d’Israël : sept mille hommes.
###### 16
Ils firent une sortie à l’heure de midi, tandis que Ben-Hadad, sous les tentes, buvait jusqu’à l’ivresse avec les rois, les trente-deux rois, ses alliés.
###### 17
L’élite des chefs de districts sortit d’abord. Ben-Hadad envoya aux nouvelles ; on lui fit ce rapport : « Des hommes sont sortis de Samarie. »
###### 18
Il répondit : « S’ils sortent pour la paix, prenez-les vivants. S’ils sortent pour le combat, prenez-les vivants aussi. »
###### 19
Ceux qui étaient sortis de la ville, c’était l’élite des chefs de districts, et l’armée venait après eux.
###### 20
Et ils frappèrent chacun son homme. Les Araméens s’enfuirent, et Israël les poursuivit. Ben-Hadad, roi d’Aram, se sauva à cheval avec quelques cavaliers.
###### 21
Le roi d’Israël sortit, il frappa les chevaux et les chars, infligeant à Aram une grande défaite.
###### 22
Le prophète s’avança vers le roi d’Israël. Il lui dit : « Va ! Montre-toi courageux ! Considère bien ce que tu dois faire, car au retour du printemps le roi d’Aram montera contre toi. »
###### 23
Les serviteurs du roi d’Aram lui dirent : « Leur dieu est un dieu des montagnes, c’est pourquoi ils l’ont emporté sur nous. Mais combattons-les dans la plaine, et, à coup sûr, nous l’emporterons sur eux.
###### 24
Fais donc ceci : relève de son poste chacun des rois et mets à leur place des gouverneurs.
###### 25
Pour toi, recrute une armée aussi puissante que celle qui est tombée à tes côtés : cheval pour cheval et char pour char ; et livrons-leur bataille dans la plaine. Alors, à coup sûr, nous l’emporterons sur eux. » Il écouta leur avis et fit ainsi.
###### 26
Au retour du printemps, Ben-Hadad passa donc en revue les Araméens. Puis il monta vers Apheq pour livrer bataille à Israël.
###### 27
De leur côté, les fils d’Israël furent passés en revue et approvisionnés, puis ils marchèrent à la rencontre des Araméens. Les fils d’Israël campèrent en face d’eux, disposés comme deux petits troupeaux de chèvres, alors que les Araméens remplissaient le pays.
###### 28
L’homme de Dieu s’avança et dit au roi d’Israël : « Ainsi parle le Seigneur : Parce que les Araméens ont dit : “Le Seigneur est un dieu des montagnes, et non un dieu des vallées,” je livrerai entre tes mains cette grande multitude, et vous reconnaîtrez que je suis le Seigneur. »
###### 29
Ils campèrent les uns en face des autres, durant sept jours. Le septième jour, le combat s’engagea, et les fils d’Israël battirent les Araméens : cent mille fantassins en un seul jour.
###### 30
Ceux qui restaient s’enfuirent dans la ville d’Apheq, mais le rempart s’écroula sur ces vingt-sept mille hommes qui restaient. Et Ben-Hadad s’enfuit. Il entra dans la ville et se réfugia dans une chambre retirée.
###### 31
Ses serviteurs lui dirent : « Voici ! Nous avons entendu dire que les rois de la maison d’Israël sont des rois qui font miséricorde. Permets que mettions de la toile à sac autour de nos reins, et des cordes autour de nos têtes ; puis nous sortirons au-devant du roi d’Israël. Peut-être te laissera-t-il la vie sauve ? »
###### 32
Ils serrèrent de la toile à sac sur leurs reins et des cordes autour de leurs têtes. Puis ils se rendirent auprès du roi d’Israël. Ils lui dirent : « Ton serviteur Ben-Hadad a dit : “Pourrais-je avoir la vie sauve ?” » Il répondit : « Est-il encore vivant ? Il est mon frère ! »
###### 33
Les hommes virent là un bon présage ; ils se hâtèrent de le prendre au mot et dirent à leur tour : « Ben-Hadad est ton frère. » Acab reprit : « Allez le chercher. » Ben-Hadad sortit vers lui et celui-ci le fit monter sur son char.
###### 34
Ben-Hadad lui dit : « Les villes que mon père a prises à ton père, je les restitue, tu auras à Damas des rues pour le commerce, tout comme en possédait mon père à Samarie. Acab répondit : « Et moi, je te laisserai aller si nous faisons alliance. » Il conclut donc avec lui une alliance et le laissa partir.
###### 35
Par ordre du Seigneur, un des frères-prophètes dit à celui qui l’accompagnait : « Frappe-moi ! » Mais l’autre refusa de le frapper.
###### 36
Il lui dit : « Parce que tu n’as pas écouté la voix du Seigneur, dès que tu m’auras quitté, un lion te frappera. » L’autre s’était à peine éloigné que le lion le rencontra et le frappa.
###### 37
Le prophète rencontra un autre homme et lui dit : « Frappe-moi ! » L’autre le frappa et le blessa.
###### 38
Le prophète alla se poster, guettant le roi sur le chemin. Il s’était rendu méconnaissable, un bandeau sur les yeux.
###### 39
Comme le roi passait, il lui cria : « Ton serviteur était sorti pour s’engager dans la bataille. Soudain quelqu’un, s’écartant du combat, m’a amené un homme en disant : “Surveille cet homme ! S’il vient à disparaître, ta vie répondra pour sa vie, ou bien tu paieras la valeur d’un lingot d’argent”.
###### 40
Or, ton serviteur s’est occupé ici et là, et l’homme n’y était plus ! » Le roi d’Israël lui dit : « Voilà ta sentence ! Tu l’as rendue toi-même ! »
###### 41
Aussitôt l’homme enleva de ses yeux le bandeau, et le roi d’Israël s’aperçut que c’était un des prophètes.
###### 42
Celui-ci lui dit : « Ainsi parle le Seigneur : Parce que tu as laissé échapper de ta main l’homme que j’avais voué à l’anathème, ta vie répondra pour sa vie, et ton peuple pour son peuple. »
###### 43
Puis le roi d’Israël s’en retourna chez lui, sombre et irrité ; il rentra à Samarie.
