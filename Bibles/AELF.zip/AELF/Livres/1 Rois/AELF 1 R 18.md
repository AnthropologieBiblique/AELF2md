---
aliases : 
- 1 Rois 18
- 1 Rois 18
- 1 R 18
- 1 Kings 18
tags : 
- Bible/1R/18
- français
cssclass : français
---

# 1 Rois 18

###### 01
De nombreux jours s’écoulèrent, et la parole du Seigneur fut adressée à Élie, la troisième année, en ces termes : « Va te présenter devant Acab ; je vais envoyer la pluie sur la surface du sol. »
###### 02
Élie partit pour se présenter devant Acab. La famine s’aggravait alors à Samarie.
###### 03
Acab appela Abdias, le maître du palais. Or, Abdias craignait beaucoup le Seigneur.
###### 04
Ainsi, lorsque Jézabel avait supprimé les prophètes du Seigneur, Abdias avait pris cent prophètes, les avait cachés, cinquante à la fois dans une grotte, et les avait approvisionnés en pain et en eau.
###### 05
Acab dit à Abdias : « Va dans le pays, vers toutes les sources d’eau et vers tous les torrents ; peut-être trouverons-nous de l’herbe pour maintenir en vie chevaux et mulets ; et nous n’aurons pas à supprimer une partie des bêtes. »
###### 06
Ils se partagèrent le pays pour le parcourir. Acab alla seul par un chemin, et Abdias alla seul par un autre chemin.
###### 07
Tandis qu’Abdias était en chemin, voici qu’Élie vint à sa rencontre. Abdias le reconnut et tomba face contre terre. Il dit : « Est-ce bien toi, mon seigneur Élie ? »
###### 08
Il lui répondit : « C’est moi ! Va dire à ton maître : “Voici Élie” ! »
###### 09
Abdias reprit : « En quoi ai-je péché, pour que tu me livres, moi ton serviteur, aux mains d’Acab, et pour qu’il me fasse mourir ?
###### 10
Par la vie du Seigneur ton Dieu ! Il n’y a pas une nation, pas un royaume, où mon seigneur Acab ne t’ait envoyé chercher ! Quand on lui disait : “Il n’est pas ici”, il faisait jurer à ce royaume et à cette nation qu’on ne t’avait pas trouvé.
###### 11
Et maintenant, tu me dis : Va dire à ton maître : “Voici Élie” !
###### 12
Mais dès que je t’aurai quitté, l’Esprit du Seigneur t’emportera je ne sais où ; moi, j’irai informer Acab, qui ne te trouvera pas, et il me tuera. Pourtant, ton serviteur craint le Seigneur depuis sa jeunesse !
###### 13
N’a-t-on pas rapporté à mon seigneur Élie ce que j’ai fait lorsque Jézabel tuait les prophètes du Seigneur : comment j’ai caché cent des prophètes du Seigneur, cinquante par cinquante, dans des grottes, et comment je les ai approvisionnés en pain et en eau ?
###### 14
Et maintenant tu dis : “Va dire à ton maître : Voici Élie !” Mais il me tuera ! »
###### 15
Élie déclara : « Par la vie du Seigneur de l’univers devant qui je me tiens ! Aujourd’hui même, je me présenterai devant lui ! »
###### 16
Abdias partit donc à la rencontre d’Acab ; il l’informa, et Acab vint à la rencontre d’Élie.
###### 17
Quand Acab vit Élie, il lui dit : « Est-ce bien toi, porte-malheur d’Israël ? »
###### 18
Élie répondit : « Ce n’est pas moi qui porte malheur à Israël ; c’est toi et la maison de ton père, parce que vous avez abandonné les commandements du Seigneur et que tu as suivi les Baals.
###### 19
Et maintenant, convoque et réunis tout Israël près de moi sur le mont Carmel, avec les quatre cent cinquante prophètes de Baal et les quatre cents prophètes d’Ashéra qui mangent à la table de Jézabel. »
###### 20
Acab convoqua tout Israël et réunit les prophètes sur le mont Carmel.
###### 21
Élie se présenta devant la foule et dit : « Combien de temps allez-vous danser pour l’un et pour l’autre ? Si c’est le Seigneur qui est Dieu, suivez le Seigneur ; si c’est Baal, suivez Baal. » Et la foule ne répondit mot.
###### 22
Élie continua : « Moi, je suis le seul qui reste des prophètes du Seigneur, tandis que les prophètes de Baal sont quatre cent cinquante.
###### 23
Amenez-nous deux jeunes taureaux ; qu’ils en choisissent un, qu’ils le dépècent et le placent sur le bûcher, mais qu’ils n’y mettent pas le feu. Moi, je préparerai l’autre taureau, je le placerai sur le bûcher, mais je n’y mettrai pas le feu.
###### 24
Vous invoquerez le nom de votre dieu, et moi, j’invoquerai le nom du Seigneur : le dieu qui répondra par le feu, c’est lui qui est Dieu. » La foule répondit : « C’est d’accord. »
###### 25
Élie dit alors aux prophètes de Baal : « Choisissez votre taureau et commencez, car vous êtes les plus nombreux. Invoquez le nom de votre dieu, mais ne mettez pas le feu. »
###### 26
Ils prirent le taureau et le préparèrent, et ils invoquèrent le nom de Baal depuis le matin jusqu’au milieu du jour, en disant : « Ô Baal, réponds-nous ! » Mais il n’y eut ni voix ni réponse ; et ils dansaient devant l’autel qu’ils avaient dressé.
###### 27
Au milieu du jour, Élie se moqua d’eux en disant : « Criez plus fort, puisque c’est un dieu : il a des soucis ou des affaires, ou bien il est en voyage ; il dort peut-être, mais il va se réveiller ! »
###### 28
Ils crièrent donc plus fort et, selon leur coutume, ils se tailladèrent jusqu’au sang avec des épées et des lances.
###### 29
Dans l’après-midi, ils se livrèrent à des transes prophétiques jusqu’à l’heure du sacrifice du soir, mais il n’y eut ni voix, ni réponse, ni le moindre signe.
###### 30
Alors Élie dit à la foule : « Approchez. » Et toute la foule s’approcha de lui. Il releva l’autel du Seigneur, qui avait été démoli.
###### 31
Il prit douze pierres, selon le nombre des tribus des fils de Jacob à qui le Seigneur avait dit : « Ton nom sera Israël. »
###### 32
Avec ces pierres il érigea un autel au Seigneur. Il creusa autour de l’autel une rigole d’une capacité d’environ trente litres.
###### 33
Il disposa le bois, dépeça le taureau et le plaça sur le bûcher.
###### 34
Puis il dit : « Emplissez d’eau quatre cruches, et versez-les sur la victime et sur le bois. » Et l’on fit ainsi. Il dit : « Une deuxième fois ! » et l’on recommença. Il dit : « Une troisième fois ! » et l’on recommença encore.
###### 35
L’eau ruissela autour de l’autel, et la rigole elle-même fut remplie d’eau.
###### 36
À l’heure du sacrifice du soir, Élie le prophète s’avança et dit : « Seigneur, Dieu d’Abraham, d’Isaac et d’Israël, on saura aujourd’hui que tu es Dieu en Israël, que je suis ton serviteur, et que j’ai accompli toutes ces choses sur ton ordre.
###### 37
Réponds-moi, Seigneur, réponds-moi, pour que tout ce peuple sache que c’est toi, Seigneur, qui es Dieu, et qui as retourné leur cœur ! »
###### 38
Alors le feu du Seigneur tomba, il dévora la victime et le bois, les pierres et la poussière, et l’eau qui était dans la rigole.
###### 39
Tout le peuple en fut témoin ; les gens tombèrent face contre terre et dirent : « C’est le Seigneur qui est Dieu ! C’est le Seigneur qui est Dieu ! »
###### 40
Élie leur dit alors : « Saisissez les prophètes de Baal : que pas un seul ne s’échappe ! » Ils les saisirent. Élie les fit descendre au ravin du Qishone, et là il les égorgea.
###### 41
Le prophète Élie dit au roi Acab : « Monte, tu peux maintenant manger et boire, car j’entends le grondement de la pluie. »
###### 42
Acab monta pour aller manger et boire. Élie, de son côté, monta sur le sommet du Carmel, il se courba vers la terre et mit son visage entre ses genoux.
###### 43
Il dit à son serviteur : « Monte, et regarde du côté de la mer. » Le serviteur monta, regarda et dit : « Il n’y a rien. » Sept fois de suite, Élie lui dit : « Retourne. »
###### 44
La septième fois, le serviteur annonça : « Voilà un nuage qui monte de la mer, gros comme le poing. » Alors Élie dit au serviteur : « Va dire au roi Acab : “Attelle ton char et descends de la montagne, avant d’être arrêté par la pluie.” »
###### 45
Peu à peu, le ciel s’obscurcit de nuages, poussés par le vent, et il tomba une grosse pluie. Acab monta sur son char et partit pour la ville de Yizréel.
###### 46
La main du Seigneur s’empara du prophète ; Élie retroussa son vêtement et courut en avant d’Acab jusqu’à l’entrée de la ville de Yizréel.
