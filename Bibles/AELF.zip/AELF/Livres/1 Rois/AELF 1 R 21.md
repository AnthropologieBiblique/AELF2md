---
aliases : 
- 1 Rois 21
- 1 Rois 21
- 1 R 21
- 1 Kings 21
tags : 
- Bible/1R/21
- français
cssclass : français
---

# 1 Rois 21

###### 01
Naboth, de la ville de Yizréel, possédait une vigne à côté du palais d’Acab, roi de Samarie.
###### 02
Acab dit un jour à Naboth : « Cède-moi ta vigne ; elle me servira de jardin potager, car elle est juste à côté de ma maison ; je te donnerai en échange une vigne meilleure, ou, si tu préfères, je te donnerai l’argent qu’elle vaut. »
###### 03
Naboth répondit à Acab : « Que le Seigneur me préserve de te céder l’héritage de mes pères ! »
###### 04
Acab retourna chez lui sombre et irrité, parce que Naboth lui avait dit : « Je ne te céderai pas l’héritage de mes pères. » Il se coucha sur son lit, tourna son visage vers le mur, et refusa de manger.
###### 05
Sa femme Jézabel vint lui dire : « Pourquoi es-tu de mauvaise humeur ? Pourquoi ne veux-tu pas manger ? »
###### 06
Il répondit : « J’ai parlé à Naboth de Yizréel. Je lui ai dit : “Cède-moi ta vigne pour de l’argent, ou, si tu préfères, pour une autre vigne en échange.” Mais il a répondu : “Je ne te céderai pas ma vigne !” »
###### 07
Alors sa femme Jézabel lui dit : « Est-ce que tu es le roi d’Israël, oui ou non ? Lève-toi, mange, et retrouve ta bonne humeur : moi, je vais te donner la vigne de Naboth. »
###### 08
Elle écrivit des lettres au nom d’Acab, elle les scella du sceau royal, et elle les adressa aux anciens et aux notables de la ville où habitait Naboth.
###### 09
Elle avait écrit dans ces lettres : « Proclamez un jeûne, faites comparaître Naboth devant le peuple.
###### 10
Placez en face de lui deux vauriens, qui témoigneront contre lui : “Tu as maudit Dieu et le roi !” Ensuite, faites-le sortir de la ville, lapidez-le, et qu’il meure ! »
###### 11
Les anciens et les notables qui habitaient la ville de Naboth firent ce que Jézabel avait ordonné dans ses lettres.
###### 12
Ils proclamèrent un jeûne et firent comparaître Naboth devant le peuple.
###### 13
Alors arrivèrent les deux individus qui se placèrent en face de lui et portèrent contre lui ce témoignage : « Naboth a maudit Dieu et le roi. » On fit sortir Naboth de la ville, on le lapida, et il mourut.
###### 14
Puis on envoya dire à Jézabel : « Naboth a été lapidé et il est mort. »
###### 15
Lorsque Jézabel en fut informée, elle dit à Acab : « Va, prends possession de la vigne de ce Naboth qui a refusé de la céder pour de l’argent, car il n’y a plus de Naboth : il est mort. »
###### 16
Quand Acab apprit que Naboth était mort, il se rendit à la vigne de Naboth et en prit possession.
###### 17
La parole du Seigneur fut adressée au prophète Élie de Tishbé :
###### 18
« Lève-toi, va trouver Acab, qui règne sur Israël à Samarie. Il est en ce moment dans la vigne de Naboth, où il s’est rendu pour en prendre possession.
###### 19
Tu lui diras : “Ainsi parle le Seigneur : Tu as commis un meurtre, et maintenant tu prends possession. C’est pourquoi, ainsi parle le Seigneur : À l’endroit même où les chiens ont lapé le sang de Naboth, les chiens laperont ton sang à toi aussi.” »
###### 20
Acab dit à Élie : « Tu m’as donc retrouvé, toi, mon ennemi ! » Élie répondit : « Oui, je t’ai retrouvé. Puisque tu t’es déshonoré en faisant ce qui est mal aux yeux du Seigneur,
###### 21
je vais faire venir sur toi le malheur : je supprimerai ta descendance, j’exterminerai tous les mâles de ta maison, esclaves ou hommes libres en Israël.
###### 22
Je ferai à ta maison ce que j’ai fait à celle de Jéroboam, fils de Nebath, et à celle de Baasa, fils d’Ahias, tes prédécesseurs, car tu as provoqué ma colère et fait pécher Israël.
###### 23
Et le Seigneur a encore cette parole contre Jézabel : “Les chiens dévoreront Jézabel sous les murs de la ville de Yizréel !”
###### 24
Celui de la maison d’Acab qui mourra dans la ville sera dévoré par les chiens ; celui qui mourra dans la campagne sera dévoré par les oiseaux du ciel. »
###### 25
On n’a jamais vu personne se déshonorer comme Acab en faisant comme lui ce qui est mal aux yeux du Seigneur, sous l’influence de sa femme Jézabel.
###### 26
Il s’est conduit d’une manière abominable en s’attachant aux idoles, comme faisaient les Amorites que le Seigneur avait chassés devant les Israélites.
###### 27
Quand Acab entendit les paroles prononcées par Élie, il déchira ses habits, se couvrit le corps d’une toile à sac – un vêtement de pénitence – ; et il jeûnait, il gardait la toile à sac pour dormir, et il marchait lentement.
###### 28
Alors la parole du Seigneur fut adressée à Élie :
###### 29
« Tu vois comment Acab s’est humilié devant moi ! Puisqu’il s’est humilié devant moi, je ne ferai pas venir le malheur de son vivant ; c’est sous le règne de son fils que je ferai venir le malheur sur sa maison. »
