---
aliases : 
- 1 Rois 4
- 1 Rois 4
- 1 R 4
- 1 Kings 4
tags : 
- Bible/1R/4
- français
cssclass : français
---

# 1 Rois 4

###### 01
Le roi Salomon régnait sur tout Israël.
###### 02
Voici les chefs qu’il avait à son service :
Azarias, fils de Sadoc, le prêtre ;
###### 03
Élihoreph et Ahias, fils de Shisha : secrétaires ;
Josaphat, fils d’Ahiloud : archiviste ;
###### 04
Benaya, fils de Joad : chef de l’armée ;
Sadoc et Abiatar : prêtres ;
###### 05
Azarias, fils de Nathan : chef des préfets ;
Zaboud, fils de Nathan : prêtre et compagnon du roi ;
###### 06
Ahishar : maître du palais ;
Adoniram, fils d’Abda : chef de la corvée.
###### 07
De plus, Salomon avait douze préfets pour l’ensemble d’Israël. Ils approvisionnaient le roi et sa maison ; un mois par an, chacun son tour, ils assuraient l’approvisionnement.
###### 08
Voici leurs noms :
Ben-Hour, dans la montagne d’Éphraïm ;
###### 09
Ben-Déqer, à Macas, à Shaalvime, à Beth-Shèmesh et à Élone-Beth-Hanane ;
###### 10
Ben-Hésed, à Aroubboth ; il avait la responsabilité de Soko et de tout le pays de Héfer.
###### 11
Ben-Abinadab, celle des coteaux de Dor ; il eut pour femme Tafath, fille de Salomon.
###### 12
Baana, fils d’Ahiloud, avait Taanak et Meguiddo, ainsi que tout Beth-Shéane, à côté de Sartane, en dessous d’Izréel, depuis Beth-Shéane jusqu’à Abel-Mehola, au-delà de Yoqméam.
###### 13
Ben-Guèber, à Ramoth-de-Galaad, avait les campements de Yaïr, fils de Manassé, en Galaad ; il avait aussi la région d’Argob, dans le Bashane ; soixante grandes villes avec remparts et verrous de bronze.
###### 14
Ahinadab, fils de Iddo, à Mahanaïm ;
###### 15
Ahimaas, en Nephtali. Lui aussi prit pour femme une fille de Salomon, Basmath.
###### 16
Baana, fils de Houshaï, sur la contrée d’Asher et à Bealoth ;
###### 17
Josaphat, fils de Paroua, sur Issakar ;
###### 18
Shiméï, fils d’Éla, sur Benjamin ;
###### 19
Guéber, fils d’Ouri, sur le pays de Galaad, pays de Séhone, roi des Amorites, et d’Og, roi de Bashane ;
Et il y avait aussi un préfet dans le pays de Juda.
###### 20
Juda et Israël étaient nombreux, aussi nombreux que le sable au bord de la mer. On mangeait, on buvait et on était dans la joie.
