---
aliases : 
- 1 Rois 2
- 1 Rois 2
- 1 R 2
- 1 Kings 2
tags : 
- Bible/1R/2
- français
cssclass : français
---

# 1 Rois 2

###### 01
Comme les jours de David approchaient de leur fin, il exprima ses volontés à son fils Salomon :
###### 02
« Je m’en vais par le chemin de tout le monde. Sois fort, sois un homme courageux !
###### 03
Tu garderas les observances du Seigneur ton Dieu, en marchant dans ses chemins. Tu observeras ses décrets, ses commandements, ses ordonnances et ses édits, selon ce qui est écrit dans la loi de Moïse. Ainsi tu réussiras dans tout ce que tu feras et entreprendras,
###### 04
et le Seigneur réalisera cette parole qu’il m’a dite : “Si tes fils veillent à suivre leur chemin en marchant devant moi avec loyauté, de tout leur cœur et de toute leur âme, jamais tes descendants ne seront écartés du trône d’Israël.”
###### 05
Et de plus, tu sais toi-même ce que m’a fait Joab, fils de Cerouya, ce qu’il a fait aux deux chefs des armées d’Israël, Abner, fils de Ner, et Amasa, fils de Jéther : il les a tués ; il a, en temps de paix, versé le sang de la guerre, et mis le sang de la guerre sur le ceinturon de ses reins et les sandales de ses pieds.
###### 06
Tu agiras selon ta sagesse et tu ne laisseras pas ses cheveux blancs descendre en paix au séjour des morts.
###### 07
Envers les fils de Barzillaï de Galaad, tu agiras avec fidélité. Ils seront parmi tes invités à table, car ils ont agi de la même manière quand ils sont venus à ma rencontre, alors que je fuyais devant ton frère Absalom.
###### 08
Mais voici près de toi Shiméï, fils de Guéra, benjaminite de Bakourim. C’est lui qui m’a maudit d’une malédiction terrible, le jour de mon départ pour Mahanaïm. C’est lui aussi qui est venu à ma rencontre au Jourdain, lors de mon retour d’exil, et je lui ai juré par le Seigneur : “Je ne te mettrai pas à mort par l’épée”.
###### 09
Cependant, ne le tiens pas pour quitte, car tu es un homme sage : tu sais ce que tu dois lui faire ! Tu feras descendre dans le sang ses cheveux blancs au séjour des morts ! »
###### 10
David mourut, il reposa avec ses pères, et il fut enseveli dans la Cité de David.
###### 11
Le règne de David sur Israël avait duré quarante ans : il avait régné sept ans à Hébron, et trente-trois ans à Jérusalem.
###### 12
Salomon prit possession du trône de David son père, et sa royauté fut solidement établie.
###### 13
Adonias, fils de Hagguith, vint trouver Bethsabée, mère de Salomon. Elle lui demanda : « Viens-tu pour la paix ? » Il dit : « Pour la paix ».
###### 14
Il poursuivit : « J’ai à te parler. » Elle dit : « Parle ».
###### 15
Il reprit : « Tu sais bien, toi, que c’est à moi que revenait la royauté ! Tout Israël me regardait déjà comme son roi. Mais la royauté m’a échappé au profit de mon frère, car c’est du Seigneur qu’elle lui est venue.
###### 16
À présent, je n’ai qu’une demande à te faire : ne me repousse pas ! » Elle dit : « Parle »
###### 17
Il poursuivit : « Demande, je te prie, au roi Salomon – car il ne te repoussera pas – de me donner pour femme Abishag la Sunamite.
###### 18
Bethsabée promit : « Bien. Je parlerai moi-même au roi en ta faveur. »
###### 19
Bethsabée se rendit chez le roi Salomon pour lui parler en faveur d’Adonias. Le roi se leva, vint à sa rencontre et se prosterna devant elle. Puis il prit place sur son trône. Il fit installer également un trône pour la mère du roi, et elle prit place à sa droite.
###### 20
Elle dit : « Je n’ai qu’une petite demande à te faire : ne me repousse pas ! » Le roi lui dit : « Demande, ma mère, je ne te repousserai pas ! »
###### 21
Elle reprit : « Que l’on donne pour femme Abishag la Sunamite à ton frère Adonias. »
###### 22
Et le roi Salomon répondit à sa mère : « Pourquoi demandes-tu Abishag la Sunamite pour Adonias ? Demande donc pour lui la royauté, puisqu’aussi bien il est mon frère aîné ! Demande pour lui, pour le prêtre Abiatar et pour Joab, fils de Cerouya. »
###### 23
Et Salomon fit ce serment par le Seigneur : « Que Dieu amène le malheur sur moi, et pire encore ! C’est au prix de sa vie qu’Adonias a parlé.
###### 24
Maintenant, par le Seigneur qui est vivant, lui qui m’a fermement établi, qui m’a fait asseoir sur le trône de David, mon père, et qui, selon sa parole, m’a édifié une maison ; oui, Adonias sera mis à mort aujourd’hui même ! »
###### 25
Le roi Salomon envoya donc Benaya, fils de Joad ; celui-ci le frappa et il mourut.
###### 26
Au prêtre Abiatar, le roi déclara : « Pars pour Anatoth dans ton domaine, car tu mérites la mort ! Aujourd’hui cependant, je ne te tuerai pas, car tu as porté l’arche du Seigneur Dieu devant David, mon père, et tu as partagé toutes les épreuves que mon père a endurées. »
###### 27
Salomon démit Abiatar de sa fonction de prêtre du Seigneur, accomplissant ainsi la parole que le Seigneur avait dite contre la maison d’Éli, à Silo.
###### 28
La nouvelle en parvint à Joab. Joab en effet avait pris le parti d’Adonias, bien qu’il n’eût pas pris le parti d’Absalom. Joab se réfugia dans la tente du Seigneur et empoigna les cornes de l’autel.
###### 29
On rapporta au roi Salomon que Joab s’était réfugié dans la tente du Seigneur et qu’il se trouvait à côté de l’autel. Salomon envoya Benaya, fils de Joad, en lui disant : « Va ! Frappe-le ! »
###### 30
Benaya entra dans la tente du Seigneur et dit à Joab : « Ainsi parle le roi : sors d’ici ! » Mais l’autre refusa : « Non ! C’est ici que je mourrai ! » Benaya rapporta la chose au roi : « Ainsi a parlé Joab, ainsi m’a-t-il répondu. »
###### 31
Le roi lui répondit : « Fais donc comme il a dit ! Frappe-le à mort et enterre-le ! Tu détourneras ainsi de moi et de la maison de mon père le sang innocent qu’a répandu Joab !
###### 32
Le Seigneur fera retomber son sang sur sa tête, parce qu’il a frappé deux hommes plus justes et meilleurs que lui. Il les a tués par l’épée, à l’insu de David, mon père : Abner, fils de Ner, chef de l’armée d’Israël, et Amasa, fils de Jéther, chef de l’armée de Juda.
###### 33
Que leur sang retombe sur la tête de Joab et sur la tête de ses descendants, à jamais ! Mais pour David et pour sa descendance, pour sa maison et pour son trône, que demeure à jamais la paix qui vient du Seigneur ! »
###### 34
Benaya, fils de Joad, monta, frappa Joab et le mit à mort. Il fut enseveli dans sa maison, au désert.
###### 35
Le roi mit à sa place, comme chef de l’armée, Benaya, fils de Joad ; et il mit à la place d’Abiatar le prêtre Sadoc.
###### 36
Le roi fit convoquer Shiméï et lui dit : « Construis pour toi une maison à Jérusalem ; tu y demeureras, et n’en sortiras pas pour aller où que ce soit.
###### 37
Le jour où tu sortiras et passeras le ravin du Cédron, sache-le bien : à coup sûr tu mourras. Et ton sang sera sur ta tête. »
###### 38
Shiméï répondit au roi : « Très bien ! Conformément à la parole de mon seigneur le roi, ainsi se conduira ton serviteur. » Il demeura donc de longs jours à Jérusalem.
###### 39
Mais, au bout de trois ans, il arriva que deux serviteurs de Shiméï s’enfuirent chez Akish, fils de Maaka, roi de Gath. On vint en informer Shiméï : « Tes serviteurs se trouvent à Gath ! »
###### 40
Shiméï se leva, sella son âne, partit pour Gath, chez Akish, pour rechercher ses serviteurs. Shiméï partit donc et ramena de Gath ses serviteurs.
###### 41
On rapporta à Salomon que Shiméï était parti de Jérusalem pour Gath et en était revenu.
###### 42
Le roi fit convoquer Shiméï et lui dit : « Ne t’avais-je pas fait prêter serment par le Seigneur, et ne t’avais-je pas averti : “Le jour où tu sortiras pour aller où que ce soit, sache-le bien : à coup sûr tu mourras ?” Et tu m’as répondu : “Très bien ! J’ai entendu !”
###### 43
Pourquoi donc n’as-tu pas respecté le serment fait au Seigneur et l’ordre que je t’avais donné ? »
###### 44
Le roi dit à Shiméï : « Tu sais – et ton cœur le sait – tout le mal que tu as fait à David, mon père. Le Seigneur va faire retomber sur ta tête le mal que tu as commis.
###### 45
Mais le roi Salomon sera béni, et le trône de David, fermement établi devant le Seigneur pour toujours ! »
###### 46
Le roi donna un ordre à Benaya, fils de Joad. Celui-ci sortit ; il frappa Shiméï qui mourut. Et dans la main de Salomon fut affermie la royauté.
