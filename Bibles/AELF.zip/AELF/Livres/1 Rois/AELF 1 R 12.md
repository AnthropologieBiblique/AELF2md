---
aliases : 
- 1 Rois 12
- 1 Rois 12
- 1 R 12
- 1 Kings 12
tags : 
- Bible/1R/12
- français
cssclass : français
---

# 1 Rois 12

###### 01
Roboam se rendit à Sichem ; c’est à Sichem, en effet, que tout Israël était venu pour le faire roi.
###### 02
Jéroboam, fils de Nebath, apprit la nouvelle. À cette époque, il était encore en Égypte. – Il s’était enfui loin du roi Salomon et, depuis, il demeurait en Égypte.
###### 03
On envoya chercher Jéroboam, et il vint, ainsi que toute l’assemblée d’Israël. Ils s’adressèrent à Roboam en disant :
###### 04
« Ton père a rendu pénible notre joug ; toi, maintenant, allège la pénible servitude imposée par ton père, et le joug pesant qu’il nous a infligé ; alors nous te servirons. »
###### 05
Il leur répondit : « Retirez-vous pour trois jours, puis revenez vers moi. » Et le peuple se retira.
###### 06
Le roi Roboam prit conseil des anciens, ceux qui s’étaient tenus en présence de son père Salomon, de son vivant. Il leur dit : « Quelle réponse conseillez-vous de faire à ce peuple ? »
###### 07
Ils lui dirent alors : « Si tu te fais aujourd’hui le serviteur de ce peuple, si tu te mets à leur service, et si, dans ta réponse, tu leur adresses des paroles bienveillantes, ils seront tes serviteurs pour toujours. »
###### 08
Mais il négligea le conseil que lui donnaient les anciens ; il prit conseil des jeunes gens qui avaient grandi avec lui et qui se tenaient en sa présence.
###### 09
Il leur demanda : « Que conseillez-vous ? Quelle réponse allons-nous faire à ce peuple qui m’a parlé en disant : “Allège donc le joug que nous a infligé ton père” ? »
###### 10
Les jeunes gens qui avaient grandi avec lui répondirent : « Voici ce que tu répondras à ce peuple qui t’a parlé en disant : “Ton père a rendu lourd notre joug : mais toi, pour nous, allège-le”. Voici ce que tu leur diras : “Mon petit doigt est plus fort que les reins de mon père.
###### 11
S’il est vrai que mon père vous accablait sous un joug pesant, je vais, moi, ajouter encore à votre joug. Mon père vous a corrigés avec des lanières ? Eh bien, moi, je vous corrigerai avec des fouets à pointes de fer !” »
###### 12
Le troisième jour, Jéroboam revint, ainsi que tout le peuple, auprès de Roboam, conformément à la parole du roi : « Revenez vers moi le troisième jour ».
###### 13
Et le roi répondit durement au peuple, en négligeant le conseil donné par les anciens.
###### 14
Il parla au peuple en suivant le conseil des jeunes gens : « Mon père a rendu lourd votre joug, je vais, moi, ajouter encore à votre joug. Mon père vous a corrigés avec des lanières ? Eh bien, moi, je vous corrigerai avec des fouets à pointes de fer ! »
###### 15
Ainsi, le roi n’écouta pas le peuple ; en effet, la tournure que prenaient les choses venait du Seigneur, pour que s’accomplisse la parole que le Seigneur avait dite par l’intermédiaire d’Ahias de Silo à Jéroboam, fils de Nebath.
###### 16
Tout Israël vit que le roi ne les avait pas écoutés. Le peuple rétorqua au roi :
« Quelle part avons-nous chez David ?
Pas d’héritage chez le fils de Jessé !
À tes tentes, Israël !
Maintenant, David, pourvois donc à ta maison ! »
Et Israël s’en alla dans ses tentes.
###### 17
Quant aux fils d’Israël qui demeuraient dans les villes de Juda, Roboam régna sur eux.
###### 18
Le roi Roboam envoya Adoram, le chef de la corvée ; mais tout Israël le lapida, et il mourut. Et le roi Roboam se vit contraint de monter sur un char pour s’enfuir à Jérusalem.
###### 19
Les dix tribus d’Israël rejetèrent la maison de David, et cette situation dure encore aujourd’hui où ceci est écrit.
###### 20
Dès que tout Israël apprit que Jéroboam était revenu, on l’envoya chercher pour qu’il vienne à la réunion du peuple, et on le fit roi sur tout Israël. Il ne restait, pour suivre la Maison de David, que la seule tribu de Juda.
###### 21
Roboam arriva à Jérusalem. Il rassembla toute la maison de Juda et la tribu de Benjamin, cent quatre-vingt mille guerriers d’élite, pour combattre la Maison d’Israël, afin de rendre la royauté à Roboam, fils de Salomon.
###### 22
Alors, la parole de Dieu fut adressée à Shemaya, homme de Dieu :
###### 23
« Parle à Roboam, fils de Salomon, roi de Juda, à toute la Maison de Juda et de Benjamin, et au reste du peuple :
###### 24
“Ainsi parle le Seigneur : Ne montez pas, ne faites pas la guerre à vos frères, les fils d’Israël. Retournez chacun chez soi, car je suis moi-même à l’origine de cette affaire”. » Alors ils écoutèrent la parole du Seigneur et ils s’en retournèrent selon la parole du Seigneur.
###### 25
Jéroboam fortifia Sichem dans la montagne d’Éphraïm et s’y établit. Puis il en sortit et fortifia Penouël.
###### 26
Jéroboam se dit : « Maintenant, le royaume risque fort de se rallier de nouveau à la maison de David.
###### 27
Si le peuple continue de monter à Jérusalem pour offrir des sacrifices dans la maison du Seigneur, le cœur de ce peuple reviendra vers son souverain, Roboam, roi de Juda, et l’on me tuera. »
###### 28
Après avoir tenu conseil, Jéroboam fit fabriquer deux veaux en or, et il déclara au peuple : « Voilà trop longtemps que vous montez à Jérusalem ! Israël, voici tes dieux, qui t’ont fait monter du pays d’Égypte. »
###### 29
Il plaça l’un des deux veaux à Béthel, l’autre à Dane,
###### 30
et ce fut un grand péché. Le peuple conduisit en procession celui qui allait à Dane.
###### 31
Jéroboam y établit un temple à la manière des lieux sacrés. Il institua des prêtres pris n’importe où, et qui n’étaient pas des descendants de Lévi.
###### 32
Jéroboam célébra la fête le quinzième jour du huitième mois, fête pareille à celle que l’on célébrait en Juda, et il monta à l’autel. Il fit de même à Béthel en offrant des sacrifices aux veaux qu’il avait fabriqués ; il établit à Béthel les prêtres des lieux sacrés qu’il avait institués.
###### 33
Il monta à l’autel qu’il avait édifié à Béthel, le quinze du huitième mois, date qu’il avait de lui-même fixée. Il organisa une fête pour les fils d’Israël et il monta à l’autel pour brûler de l’encens.
