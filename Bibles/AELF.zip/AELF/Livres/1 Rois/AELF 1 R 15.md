---
aliases : 
- 1 Rois 15
- 1 Rois 15
- 1 R 15
- 1 Kings 15
tags : 
- Bible/1R/15
- français
cssclass : français
---

# 1 Rois 15

###### 01
La dix-huitième année du règne de Jéroboam, fils de Nebath, Abiam devint roi sur Juda.
###### 02
Il régna trois ans à Jérusalem. Sa mère s’appelait Maaka, elle était la fille d’Absalom.
###### 03
Il imita tous les péchés que son père avait commis avant lui, et son cœur ne fut pas tout entier avec le Seigneur son Dieu, comme l’avait été le cœur de David, son aïeul.
###### 04
Pourtant, à cause de David, le Seigneur son Dieu lui donna une lampe à Jérusalem, en maintenant son fils après lui et en gardant Jérusalem debout.
###### 05
Car David avait fait ce qui est droit aux yeux du Seigneur, et, aucun jour de sa vie, il ne s’était détourné de tout ce qu’il lui commandait, hormis dans l’affaire d’Ourias le Hittite.
###### 06
Il y eut toujours la guerre entre Roboam et Jéroboam.
###### 07
Le reste des actions d’Abiam, tout ce qu’il a fait,
cela n’est-il pas écrit dans le livre des Annales des rois de Juda ?
Il y eut la guerre entre Abiam et Jéroboam.
###### 08
Abiam reposa avec ses pères,
et on l’ensevelit dans la Cité de David.
Son fils Asa régna à sa place.
###### 09
La vingtième année du règne de Jéroboam, roi d’Israël, Asa devint roi sur Juda.
###### 10
Il régna quarante et un ans à Jérusalem. Sa grand-mère s’appelait Maaka, fille d’Absalom.
###### 11
Asa fit ce qui est droit aux yeux du Seigneur, comme David, son ancêtre.
###### 12
Il expulsa du pays les prostitués sacrés et supprima toutes les idoles immondes que ses pères avaient fabriquées.
###### 13
Et de plus, il destitua Maaka, sa grand-mère, du titre de reine mère, parce qu’elle avait fabriqué une Infamie pour la déesse Ashéra. Asa abattit cette Infamie et la brûla dans le ravin du Cédron.
###### 14
Mais les lieux sacrés ne disparurent pas, bien que le cœur d’Asa fût tout entier au Seigneur tous les jours de sa vie.
###### 15
Il fit apporter dans la maison du Seigneur les objets sacrés de son père et ceux qu’il avait lui-même consacrés : l’argent, l’or et les ustensiles.
###### 16
Il y eut la guerre entre Asa et Baasa, roi d’Israël, durant toute leur vie.
###### 17
Baasa, roi d’Israël, monta contre le royaume de Juda. Il fortifia la ville de Rama pour empêcher quiconque de communiquer avec Asa, roi de Juda.
###### 18
Asa prit tout l’argent et l’or qui restaient dans les trésors de la maison du Seigneur, et aussi les trésors de la maison du roi ; il remit le tout aux mains de ses serviteurs. Le roi Asa envoya ceux-ci chez Ben-Hadad, roi d’Aram, qui était le fils de Tabrimmone, fils de Hézyone, et qui résidait à Damas. Il lui fit dire :
###### 19
« Il y a une alliance entre moi et toi, comme entre mon père et ton père ! Voici que je t’envoie en cadeau de l’argent et de l’or. Va, romps ton alliance avec Baasa, roi d’Israël : qu’il s’éloigne de moi ! »
###### 20
Ben-Hadad écouta le roi Asa. Il envoya les chefs de ses armées contre les villes d’Israël. Il frappa les villes de Yone, Dane, Abel-Beth-Maaka, toute la région de Kinnèreth, et même tout le pays de Nephtali.
###### 21
Lorsque Baasa apprit cela, il cessa aussitôt de fortifier Rama et demeura à Tirsa.
###### 22
Alors le roi Asa convoqua tout Juda, sans excepter personne. Ils enlevèrent de Rama les pierres et le bois dont Baasa s’était servi pour la construire, et le roi Asa les réemploya pour fortifier Guéba de Benjamin et Mispa.
###### 23
Le reste de toutes les actions d’Asa, toute sa bravoure,
tout ce qu’il a fait, et les villes qu’il a construites,
cela n’est-il pas écrit dans le livre des Annales des rois de Juda ?
Hormis ceci : au temps de sa vieillesse, il eut les pieds malades.
###### 24
Asa reposa avec ses pères,
et il fut enseveli avec eux
dans la Cité de David, son ancêtre.
Son fils Josaphat régna à sa place.
###### 25
Nadab, fils de Jéroboam, devint roi sur Israël, la deuxième année du règne d’Asa, roi de Juda. Il régna deux ans sur Israël.
###### 26
Il fit ce qui est mal aux yeux du Seigneur, et il marcha dans le chemin de son père en imitant le péché que celui-ci avait fait commettre à Israël.
###### 27
Baasa, fils d’Ahias, de la maison d’Issakar, conspira contre lui. Baasa le frappa à Guibbetone des Philistins, alors que Nadab et tout Israël assiégeaient Guibbetone.
###### 28
C’est en la troisième année d’Asa, roi de Juda, que Baasa le mit à mort, et il régna à sa place.
###### 29
Dès qu’il fut roi, il frappa toute la maison de Jéroboam, ne laissant âme qui vive ; il les extermina, conformément à la parole que le Seigneur avait dite par l’intermédiaire de son serviteur Ahias de Silo,
###### 30
à cause des péchés que Jéroboam avait commis, et des péchés qu’il avait fait commettre à Israël, provoquant l’indignation du Seigneur, Dieu d’Israël.
###### 31
Le reste des actions de Nadab, tout ce qu’il a fait,
cela n’est-il pas écrit dans le livre des Annales des rois d’Israël ?
###### 32
Il y eut la guerre entre Asa et Baasa, roi d’Israël, durant toute leur vie.
###### 33
En la troisième année du règne d’Asa, roi de Juda, Baasa, fils d’Ahias, devint roi sur Israël à Tirsa pour vingt-quatre années.
###### 34
Il fit ce qui est mal aux yeux du Seigneur, et il marcha dans le chemin de Jéroboam en imitant le péché que celui-ci avait fait commettre à Israël.
