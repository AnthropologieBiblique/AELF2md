---
aliases : 
- 1 Rois 17
- 1 Rois 17
- 1 R 17
- 1 Kings 17
tags : 
- Bible/1R/17
- français
cssclass : français
---

# 1 Rois 17

###### 01
Le prophète Élie, de Tishbé en Galaad, dit au roi Acab : « Par le Seigneur qui est vivant, par le Dieu d’Israël dont je suis le serviteur, pendant plusieurs années il n’y aura pas de rosée ni de pluie, à moins que j’en donne l’ordre. »
###### 02
La parole du Seigneur lui fut adressée :
###### 03
« Va-t’en d’ici, dirige-toi vers l’est, et cache-toi près du torrent de Kérith, qui se jette dans le Jourdain.
###### 04
Tu boiras au torrent, et j’ordonne aux corbeaux de t’apporter ta nourriture. »
###### 05
Le prophète fit ce que le Seigneur lui avait dit, et alla s’établir près du torrent de Kérith, qui se jette dans le Jourdain.
###### 06
Les corbeaux lui apportaient du pain et de la viande, matin et soir, et le prophète buvait au torrent.
###### 07
Au bout d’un certain temps, il ne tombait plus une goutte de pluie dans tout le pays, et le torrent où buvait le prophète finit par être à sec.
###### 08
Alors la parole du Seigneur lui fut adressée :
###### 09
« Lève-toi, va à Sarepta, dans le pays de Sidon ; tu y habiteras ; il y a là une veuve que j’ai chargée de te nourrir. »
###### 10
Le prophète Élie partit pour Sarepta, et il parvint à l’entrée de la ville. Une veuve ramassait du bois ; il l’appela et lui dit : « Veux-tu me puiser, avec ta cruche, un peu d’eau pour que je boive ? »
###### 11
Elle alla en puiser. Il lui dit encore : « Apporte-moi aussi un morceau de pain. »
###### 12
Elle répondit : « Je le jure par la vie du Seigneur ton Dieu : je n’ai pas de pain. J’ai seulement, dans une jarre, une poignée de farine, et un peu d’huile dans un vase. Je ramasse deux morceaux de bois, je rentre préparer pour moi et pour mon fils ce qui nous reste. Nous le mangerons, et puis nous mourrons. »
###### 13
Élie lui dit alors : « N’aie pas peur, va, fais ce que tu as dit. Mais d’abord cuis-moi une petite galette et apporte-la moi ; ensuite tu en feras pour toi et ton fils.
###### 14
Car ainsi parle le Seigneur, Dieu d’Israël :
Jarre de farine point ne s’épuisera,
vase d’huile point ne se videra,
jusqu’au jour où le Seigneur
donnera la pluie pour arroser la terre. »
###### 15
La femme alla faire ce qu’Élie lui avait demandé, et pendant longtemps, le prophète, elle-même et son fils eurent à manger.
###### 16
Et la jarre de farine ne s’épuisa pas, et le vase d’huile ne se vida pas, ainsi que le Seigneur l’avait annoncé par l’intermédiaire d’Élie.
###### 17
Après cela, le fils de la femme chez qui habitait Élie tomba malade ; le mal fut si violent que l’enfant expira.
###### 18
Alors la femme dit à Élie : « Que me veux-tu, homme de Dieu ? Tu es venu chez moi pour rappeler mes fautes et faire mourir mon fils ! »
###### 19
Élie répondit : « Donne-moi ton fils ! » Il le prit des bras de sa mère, le porta dans sa chambre en haut de la maison et l’étendit sur son lit.
###### 20
Puis il invoqua le Seigneur : « Seigneur, mon Dieu, cette veuve chez qui je loge, lui veux-tu du mal jusqu’à faire mourir son fils ? »
###### 21
Par trois fois, il s’étendit sur l’enfant en invoquant le Seigneur : « Seigneur, mon Dieu, je t’en supplie, rends la vie à cet enfant ! »
###### 22
Le Seigneur entendit la prière d’Élie ; le souffle de l’enfant revint en lui : il était vivant !
###### 23
Élie prit alors l’enfant, de sa chambre il le descendit dans la maison, le remit à sa mère et dit : « Regarde, ton fils est vivant ! »
###### 24
La femme lui répondit : « Maintenant je sais que tu es un homme de Dieu, et que, dans ta bouche, la parole du Seigneur est véridique. »
