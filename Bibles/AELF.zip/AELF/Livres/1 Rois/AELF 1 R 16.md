---
aliases : 
- 1 Rois 16
- 1 Rois 16
- 1 R 16
- 1 Kings 16
tags : 
- Bible/1R/16
- français
cssclass : français
---

# 1 Rois 16

###### 01
La parole du Seigneur fut adressée à Jéhu, fils de Hanani, contre Baasa, en ces termes :
###### 02
« Alors que je t’avais tiré de la poussière et placé comme chef sur mon peuple Israël, tu as marché dans le chemin de Jéroboam et fait commettre le péché à mon peuple Israël, pour provoquer mon indignation par leurs péchés.
###### 03
Voici que je balaierai les derniers restes de Baasa et de sa maison. Je rendrai ta maison pareille à la maison de Jéroboam, fils de Nebath.
###### 04
Celui de la famille de Baasa qui mourra dans la ville, les chiens le mangeront ; celui qui mourra dans les champs, l’oiseau du ciel le mangera. »
###### 05
Le reste des actions de Baasa,
ce qu’il a fait, sa bravoure,
cela n’est-il pas écrit dans le livre des Annales des rois d’Israël ?
###### 06
Baasa reposa avec ses pères,
et il fut enseveli à Tirsa.
Son fils Éla régna à sa place.
###### 07
De plus, par l’intermédiaire du prophète Jéhu, fils de Hanani, la parole du Seigneur fut adressée à Baasa et à sa maison. C’était à cause de tout le mal qu’ils avaient fait aux yeux du Seigneur – car ils avaient provoqué son indignation par l’œuvre de leurs mains, au point de ressembler à la maison de Jéroboam –, et aussi parce qu’ils avaient abattu cette maison.
###### 08
En la vingt-sixième année du règne d’Asa, roi de Juda, Éla, fils de Baasa, devint roi sur Israël à Tirsa, pour deux ans.
###### 09
Son serviteur Zimri, commandant de la moitié des chars, conspira contre lui. Alors qu’Éla était à Tirsa, buvant jusqu’à l’ivresse, dans la maison d’Arsa, le maître du palais,
###### 10
Zimri entra, le frappa, et il mourut. C’était la vingt-septième année du règne d’Asa, roi de Juda. Et Zimri régna à la place d’Éla.
###### 11
Devenu roi, à peine assis sur le trône, il frappa toute la maison de Baasa. Il ne lui laissa subsister ni mâles, ni proches parents, ni compagnon.
###### 12
Zimri extermina la maison de Baasa, conformément à la parole que le Seigneur avait dite contre Baasa par l’intermédiaire de Jéhu le prophète ;
###### 13
il fit cela à cause de tous les péchés de Baasa et de son fils Éla, ceux qu’ils avaient commis, et ceux qu’ils avaient fait commettre à Israël, au point de provoquer l’indignation du Seigneur, Dieu d’Israël, par leurs vaines idoles.
###### 14
Le reste des actions d’Éla, tout ce qu’il a fait,
cela n’est-il pas écrit dans le livre des Annales des rois d’Israël ?
###### 15
En la vingt-septième année du règne d’Asa, roi de Juda, Zimri régna sept jours à Tirsa. Le peuple campait alors autour de Guibbetone des Philistins.
###### 16
Le peuple qui campait entendit la nouvelle : « Zimri a conspiré ; il a frappé le roi. » Alors, le jour même, dans le camp, tout Israël établit Omri, chef de l’armée, comme roi sur Israël.
###### 17
Omri, ayant tout Israël avec lui, monta de Guibbetone, et ils assiégèrent Tirsa.
###### 18
Quand Zimri s’aperçut que la ville était prise, il entra dans le donjon de la maison du roi, à laquelle il mit le feu et où il mourut.
###### 19
Ce fut à cause des péchés qu’il avait commis : il avait fait ce qui est mal aux yeux du Seigneur, il avait marché dans le chemin de Jéroboam et imité le péché que celui-ci avait commis en faisant pécher tout Israël.
###### 20
Le reste des actions de Zimri
et le complot qu’il avait tramé,
cela n’est-il pas écrit dans le livre des Annales des rois d’Israël ?
###### 21
Alors le peuple d’Israël se divisa en deux parties : une partie du peuple suivit Tibni, fils de Guinath, pour le faire roi, et l’autre partie suivit Omri.
###### 22
Le peuple qui suivait Omri l’emporta sur celui qui suivait Tibni, fils de Guinath. Tibni mourut, et Omri devint roi.
###### 23
En la trente et unième année du règne d’Asa, roi de Juda, Omri devint roi sur Israël, pour douze années, et il régna six ans à Tirsa.
###### 24
Puis il acheta le mont de Samarie à Sémer, au prix de deux lingots d’argent. Il fortifia la montagne et donna à la ville qu’il avait bâtie le nom de Samarie, du nom de Sémer, le maître de la montagne.
###### 25
Omri fit ce qui est mal aux yeux du Seigneur ; il agit plus mal encore que tous ceux qui l’avaient précédé.
###### 26
Il marcha dans tous les chemins de Jéroboam, fils de Nebath, en imitant le péché que celui-ci avait fait commettre à Israël, au point de provoquer l’indignation du Seigneur, Dieu d’Israël, par leurs vaines idoles.
###### 27
Le reste des actions d’Omri,
ce qu’il a fait, ses actes de bravoure,
cela n’est-il pas écrit dans le livre des Annales des rois d’Israël ?
###### 28
Omri reposa avec ses pères,
et il fut enseveli à Samarie.
Son fils Acab régna à sa place.
###### 29
Acab, fils d’Omri, devint donc roi sur Israël, la trente-huitième année du règne d’Asa, roi de Juda. Acab, fils d’Omri, régna sur Israël, à Samarie, pendant vingt-deux années.
###### 30
Acab, fils d’Omri, fit ce qui est mal aux yeux du Seigneur, plus encore que tous ceux qui l’avaient précédé.
###### 31
Son moindre tort fut d’imiter les péchés de Jéroboam, fils de Nebath, car il prit pour femme Jézabel, fille d’Ethbaal, roi des Sidoniens, et il alla servir Baal et se prosterner devant lui.
###### 32
Il lui dressa un autel, dans le temple de Baal qu’il avait construit à Samarie.
###### 33
Acab fabriqua aussi le Poteau sacré d’Ashéra. Par ses actions Acab ne cessa de provoquer l’indignation du Seigneur, Dieu d’Israël, plus encore que tous les rois d’Israël qui l’avaient précédé.
###### 34
C’est de son temps que Hiël de Béthel rebâtit Jéricho : au prix d’Abiram, son premier-né, il en posa les fondations ; au prix de Segoub, son cadet, il en fixa les portes, conformément à la malédiction que le Seigneur avait dite par l’intermédiaire de Josué, fils de Noun.
