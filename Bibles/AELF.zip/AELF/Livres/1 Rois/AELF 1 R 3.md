---
aliases : 
- 1 Rois 3
- 1 Rois 3
- 1 R 3
- 1 Kings 3
tags : 
- Bible/1R/3
- français
cssclass : français
---

# 1 Rois 3

###### 01
Salomon devint le gendre de Pharaon, le roi d’Égypte ; il épousa la fille de Pharaon et la fit venir dans la Cité de David, en attendant d’avoir achevé la construction de sa propre maison, de la maison du Seigneur et du mur d’enceinte de Jérusalem.
###### 02
Seulement, le peuple sacrifiait toujours dans les lieux sacrés, car à cette époque on n’avait pas encore construit une maison pour le nom du Seigneur.
###### 03
Salomon aimait le Seigneur : il marchait selon les ordres de David, son père. Seulement, il offrait des sacrifices dans les lieux sacrés, et y brûlait de l’encens.
###### 04
Le roi Salomon se rendit à Gabaon, qui était alors le lieu sacré le plus important, pour y offrir un sacrifice ; il immola sur l’autel un millier de bêtes en holocauste.
###### 05
À Gabaon, pendant la nuit, le Seigneur lui apparut en songe. Dieu lui dit : « Demande ce que je dois te donner. »
###### 06
Salomon répondit : « Tu as traité ton serviteur David, mon père, avec une grande fidélité, lui qui a marché en ta présence dans la loyauté, la justice et la droiture de cœur envers toi. Tu lui as gardé cette grande fidélité, tu lui as donné un fils qui est assis maintenant sur son trône.
###### 07
Ainsi donc, Seigneur mon Dieu, c’est toi qui m’as fait roi, moi, ton serviteur, à la place de David, mon père ; or, je suis un tout jeune homme, ne sachant comment se comporter,
###### 08
et me voilà au milieu du peuple que tu as élu ; c’est un peuple nombreux, si nombreux qu’on ne peut ni l’évaluer ni le compter.
###### 09
Donne à ton serviteur un cœur attentif pour qu’il sache gouverner ton peuple et discerner le bien et le mal ; sans cela, comment gouverner ton peuple, qui est si important ? »
###### 10
Cette demande de Salomon plut au Seigneur, qui lui dit :
###### 11
« Puisque c’est cela que tu as demandé, et non pas de longs jours, ni la richesse, ni la mort de tes ennemis, mais puisque tu as demandé le discernement, l’art d’être attentif et de gouverner,
###### 12
je fais ce que tu as demandé : je te donne un cœur intelligent et sage, tel que personne n’en a eu avant toi et que personne n’en aura après toi.
###### 13
De plus, je te donne même ce que tu n’as pas demandé, la richesse et la gloire, si bien que pendant toute ta vie tu n’auras pas d’égal parmi les rois.
###### 14
Et si tu suis mes chemins, en gardant mes décrets et mes commandements comme l’a fait David, ton père, je t’accorderai de longs jours. »
###### 15
Salomon s’éveilla : il avait fait un songe ! Il rentra à Jérusalem et se présenta devant l’arche de l’Alliance du Seigneur. Il offrit des holocaustes et des sacrifices de paix, et donna un festin à tous ses serviteurs.
###### 16
Un jour, deux prostituées vinrent se présenter devant le roi.
###### 17
L’une des femmes dit : « De grâce, mon seigneur ! Moi et cette femme, nous habitons la même maison. Et j’ai accouché, alors qu’elle était à la maison.
###### 18
Or, trois jours après ma délivrance, cette femme accoucha à son tour. Nous étions ensemble : personne d’autre dans la maison ; il n’y avait que nous deux dans la maison !
###### 19
Une nuit, le fils de cette femme mourut : elle s’était couchée sur lui.
###### 20
Elle se leva au milieu de la nuit, prit mon fils qui reposait à mon côté – ta servante dormait – et le coucha contre elle. Et son fils mort, elle le coucha contre moi.
###### 21
Au matin, je me levai pour allaiter mon fils : il était mort ! Je l’examinai attentivement au petit jour : ce n’était pas mon fils, celui que j’avais mis au monde. »
###### 22
L’autre femme protesta : « Non ! Mon fils est celui qui est vivant, ton fils celui qui est mort. » Mais la première insistait : « Pas du tout ! Ton fils est celui qui est mort, et mon fils celui qui est vivant ! » Elles se disputaient ainsi en présence du roi.
###### 23
Le roi dit alors : « Celle-ci affirme : Mon fils, c’est le vivant, et ton fils est le mort. Celle-là affirme : Non ! Ton fils, c’est le mort, et mon fils est le vivant ! »
###### 24
Et le roi ajouta : « Donnez-moi une épée ! » On apporta une épée devant le roi.
###### 25
Et le roi poursuivit : « Coupez en deux l’enfant vivant, donnez-en la moitié à l’une et la moitié à l’autre. »
###### 26
Mais la femme dont le fils était vivant s’adressa au roi – car ses entrailles s’étaient émues à cause de son fils ! – : « De grâce, mon seigneur ! Donnez-lui l’enfant vivant, ne le tuez pas ! » L’autre protestait : « Il ne sera ni à toi ni à moi : coupez-le ! »
###### 27
Prenant la parole, le roi déclara : « Donnez à celle-ci l’enfant vivant, ne le tuez pas : c’est elle, sa mère ! »
###### 28
Tout Israël apprit le jugement qu’avait rendu le roi. Et l’on regarda le roi avec crainte et respect, car on avait vu que, pour rendre la justice, la sagesse de Dieu était en lui.
