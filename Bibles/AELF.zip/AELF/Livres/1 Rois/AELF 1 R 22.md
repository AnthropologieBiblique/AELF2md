---
aliases : 
- 1 Rois 22
- 1 Rois 22
- 1 R 22
- 1 Kings 22
tags : 
- Bible/1R/22
- français
cssclass : français
---

# 1 Rois 22

###### 01
On resta tranquille pendant trois ans, sans guerre entre Aram et Israël.
###### 02
Mais la troisième année, Josaphat, roi de Juda, descendit auprès du roi d’Israël.
###### 03
Le roi d’Israël dit à ses serviteurs : « Savez-vous que la ville de Ramoth-de-Galaad nous appartient ? Nous restons sans rien dire, au lieu de la reprendre des mains du roi d’Aram ».
###### 04
Il dit à Josaphat : « Viendrais-tu avec moi pour combattre à Ramoth-de-Galaad ? » Et Josaphat répondit au roi d’Israël : « Ce sera pour moi comme pour toi, pour mon peuple comme pour ton peuple, pour mes chevaux comme pour tes chevaux. »
###### 05
Josaphat dit au roi d’Israël : « Mais consulte d’abord la parole du Seigneur. »
###### 06
Le roi d’Israël réunit les prophètes, au nombre d’environ quatre cents. Il leur demanda : « Irai-je à Ramoth-de-Galaad pour combattre, ou dois-je y renoncer ? » Ils dirent : « Monte ! Le Seigneur livrera la ville aux mains du roi. »
###### 07
Mais Josaphat reprit : « N’y a-t-il ici aucun autre prophète du Seigneur, par qui nous pourrions le consulter ? »
###### 08
Le roi d’Israël répondit à Josaphat : « Il y a encore un homme par qui nous pourrions consulter le Seigneur, mais moi, je le hais, car il ne prophétise rien de bon à mon sujet, mais seulement du mal. C’est Michée, fils de Yimla. » Josaphat répliqua : « Que le roi ne parle pas ainsi ! »
###### 09
Le roi d’Israël appela un dignitaire et lui dit : « Vite, fais venir Michée, fils de Yimla ! »
###### 10
Le roi d’Israël et Josaphat, roi de Juda, siégeaient, en tenue d’apparat, chacun sur son trône, sur l’esplanade à l’entrée de la porte de Samarie. Et, devant eux, tous les prophètes se mettaient à prophétiser.
###### 11
Sédécias, fils de Kenahana, s’était fabriqué des cornes de fer. Il disait : « Ainsi parle le Seigneur : Avec cela tu pourfendras Aram jusqu’à l’exterminer. »
###### 12
Tous les prophètes prophétisaient de la même manière ; ils disaient : « Monte à Ramoth-de-Galaad ! Tu réussiras ! Le Seigneur livrera la ville aux mains du roi. »
###### 13
Le messager qui était allé appeler Michée lui dit : « Voici les paroles des prophètes : d’une seule voix, ils annoncent du bien pour le roi. Que ta parole soit donc conforme à celle de chacun : annonce du bien ! »
###### 14
Michée répondit : « Par le Seigneur qui est vivant ! Ce que le Seigneur me dira, c’est cela que j’annoncerai ! »
###### 15
Il entra chez le roi qui lui dit : « Michée, irons-nous à Ramoth-de-Galaad pour combattre, ou devons-nous y renoncer ? » Il répondit : « Monte ! Tu réussiras. Le Seigneur livrera la ville aux mains du roi. »
###### 16
Le roi lui rétorqua : « Combien de fois devrai-je t’adjurer de me dire seulement la vérité au nom du Seigneur ? »
###### 17
Michée dit alors :
« J’ai vu tout Israël dispersé sur les montagnes,
comme des brebis sans berger.
Le Seigneur a dit :
“Ces gens n’ont plus de maître ;
qu’ils retournent en paix, chacun dans sa maison”. »
###### 18
Le roi d’Israël dit à Josaphat : « Ne te l’avais-je pas dit ? Il ne prophétise à mon sujet rien de bon, mais seulement du mal ! »
###### 19
Michée reprit : « Eh bien ! Écoute la parole du Seigneur ! J’ai vu le Seigneur qui siégeait sur son trône ; toute l’armée des cieux se tenait près de lui, à sa droite et à sa gauche.
###### 20
Le Seigneur demanda : “Qui séduira Acab, pour qu’il monte et qu’il tombe à Ramoth-de-Galaad ?” L’un répondit ceci, l’autre répondit cela.
###### 21
Alors un esprit s’avança et se tint en présence du Seigneur. Il dit : “Moi, je le séduirai”. Le Seigneur reprit : “De quelle manière ?”
###### 22
Il répondit : “J’avancerai, je deviendrai esprit de mensonge dans la bouche de tous ses prophètes.” Le Seigneur déclara : “Tu le séduiras, tu l’auras même en ton pouvoir. Avance, et fais comme tu as dit.” »
###### 23
Michée continua : « Maintenant donc, voici que le Seigneur a mis un esprit de mensonge dans la bouche de tous tes prophètes qui sont là, voici que le Seigneur annonce contre toi le malheur. »
###### 24
Sédécias, fils de Kenahana, s’approcha et frappa Michée sur la joue, en disant : « Par où l’esprit du Seigneur s’est-il échappé de moi pour te parler ? »
###### 25
Michée répondit : « Eh bien ! Le jour où tu fuiras dans une chambre retirée pour te cacher, tu le verras. »
###### 26
Le roi d’Israël donna cet ordre : « Saisis-toi de Michée et remets-le aux mains d’Amone, gouverneur de la ville, et à Joas, le fils du roi.
###### 27
Tu diras : “Ainsi parle le roi : Mettez cet homme en prison, nourrissez-le de rations réduites de pain et d’eau jusqu’à ce que je revienne sain et sauf”. »
###### 28
Michée reprit : « Si vraiment tu reviens sain et sauf, c’est que le Seigneur n’a pas parlé par ma bouche ! » Il ajouta : « Vous, tous les peuples, écoutez ! »
###### 29
Le roi d’Israël et Josaphat, roi de Juda, montèrent à Ramoth-de-Galaad.
###### 30
Le roi d’Israël dit à Josaphat : « Je vais me déguiser pour marcher au combat, mais toi, revêts ta tenue. » Le roi d’Israël se déguisa pour marcher au combat.
###### 31
Le roi d’Aram avait donné cet ordre à ses trente-deux commandants de chars : « Vous n’attaquerez ni petit ni grand, mais uniquement le roi d’Israël ! »
###### 32
Lorsque les commandants de chars virent Josaphat, ils dirent : « C’est sûrement le roi d’Israël. » Et ils se dirigèrent de son côté pour l’attaquer. Mais Josaphat poussa un cri.
###### 33
Alors les commandants de chars virent que ce n’était pas le roi d’Israël et ils se détournèrent de lui.
###### 34
Un homme tira de l’arc au hasard et atteignit le roi d’Israël entre les attaches et la cuirasse. Le roi dit au conducteur de son char : « Tourne bride et fais-moi sortir du champ de bataille, car je me sens mal ! »
###### 35
Le combat, ce jour-là, devint très violent. On maintenait le roi debout sur son char, face aux Araméens. Et le soir, il mourut. Le sang de sa blessure coulait au fond du char.
###### 36
Au coucher du soleil, un cri se propagea dans le campement : « Chacun à sa ville et chacun à sa terre ! »
###### 37
Le roi était mort ; il fut ramené à Samarie, et c’est à Samarie que fut enseveli le roi.
###### 38
On lava le char à grande eau à l’étang de Samarie. Les chiens lapèrent le sang et les prostituées s’y baignèrent, conformément à la parole que le Seigneur avait dite.
###### 39
Le reste des actions d’Acab, tout ce qu’il a fait,
la maison d’ivoire qu’il a édifiée
et toutes les villes qu’il a construites,
cela n’est-il pas écrit dans le livre des Annales des rois d’Israël ?
###### 40
Acab reposa avec ses pères.
Son fils Ocozias régna à sa place.
###### 41
Josaphat, fils d’Asa, devint roi sur Juda, la quatrième année du règne d’Acab, roi d’Israël.
###### 42
Josaphat avait trente-cinq ans lorsqu’il devint roi, et il régna vingt-cinq ans à Jérusalem. Le nom de sa mère était Azouba ; elle était fille de Shilki.
###### 43
Il marcha dans tous les chemins d’Asa, son père ; il ne s’en détourna pas, faisant ce qui est droit aux yeux du Seigneur.
###### 44
Toutefois les lieux sacrés ne disparurent pas : le peuple offrait encore des sacrifices et brûlait de l’encens dans les lieux sacrés.
###### 45
Josaphat fut en paix avec le roi d’Israël.
###### 46
Le reste des actions de Josaphat,
la bravoure dont il fit preuve,
les guerres qu’il livra,
cela n’est-il pas écrit dans le livre des Annales des rois de Juda ?
###### 47
Les derniers prostitués sacrés qui restaient du temps de son père Asa, il les balaya du pays.
###### 48
Il n’y avait pas de roi en Édom, mais un préfet du roi.
###### 49
Josaphat fit des navires de haut bord pour aller à Ophir chercher de l’or, mais il n’y alla pas car les navires se brisèrent à Écione-Guéber.
###### 50
Alors, Ocozias, fils d’Acab, dit à Josaphat : « Mes serviteurs iront avec tes serviteurs sur les navires ». Mais Josaphat refusa !
###### 51
Josaphat reposa avec ses pères.
Il fut enseveli avec eux dans la Cité de David, son ancêtre.
Son fils Joram régna à sa place.
###### 52
Ocozias, fils d’Acab, devint roi sur Israël, à Samarie, la dix-septième année du règne de Josaphat, roi de Juda. Il régna deux ans sur Israël.
###### 53
Il fit ce qui est mal aux yeux du Seigneur. Il marcha dans le chemin de son père, dans le chemin de sa mère, et dans le chemin de Jéroboam, fils de Nebath, qui avait fait commettre à Israël des péchés.
###### 54
Il servit Baal et se prosterna devant lui. Il provoqua l’indignation du Seigneur, Dieu d’Israël, tout comme l’avait fait son père.
