---
aliases : 
- 1 Rois 9
- 1 Rois 9
- 1 R 9
- 1 Kings 9
tags : 
- Bible/1R/9
- français
cssclass : français
---

# 1 Rois 9

###### 01
Après que Salomon eut achevé de construire la maison du Seigneur et la maison du roi, et tout ce que Salomon avait désiré faire pour son bon plaisir,
###### 02
le Seigneur lui apparut une seconde fois, comme il lui était déjà apparu à Gabaon.
###### 03
Le Seigneur lui dit : « J’ai entendu la prière et la supplication que tu as présentées devant moi. Je consacre cette Maison que tu as construite pour y mettre mon nom à jamais. Et mes yeux et mon cœur y seront pour toujours.
###### 04
Pour toi, si tu marches devant moi, comme l’a fait David, ton père, d’un cœur intègre et avec droiture, afin d’agir en tout selon mes commandements, et si tu gardes mes décrets et mes ordonnances,
###### 05
alors je maintiendrai le trône de ta royauté sur Israël à jamais, selon ce que j’ai dit à David, ton père : “Aucun des tiens siégeant sur le trône d’Israël ne sera écarté”.
###### 06
Mais si vous vous détournez de moi, vous et vos fils, si vous ne gardez plus les commandements et les décrets que j’ai placés devant vous, si vous suivez et servez d’autres dieux, et vous prosternez devant eux,
###### 07
alors je retrancherai Israël de la surface de la terre que je lui ai donnée ; la Maison que j’ai consacrée à mon nom, je la rejetterai loin de ma face ; et Israël deviendra la fable et la risée de tous les peuples ;
###### 08
cette Maison qui était élevée, quiconque passera près d’elle sifflera de stupeur ; on dira : “Pourquoi donc le Seigneur a-t-il agi de cette manière envers ce pays et envers cette Maison ?”
###### 09
On lui répondra : “C’est qu’ils ont abandonné le Seigneur leur Dieu, lui qui avait fait sortir leurs pères du pays d’Égypte. Ils se sont attachés à d’autres dieux, devant lesquels ils se sont prosternés et qu’ils ont servis. Voilà pourquoi le Seigneur a fait venir sur eux tout ce malheur.” »
###### 10
Au terme des vingt années pendant lesquelles Salomon avait bâti les deux Maisons, la maison du Seigneur et la maison du roi,
###### 11
Hiram, le roi de Tyr, ayant fourni à Salomon du bois de cèdre et de cyprès, et de l’or selon son bon plaisir, le roi Salomon lui donna vingt villes au pays de Galilée.
###### 12
Hiram sortit de Tyr pour aller voir les villes que Salomon lui avait données. Mais elles ne plurent pas à ses yeux. Il s’exclama :
###### 13
« Quelles villes m’as-tu données là, mon frère ! » Il les surnomma « Terre-de-Rien », nom qu’elles portent encore aujourd’hui.
###### 14
Hiram envoya au roi cent vingt lingots d’or.
###### 15
Voici maintenant un mot sur la corvée que leva le roi Salomon pour la construction de la maison du Seigneur et de sa propre maison, le Terre-Plein et la muraille de Jérusalem, ainsi que Haçor, Meguiddo et Guèzer.
###### 16
Pharaon, roi d’Égypte, était monté contre Guèzer, s’en était emparé, et y avait mis le feu. Les Cananéens qui habitaient la ville, il les avait massacrés. Puis il l’avait donnée en dot à sa fille, la femme de Salomon.
###### 17
Salomon rebâtit Guèzer et Beth-Horone-le-Bas,
###### 18
Baalath et Tamar-du-Désert, dans le pays,
###### 19
toutes les villes d’entrepôts appartenant à Salomon, les villes de garnison pour les chars et celles des cavaliers. Et Salomon bâtit ce qu’il désirait, dans Jérusalem, au Liban et dans tout le pays soumis à son autorité.
###### 20
Il restait toute une population d’Amorites, de Hittites, de Perizzites, de Hivvites et de Jébuséens, qui n’étaient pas des fils d’Israël.
###### 21
Leurs fils qui, après eux, étaient restés dans le pays et que les fils d’Israël n’avaient pu vouer à l’anathème, Salomon les réquisitionna pour la corvée servile, jusqu’à ce jour.
###### 22
Mais Salomon ne soumit au servage aucun des fils d’Israël, car ceux-ci étaient des hommes de guerre, ses serviteurs, ses officiers, ses écuyers, les commandants de ses chars et de ses cavaliers.
###### 23
Voici le nombre des chefs des préposés aux travaux de Salomon : ils étaient cinq cent cinquante et commandaient au peuple qui effectuait les travaux.
###### 24
Quand la fille de Pharaon monta de la Cité de David à la maison que le roi lui avait bâtie, alors Salomon édifia le Terre-Plein.
###### 25
Trois fois par an, Salomon offrait des holocaustes et des sacrifices de paix sur l’autel qu’il avait bâti pour le Seigneur. Et là il brûlait aussi de l’encens devant le Seigneur. Il portait ainsi la Maison à son achèvement.
###### 26
Le roi Salomon arma une flotte à Écione-Guéber, près d’Eilath, sur le rivage de la mer des Roseaux, au pays d’Édom.
###### 27
Avec les serviteurs de Salomon, Hiram dépêcha sur les navires ses serviteurs, des navigateurs connaissant bien la mer.
###### 28
Ils arrivèrent à Ophir et s’y procurèrent de l’or : quatre cent vingt lingots qu’ils rapportèrent au roi Salomon.
