---
aliases : 
- 1 Rois 11
- 1 Rois 11
- 1 R 11
- 1 Kings 11
tags : 
- Bible/1R/11
- français
cssclass : français
---

# 1 Rois 11

###### 01
Le roi Salomon aima de nombreuses femmes étrangères : outre la fille de Pharaon, des Moabites, des Ammonites, des Édomites, des Sidoniennes, des Hittites.
###### 02
Elles étaient de ces nations dont le Seigneur avait dit aux fils d’Israël : « Vous n’entrerez pas chez elles, et elles n’entreront pas chez vous : sûrement, elles détourneraient votre cœur vers leurs dieux. » Mais Salomon s’attacha à elles par amour.
###### 03
Il eut sept cents femmes de rang princier et trois cents concubines ; et ses femmes détournèrent son cœur.
###### 04
Salomon vieillissait ; ses femmes le détournèrent vers d’autres dieux, et son cœur n’était plus tout entier au Seigneur, comme l’avait été celui de son père David.
###### 05
Salomon prit part au culte d’Astarté, la déesse des Sidoniens, et à celui de Milcom, l’horrible idole des Ammonites.
###### 06
Il fit ce qui est mal aux yeux du Seigneur, et il ne lui obéit pas aussi parfaitement que son père David.
###### 07
Il construisit alors, sur la montagne à l’est de Jérusalem, un lieu sacré pour Camosh, l’horrible idole de Moab, et un autre pour Milcom, l’horrible idole des Ammonites.
###### 08
Il en fit d’autres pour permettre à toutes ses femmes étrangères de brûler de l’encens et d’offrir des sacrifices à leurs dieux.
###### 09
Le Seigneur s’irrita contre Salomon parce qu’il s’était détourné du Seigneur Dieu d’Israël. Pourtant, celui-ci lui était apparu deux fois,
###### 10
et lui avait défendu de suivre d’autres dieux ; mais Salomon avait désobéi.
###### 11
Le Seigneur lui déclara : « Puisque tu t’es conduit de cette manière, puisque tu n’as pas gardé mon alliance ni observé mes décrets, je vais t’enlever le royaume et le donner à l’un de tes serviteurs.
###### 12
Seulement, à cause de ton père David, je ne ferai pas cela durant ta vie ; c’est de la main de ton fils que j’enlèverai le royaume.
###### 13
Et encore, je ne lui enlèverai pas tout, je laisserai une tribu à ton fils, à cause de mon serviteur David et de Jérusalem, la ville que j’ai choisie. »
###### 14
Le Seigneur suscita un adversaire à Salomon : Hadad l’Édomite, qui était de la descendance royale d’Édom.
###### 15
Au temps où David était en Édom, Joab, le chef de l’armée, était monté pour ensevelir les morts et avait frappé tous les mâles du pays d’Édom,
###### 16
– car Joab et tout Israël étaient restés là pendant six mois, jusqu’à ce qu’ils aient supprimé tous les mâles d’Édom.
###### 17
C’est alors que Hadad s’était enfui avec des Édomites, des serviteurs de son père, pour aller en Égypte. Hadad était encore un tout jeune homme.
###### 18
Ils partirent de Madiane et arrivèrent à Parane. Ils prirent avec eux des hommes de Parane et arrivèrent en Égypte auprès de Pharaon, roi d’Égypte. Celui-ci lui donna une maison, lui promit le pain et lui attribua une terre.
###### 19
Hadad fut en grande faveur auprès de Pharaon, qui lui donna pour épouse la sœur de sa femme, la sœur de Tapnès la reine mère.
###### 20
La sœur de Tapnès lui enfanta son fils Guenoubath, et Tapnès l’éleva dans la maison de Pharaon. Guenoubath demeura donc dans la maison de Pharaon, parmi les fils de Pharaon.
###### 21
Hadad apprit en Égypte que David reposait avec ses pères, et que Joab, le chef de l’armée, était mort. Il dit à Pharaon : « Laisse-moi partir, que j’aille dans mon pays ! »
###### 22
Pharaon lui demanda : « Que te manque-t-il auprès de moi, pour que tu cherches à t’en aller dans ton pays ? » Il répondit : « Rien, mais laisse-moi partir. »
###### 23
Dieu suscita un autre adversaire à Salomon : Rezone, fils d’Éliada. Il s’était enfui de chez son maître Hadadèzer, roi de Soba ;
###### 24
il avait ensuite rallié des hommes autour de lui et il était devenu chef de bande. Mais parce que David les massacrait, ils allèrent à Damas et s’y installèrent. Et ils régnèrent à Damas.
###### 25
Rezone fut un adversaire d’Israël durant toute la vie de Salomon. Voici le mal que fit Hadad : il eut Israël en aversion. Il avait régné sur Aram.
###### 26
Jéroboam, fils de Nebath l’Éphraïmite, était de Seréda ; le nom de sa mère était Seroua ; elle était veuve. Lui était au service de Salomon et il se révolta contre le roi.
###### 27
Voici comment il se révolta contre le roi. Salomon construisait le Terre-Plein pour fermer la brèche de la Cité de David son père.
###### 28
Ce Jéroboam était quelqu’un de grande valeur. Salomon avait remarqué comment le jeune homme accomplissait son ouvrage, et il fit de lui l’inspecteur des corvées qui pesaient sur la Maison de Joseph.
###### 29
Un jour que Jéroboam était sorti de Jérusalem, il fut arrêté en chemin par le prophète Ahias de Silo ; celui-ci portait un manteau neuf, et tous deux étaient seuls dans la campagne.
###### 30
Ahias prit le manteau neuf qu’il portait et le déchira en douze morceaux.
###### 31
Puis il dit à Jéroboam : « Prends pour toi dix morceaux, car ainsi parle le Seigneur, Dieu d’Israël : Voici que je vais déchirer le royaume en l’arrachant à Salomon, et je te donnerai dix tribus.
###### 32
Il lui restera une tribu, à cause de mon serviteur David, et de Jérusalem, la ville que je me suis choisie parmi toutes les tribus d’Israël.
###### 33
C’est qu’ils m’ont abandonné et se sont prosternés devant Astarté, la déesse des Sidoniens, devant Camosh, le dieu de Moab, et devant Milcom, le dieu des Ammonites ; ils n’ont pas marché dans mes chemins, pour pratiquer ce qui est droit à mes yeux et respecter mes décrets et mes ordonnances, comme l’a fait David, son père.
###### 34
Mais je ne reprendrai pas de sa main tout le royaume, car je le maintiendrai prince tous les jours de sa vie, à cause de David, mon serviteur, que j’ai choisi, lui qui a gardé mes commandements et mes décrets.
###### 35
Je reprendrai des mains de son fils la royauté et je te la donnerai sur dix tribus.
###### 36
Mais à son fils, je donnerai une seule tribu pour que mon serviteur David ait toujours une lampe qui brille devant moi, à Jérusalem, la ville que je me suis choisie pour y mettre mon nom.
###### 37
Toi, je te prendrai, tu régneras sur tout ce que tu désires, et tu seras roi sur Israël.
###### 38
Si tu obéis à tout ce que je vais te commander, si tu marches dans mes chemins et si tu pratiques ce qui est droit à mes yeux, en gardant mes décrets et mes commandements, comme l’a fait David mon serviteur, alors je serai avec toi et je construirai pour toi une maison stable, comme celle que j’ai bâtie pour David, et je te donnerai Israël.
###### 39
De la sorte, j’humilierai la descendance de David, mais pas pour toujours. »
###### 40
Salomon chercha à faire mourir Jéroboam. Jéroboam se leva et s’enfuit en Égypte auprès de Shishaq, roi d’Égypte, et il vécut en Égypte jusqu’à la mort de Salomon.
###### 41
Le reste des actions de Salomon,
tout ce qu’il a fait, et sa sagesse,
cela n’est-il pas écrit dans le livre des Actes de Salomon ?
###### 42
Le temps que Salomon régna à Jérusalem
sur tout Israël fut de quarante ans.
###### 43
Puis Salomon reposa avec ses pères,
et il fut enseveli dans la Cité de David son père.
Son fils Roboam régna à sa place.
