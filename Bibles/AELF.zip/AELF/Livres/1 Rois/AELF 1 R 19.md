---
aliases : 
- 1 Rois 19
- 1 Rois 19
- 1 R 19
- 1 Kings 19
tags : 
- Bible/1R/19
- français
cssclass : français
---

# 1 Rois 19

###### 01
Le roi Acab avait rapporté à Jézabel comment le prophète Élie avait réagi et comment il avait fait égorger tous les prophètes de Baal.
###### 02
Alors Jézabel envoya un messager dire à Élie : « Que les dieux amènent le malheur sur moi, et pire encore, si demain, à cette heure même, je ne t’inflige pas le même sort que tu as infligé à ces prophètes. »
###### 03
Devant cette menace, Élie se hâta de partir pour sauver sa vie. Arrivé à Bershéba, au royaume de Juda, il y laissa son serviteur.
###### 04
Quant à lui, il marcha toute une journée dans le désert. Il vint s’asseoir à l’ombre d’un buisson, et demanda la mort en disant : « Maintenant, Seigneur, c’en est trop ! Reprends ma vie : je ne vaux pas mieux que mes pères. »
###### 05
Puis il s’étendit sous le buisson, et s’endormit. Mais voici qu’un ange le toucha et lui dit : « Lève-toi, et mange ! »
###### 06
Il regarda, et il y avait près de sa tête une galette cuite sur des pierres brûlantes et une cruche d’eau. Il mangea, il but, et se rendormit.
###### 07
Une seconde fois, l’ange du Seigneur le toucha et lui dit : « Lève-toi, et mange, car il est long, le chemin qui te reste. »
###### 08
Élie se leva, mangea et but. Puis, fortifié par cette nourriture, il marcha quarante jours et quarante nuits jusqu’à l’Horeb, la montagne de Dieu.
###### 09
Là, il entra dans une caverne et y passa la nuit. Et voici que la parole du Seigneur lui fut adressée. Il lui dit : « Que fais-tu là, Élie ? »
###### 10
Il répondit : « J’éprouve une ardeur jalouse pour toi, Seigneur, Dieu de l’univers. Les fils d’Israël ont abandonné ton Alliance, renversé tes autels, et tué tes prophètes par l’épée ; moi, je suis le seul à être resté et ils cherchent à prendre ma vie. »
###### 11
Le Seigneur dit : « Sors et tiens-toi sur la montagne devant le Seigneur, car il va passer. » À l’approche du Seigneur, il y eut un ouragan, si fort et si violent qu’il fendait les montagnes et brisait les rochers, mais le Seigneur n’était pas dans l’ouragan ; et après l’ouragan, il y eut un tremblement de terre, mais le Seigneur n’était pas dans le tremblement de terre ;
###### 12
et après ce tremblement de terre, un feu, mais le Seigneur n’était pas dans ce feu ; et après ce feu, le murmure d’une brise légère.
###### 13
Aussitôt qu’il l’entendit, Élie se couvrit le visage avec son manteau, il sortit et se tint à l’entrée de la caverne. Alors il entendit une voix qui disait : « Que fais-tu là, Élie ? »
###### 14
Il répondit : « J’éprouve une ardeur jalouse pour toi, Seigneur, Dieu de l’univers. Les fils d’Israël ont abandonné ton Alliance, renversé tes autels, et tué tes prophètes par l’épée ; moi, je suis le seul à être resté et ils cherchent à prendre ma vie. »
###### 15
Le Seigneur lui dit : « Repars vers Damas, par le chemin du désert. Arrivé là, tu consacreras par l’onction Hazaël comme roi de Syrie ;
###### 16
puis tu consacreras Jéhu, fils de Namsi, comme roi d’Israël ; et tu consacreras Élisée, fils de Shafath, d’Abel-Mehola, comme prophète pour te succéder.
###### 17
Celui qui échappera à l’épée d’Hazaël, Jéhu le tuera, et celui qui échappera à l’épée de Jéhu, Élisée le tuera.
###### 18
Mais je garderai en Israël un reste de sept mille hommes : tous les genoux qui n’auront pas fléchi devant Baal et toutes les bouches qui ne lui auront pas donné de baiser ! »
###### 19
Élie s’en alla. Il trouva Élisée, fils de Shafath, en train de labourer. Il avait à labourer douze arpents, et il en était au douzième. Élie passa près de lui et jeta vers lui son manteau.
###### 20
Alors Élisée quitta ses bœufs, courut derrière Élie, et lui dit : « Laisse-moi embrasser mon père et ma mère, puis je te suivrai. » Élie répondit : « Va-t’en, retourne là-bas ! Je n’ai rien fait. »
###### 21
Alors Élisée s’en retourna ; mais il prit la paire de bœufs pour les immoler, les fit cuire avec le bois de l’attelage, et les donna à manger aux gens. Puis il se leva, partit à la suite d’Élie et se mit à son service.
