---
aliases : 
- Exode 8
- Exode 8
- Ex 8
- Exodus 8
tags : 
- Bible/Ex/8
- français
cssclass : français
---

# Exode 8

###### 01
Le Seigneur dit à Moïse : « Va dire à Aaron : Étends la main avec ton bâton sur les rivières, les canaux, les étangs, et fais grimper les grenouilles sur le pays d’Égypte. »
###### 02
Aaron étendit la main sur les eaux d’Égypte ; les grenouilles grimpèrent et couvrirent le pays d’Égypte.
###### 03
Mais les magiciens en firent autant avec leurs sortilèges ; ils firent grimper, eux aussi, des grenouilles sur le pays d’Égypte.
###### 04
Pharaon appela Moïse et Aaron, et leur dit : « Priez le Seigneur de nous débarrasser des grenouilles, moi et mon peuple, et j’accepterai de laisser partir le peuple des Hébreux pour qu’il offre un sacrifice au Seigneur. »
###### 05
Moïse dit à Pharaon : « Daigne me dire quand je devrai prier pour toi, pour tes serviteurs et pour ton peuple, afin que les grenouilles disparaissent de chez toi et de toutes les maisons, et qu’il n’en reste plus, sinon dans le Nil. »
###### 06
Pharaon répondit : « Demain. » Moïse reprit : « Il en sera donc selon ta parole, afin que tu reconnaisses que nul n’est comme le Seigneur notre Dieu.
###### 07
Les grenouilles s’éloigneront de toi, de tes maisons, de tes serviteurs et de ton peuple ; il n’en restera plus, sinon dans le Nil. »
###### 08
Moïse et Aaron sortirent de chez Pharaon, et Moïse cria vers le Seigneur à propos des grenouilles dont il avait accablé Pharaon.
###### 09
Le Seigneur agit selon la parole de Moïse : les grenouilles crevèrent dans les maisons, dans les cours, dans les champs.
###### 10
On en fit des tas et des tas, et le pays s’empuantit.
###### 11
Pharaon vit qu’il y avait un répit ; il s’entêta ; il n’écouta pas Moïse et Aaron, ainsi que l’avait annoncé le Seigneur.
###### 12
Le Seigneur dit à Moïse : « Va dire à Aaron : Étends ton bâton et frappe la poussière du sol ; elle se changera en moustiques dans tout le pays d’Égypte. »
###### 13
Ils firent ainsi. Aaron étendit la main, il frappa de son bâton la poussière du sol, et les moustiques s’abattirent sur les gens et sur les bêtes ; toute la poussière du sol se changea en moustiques dans tout le pays d’Égypte.
###### 14
Les magiciens firent le même geste avec leurs sortilèges pour éliminer les moustiques, mais ils n’y réussirent pas : les moustiques restaient sur les gens et sur les bêtes.
###### 15
Les magiciens dirent alors à Pharaon : « C’est le doigt de Dieu ! » Mais Pharaon s’obstina ; il n’écouta pas Moïse et Aaron, ainsi que l’avait annoncé le Seigneur.
###### 16
Le Seigneur dit à Moïse : « Lève-toi de bon matin, et tu te posteras devant Pharaon quand il sortira pour se rendre près de l’eau. Tu lui diras : Ainsi parle le Seigneur : Laisse partir mon peuple afin qu’il me serve.
###### 17
Si toi, tu ne renvoies pas mon peuple, moi j’enverrai la vermine sur toi, sur tes serviteurs, sur ton peuple et dans tes maisons. Les maisons des Égyptiens seront pleines de vermine, et même le sol qu’ils foulent en sera couvert.
###### 18
Mais ce jour-là, je mettrai à part le pays de Goshèn où réside mon peuple : là il n’y aura pas de vermine, afin que tu reconnaisses que moi, le Seigneur Dieu, je suis au milieu du pays.
###### 19
J’établirai une distinction entre mon peuple et ton peuple ; c’est demain qu’aura lieu ce signe. »
###### 20
Et le Seigneur fit ainsi. La vermine envahit la maison de Pharaon, celles de ses serviteurs et tout le pays d’Égypte ; le pays en fut infesté.
###### 21
Pharaon appela Moïse et Aaron, et leur dit : « Allez, offrez un sacrifice à votre Dieu, mais ici, dans le pays. »
###### 22
Moïse répondit : « Sûrement pas ! Car les Égyptiens ont en abomination les sacrifices que nous offrons au Seigneur notre Dieu. Pourrions-nous faire sous leurs yeux, sans qu’ils nous lapident, un sacrifice qu’ils ont en abomination ?
###### 23
Nous voulons aller à trois jours de marche dans le désert pour offrir un sacrifice au Seigneur notre Dieu, selon ce qu’il nous dira. »
###### 24
Pharaon dit : « Moi, je vous laisserai partir et, dans le désert, vous offrirez un sacrifice au Seigneur votre Dieu. Seulement, ne vous éloignez pas trop et priez pour moi ! »
###### 25
Moïse répondit : « Eh bien, je vais sortir de chez toi, et je prierai le Seigneur. Demain, Pharaon, ses serviteurs et son peuple seront débarrassés de la vermine. Mais, que Pharaon cesse de se moquer de nous, en refusant de laisser partir le peuple afin qu’il offre un sacrifice au Seigneur ! »
###### 26
Moïse sortit de chez Pharaon et pria le Seigneur.
###### 27
Le Seigneur agit selon la parole de Moïse, et la vermine s’éloigna de Pharaon, de ses serviteurs et de son peuple ; il n’en resta plus.
###### 28
Une fois encore, Pharaon s’entêta et ne laissa pas le peuple partir.
