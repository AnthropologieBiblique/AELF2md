---
aliases : 
- Exode 29
- Exode 29
- Ex 29
- Exodus 29
tags : 
- Bible/Ex/29
- français
cssclass : français
---

# Exode 29

###### 01
« Et voici le rite que tu accompliras pour les consacrer, afin qu’ils exercent pour moi le sacerdoce : prends un taureau et deux béliers sans défaut,
###### 02
ainsi que du pain sans levain, des gâteaux sans levain pétris à l’huile et des galettes sans levain frottées d’huile. Tu les feras avec de la farine de blé.
###### 03
Tu les mettras dans une corbeille et tu les présenteras en même temps que le taureau et les deux béliers.
###### 04
Tu feras approcher Aaron et ses fils à l’entrée de la tente de la Rencontre, et tu leur feras prendre un bain.
###### 05
Ensuite, tu prendras les vêtements et tu revêtiras Aaron de la tunique, du manteau, de l’éphod et du pectoral. Tu le draperas dans l’écharpe de l’éphod
###### 06
et tu poseras le turban sur sa tête. Sur le turban, tu mettras le saint diadème.
###### 07
Puis tu prendras l’huile de l’onction : tu lui en verseras sur la tête et tu lui donneras l’onction.
###### 08
Alors tu feras approcher les fils d’Aaron, tu les revêtiras de tuniques.
###### 09
Tu leur mettras des ceintures, tu les coifferas de tiares, et le sacerdoce leur appartiendra en vertu d’un décret perpétuel. Tu conféreras l’investiture à Aaron et à ses fils.
###### 10
Tu feras approcher le taureau devant la tente de la Rencontre ; Aaron et ses fils imposeront la main sur sa tête,
###### 11
et tu l’immoleras devant le Seigneur, à l’entrée de la tente de la Rencontre.
###### 12
Tu prendras le sang du taureau et tu en mettras avec ton doigt sur les cornes de l’autel. Puis tu répandras le sang à la base de l’autel.
###### 13
Tu prendras toute la graisse qui enveloppe les entrailles ainsi que le lobe du foie, les deux rognons et la graisse qui les entoure, et tu les feras fumer sur l’autel.
###### 14
Mais tu brûleras hors du camp la chair du taureau, la peau et les excréments. C’est un sacrifice pour la faute.
###### 15
Tu prendras le premier bélier. Aaron et ses fils imposeront la main sur sa tête.
###### 16
Puis tu l’immoleras, tu prendras son sang et tu en aspergeras chaque côté de l’autel.
###### 17
Tu couperas le bélier en quartiers, tu laveras ses entrailles et ses pattes, et tu les poseras sur les quartiers et la tête.
###### 18
Tu feras fumer entièrement le bélier sur l’autel. C’est un holocauste pour le Seigneur, une nourriture offerte, en agréable odeur pour le Seigneur.
###### 19
Puis tu prendras le second bélier : Aaron et ses fils imposeront la main sur sa tête.
###### 20
Tu immoleras le bélier, tu prendras de son sang et tu en marqueras le lobe de l’oreille droite d’Aaron, le lobe de l’oreille droite de ses fils, le pouce de leur main droite et le gros orteil de leur pied droit. Et avec le sang tu aspergeras chaque côté de l’autel.
###### 21
Tu prendras du sang sur l’autel et de l’huile de l’onction, et tu feras l’aspersion sur Aaron et sur ses vêtements, sur ses fils et sur leurs vêtements également : ainsi seront consacrés Aaron et ses vêtements, ses fils et leurs vêtements.
###### 22
Tu prendras la graisse du bélier, la queue, la graisse qui recouvre les entrailles, le lobe du foie, les deux rognons et la graisse qui les recouvre, ainsi que la cuisse droite, car c’est un bélier d’investiture.
###### 23
Tu prendras une couronne de pain, un gâteau à l’huile et une galette, dans la corbeille des pains sans levain placée devant le Seigneur.
###### 24
Tu poseras le tout sur les paumes d’Aaron et de ses fils, et tu le leur feras présenter avec le geste d’élévation devant le Seigneur.
###### 25
Ensuite, tu le reprendras de leurs mains et tu le feras fumer sur l’autel de l’holocauste ; c’est une nourriture offerte, en agréable odeur pour le Seigneur.
###### 26
Tu prendras la poitrine du bélier d’investiture d’Aaron et tu feras avec elle le geste d’élévation devant le Seigneur : cette part sera la tienne.
###### 27
Tu consacreras la poitrine présentée et la cuisse prélevée du bélier d’investiture d’Aaron et de ses fils.
###### 28
Ce sera, selon un décret perpétuel, ce qu’Aaron et ses fils recevront des fils d’Israël. Car c’est une contribution des fils d’Israël – et cela le restera –, une contribution prise sur leurs sacrifices de paix, une contribution pour le Seigneur.
###### 29
Les vêtements sacrés d’Aaron passeront après lui à ses fils qui les porteront pour leur onction et leur investiture.
###### 30
Pendant sept jours, le fils d’Aaron qui lui succédera comme prêtre portera ces vêtements. Il entrera dans la tente de la Rencontre pour officier dans le sanctuaire.
###### 31
Tu prendras le bélier d’investiture et tu feras cuire sa chair dans un lieu saint.
###### 32
Aaron mangera – et ses fils avec lui – la chair du bélier et le pain qui est dans la corbeille, à l’entrée de la tente de la Rencontre.
###### 33
Ils mangeront ce qui a servi au rite de l’expiation, lors de leur investiture et de leur consécration. Aucun profane n’en mangera, car c’est chose sainte.
###### 34
Au matin, s’il reste de la viande et du pain, tu brûleras ce reste au feu. On ne le mangera pas, car c’est chose sainte.
###### 35
Tu feras donc ainsi pour Aaron et ses fils, comme je te l’ai ordonné. Pendant sept jours, tu accompliras le rite d’investiture.
Le sacrifice quotidien
###### 36
« Chaque jour, tu apprêteras pour le rite d’expiation un taureau, en vue du sacrifice pour la faute ; puis tu accompliras le rite d’expiation sur l’autel en sacrifice pour la faute, et tu lui feras une onction pour le consacrer.
###### 37
Pendant sept jours, tu accompliras ce rite d’expiation sur l’autel et tu le consacreras ; ainsi, l’autel sera très saint, et tout ce qui touche à l’autel sera sanctifié.
###### 38
Voici ce que tu mettras sur l’autel : des agneaux de l’année, deux par jour, perpétuellement.
###### 39
Le premier agneau, tu le mettras le matin ; et le second agneau, au coucher du soleil.
###### 40
Avec le premier agneau, tu mettras dix livres de fleur de farine, pétrie dans un quart de setier d’huile vierge ; et, de plus, une libation d’un quart de setier de vin.
###### 41
Avec le second agneau, que tu mettras au coucher du soleil, tu feras la même offrande que le matin, et la même libation : ce sera une nourriture offerte, en agréable odeur au Seigneur.
###### 42
Tel sera l’holocauste perpétuel que vous ferez d’âge en âge, à l’entrée de la tente de la Rencontre, en présence du Seigneur ; ce sera pour vous le lieu de rencontre, où je te parlerai.
###### 43
Là, je me laisserai rencontrer par les fils d’Israël et ce lieu sera consacré par ma gloire.
###### 44
Je consacrerai la tente de la Rencontre ainsi que l’autel. Je consacrerai Aaron et ses fils, afin qu’ils exercent pour moi le sacerdoce.
###### 45
Je demeurerai au milieu des fils d’Israël, et je serai leur Dieu.
###### 46
Ils sauront que je suis le Seigneur, leur Dieu, qui les a fait sortir du pays d’Égypte pour demeurer au milieu d’eux. Je suis le Seigneur, leur Dieu.
