---
aliases : 
- Exode 17
- Exode 17
- Ex 17
- Exodus 17
tags : 
- Bible/Ex/17
- français
cssclass : français
---

# Exode 17

###### 01
Toute la communauté des fils d’Israël partit du désert de Sine, en observant les étapes prescrites par le Seigneur. Ils campèrent à Rephidim. Comme il n’y avait pas d’eau à boire,
###### 02
le peuple chercha querelle à Moïse : « Donne-nous de l’eau à boire ! » Moïse leur répondit : « Pourquoi me cherchez-vous querelle ? Pourquoi mettez-vous le Seigneur à l’épreuve ? »
###### 03
Là, le peuple souffrit de la soif. Il récrimina contre Moïse et dit : « Pourquoi nous as-tu fait monter d’Égypte ? Était-ce pour nous faire mourir de soif avec nos fils et nos troupeaux ? »
###### 04
Moïse cria vers le Seigneur : « Que vais-je faire de ce peuple ? Encore un peu, et ils me lapideront ! »
###### 05
Le Seigneur dit à Moïse : « Passe devant le peuple, emmène avec toi plusieurs des anciens d’Israël, prends en main le bâton avec lequel tu as frappé le Nil, et va !
###### 06
Moi, je serai là, devant toi, sur le rocher du mont Horeb. Tu frapperas le rocher, il en sortira de l’eau, et le peuple boira ! » Et Moïse fit ainsi sous les yeux des anciens d’Israël.
###### 07
Il donna à ce lieu le nom de Massa (c’est-à-dire : Épreuve) et Mériba (c’est-à-dire : Querelle), parce que les fils d’Israël avaient cherché querelle au Seigneur, et parce qu’ils l’avaient mis à l’épreuve, en disant : « Le Seigneur est-il au milieu de nous, oui ou non ? »
###### 08
Les Amalécites survinrent et attaquèrent Israël à Rephidim.
###### 09
Moïse dit alors à Josué : « Choisis des hommes, et va combattre les Amalécites. Moi, demain, je me tiendrai sur le sommet de la colline, le bâton de Dieu à la main. »
###### 10
Josué fit ce que Moïse avait dit : il mena le combat contre les Amalécites. Moïse, Aaron et Hour étaient montés au sommet de la colline.
###### 11
Quand Moïse tenait la main levée, Israël était le plus fort. Quand il la laissait retomber, Amalec était le plus fort.
###### 12
Mais les mains de Moïse s’alourdissaient ; on prit une pierre, on la plaça derrière lui, et il s’assit dessus. Aaron et Hour lui soutenaient les mains, l’un d’un côté, l’autre de l’autre. Ainsi les mains de Moïse restèrent fermes jusqu’au coucher du soleil.
###### 13
Et Josué triompha des Amalécites au fil de l’épée.
###### 14
Alors le Seigneur dit à Moïse : « Écris cela dans le Livre pour en faire mémoire et déclare à Josué que j’effacerai complètement le souvenir d’Amalec de dessous les cieux ! »
###### 15
Moïse bâtit un autel et l’appela : « Le-Seigneur-est-mon-étendard. »
###### 16
Et il dit : « Puisqu’une main s’est levée contre le trône du Seigneur, le Seigneur est en guerre contre Amalec, de génération en génération. »
