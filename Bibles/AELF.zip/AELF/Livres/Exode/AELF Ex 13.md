---
aliases : 
- Exode 13
- Exode 13
- Ex 13
- Exodus 13
tags : 
- Bible/Ex/13
- français
cssclass : français
---

# Exode 13

###### 01
Le Seigneur parla à Moïse. Il dit :
###### 02
« Consacre-moi tous les premiers-nés parmi les fils d’Israël, car les premiers-nés des hommes et les premiers-nés du bétail m’appartiennent. »
###### 03
Moïse dit au peuple : « Souvenez-vous de ce jour, le jour de votre sortie du pays d’Égypte, la maison d’esclavage, car c’est par la force de sa main que le Seigneur vous en a fait sortir. On ne mangera pas de pain levé, ce jour-là.
###### 04
C’est aujourd’hui, au mois des Épis, que vous sortez.
###### 05
Le Seigneur te fera entrer dans le pays du Cananéen, du Hittite, de l’Amorite, du Hivvite et du Jébuséen, le pays qu’il a juré à tes pères de te donner, le pays ruisselant de lait et de miel. Alors, en ce mois des Épis, tu pratiqueras ce rite-ci.
###### 06
Pendant sept jours, tu mangeras des pains sans levain. Et, le septième jour, tu célébreras la fête en l’honneur du Seigneur.
###### 07
On mangera du pain sans levain pendant les sept jours. Sur ton territoire tout entier, on ne trouvera pas de pain levé, on ne trouvera même pas de levain.
###### 08
Ce jour-là, tu donneras à ton fils cette explication : “C’est en raison de ce que le Seigneur a fait pour moi lors de ma sortie d’Égypte.”
###### 09
Ce rite sera pour toi comme un signe sur ta main, comme un mémorial entre tes yeux, afin que la loi du Seigneur soit dans ta bouche ; car, par la force de sa main, le Seigneur t’a fait sortir d’Égypte.
###### 10
Tu observeras ce décret au moment prescrit, d’année en année.
###### 11
Alors, quand le Seigneur t’aura fait entrer dans le pays de Canaan, cette terre qu’il a juré à toi et à tes pères de te donner,
###### 12
alors tu remettras au Seigneur tout premier-né : tout premier-né de sexe masculin et tout premier-né mâle du bétail appartiennent au Seigneur.
###### 13
Le premier-né des ânes, tu le rachèteras par un mouton. Si tu ne le rachètes pas, tu lui briseras la nuque. Mais chez les hommes, tout fils premier-né, tu le rachèteras.
###### 14
Alors, demain, quand ton fils te demandera : “Que fais-tu là ?”, tu lui répondras : “C’est par la force de sa main que le Seigneur nous a fait sortir d’Égypte, la maison d’esclavage.
###### 15
En effet, comme Pharaon multipliait les obstacles pour nous laisser partir, le Seigneur fit mourir tous les premiers-nés au pays d’Égypte, du premier-né des hommes au premier-né du bétail. C’est pourquoi j’offre en sacrifice au Seigneur tous les premiers-nés de sexe mâle ; mais le premier-né de mes fils, je le rachète.”
###### 16
Ce rite sera pour toi comme un signe à ton poignet, comme un bandeau sur ton front : c’est par la force de sa main que le Seigneur nous a fait sortir d’Égypte. »
###### 17
Quand Pharaon laissa partir le peuple, Dieu ne leur fit pas prendre la route du pays des Philistins, bien qu’elle fût la plus directe. Dieu s’était dit : « Il ne faudrait pas qu’à la perspective des combats, le peuple revienne sur sa décision et retourne en Égypte. »
###### 18
Dieu fit donc faire au peuple un détour par le désert de la mer des Roseaux. C’est, rangés comme une armée, que les fils d’Israël étaient montés du pays d’Égypte.
###### 19
Moïse prit avec lui les ossements de Joseph, car celui-ci avait exigé des fils d’Israël un serment solennel, en leur disant : « Dieu ne manquera pas de vous visiter : alors, quand vous remonterez d’Égypte, emportez mes ossements avec vous. »
###### 20
Ils partirent de Souccoth et campèrent à Étam, en bordure du désert.
###### 21
Le Seigneur lui-même marchait à leur tête : le jour dans une colonne de nuée pour leur ouvrir la route, la nuit dans une colonne de feu pour les éclairer ; ainsi pouvaient-ils marcher jour et nuit.
###### 22
Le jour, la colonne de nuée ne quittait pas la tête du peuple ; ni, la nuit, la colonne de feu.
