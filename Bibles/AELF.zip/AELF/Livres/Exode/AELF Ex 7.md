---
aliases : 
- Exode 7
- Exode 7
- Ex 7
- Exodus 7
tags : 
- Bible/Ex/7
- français
cssclass : français
---

# Exode 7

###### 01
Le Seigneur dit à Moïse : « Vois, j’ai fait de toi un dieu pour Pharaon, et ton frère Aaron sera ton prophète.
###### 02
Toi, tu lui diras tout ce que je t’ordonnerai, et ton frère Aaron le répétera à Pharaon pour qu’il laisse partir de son pays les fils d’Israël.
###### 03
Mais moi, je rendrai le cœur de Pharaon inflexible ; je multiplierai mes signes et mes prodiges dans le pays d’Égypte,
###### 04
mais Pharaon ne vous écoutera pas. Alors je poserai la main sur l’Égypte et je ferai sortir du pays d’Égypte mes armées, mon peuple, les fils d’Israël, en exerçant de terribles jugements.
###### 05
Les Égyptiens reconnaîtront que Je suis le Seigneur, quand j’étendrai la main contre l’Égypte et que j’en ferai sortir les fils d’Israël. »
###### 06
Moïse et Aaron s’exécutèrent : ce que le Seigneur leur avait ordonné, ils le firent.
###### 07
Moïse était âgé de quatre-vingts ans et Aaron de quatre-vingt-trois ans, lorsqu’ils parlèrent à Pharaon.
###### 08
Le Seigneur dit à Moïse et Aaron :
###### 09
« Si Pharaon vous demande d’accomplir un prodige, tu diras alors à Aaron : Prends ton bâton, jette-le devant Pharaon, et qu’il devienne un serpent. »
###### 10
Moïse et Aaron allèrent trouver Pharaon et firent comme l’avait ordonné le Seigneur. Aaron jeta son bâton devant Pharaon et ses serviteurs, et le bâton devint un serpent.
###### 11
Pharaon, à son tour, convoqua les sages et les enchanteurs. Les magiciens d’Égypte en firent autant avec leurs sortilèges.
###### 12
Chacun jeta son bâton qui devint un serpent, mais le bâton d’Aaron engloutit leurs bâtons.
###### 13
Cependant, Pharaon s’obstina ; il n’écouta pas Moïse et Aaron, ainsi que l’avait annoncé le Seigneur.
###### 14
Le Seigneur dit à Moïse : « Le cœur de Pharaon s’est appesanti ; il refuse de laisser partir le peuple.
###### 15
Va trouver Pharaon demain matin : il sortira pour se rendre près de l’eau ; tu te posteras au bord du Nil pour le rencontrer. Le bâton qui s’est changé en serpent, tu le prendras en main.
###### 16
Tu diras à Pharaon : “Le Seigneur, le Dieu des Hébreux, m’a envoyé vers toi pour te dire : Laisse partir mon peuple afin qu’il me serve dans le désert.” Jusqu’à présent tu n’as pas écouté.
###### 17
Ainsi parle le Seigneur : À ceci tu reconnaîtras que je suis le Seigneur. Voici que moi, je vais frapper les eaux du Nil avec le bâton que j’ai dans la main, et elles se changeront en sang.
###### 18
Les poissons du Nil crèveront, le Nil s’empuantira et les Égyptiens ne pourront plus boire l’eau du fleuve. »
###### 19
Le Seigneur dit à Moïse : « Va dire à Aaron : Prends ton bâton, étends la main sur les eaux d’Égypte – sur ses rivières, ses canaux, ses étangs, sur toutes ses réserves d’eau – et qu’elles soient du sang ! Qu’il y ait du sang dans tout le pays d’Égypte, jusque dans les récipients de bois et de pierre. »
###### 20
Moïse et Aaron firent comme le Seigneur l’avait ordonné. Aaron leva son bâton et frappa les eaux du Nil sous les yeux de Pharaon et de ses serviteurs, et toutes les eaux du Nil se changèrent en sang.
###### 21
Les poissons du Nil crevèrent et le Nil s’empuantit ; les Égyptiens ne pouvaient plus boire l’eau du fleuve ; il y avait du sang dans tout le pays d’Égypte.
###### 22
Mais les magiciens d’Égypte en firent autant avec leurs sortilèges, et Pharaon s’obstina ; il n’écouta pas Moïse et Aaron, ainsi que l’avait annoncé le Seigneur.
###### 23
Pharaon s’en retourna. Il rentra chez lui sans prendre la chose à cœur.
###### 24
En quête d’eau, tous les Égyptiens se mirent à creuser aux alentours du Nil, car ils ne pouvaient plus boire les eaux du fleuve.
###### 25
Sept jours s’écoulèrent après que le Seigneur eut frappé le Nil.
###### 26
Le Seigneur dit à Moïse : « Va trouver Pharaon et dis-lui : Ainsi parle le Seigneur : “Laisse partir mon peuple, afin qu’il me serve.”
###### 27
Si toi, tu refuses de le laisser partir, moi je vais infester de grenouilles tout ton territoire.
###### 28
Le Nil grouillera de grenouilles ; elles monteront, elles entreront dans ta maison, dans ta chambre à coucher, sur ton lit, dans les maisons de tes serviteurs et de ton peuple, dans tes fours et dans tes pétrins.
###### 29
Sur toi, sur les gens de ton peuple et sur tous tes serviteurs, grimperont les grenouilles. »
