---
aliases : 
- Exode 1
- Exode 1
- Ex 1
- Exodus 1
tags : 
- Bible/Ex/1
- français
cssclass : français
---

# Exode 1

###### 01
VOICI LES NOMS des fils d’Israël venus en Égypte avec Jacob, leur père. Chacun y vint avec sa famille.
###### 02
C’étaient Roubène, Siméon, Lévi et Juda,
###### 03
Issakar, Zabulon et Benjamin,
###### 04
Dane et Nephtali, Gad et Asher.
###### 05
Toutes les personnes issues de Jacob étaient au nombre de soixante-dix. Joseph, lui, était déjà en Égypte.
###### 06
Puis Joseph mourut, ainsi que tous ses frères et toute cette génération-là.
###### 07
Les fils d’Israël furent féconds, ils devinrent très nombreux, ils se multiplièrent et devinrent de plus en plus forts : tout le pays en était rempli.
###### 08
Un nouveau roi vint au pouvoir en Égypte. Il n’avait pas connu Joseph.
###### 09
Il dit à son peuple : « Voici que le peuple des fils d’Israël est maintenant plus nombreux et plus puissant que nous.
###### 10
Prenons donc les dispositions voulues pour l’empêcher de se multiplier. Car, s’il y avait une guerre, il se joindrait à nos ennemis, combattrait contre nous, et ensuite il sortirait du pays. »
###### 11
On imposa donc aux fils d’Israël des chefs de corvée pour les accabler de travaux pénibles. Ils durent bâtir pour Pharaon les villes d’entrepôts de Pithome et de Ramsès.
###### 12
Mais, plus on les accablait, plus ils se multipliaient et proliféraient, ce qui les fit détester.
###### 13
Les Égyptiens soumirent les fils d’Israël à un dur esclavage
###### 14
et leur rendirent la vie intenable à force de corvées : préparation de l’argile et des briques et toutes sortes de travaux à la campagne ; tous ces travaux étaient pour eux un dur esclavage.
###### 15
Alors le roi d’Égypte parla aux sages-femmes des Hébreux dont l’une s’appelait Shifra et l’autre Poua ;
###### 16
il leur dit : « Quand vous accoucherez les femmes des Hébreux, regardez bien le sexe de l’enfant : si c’est un garçon, faites-le mourir ; si c’est une fille, laissez-la vivre. »
###### 17
Mais les sages-femmes craignirent Dieu et n’obéirent pas à l’ordre du roi : elles laissèrent vivre les garçons.
###### 18
Alors le roi d’Égypte les appela et leur dit : « Pourquoi avez-vous agi de la sorte, pourquoi avez-vous laissé vivre les garçons ? »
###### 19
Les sages-femmes répondirent à Pharaon : « Les femmes des Hébreux ne sont pas comme les Égyptiennes, elles sont pleines de vitalité ; avant l’arrivée de la sage-femme, elles ont déjà accouché. »
###### 20
Dieu accorda ses bienfaits aux sages-femmes ; le peuple devint très nombreux et très fort.
###### 21
Comme les sages-femmes avaient craint Dieu, il leur avait accordé une descendance.
###### 22
Pharaon donna cet ordre à tout son peuple : « Tous les fils qui naîtront aux Hébreux, jetez-les dans le Nil. Ne laissez vivre que les filles. »
