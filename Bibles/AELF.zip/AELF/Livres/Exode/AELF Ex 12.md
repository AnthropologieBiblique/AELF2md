---
aliases : 
- Exode 12
- Exode 12
- Ex 12
- Exodus 12
tags : 
- Bible/Ex/12
- français
cssclass : français
---

# Exode 12

###### 01
Dans le pays d’Égypte, le Seigneur dit à Moïse et à son frère Aaron :
###### 02
« Ce mois-ci sera pour vous le premier des mois, il marquera pour vous le commencement de l’année.
###### 03
Parlez ainsi à toute la communauté d’Israël : le dix de ce mois, que l’on prenne un agneau par famille, un agneau par maison.
###### 04
Si la maisonnée est trop peu nombreuse pour un agneau, elle le prendra avec son voisin le plus proche, selon le nombre des personnes. Vous choisirez l’agneau d’après ce que chacun peut manger.
###### 05
Ce sera une bête sans défaut, un mâle, de l’année. Vous prendrez un agneau ou un chevreau.
###### 06
Vous le garderez jusqu’au quatorzième jour du mois. Dans toute l’assemblée de la communauté d’Israël, on l’immolera au coucher du soleil.
###### 07
On prendra du sang, que l’on mettra sur les deux montants et sur le linteau des maisons où on le mangera.
###### 08
On mangera sa chair cette nuit-là, on la mangera rôtie au feu, avec des pains sans levain et des herbes amères.
###### 09
Vous n’en mangerez aucun morceau qui soit à moitié cuit ou qui soit bouilli ; tout sera rôti au feu, y compris la tête, les jarrets et les entrailles.
###### 10
Vous n’en garderez rien pour le lendemain ; ce qui resterait pour le lendemain, vous le détruirez en le brûlant.
###### 11
Vous mangerez ainsi : la ceinture aux reins, les sandales aux pieds, le bâton à la main. Vous mangerez en toute hâte : c’est la Pâque du Seigneur.
###### 12
Je traverserai le pays d’Égypte, cette nuit-là ; je frapperai tout premier-né au pays d’Égypte, depuis les hommes jusqu’au bétail. Contre tous les dieux de l’Égypte j’exercerai mes jugements : Je suis le Seigneur.
###### 13
Le sang sera pour vous un signe, sur les maisons où vous serez. Je verrai le sang, et je passerai : vous ne serez pas atteints par le fléau dont je frapperai le pays d’Égypte.
###### 14
Ce jour-là sera pour vous un mémorial. Vous en ferez pour le Seigneur une fête de pèlerinage. C’est un décret perpétuel : d’âge en âge vous la fêterez.
###### 15
Pendant sept jours, vous mangerez des pains sans levain. Dès le premier jour, vous ferez disparaître le levain de vos maisons. Et celui qui mangera du pain levé, entre le premier et le septième jour, celui-là sera retranché du peuple d’Israël.
###### 16
Le premier jour, vous tiendrez une assemblée sainte ; vous ferez de même le septième jour. Ces jours-là, on ne fera aucun travail, sauf pour préparer le repas de chacun ; on ne fera rien d’autre.
###### 17
Vous observerez la fête des Pains sans levain car, en ce jour même, j’ai fait sortir vos armées du pays d’Égypte. D’âge en âge, vous observerez ce jour. C’est un décret perpétuel.
###### 18
Le premier mois, du quatorzième jour au soir jusqu’au vingt et unième jour au soir, vous mangerez du pain sans levain.
###### 19
Pendant sept jours, on ne trouvera pas de levain dans vos maisons. Et celui qui mangera du pain levé – qu’il soit immigré ou israélite originaire du pays – celui-là sera retranché de la communauté d’Israël.
###### 20
Vous ne mangerez aucun pain levé. Où que vous habitiez, vous mangerez des pains sans levain. »
###### 21
Moïse convoqua tous les anciens d’Israël et leur dit : « Prenez un agneau par clan et immolez-le pour la Pâque.
###### 22
Puis vous prendrez un bouquet d’hysope, vous le tremperez dans le sang que vous aurez recueilli dans un récipient, et vous étendrez le sang sur le linteau et les deux montants de la porte. Que nul d’entre vous ne sorte de sa maison avant le matin.
###### 23
Ainsi, lorsque le Seigneur traversera l’Égypte pour la frapper, et qu’il verra le sang sur le linteau et les deux montants, il passera cette maison sans permettre à l’Exterminateur d’y entrer pour la frapper.
###### 24
Vous observerez cette parole comme un décret perpétuel pour vous et vos fils.
###### 25
Quand vous serez entrés dans le pays que le Seigneur vous donnera comme il l’a dit, vous conserverez ce rite.
###### 26
Et quand vos fils vous demanderont : “Que signifie pour vous ce rite ?”
###### 27
vous répondrez : “C’est le sacrifice de la Pâque en l’honneur du Seigneur : il a passé les maisons des fils d’Israël en Égypte ; lorsqu’il a frappé l’Égypte, il a épargné nos maisons !” »
Alors, le peuple s’inclina et se prosterna.
###### 28
Puis, les fils d’Israël s’en allèrent et firent comme le Seigneur l’avait ordonné à Moïse et Aaron.
###### 29
Au milieu de la nuit, le Seigneur frappa tous les premiers-nés de l’Égypte, du premier-né de Pharaon qui siège sur le trône, jusqu’au premier-né du captif dans sa prison, et tous les premiers-nés du bétail.
###### 30
Cette nuit-là, Pharaon se leva, ainsi que tous ses serviteurs et tous les Égyptiens ; et une immense clameur s’éleva en Égypte, car il n’y avait pas une seule maison sans un mort.
###### 31
Pharaon convoqua Moïse et Aaron en pleine nuit, et leur dit : « Levez-vous ! Sortez du milieu de mon peuple, vous et les fils d’Israël. Allez ! Servez le Seigneur comme vous l’avez demandé.
###### 32
Même votre bétail, le petit et le gros, prenez-le comme vous l’avez demandé, et partez ! Appelez sur moi la bénédiction ! »
###### 33
Les Égyptiens pressèrent le peuple d’Israël de quitter le pays au plus vite, car ils se disaient : « Nous allons tous mourir ! »
###### 34
Le peuple emporta la pâte avant qu’elle n’ait levé : ils enveloppèrent les pétrins dans leurs manteaux et les mirent sur leurs épaules.
###### 35
Les fils d’Israël avaient agi selon la parole de Moïse : ils avaient demandé aux Égyptiens des objets d’argent, des objets d’or et des manteaux.
###### 36
Le Seigneur fit que son peuple trouve grâce aux yeux des Égyptiens : ils cédèrent à leur demande. Ainsi les fils d’Israël dépouillèrent-ils les Égyptiens.
###### 37
Les fils d’Israël partirent de la ville de Ramsès en direction de Souccoth, au nombre d’environ six cent mille sans compter les enfants.
###### 38
Une multitude disparate les accompagnait, ainsi qu’un immense troupeau de moutons et de bœufs.
###### 39
Ils firent cuire des galettes sans levain avec la pâte qu’ils avaient emportée d’Égypte et qui n’avait pas levé ; en effet, ils avaient été chassés d’Égypte sans avoir eu le temps de faire des provisions.
###### 40
Le séjour des fils d’Israël en Égypte avait duré quatre cent trente ans.
###### 41
Et c’est au bout de quatre cent trente ans, c’est en ce jour même que toutes les armées du Seigneur sortirent du pays d’Égypte.
###### 42
Ce fut une nuit de veille pour le Seigneur, quand il fit sortir d’Égypte les fils d’Israël ; ce doit être pour eux, de génération en génération, une nuit de veille en l’honneur du Seigneur.
###### 43
Le Seigneur dit à Moïse et Aaron : « Voici le rituel pour la Pâque : aucun étranger n’en mangera.
###### 44
Tout esclave acquis à prix d’argent, tu le circonciras, et alors il pourra en manger.
###### 45
Ni l’hôte, ni le salarié n’en mangeront.
###### 46
On la mangera dans une seule maison. Tu ne sortiras de cette maison aucun morceau de viande. Vous ne briserez aucun de ses os.
###### 47
Toute la communauté d’Israël observera ce rituel.
###### 48
Si un immigré qui réside chez toi veut célébrer la Pâque pour le Seigneur, tous les hommes de sa maison devront être circoncis. Alors il pourra s’approcher pour célébrer ; il sera considéré comme un israélite originaire du pays. Mais celui qui n’aura pas été circoncis n’en mangera pas.
###### 49
La loi sera la même pour l’israélite de souche et pour l’immigré qui réside chez vous. »
###### 50
Tous les fils d’Israël firent comme le Seigneur l’avait ordonné à Moïse et Aaron. Ils firent ainsi.
###### 51
C’est en ce jour même que le Seigneur fit sortir du pays d’Égypte les fils d’Israël rangés comme une armée.
