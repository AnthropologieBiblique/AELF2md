---
aliases : 
- Exode 14
- Exode 14
- Ex 14
- Exodus 14
tags : 
- Bible/Ex/14
- français
cssclass : français
---

# Exode 14

###### 01
Le Seigneur parla à Moïse. Il dit :
###### 02
« Va dire aux fils d’Israël de revenir camper devant Pi-Hahiroth, entre Migdol et la mer, devant Baal-Sefone ; vous camperez juste en face, au bord de la mer.
###### 03
Alors Pharaon dira : “Voilà que les fils d’Israël, affolés, errent dans le pays ! Le désert s’est refermé sur eux !”
###### 04
Alors, je ferai en sorte que Pharaon s’obstine, et il les poursuivra. Mais je me glorifierai aux dépens de Pharaon et de toute son armée, et les Égyptiens reconnaîtront que je suis le Seigneur. » Les fils d’Israël firent ainsi.
###### 05
On annonça au roi d’Égypte, que le peuple d’Israël s’était enfui. Alors Pharaon et ses serviteurs changèrent de sentiment envers ce peuple. Ils dirent : « Qu’avons-nous fait en laissant partir Israël : il ne sera plus à notre service ! »
###### 06
Pharaon fit atteler son char et rassembler ses troupes ;
###### 07
il prit six cents chars d’élite et tous les chars de l’Égypte, chacun avec son équipage.
###### 08
Le Seigneur fit en sorte que s’obstine Pharaon, roi d’Égypte, qui se lança à la poursuite des fils d’Israël, tandis que ceux-ci avançaient librement.
###### 09
Les Égyptiens, tous les chevaux, les chars de Pharaon, ses guerriers et son armée, les poursuivirent et les rejoignirent alors qu’ils campaient au bord de la mer, près de Pi-Hahiroth, en face de Baal-Sefone.
###### 10
Comme Pharaon approchait, les fils d’Israël regardèrent et, voyant les Égyptiens lancés à leur poursuite, ils eurent très peur, et ils crièrent vers le Seigneur.
###### 11
Ils dirent à Moïse : « L’Égypte manquait-elle de tombeaux, pour que tu nous aies emmenés mourir dans le désert ? Quel mauvais service tu nous as rendu en nous faisant sortir d’Égypte !
###### 12
C’est bien là ce que nous te disions en Égypte : “Ne t’occupe pas de nous, laisse-nous servir les Égyptiens. Il vaut mieux les servir que de mourir dans le désert !” »
###### 13
Moïse répondit au peuple : « N’ayez pas peur ! Tenez bon ! Vous allez voir aujourd’hui ce que le Seigneur va faire pour vous sauver ! Car, ces Égyptiens que vous voyez aujourd’hui, vous ne les verrez plus jamais.
###### 14
Le Seigneur combattra pour vous, et vous, vous n’aurez rien à faire. »
###### 15
Le Seigneur dit à Moïse : « Pourquoi crier vers moi ? Ordonne aux fils d’Israël de se mettre en route !
###### 16
Toi, lève ton bâton, étends le bras sur la mer, fends-la en deux, et que les fils d’Israël entrent au milieu de la mer à pied sec.
###### 17
Et moi, je ferai en sorte que les Égyptiens s’obstinent : ils y entreront derrière eux ; je me glorifierai aux dépens de Pharaon et de toute son armée, de ses chars et de ses guerriers.
###### 18
Les Égyptiens sauront que je suis le Seigneur, quand je me serai glorifié aux dépens de Pharaon, de ses chars et de ses guerriers. »
###### 19
L’ange de Dieu, qui marchait en avant d’Israël, se déplaça et marcha à l’arrière. La colonne de nuée se déplaça depuis l’avant-garde et vint se tenir à l’arrière,
###### 20
entre le camp des Égyptiens et le camp d’Israël. Cette nuée était à la fois ténèbres et lumière dans la nuit, si bien que, de toute la nuit, ils ne purent se rencontrer.
###### 21
Moïse étendit le bras sur la mer. Le Seigneur chassa la mer toute la nuit par un fort vent d’est ; il mit la mer à sec, et les eaux se fendirent.
###### 22
Les fils d’Israël entrèrent au milieu de la mer à pied sec, les eaux formant une muraille à leur droite et à leur gauche.
###### 23
Les Égyptiens les poursuivirent ; tous les chevaux de Pharaon, ses chars et ses guerriers entrèrent derrière eux jusqu’au milieu de la mer.
###### 24
Aux dernières heures de la nuit, le Seigneur observa, depuis la colonne de feu et de nuée, l’armée des Égyptiens, et il la frappa de panique.
###### 25
Il faussa les roues de leurs chars, et ils eurent beaucoup de peine à les conduire. Les Égyptiens s’écrièrent : « Fuyons devant Israël, car c’est le Seigneur qui combat pour eux contre nous ! »
###### 26
Le Seigneur dit à Moïse : « Étends le bras sur la mer : que les eaux reviennent sur les Égyptiens, leurs chars et leurs guerriers ! »
###### 27
Moïse étendit le bras sur la mer. Au point du jour, la mer reprit sa place ; dans leur fuite, les Égyptiens s’y heurtèrent, et le Seigneur les précipita au milieu de la mer.
###### 28
Les eaux refluèrent et recouvrirent les chars et les guerriers, toute l’armée de Pharaon qui était entrée dans la mer à la poursuite d’Israël. Il n’en resta pas un seul.
###### 29
Mais les fils d’Israël avaient marché à pied sec au milieu de la mer, les eaux formant une muraille à leur droite et à leur gauche.
###### 30
Ce jour-là, le Seigneur sauva Israël de la main de l’Égypte, et Israël vit les Égyptiens morts sur le bord de la mer.
###### 31
Israël vit avec quelle main puissante le Seigneur avait agi contre l’Égypte. Le peuple craignit le Seigneur, il mit sa foi dans le Seigneur et dans son serviteur Moïse.
