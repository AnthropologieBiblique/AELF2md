---
aliases : 
- Exode 32
- Exode 32
- Ex 32
- Exodus 32
tags : 
- Bible/Ex/32
- français
cssclass : français
---

# Exode 32

###### 01
Le peuple vit que Moïse tardait à descendre de la montagne. Il se rassembla contre Aaron et lui dit : « Debout ! Fais-nous des dieux qui marchent devant nous. Car ce Moïse, l’homme qui nous a fait monter du pays d’Égypte, nous ne savons pas ce qui lui est arrivé. »
###### 02
Aaron leur répondit : « Enlevez les boucles d’or qui sont aux oreilles de vos femmes, de vos fils, de vos filles, et apportez-les moi. »
###### 03
Tout le peuple se dépouilla des boucles d’or qu’ils avaient aux oreilles et ils les apportèrent à Aaron.
###### 04
Il reçut l’or de leurs mains, le façonna au burin et en fit un veau en métal fondu. Ils dirent alors : « Israël, voici tes dieux, qui t’ont fait monter du pays d’Égypte. »
###### 05
Ce que voyant, Aaron bâtit un autel en face du veau en métal fondu et il proclama : « Demain, fête pour le Seigneur ! »
###### 06
Le lendemain, levés de bon matin, ils offrirent des holocaustes et présentèrent des sacrifices de paix ; le peuple s’assit pour manger et boire ; puis il se leva pour se divertir.
###### 07
Le Seigneur parla à Moïse : « Va, descends, car ton peuple s’est corrompu, lui que tu as fait monter du pays d’Égypte.
###### 08
Ils n’auront pas mis longtemps à s’écarter du chemin que je leur avais ordonné de suivre ! Ils se sont fait un veau en métal fondu et se sont prosternés devant lui. Ils lui ont offert des sacrifices en proclamant : “Israël, voici tes dieux, qui t’ont fait monter du pays d’Égypte.” »
###### 09
Le Seigneur dit encore à Moïse : « Je vois que ce peuple est un peuple à la nuque raide.
###### 10
Maintenant, laisse-moi faire ; ma colère va s’enflammer contre eux et je vais les exterminer ! Mais, de toi, je ferai une grande nation. »
###### 11
Moïse apaisa le visage du Seigneur son Dieu en disant : « Pourquoi, Seigneur, ta colère s’enflammerait-elle contre ton peuple, que tu as fait sortir du pays d’Égypte par ta grande force et ta main puissante ?
###### 12
Pourquoi donner aux Égyptiens l’occasion de dire : “C’est par méchanceté qu’il les a fait sortir ; il voulait les tuer dans les montagnes et les exterminer à la surface de la terre” ? Reviens de l’ardeur de ta colère, renonce au mal que tu veux faire à ton peuple.
###### 13
Souviens-toi de tes serviteurs, Abraham, Isaac et Israël, à qui tu as juré par toi-même : “Je multiplierai votre descendance comme les étoiles du ciel ; je donnerai, comme je l’ai dit, tout ce pays à vos descendants, et il sera pour toujours leur héritage.” »
###### 14
Le Seigneur renonça au mal qu’il avait voulu faire à son peuple.
###### 15
Moïse redescendit de la montagne. Il portait les deux tables du Témoignage ; ces tables étaient écrites sur les deux faces ;
###### 16
elles étaient l’œuvre de Dieu, et l’écriture, c’était l’écriture de Dieu, gravée sur ces tables.
###### 17
Josué entendit le bruit et le tumulte du peuple et dit à Moïse : « Bruit de bataille dans le camp. »
###### 18
Moïse répliqua : « Ces bruits, ce ne sont pas des chants de victoire ni de défaite ; ce que j’entends, ce sont des cantiques qui se répondent. »
###### 19
Comme il approchait du camp, il aperçut le veau et les danses. Il s’enflamma de colère, il jeta les tables qu’il portait, et les brisa au bas de la montagne.
###### 20
Il se saisit du veau qu’ils avaient fait, le brûla, le réduisit en poussière, qu’il répandit à la surface de l’eau. Et cette eau, il la fit boire aux fils d’Israël.
###### 21
Moïse dit à Aaron : « Qu’est-ce que ce peuple t’avait donc fait, pour que tu l’aies entraîné dans un si grand péché ? »
###### 22
Aaron répondit : « Que mon seigneur ne s’enflamme pas de colère ! Tu sais bien que ce peuple est porté au mal !
###### 23
C’est eux qui m’ont dit : “Fais-nous des dieux qui marchent devant nous. Car ce Moïse, l’homme qui nous a fait monter du pays d’Égypte, nous ne savons pas ce qui lui est arrivé.”
###### 24
Je leur ai dit : “Ceux d’entre vous qui ont de l’or, qu’ils s’en dépouillent.” Ils me l’ont donné, je l’ai jeté au feu, et il en est sorti ce veau. »
###### 25
Moïse vit que le peuple était débridé, car Aaron leur avait laissé la bride sur le cou, les exposant aux moqueries de leurs adversaires.
###### 26
Alors, Moïse vint à la porte du camp et dit : « À moi, les partisans du Seigneur ! » Et tous les fils de Lévi se groupèrent autour de lui.
###### 27
Il leur dit : « Ainsi parle le Seigneur, le Dieu d’Israël : Mettez l’épée au côté, parcourez le camp de porte en porte, et tuez qui son frère, qui son ami, qui son proche ! »
###### 28
Les fils de Lévi exécutèrent la parole de Moïse et, parmi le peuple, il tomba, ce jour-là, environ trois mille hommes.
###### 29
Puis Moïse dit : « Recevez aujourd’hui l’investiture pour le Seigneur ; vous l’avez mérité, l’un au prix de son fils, l’autre au prix de son frère, et que le Seigneur vous accorde aujourd’hui sa bénédiction. »
###### 30
Le lendemain, Moïse dit au peuple : « Vous avez commis un grand péché. Maintenant, je vais monter vers le Seigneur. Peut-être obtiendrai-je la rémission de votre péché. »
###### 31
Moïse retourna vers le Seigneur et lui dit : « Hélas ! Ce peuple a commis un grand péché : ils se sont fait des dieux en or.
###### 32
Ah, si tu voulais enlever leur péché ! Ou alors, efface-moi de ton livre, celui que tu as écrit. »
###### 33
Le Seigneur répondit à Moïse : « Celui que j’effacerai de mon livre, c’est celui qui a péché contre moi.
###### 34
Va donc, conduis le peuple vers le lieu que je t’ai indiqué, et mon ange ira devant toi. Le jour où j’interviendrai, je les punirai de leur péché. »
###### 35
Le Seigneur frappa le peuple, car ils avaient fait le veau, celui qu’avait fait Aaron.
