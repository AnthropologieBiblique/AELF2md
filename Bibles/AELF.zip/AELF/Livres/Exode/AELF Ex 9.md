---
aliases : 
- Exode 9
- Exode 9
- Ex 9
- Exodus 9
tags : 
- Bible/Ex/9
- français
cssclass : français
---

# Exode 9

###### 01
Le Seigneur dit à Moïse : « Va trouver Pharaon et dis-lui : Ainsi parle le Seigneur, le Dieu des Hébreux : Laisse partir mon peuple afin qu’il me serve.
###### 02
Si tu refuses de les laisser partir, si tu les retiens plus longtemps,
###### 03
voici que la main du Seigneur s’abattra sur tes troupeaux qui sont dans les champs, sur les chevaux, les ânes, les chameaux, sur le gros et le petit bétail : ils seront frappés d’une terrible peste !
###### 04
Le Seigneur fera la distinction entre les troupeaux d’Israël et les troupeaux des Égyptiens ; pas une seule bête appartenant aux fils d’Israël ne périra. »
###### 05
Le Seigneur fixa le moment en disant : « Demain, le Seigneur accomplira cela dans le pays. »
###### 06
Le lendemain, le Seigneur mit sa parole à exécution : tous les troupeaux des Égyptiens périrent ; mais, dans les troupeaux des fils d’Israël, pas une bête ne périt.
###### 07
Pharaon s’informa, et voici : pas une seule bête des troupeaux d’Israël n’avait péri. Mais Pharaon s’entêta et il ne laissa pas le peuple partir.
###### 08
Le Seigneur dit à Moïse et Aaron : « Prenez deux pleines poignées de suie de fourneau, et que Moïse la lance en l’air, sous les yeux de Pharaon.
###### 09
Elle deviendra une fine poussière qui retombera sur tout le pays d’Égypte et provoquera, chez les gens et les bêtes, des ulcères bourgeonnant en pustules. »
###### 10
Ils prirent de la suie de fourneau et vinrent se tenir devant Pharaon ; Moïse la lança en l’air : hommes et bêtes furent couverts d’ulcères bourgeonnant en pustules.
###### 11
Les magiciens ne purent se tenir devant Moïse à cause des ulcères : en effet, ils en étaient couverts comme tous les Égyptiens.
###### 12
Le Seigneur fit en sorte que Pharaon s’obstine ; et celui-ci n’écouta pas Moïse et Aaron, ainsi que l’avait annoncé le Seigneur.
###### 13
Le Seigneur dit à Moïse : « Lève-toi de bon matin, et tu te posteras devant Pharaon. Tu lui diras : Ainsi parle le Seigneur, le Dieu des Hébreux : “Laisse partir mon peuple, afin qu’il me serve.”
###### 14
Car cette fois-ci, je vais envoyer tous mes fléaux contre ta personne, contre tes serviteurs et contre ton peuple, afin que tu reconnaisses que, sur toute la terre, nul n’est comme moi.
###### 15
Si, dès l’abord, j’avais laissé aller ma main et t’avais frappé de la peste, toi et ton peuple, tu aurais été effacé de la terre.
###### 16
Cependant, je t’ai laissé subsister, et voici pourquoi : c’est afin que tu voies ma force et qu’on proclame mon nom par toute la terre.
###### 17
Tu le prends de haut avec mon peuple en t’opposant à son départ !
###### 18
Eh bien, moi, demain, à pareille heure, je ferai tomber une grêle d’une extrême violence, comme il n’y en a jamais eu en Égypte depuis le jour de sa fondation jusqu’à présent.
###### 19
Maintenant, envoie donc mettre à l’abri tes troupeaux, ainsi que tout ce qui t’appartient dans les champs. Tout homme et toute bête qui se trouveront dans les champs et n’auront pas regagné les maisons, tous, quand la grêle s’abattra, périront. »
###### 20
Parmi les serviteurs de Pharaon, celui qui craignit la parole du Seigneur mit à l’abri serviteurs et troupeaux.
###### 21
Mais celui qui ne prit pas à cœur la parole du Seigneur laissa dans les champs serviteurs et troupeaux.
###### 22
Le Seigneur dit à Moïse : « Étends la main vers le ciel, et qu’il y ait de la grêle partout en Égypte, sur les hommes et sur les bêtes, et sur l’herbe des champs dans ce pays d’Égypte. »
###### 23
Moïse étendit son bâton vers le ciel, et le Seigneur déchaîna tonnerre et grêle. La foudre tomba sur terre, et le Seigneur fit pleuvoir la grêle sur le pays d’Égypte.
###### 24
Il y eut grêle et foudre mêlée à la grêle. Ce fut d’une violence extrême : jamais il n’y eut rien de tel dans le pays d’Égypte depuis qu’il est une nation.
###### 25
Partout en Égypte, la grêle frappa tout ce qui était dans les champs, depuis l’homme jusqu’au bétail ; la grêle frappa toute l’herbe des champs et brisa tout arbre dans les champs.
###### 26
Au seul pays de Goshèn, là où résidaient les fils d’Israël, il n’y eut pas de grêle.
###### 27
Pharaon fit appeler Moïse et Aaron, et leur dit : « Cette fois-ci, je reconnais mon péché. C’est le Seigneur qui est le juste ; moi et mon peuple, nous sommes les coupables.
###### 28
Priez le Seigneur ! Assez de tonnerre et de grêle ! Je vais vous laisser partir : ne restez pas plus longtemps sur place. »
###### 29
Moïse lui dit : « Dès que je serai sorti de la ville, je tendrai les mains vers le Seigneur : le tonnerre cessera, la grêle ne tombera plus, afin que tu reconnaisses que le pays appartient au Seigneur.
###### 30
Et pourtant, toi et tes serviteurs, je le sais, vous ne craindrez pas encore le Seigneur Dieu. »
###### 31
Le lin et l’orge avaient été saccagés, car l’orge était en épis, et le lin en fleurs.
###### 32
Le blé ainsi que l’épeautre avaient été épargnés, car ils sont tardifs.
###### 33
Moïse quitta Pharaon et sortit de la ville ; il tendit les mains vers le Seigneur : le tonnerre et la grêle cessèrent, et la pluie s’arrêta de tomber sur la terre.
###### 34
Pharaon, voyant que la pluie, la grêle et le tonnerre avaient cessé, persévéra dans son péché ; lui et ses serviteurs s’entêtèrent.
###### 35
Pharaon s’obstina : il ne laissa pas partir les fils d’Israël, ainsi que le Seigneur l’avait annoncé par l’intermédiaire de Moïse.
