---
aliases : 
- Exode 22
- Exode 22
- Ex 22
- Exodus 22
tags : 
- Bible/Ex/22
- français
cssclass : français
---

# Exode 22

###### 01
Si un voleur, surpris de nuit en délit d’effraction, est frappé à mort, les siens ne pourront pas le venger.
###### 02
Mais si le soleil était levé, la vengeance du sang s’exercera. Un voleur devra rembourser : s’il n’a pas de quoi, il sera vendu pour ce qu’il a volé.
###### 03
Si la bête volée – bœuf, âne ou mouton – est retrouvée vivante entre ses mains, il fournira en compensation le double de sa valeur.
###### 04
Quand un homme fait brouter un champ ou une vigne, s’il envoie ses bêtes brouter le champ de quelqu’un d’autre, il fournira une compensation avec le meilleur de son champ, le meilleur de sa vigne.
###### 05
Si un feu éclate, se propage dans des buissons d’épines et consume les meules, les moissons ou les champs, le responsable devra rembourser ce qui a brûlé.
###### 06
Si un homme confie à son prochain de l’argent ou des objets pour qu’il les garde, et qu’on les vole dans la maison de celui-ci, le voleur, s’il est découvert, devra fournir en compensation le double de ce qu’il a pris.
###### 07
Mais si le voleur n’est pas découvert, le maître de la maison s’approchera de Dieu pour jurer qu’il n’a pas porté la main sur le bien de son prochain.
###### 08
Pour toute affaire frauduleuse portant sur un bœuf, un âne, un mouton, un vêtement ou tout objet perdu dont chacun dira : “C’est bien à moi !”, l’affaire des deux parties sera portée devant Dieu. Et celui que Dieu déclarera coupable devra fournir le double en compensation à son prochain.
###### 09
Si un homme confie à son prochain un âne, un bœuf, un mouton, ou toute sorte de bête pour qu’il la garde, et que la bête crève, se blesse ou soit enlevée sans témoin,
###### 10
les deux parties prêteront serment au nom du Seigneur : le gardien jurera qu’il n’a pas porté la main sur le bien du prochain. Alors le propriétaire de l’animal acceptera, et le gardien n’aura pas à fournir de compensation.
###### 11
Mais si l’animal a été volé à proximité du gardien, celui-ci fournira une compensation au propriétaire.
###### 12
Si l’animal a été déchiré, le gardien en produira une preuve et n’aura pas à fournir de compensation.
###### 13
Et si un homme emprunte un animal à son prochain, et que la bête se blesse ou crève en l’absence de son propriétaire, il devra fournir une compensation à ce dernier.
###### 14
Mais il ne devra rien, si le propriétaire est présent. S’il s’agit d’un animal loué, le montant de la location reste dû.
###### 15
Si un homme séduit une jeune fille vierge qui n’est pas fiancée, et qu’il couche avec elle, il devra verser le prix pour en faire sa femme.
###### 16
Si le père refuse de lui donner sa fille, l’homme versera néanmoins la somme d’argent fixée pour le prix d’une vierge.
###### 17
« Une sorcière, tu ne la laisseras pas vivre.
###### 18
Celui qui couche avec une bête sera mis à mort.
###### 19
Celui qui sacrifie aux dieux sera voué à l’anathème, sauf s’il sacrifie au Seigneur, à lui seul.
###### 20
Tu n’exploiteras pas l’immigré, tu ne l’opprimeras pas, car vous étiez vous-mêmes des immigrés au pays d’Égypte.
###### 21
Vous n’accablerez pas la veuve et l’orphelin.
###### 22
Si tu les accables et qu’ils crient vers moi, j’écouterai leur cri.
###### 23
Ma colère s’enflammera et je vous ferai périr par l’épée : vos femmes deviendront veuves, et vos fils, orphelins.
###### 24
Si tu prêtes de l’argent à quelqu’un de mon peuple, à un pauvre parmi tes frères, tu n’agiras pas envers lui comme un usurier : tu ne lui imposeras pas d’intérêts.
###### 25
Si tu prends en gage le manteau de ton prochain, tu le lui rendras avant le coucher du soleil.
###### 26
C’est tout ce qu’il a pour se couvrir ; c’est le manteau dont il s’enveloppe, la seule couverture qu’il ait pour dormir. S’il crie vers moi, je l’écouterai, car moi, je suis compatissant !
###### 27
Dieu, tu ne le maudiras pas, et tu ne prononceras pas de malédiction contre un chef de ton peuple.
###### 28
Tu ne tarderas pas à offrir le fruit de tes champs et de ton pressoir.
Le premier-né de tes fils, tu me le donneras.
###### 29
Tu feras de même pour ton bœuf et ton petit bétail : le premier-né restera sept jours avec sa mère ; le huitième jour, tu me le donneras.
###### 30
Vous serez pour moi des hommes de sainteté. Vous ne mangerez pas la viande d’une bête déchirée par un fauve dans la campagne ; vous la jetterez aux chiens.
