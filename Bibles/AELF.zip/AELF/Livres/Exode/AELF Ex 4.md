---
aliases : 
- Exode 4
- Exode 4
- Ex 4
- Exodus 4
tags : 
- Bible/Ex/4
- français
cssclass : français
---

# Exode 4

###### 01
Moïse reprit la parole et dit : « Mais voilà ! Ils ne me croiront pas ; ils n’écouteront pas ma voix. Ils diront : Le Seigneur ne t’est pas apparu ! »
###### 02
Le Seigneur dit : « Que tiens-tu en main ? » Moïse répondit : « Un bâton. »
###### 03
Le Seigneur dit : « Jette-le à terre. » Moïse le jeta à terre : le bâton devint un serpent, et Moïse s’enfuit devant lui.
###### 04
Le Seigneur dit à Moïse : « Étends la main et prends-le par la queue. » Il étendit la main et le saisit : dans sa main, le serpent redevint un bâton.
###### 05
Dieu reprit : « Ainsi croiront-ils que le Seigneur t’est apparu, le Dieu de leurs pères, Dieu d’Abraham, Dieu d’Isaac, Dieu de Jacob. »
###### 06
Le Seigneur dit encore à Moïse : « Mets donc la main sur ta poitrine. » Il mit la main sur sa poitrine, puis la retira : et sa main était lépreuse, blanche comme neige.
###### 07
Le Seigneur dit : « Remets la main sur ta poitrine. » Il remit la main sur sa poitrine, puis la retira : elle était redevenue comme le reste de son corps.
###### 08
« Ainsi donc, s’ils ne te croient pas, s’ils restent sourds à la voix du premier signe, ils croiront à cause du second signe.
###### 09
Et s’ils ne croient pas encore à ces deux signes et restent sourds à ta voix, alors tu prendras de l’eau du Nil et tu la répandras sur la terre sèche. Et l’eau que tu auras puisée dans le Nil deviendra du sang sur la terre sèche. »
###### 10
Moïse dit encore au Seigneur : « Pardon, mon Seigneur, mais moi, je n’ai jamais été doué pour la parole, ni d’hier ni d’avant-hier, ni même depuis que tu parles à ton serviteur ; j’ai la bouche lourde et la langue pesante, moi ! »
###### 11
Le Seigneur lui dit : « Qui donc a donné une bouche à l’homme ? Qui rend muet ou sourd, voyant ou aveugle ? N’est-ce pas moi, le Seigneur ?
###### 12
Et maintenant, va. Je suis avec ta bouche et je te ferai savoir ce que tu devras dire. »
###### 13
Moïse répliqua : « Je t’en prie, mon Seigneur, envoie n’importe quel autre émissaire. »
###### 14
Alors la colère du Seigneur s’enflamma contre Moïse, et il dit : « Et ton frère Aaron, le lévite ? Je sais qu’il a la parole facile, lui ! Le voici justement qui sort à ta rencontre, et quand il te verra, son cœur se réjouira.
###### 15
Tu lui parleras et tu mettras mes paroles dans sa bouche. Et moi, je suis avec ta bouche et avec sa bouche, et je vous ferai savoir ce que vous aurez à faire.
###### 16
C’est lui qui parlera pour toi au peuple ; il sera ta bouche et tu seras son dieu.
###### 17
Quant à ce bâton, prends-le en main ! C’est par lui que tu accompliras les signes. »
###### 18
Moïse s’en alla et retourna chez son beau-père Jéthro. Il lui dit : « Je dois m’en aller et retourner chez mes frères, en Égypte, pour voir s’ils vivent encore. » Jéthro lui dit : « Va en paix. »
###### 19
Au pays de Madiane, le Seigneur dit à Moïse : « Va, retourne en Égypte, car ils sont morts, tous ceux qui en voulaient à ta vie. »
###### 20
Moïse prit sa femme et ses fils, les installa sur l’âne et retourna au pays d’Égypte. Il avait pris en main le bâton de Dieu.
###### 21
Le Seigneur dit à Moïse : « Sur le chemin du retour vers l’Égypte, songe aux prodiges que j’ai mis en ta main. Tu les accompliras devant Pharaon. Mais moi, je ferai en sorte qu’il s’obstine, et il ne laissera pas le peuple s’en aller.
###### 22
Tu diras à Pharaon : “Ainsi parle le Seigneur :
###### 23
Mon fils premier-né, c’est Israël. Je te dis : Laisse partir mon fils pour qu’il me serve ; et tu refuses de le laisser partir ! Eh bien, moi, je vais faire périr ton fils premier-né !” »
###### 24
Or, en cours de route, au campement de nuit, le Seigneur rencontra Moïse et chercha à le faire mourir.
###### 25
Cippora, sa femme, prit un silex, coupa le prépuce de son fils, en toucha le sexe de Moïse et dit : « Tu es pour moi un époux de sang. »
###### 26
Alors Dieu s’éloigna de Moïse. Cippora avait parlé d’« époux de sang » à cause des circoncisions.
###### 27
Le Seigneur dit à Aaron : « Va sur la route du désert au-devant de Moïse. » Il y alla, le rencontra à la montagne de Dieu et l’embrassa.
###### 28
Moïse transmit à son frère toutes les paroles que le Seigneur l’avait envoyé dire et tous les signes qu’il avait ordonné de faire.
###### 29
Moïse et Aaron se mirent en route et réunirent tous les anciens des fils d’Israël.
###### 30
Aaron redit toutes les paroles que le Seigneur avait adressées à Moïse et il accomplit les signes sous les yeux du peuple.
###### 31
Et le peuple crut : il comprit que le Seigneur avait visité les fils d’Israël et qu’il avait vu leur misère. Alors ils s’inclinèrent et se prosternèrent.
