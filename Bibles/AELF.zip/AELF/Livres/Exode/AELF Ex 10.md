---
aliases : 
- Exode 10
- Exode 10
- Ex 10
- Exodus 10
tags : 
- Bible/Ex/10
- français
cssclass : français
---

# Exode 10

###### 01
Le Seigneur dit à Moïse : « Rends-toi chez Pharaon, car c’est moi qui l’ai rendu entêté, lui et ses serviteurs, afin d’accomplir mes signes au milieu d’eux,
###### 02
et afin que tu puisses raconter à ton fils et au fils de ton fils comment je me suis joué des Égyptiens et quels signes j’ai accomplis parmi eux. Alors, vous saurez que je suis le Seigneur. »
###### 03
Moïse et Aaron allèrent trouver Pharaon et lui dirent : « Ainsi parle le Seigneur, le Dieu des Hébreux : Combien de temps refuseras-tu de t’humilier devant moi ? Laisse partir mon peuple afin qu’il me serve.
###### 04
Si toi, tu refuses toujours de laisser partir mon peuple, moi, dès demain, je ferai venir des sauterelles sur ton territoire.
###### 05
Elles recouvriront le pays, et l’on ne pourra plus en voir le sol. Elles dévoreront ce qui reste, ce qui a échappé à la grêle, ce que la grêle vous a laissé ; elles dévoreront tout arbre qui pousse dans vos champs.
###### 06
Elles envahiront tes maisons, les maisons de tous tes serviteurs, les maisons de tous les Égyptiens : tes pères, ni les pères de tes pères n’ont jamais vu cela, depuis le jour où ils sont venus au monde, jusqu’à ce jour. » Moïse tourna le dos et sortit de chez Pharaon.
###### 07
Les serviteurs de Pharaon lui dirent : « Combien de temps encore cet individu sera-t-il un piège pour nous ? Laisse partir les hommes, afin qu’ils servent le Seigneur leur Dieu. N’as-tu pas encore compris que l’Égypte va à sa ruine ? »
###### 08
On fit revenir Moïse et Aaron auprès de Pharaon, qui leur dit : « Allez, servez le Seigneur votre Dieu. Mais qui donc va partir ? »
###### 09
Moïse répondit : « Nous partirons avec nos jeunes gens et nos vieillards, nous partirons avec nos fils et nos filles, notre petit et notre gros bétail, car c’est pour nous une fête en l’honneur du Seigneur. »
###### 10
Pharaon dit : « Que le Seigneur soit avec vous si je vous laisse partir, vous et vos enfants ! Voyez comme vos projets sont pervers !
###### 11
Non et non ! Vous, les hommes, allez donc et servez le Seigneur, puisque c’est cela que vous cherchez. » Et on les chassa de chez Pharaon.
###### 12
Le Seigneur dit à Moïse : « Étends la main sur le pays d’Égypte pour que viennent les sauterelles ; qu’elles montent sur le pays d’Égypte et qu’elles dévorent toute l’herbe du pays, tout ce qu’a laissé la grêle. »
###### 13
Moïse étendit son bâton sur le pays d’Égypte, et le Seigneur fit lever sur le pays un vent d’est qui souffla tout ce jour-là et toute la nuit. Au matin, le vent d’est avait amené les sauterelles.
###### 14
Des nuées de sauterelles montèrent sur tout le pays d’Égypte et se posèrent sur l’ensemble du territoire. Jamais auparavant et jamais depuis lors, il n’y eut une telle masse de sauterelles.
###### 15
Elles recouvrirent tout le pays, qui en fut obscurci. Elles dévorèrent toute l’herbe du pays et tous les fruits des arbres épargnés par la grêle ; il ne resta rien de vert ni sur les arbres ni dans les prairies, par tout le pays d’Égypte.
###### 16
Pharaon se hâta d’appeler Moïse et Aaron, et leur dit : « J’ai péché contre le Seigneur votre Dieu, et contre vous.
###### 17
Et maintenant, je t’en prie : une fois encore, enlève ma faute. Priez le Seigneur votre Dieu, pour qu’il écarte de moi cette mort. »
###### 18
Moïse sortit de chez Pharaon et pria le Seigneur.
###### 19
Le Seigneur changea le vent d’est en un très fort vent d’ouest qui emporta les sauterelles et les précipita dans la mer des Roseaux. Il ne resta plus une seule sauterelle sur tout le territoire d’Égypte.
###### 20
Mais le Seigneur fit en sorte que Pharaon s’obstine ; et celui-ci ne laissa pas partir les fils d’Israël.
###### 21
Le Seigneur dit à Moïse : « Étends la main vers le ciel. Qu’il y ait des ténèbres sur le pays d’Égypte, des ténèbres où l’on tâtonne. »
###### 22
Moïse étendit la main vers le ciel et, pendant trois jours, il y eut d’épaisses ténèbres sur tout le pays d’Égypte.
###### 23
Les gens ne se voyaient plus l’un l’autre, et chacun resta sur place pendant trois jours. Mais il y avait de la lumière pour les fils d’Israël, là où ils habitaient.
###### 24
Pharaon appela Moïse et lui dit : « Allez-vous-en, servez le Seigneur ! Votre petit et votre gros bétail devra rester ici, mais vos enfants pourront vous accompagner. »
###### 25
Moïse dit : « C’est donc toi qui mettras dans nos mains de quoi offrir sacrifices et holocaustes au Seigneur notre Dieu ?
###### 26
Nos troupeaux partiront également avec nous. Pas une bête ne restera ; c’est parmi nos troupeaux que nous prendrons de quoi servir le Seigneur notre Dieu. Nous ne pouvons pas savoir, avant d’arriver là-bas, ce que nous devrons offrir au Seigneur pour le servir. »
###### 27
Mais le Seigneur fit en sorte que Pharaon s’obstine ; et celui-ci ne voulut pas les laisser partir.
###### 28
Pharaon dit alors à Moïse : « Hors d’ici ! Prends garde à toi ! Ne t’avise plus de paraître devant ma face ! Le jour où tu te présenteras devant ma face, tu mourras. »
###### 29
Et Moïse de répondre : « Tu l’as dit ! Je ne te reverrai plus ! »
