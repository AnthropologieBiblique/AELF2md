---
aliases : 
- Exode 34
- Exode 34
- Ex 34
- Exodus 34
tags : 
- Bible/Ex/34
- français
cssclass : français
---

# Exode 34

###### 01
Le Seigneur dit à Moïse : « Taille deux tables de pierre, semblables aux premières : j’écrirai sur ces tables les paroles qui étaient sur les premières, celles que tu as brisées.
###### 02
Sois prêt pour demain et monte dès le matin sur la montagne du Sinaï. Tu te placeras là pour moi, au sommet de la montagne.
###### 03
Que personne ne monte avec toi ; que personne même ne paraisse sur toute la montagne. Que même le petit et le gros bétail ne soient pas conduits au pâturage devant cette montagne. »
###### 04
Moïse tailla deux tables de pierre semblables aux premières. Il se leva de bon matin, et il gravit la montagne du Sinaï comme le Seigneur le lui avait ordonné. Il emportait les deux tables de pierre.
###### 05
Le Seigneur descendit dans la nuée et vint se placer là, auprès de Moïse. Il proclama son nom qui est : LE SEIGNEUR.
###### 06
Il passa devant Moïse et proclama : « LE SEIGNEUR, LE SEIGNEUR, Dieu tendre et miséricordieux, lent à la colère, plein d’amour et de vérité,
###### 07
qui garde sa fidélité jusqu’à la millième génération, supporte faute, transgression et péché, mais ne laisse rien passer, car il punit la faute des pères sur les fils et les petits-fils, jusqu’à la troisième et la quatrième génération. »
###### 08
Aussitôt Moïse s’inclina jusqu’à terre et se prosterna.
###### 09
Il dit : « S’il est vrai, mon Seigneur, que j’ai trouvé grâce à tes yeux, daigne marcher au milieu de nous. Oui, c’est un peuple à la nuque raide ; mais tu pardonneras nos fautes et nos péchés, et tu feras de nous ton héritage. »
###### 10
Le Seigneur dit : « Voici que je vais conclure une alliance. Devant tout ton peuple, je vais faire des merveilles qui n’ont été créées nulle part, dans aucune nation. Tout le peuple qui t’entoure verra l’œuvre du Seigneur, car je vais réaliser avec toi quelque chose d’extraordinaire.
###### 11
Observe donc bien ce que je t’ordonne aujourd’hui. Je vais chasser devant toi l’Amorite, le Cananéen, le Hittite, le Perizzite, le Hivvite et le Jébuséen.
###### 12
Garde-toi de conclure une alliance avec l’habitant du pays où tu vas entrer, de peur qu’il ne devienne un piège au milieu de toi.
###### 13
Bien plus, leurs autels, vous les démolirez ; leurs stèles, vous les briserez ; leurs poteaux sacrés, vous les couperez.
###### 14
Car tu ne te prosterneras pas devant un autre dieu. Le Seigneur, en effet, a pour nom : “Jaloux” ; il est un Dieu jaloux.
###### 15
Ne fais pas alliance avec les habitants du pays, car lorsqu’ils se prostituent avec leurs dieux et leur offrent des sacrifices, ils t’inviteraient et tu mangerais de leurs sacrifices,
###### 16
tu prendrais leurs filles comme épouses pour tes fils, leurs filles se prostitueraient avec leurs dieux et amèneraient tes fils à se prostituer avec leurs dieux.
###### 17
Tu ne te feras pas des dieux en métal fondu.
###### 18
Tu observeras la fête des Pains sans levain. Comme je te l’ai ordonné, tu mangeras des pains sans levain pendant sept jours, au temps fixé du mois des Épis, car c’est alors que tu es sorti d’Égypte.
###### 19
Tout premier-né m’appartient : tout premier-né mâle de ton troupeau, gros ou petit bétail.
###### 20
Le premier-né des ânes, tu le rachèteras par un mouton, et si tu ne le rachètes pas, tu lui rompras la nuque. Tout premier-né de tes fils, tu le rachèteras. On ne se présentera pas devant moi les mains vides.
###### 21
Pendant six jours, tu travailleras, mais, le septième jour, tu chômeras ; même au temps des labours et de la moisson, tu chômeras.
###### 22
Tu célébreras la fête des Semaines, des premiers fruits, de la moisson des blés, et aussi la fête de la Récolte, en fin de l’année.
###### 23
Trois fois par an, tous les hommes paraîtront devant la face du Maître, le Seigneur, le Dieu d’Israël.
###### 24
En effet, lorsque j’aurai dépossédé les nations devant toi et que j’aurai élargi ton territoire, nul ne convoitera la terre qui t’appartient, quand, trois fois par an, tu monteras pour voir la face du Seigneur ton Dieu.
###### 25
Tu n’immoleras pas le sacrifice sanglant en l’accompagnant de pain levé, et tu ne laisseras pas jusqu’au lendemain matin la victime sacrifiée pour la fête de la Pâque.
###### 26
Tu apporteras les tout premiers fruits de ton sol à la Maison du Seigneur ton Dieu. Tu ne feras pas cuire un chevreau dans le lait de sa mère. »
###### 27
Le Seigneur dit encore à Moïse :
« Mets par écrit ces paroles car, sur la base de celles-ci, je conclus une alliance avec toi et avec Israël. »
###### 28
Moïse demeura sur le Sinaï avec le Seigneur quarante jours et quarante nuits ; il ne mangea pas de pain et ne but pas d’eau. Sur les tables de pierre, il écrivit les paroles de l’Alliance, les Dix Paroles.
###### 29
Lorsque Moïse descendit de la montagne du Sinaï, ayant en mains les deux tables du Témoignage, il ne savait pas que son visage rayonnait de lumière depuis qu’il avait parlé avec le Seigneur.
###### 30
Aaron et tous les fils d’Israël virent arriver Moïse : son visage rayonnait.
###### 31
Comme ils n’osaient pas s’approcher, Moïse les appela. Aaron et tous les chefs de la communauté vinrent alors vers lui, et il leur adressa la parole.
###### 32
Ensuite, tous les fils d’Israël s’approchèrent, et il leur transmit tous les ordres que le Seigneur lui avait donnés sur la montagne du Sinaï.
###### 33
Quand il eut fini de leur parler, il mit un voile sur son visage.
###### 34
Et, lorsqu’il se présentait devant le Seigneur pour parler avec lui, il enlevait son voile jusqu’à ce qu’il soit sorti. Alors, il transmettait aux fils d’Israël les ordres qu’il avait reçus,
###### 35
et les fils d’Israël voyaient rayonner son visage. Puis il remettait le voile sur son visage jusqu’à ce qu’il rentre pour parler avec le Seigneur.
