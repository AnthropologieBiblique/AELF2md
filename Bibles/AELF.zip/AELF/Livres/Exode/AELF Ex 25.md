---
aliases : 
- Exode 25
- Exode 25
- Ex 25
- Exodus 25
tags : 
- Bible/Ex/25
- français
cssclass : français
---

# Exode 25

###### 01
Le Seigneur parla à Moïse. Il dit :
###### 02
« Dis aux fils d’Israël de prélever pour moi une contribution. Vous la recevrez de tout homme que son cœur y incitera.
###### 03
Voici la contribution que vous recevrez d’eux : de l’or, de l’argent et du bronze,
###### 04
de la pourpre violette et de la pourpre rouge, du cramoisi éclatant, du lin et du poil de chèvre,
###### 05
des peaux de bélier teintes en rouge, du cuir fin et du bois d’acacia,
###### 06
de l’huile pour le luminaire, du baume pour l’huile de l’onction et de l’encens aromatique,
###### 07
des pierres de cornaline et des pierres pour orner l’éphod et le pectoral.
###### 08
Ils me feront un sanctuaire et je demeurerai au milieu d’eux.
###### 09
Je vais te montrer le modèle de la Demeure et le modèle de tous ses objets : vous les reproduirez exactement.
###### 10
« On fera une arche en bois d’acacia de deux coudées et demie de long sur une coudée et demie de large et une coudée et demie de haut.
###### 11
Tu la plaqueras d’or pur à l’intérieur et à l’extérieur, et tu l’entoureras d’une moulure en or.
###### 12
Tu couleras quatre anneaux d’or que tu attacheras aux quatre pieds de l’arche : deux anneaux sur un côté, deux anneaux sur l’autre.
###### 13
Tu feras des barres en bois d’acacia, tu les plaqueras d’or
###### 14
et tu les introduiras dans les anneaux des côtés de l’arche pour pouvoir la porter.
###### 15
Les barres resteront dans les anneaux de l’arche ; elles n’en seront pas retirées.
###### 16
Tu placeras dans l’arche le Témoignage que je te donnerai.
###### 17
Puis tu feras en or pur un couvercle, le propitiatoire, long de deux coudées et demie et large d’une coudée et demie.
###### 18
Ensuite tu forgeras deux kéroubim en or à placer aux deux extrémités du propitiatoire.
###### 19
Fais un kéroub à une extrémité, et l’autre kéroub à l’autre extrémité ; vous ferez donc les kéroubim aux deux extrémités du propitiatoire.
###### 20
Les kéroubim auront les ailes déployées vers le haut et protégeront le propitiatoire de leurs ailes. Ils se feront face, le regard tourné vers le propitiatoire.
###### 21
Tu placeras le propitiatoire sur le dessus de l’arche et, dans l’arche, tu placeras le Témoignage que je te donnerai.
###### 22
C’est là que je te laisserai me rencontrer ; je parlerai avec toi d’au-dessus du propitiatoire entre les deux kéroubim situés sur l’arche du Témoignage ; là, je te donnerai mes ordres pour les fils d’Israël.
###### 23
« Puis tu feras une table en bois d’acacia, longue de deux coudées, large d’une coudée et haute d’une coudée et demie.
###### 24
Tu la plaqueras d’or pur et tu l’entoureras d’une moulure en or.
###### 25
Tu feras des entretoises de la largeur d’une main et tu les entoureras d’une moulure en or.
###### 26
Tu feras quatre anneaux d’or que tu mettras aux quatre angles formés par les quatre pieds.
###### 27
Ces anneaux seront placés près des entretoises, pour loger les barres servant à porter la table.
###### 28
Tu feras des barres en bois d’acacia et tu les plaqueras d’or ; elles serviront à porter la table.
###### 29
Tu feras des plats, des gobelets, des aiguières et des timbales pour les libations. Tu les feras en or pur.
###### 30
Et sur la table, tu placeras face à moi le pain qui m’est destiné, perpétuellement.
###### 31
« Puis tu feras un chandelier en or pur. Le chandelier sera forgé : base, tige, coupes, boutons et fleurs feront corps avec lui.
###### 32
Six branches s’en détacheront sur les côtés : trois d’un côté et trois de l’autre.
###### 33
Sur une branche, trois coupes en forme d’amande avec bouton et fleur et, sur une autre branche, trois coupes en forme d’amande avec bouton et fleur ; de même pour les six branches sortant du chandelier.
###### 34
Le chandelier lui-même portera quatre coupes en forme d’amande avec boutons et fleurs :
###### 35
un bouton sous les deux premières branches issues du chandelier, un bouton sous les deux suivantes et un bouton sous les deux dernières ; ainsi donc pour les six branches qui sortent du chandelier.
###### 36
Boutons et branches feront corps avec le chandelier qui sera tout entier forgé d’une seule pièce, en or pur.
###### 37
Ensuite, tu lui feras sept lampes. On allumera les lampes de manière à éclairer l’espace qui est devant lui.
###### 38
Ses pincettes et ses porte-lampes seront en or pur.
###### 39
Il te faudra un lingot d’or pur pour le chandelier et tous ses accessoires.
###### 40
Regarde et exécute selon le modèle qui t’a été montré sur la montagne.
