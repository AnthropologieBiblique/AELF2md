---
aliases : 
- Exode 26
- Exode 26
- Ex 26
- Exodus 26
tags : 
- Bible/Ex/26
- français
cssclass : français
---

# Exode 26

###### 01
« Pour construire la Demeure, tu feras dix tentures de lin retors, pourpre violette, pourpre rouge et cramoisi éclatant ; tu y broderas des kéroubim : ce sera une œuvre d’artiste.
###### 02
Chaque tenture mesurera vingt-huit coudées de long et quatre de large. Toutes les tentures auront les mêmes dimensions.
###### 03
Cinq tentures seront assemblées l’une à l’autre, et les cinq autres également.
###### 04
Tu feras des lacets de pourpre violette au bord de la première tenture, à l’extrémité de l’assemblage, et tu feras de même au bord de la dernière tenture du deuxième assemblage.
###### 05
Tu mettras cinquante lacets à la première tenture et cinquante lacets à l’extrémité de la tenture du deuxième assemblage, les lacets s’attachant l’un à l’autre.
###### 06
Tu feras cinquante agrafes en or, tu assembleras les tentures l’une à l’autre par les agrafes. Ainsi, la Demeure sera d’un seul tenant.
###### 07
Ensuite, pour former une tente au-dessus de la Demeure, tu feras onze tentures en poil de chèvre.
###### 08
Chaque tenture mesurera trente coudées de long et quatre coudées de large. Les onze tentures auront les mêmes dimensions.
###### 09
Tu assembleras cinq tentures à part, puis six tentures à part, et tu replieras la sixième tenture sur le devant de la tente.
###### 10
Tu feras cinquante lacets au bord d’une première tenture, la dernière de l’assemblage, et cinquante lacets au bord de la même tenture du deuxième assemblage.
###### 11
Tu feras cinquante agrafes de bronze, tu introduiras les agrafes dans les lacets pour assembler la tente d’un seul tenant.
###### 12
De ce qui retombe en surplus des tentures, une moitié de la tenture en surplus retombera sur l’arrière de la Demeure.
###### 13
Et, dans le sens de la longueur des tentures, une coudée en surplus retombera, de part et d’autre, sur les côtés de la Demeure pour la couvrir.
###### 14
Enfin tu feras pour la tente une couverture en peaux de béliers teintes en rouge, et une autre en cuir fin à mettre par-dessus.
###### 15
« Puis tu feras pour la Demeure des cadres en bois d’acacia, dressés debout.
###### 16
Ils mesureront dix coudées de long et une coudée et demie de large.
###### 17
Un cadre sera assemblé par deux tenons jumelés : ainsi feras-tu pour tous les cadres de la Demeure.
###### 18
Tu disposeras les cadres pour la Demeure comme suit : vingt en direction du Néguev, au sud ;
###### 19
et tu feras quarante socles en argent sous les vingt cadres : deux socles sous un cadre pour ses deux tenons, puis deux socles sous un autre cadre pour ses deux tenons.
###### 20
Pour le deuxième côté de la Demeure, tu disposeras, en direction du nord, vingt cadres
###### 21
avec leurs quarante socles en argent : deux socles sous un cadre et deux socles sous un autre cadre.
###### 22
Et pour le fond de la Demeure, vers l’ouest, tu feras six cadres ;
###### 23
tu feras aussi deux cadres comme contreforts de la Demeure, au fond ;
###### 24
ils seront jumelés à leur base et le seront également au sommet, à la hauteur du premier anneau : ainsi en sera-t-il pour eux deux, ils seront comme deux contreforts.
###### 25
Il y aura donc huit cadres, avec leurs socles en argent, soit seize socles : deux socles sous un cadre et deux socles sous un autre cadre.
###### 26
Puis tu feras des traverses en bois d’acacia : cinq pour les cadres du premier côté de la Demeure,
###### 27
cinq pour les cadres du deuxième côté de la Demeure, cinq pour les cadres qui forment le fond de la Demeure vers l’ouest ;
###### 28
tu feras aussi la traverse médiane, à mi-hauteur des cadres, traversant la Demeure d’un bout à l’autre.
###### 29
Les cadres, tu les plaqueras d’or, tu feras en or leurs anneaux pour loger les traverses, et les traverses, tu les plaqueras d’or.
###### 30
Tu dresseras la Demeure d’après la règle qui t’a été montrée sur la montagne.
###### 31
« Puis tu feras un rideau de pourpre violette, pourpre rouge, cramoisi éclatant et lin retors ; ce sera une œuvre d’artiste : on y brodera des kéroubim.
###### 32
Tu le fixeras à quatre colonnes en acacia et tu les plaqueras d’or, munies de crochets en or et posées sur quatre socles en argent.
###### 33
Tu fixeras le rideau sous les agrafes et là, derrière le rideau, tu introduiras l’arche du Témoignage. Le rideau marquera pour vous la séparation entre le Sanctuaire et le Saint des saints.
###### 34
Tu placeras le propitiatoire sur l’arche du Témoignage dans le Saint des saints.
###### 35
À l’extérieur du rideau, tu poseras la table et, en face d’elle, le chandelier : la table côté nord de la Demeure, et le chandelier côté sud.
###### 36
« Enfin, pour l’entrée de la tente, tu feras un voile en pourpre violette, pourpre rouge, cramoisi éclatant et lin retors : ce sera une œuvre d’artisan brocheur.
###### 37
Tu feras, pour le voile, cinq colonnes en acacia et tu les plaqueras d’or, tu les muniras de crochets en or, et tu couleras pour elles cinq socles en bronze.
