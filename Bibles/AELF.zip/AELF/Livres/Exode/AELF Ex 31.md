---
aliases : 
- Exode 31
- Exode 31
- Ex 31
- Exodus 31
tags : 
- Bible/Ex/31
- français
cssclass : français
---

# Exode 31

###### 01
Le Seigneur parla à Moïse. Il dit :
###### 02
« Vois : j’ai appelé par son nom Beçalel, fils d’Ouri, fils de Hour, de la tribu de Juda.
###### 03
Je l’ai rempli de l’esprit de Dieu pour qu’il possède la sagesse, l’intelligence, la connaissance et le savoir-faire pour toutes sortes de travaux :
###### 04
la création artistique, le travail de l’or, de l’argent, du bronze,
###### 05
la taille des pierres précieuses, la sculpture sur bois et toutes sortes de travaux.
###### 06
Et c’est moi qui lui donne comme adjoint Oholiab, fils d’Ahisamak, de la tribu de Dane. C’est moi qui donne la sagesse à tout artisan habile, pour qu’il fasse tout ce que je t’ai ordonné, c’est-à-dire :
###### 07
la tente de la Rencontre, l’arche du Témoignage, le propitiatoire qui la couvre, tous les accessoires de la Tente,
###### 08
la table et ses accessoires, le chandelier d’or pur et tous ses accessoires, l’autel de l’encens,
###### 09
l’autel de l’holocauste et tous ses accessoires, la cuve et son support,
###### 10
les vêtements liturgiques, les vêtements sacrés pour le prêtre Aaron, les vêtements que porteront ses fils pour exercer le sacerdoce,
###### 11
l’huile de l’onction, l’encens aromatique pour le sanctuaire. Ils feront exactement comme je te l’ai ordonné. »
###### 12
Le Seigneur dit à Moïse :
###### 13
« Toi, tu parleras ainsi aux fils d’Israël : Surtout, vous observerez mes sabbats, car c’est un signe entre moi et vous, de génération en génération, pour qu’on reconnaisse que je suis le Seigneur, celui qui vous sanctifie.
###### 14
Vous observerez le sabbat, car il est saint pour vous. Qui le profanera sera mis à mort : Oui, quiconque fera, en ce jour, quelque ouvrage, cette personne-là sera retranchée du milieu de sa parenté.
###### 15
Pendant six jours, on travaillera, mais, le septième jour, c’est un sabbat, un sabbat solennel consacré au Seigneur. Quiconque travaillera le jour du sabbat sera mis à mort.
###### 16
Les fils d’Israël observeront le sabbat en le célébrant de génération en génération : c’est une alliance éternelle.
###### 17
À jamais, il est un signe entre moi et les fils d’Israël, car le Seigneur a fait le ciel et la terre en six jours mais, le septième jour, il a chômé et repris souffle. »
###### 18
Quand le Seigneur eut fini de parler avec Moïse sur le mont Sinaï, il lui donna les deux tables du Témoignage, les tables de pierre écrites du doigt de Dieu.
