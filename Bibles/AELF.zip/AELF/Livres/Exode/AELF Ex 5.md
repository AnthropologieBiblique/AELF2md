---
aliases : 
- Exode 5
- Exode 5
- Ex 5
- Exodus 5
tags : 
- Bible/Ex/5
- français
cssclass : français
---

# Exode 5

###### 01
Ensuite, Moïse et Aaron s’en vinrent déclarer à Pharaon : « Ainsi parle le Seigneur, Dieu d’Israël : Laisse partir mon peuple pour qu’il célèbre en mon honneur une fête au désert. »
###### 02
Pharaon dit : « Qui est le Seigneur pour que j’écoute sa voix et laisse partir Israël ? Je ne connais pas le Seigneur et je ne veux pas laisser partir Israël. »
###### 03
Ils dirent : « Le Dieu des Hébreux s’est présenté à nous : il nous faut aller à trois jours de marche dans le désert pour offrir un sacrifice au Seigneur notre Dieu. Sinon, il nous frappera de la peste ou de l’épée. »
###### 04
Le roi d’Égypte leur dit : « Moïse et Aaron, pourquoi voulez-vous détourner le peuple de ses travaux ? Retournez à vos corvées ! »
###### 05
Et Pharaon ajouta : « Maintenant que les gens du peuple sont nombreux, vous voudriez qu’ils se reposent de leurs corvées ! »
###### 06
Ce jour-là, Pharaon ordonna aux surveillants du peuple et aux contremaîtres :
###### 07
« Vous ne fournirez plus au peuple, comme vous le faisiez auparavant, la paille pour fabriquer les briques. Ils iront eux-mêmes ramasser la paille.
###### 08
Quant au nombre de briques imposé jusqu’à présent, continuez à l’exiger. Ne réduisez en rien la cadence. Ce ne sont que des paresseux ! C’est pourquoi ils crient : “Allons offrir un sacrifice à notre Dieu !”
###### 09
Que la servitude pèse sur ces gens et qu’ils travaillent, sans rêvasser à des paroles mensongères ! »
###### 10
Les surveillants du peuple et les contremaîtres sortirent et déclarèrent au peuple : « Ainsi parle Pharaon : Je ne vous donne plus de paille.
###### 11
Allez vous-mêmes en prendre où vous en trouverez ! Mais votre production ne sera réduite en rien. »
###### 12
Alors le peuple se dispersa dans tout le pays d’Égypte, pour ramasser du chaume et en faire de la paille à torchis.
###### 13
Les surveillants les harcelaient : « Achevez votre travail ! Chaque jour la quantité exigée, comme lorsqu’il y avait de la paille ! »
###### 14
On frappa les contremaîtres des fils d’Israël – ceux que leur avaient imposés les surveillants de Pharaon – en disant : « Pourquoi n’avez-vous pas exécuté la commande de briques comme auparavant ? Faites aujourd’hui comme hier ! »
###### 15
Les contremaîtres des fils d’Israël vinrent alors crier vers Pharaon : « Pourquoi traiter ainsi tes serviteurs ?
###### 16
De la paille, on n’en donne plus à tes serviteurs, et on nous dit : Faites des briques ! Et voici qu’on frappe tes serviteurs. Tes gens ont tort ! »
###### 17
Pharaon répondit : « Vous êtes des paresseux, oui, des paresseux ! C’est pourquoi vous dites : Allons offrir un sacrifice au Seigneur.
###### 18
Et maintenant, au travail ! On ne vous fournira pas la paille, mais vous fournirez le même nombre de briques. »
###### 19
Les contremaîtres des fils d’Israël se virent en mauvaise posture lorsqu’on leur dit : « Vous ne réduirez pas le nombre de briques : chaque jour la quantité exigée ! »
###### 20
En sortant de chez Pharaon, ils tombèrent sur Moïse et Aaron qui les attendaient.
###### 21
Ils leur dirent : « Que le Seigneur vous tienne à l’œil et qu’il juge : à cause de vous, Pharaon et ses serviteurs nous détestent ; vous leur avez mis en main l’épée pour nous tuer. »
###### 22
Moïse retourna trouver le Seigneur et lui dit : « Mon Seigneur, pourquoi as-tu maltraité ce peuple ? Pourquoi donc m’as-tu envoyé ?
###### 23
Depuis que je suis allé chez Pharaon et lui ai parlé en ton nom, il a maltraité ce peuple, et tu ne fais absolument rien pour délivrer ton peuple. »
