---
aliases : 
- Exode 16
- Exode 16
- Ex 16
- Exodus 16
tags : 
- Bible/Ex/16
- français
cssclass : français
---

# Exode 16

###### 01
Toute la communauté des fils d’Israël partit d’Élim et atteignit le désert de Sine, entre Élim et le Sinaï, le quinzième jour du deuxième mois après sa sortie du pays d’Égypte.
###### 02
Dans le désert, toute la communauté des fils d’Israël récriminait contre Moïse et Aaron.
###### 03
Les fils d’Israël leur dirent : « Ah ! Il aurait mieux valu mourir de la main du Seigneur, au pays d’Égypte, quand nous étions assis près des marmites de viande, quand nous mangions du pain à satiété ! Vous nous avez fait sortir dans ce désert pour faire mourir de faim tout ce peuple assemblé ! »
###### 04
Le Seigneur dit à Moïse : « Voici que, du ciel, je vais faire pleuvoir du pain pour vous. Le peuple sortira pour recueillir chaque jour sa ration quotidienne, et ainsi je vais le mettre à l’épreuve : je verrai s’il marchera, ou non, selon ma loi.
###### 05
Mais, le sixième jour, quand ils feront le compte de leur récolte, ils trouveront le double de la ration quotidienne. »
###### 06
Moïse et Aaron dirent alors aux fils d’Israël : « Ce soir, vous saurez que le Seigneur vous a fait sortir du pays d’Égypte ;
###### 07
et, demain matin, vous verrez la gloire du Seigneur, parce qu’il a entendu vos récriminations contre lui. Nous, que sommes-nous pour que vous récriminiez contre nous ? »
###### 08
Par là, Moïse voulait dire : « Vous verrez la gloire du Seigneur quand, le soir, il vous donnera de la viande en nourriture et, le matin, du pain à satiété. En effet, le Seigneur a entendu vos récriminations. Car ce n’est pas contre nous que vous récriminez mais bien contre le Seigneur. »
###### 09
Moïse dit ensuite à Aaron : « Ordonne à toute la communauté des fils d’Israël : “Présentez-vous devant le Seigneur, car il a entendu vos récriminations.” »
###### 10
Aaron parla à toute la communauté des fils d’Israël ; puis ils se tournèrent du côté du désert, et voici que la gloire du Seigneur apparut dans la nuée.
###### 11
Le Seigneur dit alors à Moïse :
###### 12
« J’ai entendu les récriminations des fils d’Israël. Tu leur diras : “Au coucher du soleil, vous mangerez de la viande et, le lendemain matin, vous aurez du pain à satiété. Alors vous saurez que moi, le Seigneur, je suis votre Dieu.” »
###### 13
Le soir même, surgit un vol de cailles qui recouvrirent le camp ; et, le lendemain matin, il y avait une couche de rosée autour du camp.
###### 14
Lorsque la couche de rosée s’évapora, il y avait, à la surface du désert, une fine croûte, quelque chose de fin comme du givre, sur le sol.
###### 15
Quand ils virent cela, les fils d’Israël se dirent l’un à l’autre : « Mann hou ? » (ce qui veut dire : Qu’est-ce que c’est ?), car ils ne savaient pas ce que c’était. Moïse leur dit : « C’est le pain que le Seigneur vous donne à manger.
###### 16
Voici ce que le Seigneur a ordonné : Recueillez-en autant que chacun peut en manger : une mesure par personne. Chacun de vous en prendra selon le nombre d’habitants de sa tente. »
###### 17
Les fils d’Israël firent ainsi : certains en recueillirent beaucoup, d’autres peu.
###### 18
Celui qui en avait ramassé beaucoup n’eut rien de trop ; celui qui en avait ramassé peu ne manqua de rien. Ainsi, chacun en avait recueilli autant qu’il pouvait en manger.
###### 19
Moïse leur dit encore : « Que personne n’en garde jusqu’au matin ! »
###### 20
Ils n’écoutèrent pas Moïse et certains en gardèrent jusqu’au matin. Mais le surplus fut infesté de vers et se mit à sentir mauvais. Alors Moïse s’irrita contre eux.
###### 21
Matin après matin, ils en recueillaient autant que chacun pouvait en manger. À la chaleur du soleil, tout était fondu.
###### 22
Or, le sixième jour, ils recueillirent le double de ce pain : deux mesures par personne. Et tous les chefs de la communauté vinrent en informer Moïse.
###### 23
Moïse leur dit : « Oui, c’est bien ce que le Seigneur avait dit. Demain est un grand sabbat, un sabbat consacré au Seigneur. Cuisez ce qui doit cuire, faites bouillir ce qui est à bouillir. Et gardez le surplus en réserve jusqu’au matin. »
###### 24
Ils le gardèrent, comme Moïse l’avait ordonné. Et il n’y eut ni mauvaise odeur ni vermine.
###### 25
Moïse leur dit : « Mangez-le aujourd’hui. Aujourd’hui, c’est le sabbat du Seigneur. Aujourd’hui, vous n’en trouverez pas dehors.
###### 26
Pendant six jours, vous en ramasserez, mais, le septième jour, c’est le sabbat : il n’y en aura pas. »
###### 27
Or, le septième jour, des gens sortirent pour en recueillir, mais ils n’en trouvèrent pas.
###### 28
Le Seigneur dit à Moïse : « Combien de temps encore refuserez-vous de garder mes commandements et mes lois ?
###### 29
Voyez : le Seigneur vous a donné le sabbat ; aussi, le sixième jour, vous donne-t-il du pain pour deux jours. Restez donc chacun chez vous. Que personne ne sorte de chez lui le septième jour. »
###### 30
Et, le septième jour, le peuple cessa toute activité.
###### 31
La maison d’Israël donna à ce pain le nom de « manne ». C’était comme de la graine de coriandre, de couleur blanche, au goût de beignet au miel.
###### 32
Moïse dit : « Voici ce que le Seigneur a ordonné : Qu’on en garde une pleine mesure en réserve pour les générations futures. Ainsi pourront-ils voir le pain dont je vous ai nourri au désert, quand je vous ai fait sortir du pays d’Égypte. »
###### 33
Moïse dit à Aaron : « Prends un vase, tu y mettras une pleine mesure, de manne et tu le déposeras devant le Seigneur, en réserve pour les générations futures. »
###### 34
Comme le Seigneur l’avait ordonné à Moïse, Aaron déposa le vase, en réserve, devant le Témoignage.
###### 35
Les fils d’Israël mangèrent de la manne pendant quarante ans, jusqu’à leur arrivée en pays habité ; ils mangèrent de la manne jusqu’à leur arrivée aux confins du pays de Canaan.
###### 36
La mesure utilisée, l’omèr, est un dixième de l’épha.
