---
aliases : 
- Exode 6
- Exode 6
- Ex 6
- Exodus 6
tags : 
- Bible/Ex/6
- français
cssclass : français
---

# Exode 6

###### 01
Le Seigneur dit à Moïse :
« Maintenant, tu vas voir ce que je vais faire à Pharaon : contraint par une main forte, il les laissera partir ; contraint par une main forte, il les chassera de son pays. »
###### 02
Dieu parla à Moïse. Il lui dit : « Je suis le Seigneur.
###### 03
Je suis apparu à Abraham, à Isaac et à Jacob comme le Dieu-Puissant ; mais mon nom “Le Seigneur”, je ne l’ai pas fait connaître.
###### 04
Ensuite, j’ai établi mon alliance avec eux, m’engageant à leur donner la terre de Canaan, la terre étrangère où ils étaient venus en immigrés.
###### 05
Puis enfin, j’ai entendu la plainte des fils d’Israël réduits en esclavage par les Égyptiens, et je me suis souvenu de mon alliance.
###### 06
C’est pourquoi, parle ainsi aux fils d’Israël : “Je suis le Seigneur. Je vous ferai sortir loin des corvées qui vous accablent en Égypte. Je vous délivrerai de la servitude. Je vous rachèterai d’un bras vigoureux et par de grands châtiments.
###### 07
Je vous prendrai pour peuple, et moi, je serai votre Dieu. Alors, vous saurez que je suis le Seigneur, votre Dieu, celui qui vous fait sortir loin des corvées qui vous accablent en Égypte.
###### 08
Puis, je vous ferai entrer dans la terre que, la main levée, je me suis engagé à donner à Abraham, à Isaac et à Jacob. Je vous la donnerai pour que vous la possédiez. Je suis le Seigneur”. »
###### 09
Moïse rapporta ces paroles aux fils d’Israël, mais ils n’écoutèrent pas Moïse, car ils étaient à bout de souffle, tant leur esclavage était dur.
###### 10
Le Seigneur dit à Moïse :
###### 11
« Va dire à Pharaon, le roi d’Égypte, qu’il laisse partir de son pays les fils d’Israël. »
###### 12
Mais Moïse prit la parole en présence du Seigneur et dit : « Les fils d’Israël ne m’ont pas écouté. Comment Pharaon m’écouterait-il, moi qui n’ai pas la parole facile ? »
###### 13
Le Seigneur parla à Moïse et Aaron, et leur communiqua ses ordres pour les fils d’Israël et pour Pharaon, roi d’Égypte, en vue de faire sortir les fils d’Israël du pays d’Égypte.
###### 14
Voici les chefs de leurs familles : fils de Roubène, premier-né d’Israël : Hénok, Pallou, Hesrone et Karmi ; tels sont les clans de Roubène.
###### 15
Fils de Siméon : Yemouël, Yamine, Ohad, Yakine, Sohar et Shaoul, le fils de la Cananéenne ; tels sont les clans de Siméon.
###### 16
Voici les noms des fils de Lévi avec leurs descendances : Guershone, Qehath et Merari. Lévi vécut cent trente-sept ans.
###### 17
Fils de Guershone : Libni et Shiméï, par clans.
###### 18
Fils de Qehath : Amram, Yisehar, Hébrone et Ouzziel. Qehath vécut cent trente-trois ans.
###### 19
Fils de Merari : Mahli et Moushi. Tels sont les clans de Lévi avec leurs descendances.
###### 20
Amram prit pour femme Yokèbed, sa tante, qui lui enfanta Aaron et Moïse. Amram vécut cent trente-sept ans.
###### 21
Fils de Yisehar : Coré, Néfeg et Zikri ;
###### 22
fils d’Ouzziel : Mishaël, Elçafane et Sitri.
###### 23
Aaron prit pour femme Élishèba, fille d’Amminadab, sœur de Nashone, et elle lui enfanta Nadab, Abihou, Éléazar et Itamar.
###### 24
Fils de Coré : Assir, Elcana et Abiasaph ; tels sont les clans des Coréites.
###### 25
Éléazar, fils d’Aaron, prit pour femme l’une des filles de Poutiel, qui lui enfanta Pinhas. Tels sont les chefs de famille des Lévites, par clans.
###### 26
C’est à Aaron et Moïse que le Seigneur avait dit : « Faites sortir du pays d’Égypte les fils d’Israël rangés comme une armée. »
###### 27
Ce sont eux – Moïse et Aaron – qui parlèrent à Pharaon, roi d’Égypte, pour faire sortir d’Égypte les fils d’Israël.
###### 28
C’était le jour où le Seigneur parla à Moïse au pays d’Égypte.
###### 29
Le Seigneur parla à Moïse. Il dit : « Je suis le Seigneur. Répète à Pharaon, le roi d’Égypte, tout ce que moi, je vais te dire. »
###### 30
Alors, Moïse dit en présence du Seigneur : « Je n’ai pas la parole facile. Comment Pharaon m’écouterait-il ? »
