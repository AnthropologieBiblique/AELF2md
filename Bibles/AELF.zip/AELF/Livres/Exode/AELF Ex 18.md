---
aliases : 
- Exode 18
- Exode 18
- Ex 18
- Exodus 18
tags : 
- Bible/Ex/18
- français
cssclass : français
---

# Exode 18

###### 01
Jéthro, prêtre de Madiane, le beau-père de Moïse, entendit parler de tout ce que Dieu avait fait pour Moïse et pour Israël, son peuple : le Seigneur avait fait sortir Israël d’Égypte !
###### 02
Jéthro, le beau-père de Moïse, prit Cippora, la femme de Moïse, qu’il avait répudiée ;
###### 03
il prit aussi ses deux fils. L’un s’appelait Guershom (ce qui signifie : Immigré en ce lieu) car, avait dit Moïse, « Je suis devenu un immigré en terre étrangère ».
###### 04
L’autre s’appelait Élièzer (ce qui signifie : Mon Dieu est mon secours) « car, avait-il dit, le Dieu de mon père est venu à mon secours, il m’a délivré de l’épée de Pharaon ».
###### 05
Jéthro, beau-père de Moïse, prit donc Cippora et ses deux fils ; il s’en alla rejoindre Moïse, au désert, là où il campait, à la montagne de Dieu.
###### 06
Il fit dire à Moïse : « C’est moi Jéthro, ton beau-père, qui viens vers toi avec ta femme et tes deux fils. »
###### 07
Moïse sortit à la rencontre de son beau-père, se prosterna et l’embrassa ; ils se saluèrent et entrèrent dans la tente.
###### 08
Moïse raconta à son beau-père tout ce que le Seigneur avait fait à Pharaon et à l’Égypte à cause d’Israël, toutes les difficultés survenues en chemin et dont le Seigneur les avait délivrés.
###### 09
Jéthro se réjouit de tout le bien que le Seigneur avait fait à Israël, en le délivrant de la main des Égyptiens.
###### 10
Et Jéthro dit : « Béni soit le Seigneur qui vous a délivrés de la main des Égyptiens et de la main de Pharaon ! Béni soit le Seigneur qui a délivré le peuple de la main des Égyptiens !
###### 11
Je reconnais maintenant que le Seigneur est plus grand que tous les dieux, comme il l’a bien montré au temps de leur oppression. »
###### 12
Jéthro, beau-père de Moïse, offrit un holocauste et des sacrifices à Dieu. Aaron et tous les anciens d’Israël vinrent participer au repas devant Dieu avec le beau-père de Moïse.
###### 13
Or, le lendemain, Moïse siégea pour rendre la justice au peuple, et le peuple resta devant Moïse du matin jusqu’au soir.
###### 14
Le beau-père de Moïse vit tout ce que celui-ci faisait pour le peuple. Il lui dit : « Que fais-tu là pour le peuple ? Pourquoi es-tu seul à siéger, tandis que tout le peuple est debout devant toi du matin jusqu’au soir ? »
###### 15
Moïse dit à son beau-père : « C’est que le peuple vient à moi pour consulter Dieu.
###### 16
S’ils ont un litige, ils viennent me trouver ; je leur rends justice, et je fais connaître les décrets de Dieu et ses lois. »
###### 17
Le beau-père de Moïse lui dit : « Ta façon de faire n’est pas la bonne.
###### 18
Tu vas t’épuiser complètement, ainsi que ce peuple qui est avec toi. La tâche est trop lourde pour toi, tu ne peux l’accomplir seul.
###### 19
Maintenant, écoute-moi ! Je vais te donner un conseil, et que Dieu soit avec toi ! Tiens-toi face à Dieu au nom du peuple : tu présenteras les litiges devant Dieu,
###### 20
tu informeras les gens des décrets et des lois, tu leur feras connaître le chemin à suivre et la conduite à tenir.
###### 21
Toi, tu distingueras, dans tout le peuple, des hommes de valeur, craignant Dieu, dignes de confiance, incorruptibles, et tu les institueras officiers de millier, officiers de centaine, officiers de cinquantaine et officiers de dizaine.
###### 22
Ils auront à juger le peuple en tout temps. Les affaires importantes, ils te les présenteront, mais les affaires mineures, ils les jugeront eux-mêmes. Allège ainsi ta charge. Qu’ils la portent avec toi !
###### 23
Si tu fais cela, et que Dieu te l’ordonne, tu pourras tenir et, de plus, tout ce peuple rentrera chez lui en paix. »
###### 24
Moïse écouta la voix de son beau-père et fit tout ce qu’il avait dit.
###### 25
Parmi tout Israël, Moïse choisit des hommes de valeur et les plaça à la tête du peuple : officiers de millier, officiers de centaine, officiers de cinquantaine et officiers de dizaine.
###### 26
Ils jugeaient le peuple en tout temps. Les affaires difficiles, ils les présentaient à Moïse, et les affaires de moindre importance, ils les jugeaient eux-mêmes.
###### 27
Et Moïse laissa partir son beau-père, qui s’en retourna dans son pays.
