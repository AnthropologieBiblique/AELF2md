---
aliases : 
- Exode 23
- Exode 23
- Ex 23
- Exodus 23
tags : 
- Bible/Ex/23
- français
cssclass : français
---

# Exode 23

###### 01
« Tu ne répandras pas de vaines rumeurs. Tu ne prêteras pas main forte au méchant en lui servant de témoin à charge.
###### 02
Tu ne suivras pas la foule pour faire le mal ; et quand tu déposeras dans un procès, tu ne t’aligneras pas sur son opinion pour faire dévier le droit.
###### 03
Tu ne favoriseras pas un faible dans son procès.
###### 04
Quand tu rencontreras, égaré, le bœuf ou l’âne de ton ennemi, tu devras le lui ramener.
###### 05
Si tu vois l’âne de celui qui te déteste crouler sous la charge, tu ne le laisseras pas à l’abandon mais tu lui viendras en aide.
###### 06
Tu ne feras pas dévier le droit du malheureux qui s’adresse à toi lors de son procès.
###### 07
Tu te tiendras éloigné d’une cause mensongère. Ne tue pas l’innocent ni le juste, car je ne justifie pas le méchant.
###### 08
Tu n’accepteras pas de présent, car le présent aveugle les clairvoyants et compromet la cause des justes.
###### 09
Tu n’opprimeras pas l’immigré : vous savez bien ce qu’est sa vie, car vous avez été, vous aussi, des immigrés au pays d’Égypte.
###### 10
« Pendant six ans, tu ensemenceras la terre et tu récolteras son produit.
###### 11
Mais, la septième année, tu la laisseras en jachère et tu abandonneras son produit : les malheureux de ton peuple le mangeront et, ce qu’ils auront laissé, les bêtes sauvages le mangeront. Tu feras de même pour ta vigne et ton olivier.
###### 12
Pendant six jours, tu feras ce que tu as à faire, mais, le septième jour, tu chômeras, afin que ton bœuf et ton âne se reposent, et que le fils de ta servante et l’immigré reprennent souffle.
###### 13
Vous prendrez bien garde à tout ce que je vous ai dit. Vous ne prononcerez pas le nom d’autres dieux : on ne l’entendra pas sortir de ta bouche.
###### 14
« Tu me fêteras trois fois par an.
###### 15
Tu observeras la fête des Pains sans levain. Comme je te l’ai ordonné, tu mangeras des pains sans levain pendant sept jours, au temps fixé du mois des Épis, car c’est alors que tu es sorti d’Égypte. On ne paraîtra pas devant ma face les mains vides.
###### 16
Tu observeras aussi la fête de la Moisson, celle des premiers fruits de ton travail, de ce que tu auras semé dans les champs. Et tu observeras la fête de la Récolte en fin d’année, quand tu récoltes dans les champs le fruit de ton travail.
###### 17
Trois fois par an, tous les hommes paraîtront devant la face du Maître, le Seigneur.
###### 18
Tu ne présenteras pas le sacrifice sanglant avec du pain levé, et tu ne laisseras pas jusqu’au lendemain matin la graisse offerte pour me fêter.
###### 19
Tu apporteras les tout premiers fruits de ton sol à la Maison du Seigneur ton Dieu. Tu ne feras pas cuire un chevreau dans le lait de sa mère.
###### 20
« Je vais envoyer un ange devant toi pour te garder en chemin et te faire parvenir au lieu que je t’ai préparé.
###### 21
Respecte sa présence, écoute sa voix. Ne lui résiste pas : il ne te pardonnerait pas ta révolte, car mon nom est en lui.
###### 22
Mais si tu écoutes parfaitement sa voix, si tu fais tout ce que je dirai, je serai l’ennemi de tes ennemis, et l’adversaire de tes adversaires.
###### 23
Mon ange marchera devant toi. Il te fera rencontrer de nombreux peuples : l’Amorite, le Hittite, le Perizzite et le Cananéen, le Hivvite et le Jébuséen. Je vais tous les anéantir.
###### 24
Tu ne te prosterneras pas devant leurs dieux. Tu ne les serviras pas. Tu ne te conduiras pas comme ces peuples, mais tu détruiras leurs dieux et tu briseras leurs stèles.
###### 25
Vous servirez le Seigneur votre Dieu : il bénira ton pain et ton eau, et j’écarterai de toi la maladie.
###### 26
Aucune femme de ton pays n’aura de fausse couche ou ne sera stérile, et je laisserai s’accomplir le nombre de tes jours.
###### 27
Devant toi, j’enverrai ma terreur ; je frapperai de panique tout peuple chez qui tu entreras ; devant toi, je ferai tourner le dos à tous tes ennemis.
###### 28
Devant toi, j’enverrai des frelons ; devant toi, ils chasseront le Hivvite, le Cananéen et le Hittite.
###### 29
Je ne les chasserai pas devant toi en une seule année, car le pays deviendrait une terre désolée où les bêtes sauvages se multiplieraient à tes dépens.
###### 30
Je les chasserai devant toi peu à peu, jusqu’à ce que ton peuple soit assez nombreux pour hériter du pays.
###### 31
Je fixerai tes frontières ainsi : de la mer des Roseaux à la Méditerranée, et du désert au Fleuve. Je livrerai entre vos mains les habitants du pays, et tu les chasseras devant toi.
###### 32
Tu ne concluras pas d’alliance avec eux ni avec leurs dieux.
###### 33
Ils n’habiteront pas dans ton pays, de peur qu’ils ne te fassent pécher contre moi : tu pourrais alors servir leurs dieux et ce serait pour toi un piège. »
