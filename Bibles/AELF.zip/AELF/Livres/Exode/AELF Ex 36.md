---
aliases : 
- Exode 36
- Exode 36
- Ex 36
- Exodus 36
tags : 
- Bible/Ex/36
- français
cssclass : français
---

# Exode 36

###### 01
Beçalel, Oholiab et tout artisan habile à qui le Seigneur a donné sagesse et intelligence pour concevoir et exécuter les travaux au service du sanctuaire, tous exécuteront ce que le Seigneur a ordonné. »
###### 02
Moïse appela donc, pour se mettre à l’ouvrage et l’exécuter, Beçalel, Oholiab et tout artisan habile à qui le Seigneur avait donné la sagesse, tous ceux que leur cœur y portait.
###### 03
Ils reçurent de Moïse la contribution que les fils d’Israël avaient apportée pour exécuter ces travaux au service du sanctuaire. Chaque matin, on apportait encore des offrandes volontaires.
###### 04
Alors, tous les artisans occupés aux divers travaux du sanctuaire quittèrent chacun l’ouvrage qu’ils étaient en train de faire
###### 05
et vinrent dire à Moïse : « Le peuple apporte plus qu’il n’en faut pour le travail que le Seigneur a ordonné d’exécuter. »
###### 06
Moïse donna donc cet ordre que l’on fit passer dans le camp : « Que personne, ni homme ni femme, n’apporte plus rien en contribution pour le sanctuaire. » Le peuple cessa d’apporter quoi que ce soit.
###### 07
Il y avait suffisamment de matériaux pour faire tout le travail ; il y en avait même en surplus.
###### 08
Les ouvriers, artisans habiles, construisirent la Demeure ; ils firent dix tentures de lin retors, pourpre violette, pourpre rouge et cramoisi éclatant, et on y broda des kéroubim : c’est une œuvre d’artiste.
###### 09
Chaque tenture mesurait vingt-huit coudées de long et quatre de large. Toutes les tentures avaient les mêmes dimensions.
###### 10
On assembla cinq tentures l’une à l’autre, et les cinq autres également.
###### 11
On fit des lacets de pourpre violette au bord de la première tenture, à l’extrémité de l’assemblage, et on fit de même au bord de la dernière tenture du deuxième assemblage.
###### 12
On mit cinquante lacets à la première tenture et cinquante lacets à l’extrémité de la tenture du deuxième assemblage, les lacets s’attachant l’un à l’autre.
###### 13
On fit cinquante agrafes en or, on assembla les tentures l’une à l’autre par les agrafes. Ainsi, la Demeure fut d’un seul tenant.
###### 14
Ensuite, pour former une tente au-dessus de la Demeure, on fit onze tentures en poil de chèvre.
###### 15
Chaque tenture mesurait trente coudées de long et quatre de large. Les onze tentures avaient les mêmes dimensions.
###### 16
On assembla cinq tentures à part, puis six tentures à part.
###### 17
On fit cinquante lacets au bord d’une première tenture, la dernière de l’assemblage, et cinquante lacets au bord de la même tenture du deuxième assemblage.
###### 18
On fit cinquante agrafes de bronze pour assembler la tente d’un seul tenant.
###### 19
Et on fit pour la tente une couverture en peaux de béliers teintes en rouge, et une autre en cuir fin mise par-dessus.
###### 20
On fit pour la Demeure des cadres en bois d’acacia, dressés debout.
###### 21
Chaque cadre mesurait dix coudées de long et une coudée et demie de large.
###### 22
Il était assemblé par deux tenons jumelés. Ainsi fut-il fait pour tous les cadres de la Demeure.
###### 23
On en disposa vingt en direction du Néguev, au sud ;
###### 24
et on fit quarante socles en argent sous les vingt cadres : deux socles sous un cadre pour ses deux tenons, puis deux socles sous un autre cadre pour ses deux tenons.
###### 25
Pour le deuxième côté de la Demeure, on disposa, en direction du nord, vingt cadres
###### 26
avec leurs quarante socles en argent : deux socles sous un cadre et deux socles sous un autre cadre.
###### 27
Et pour le fond de la Demeure, vers l’ouest, on fit six cadres ;
###### 28
on fit aussi deux cadres comme contreforts de la Demeure, au fond ;
###### 29
ils étaient jumelés à leur base et l’étaient également à leur sommet, à la hauteur du premier anneau : ainsi fut-il fait pour eux deux, pour les deux contreforts.
###### 30
Il y eut donc huit cadres, avec leurs socles en argent, soit seize socles : deux socles sous un cadre, deux socles sous un autre cadre.
###### 31
On fit les traverses en bois d’acacia : cinq pour les cadres du premier côté de la Demeure,
###### 32
cinq pour les cadres du deuxième côté de la Demeure, cinq pour les cadres qui forment le fond de la Demeure vers l’ouest.
###### 33
On fit aussi la traverse médiane, à mi-hauteur des cadres, traversant la Demeure d’un bout à l’autre.
###### 34
Les cadres, on les plaqua d’or, on fit en or leurs anneaux pour loger les traverses, et les traverses, on les plaqua d’or.
###### 35
On fit un rideau de pourpre violette, pourpre rouge, cramoisi éclatant et lin retors ; c’est une œuvre d’artiste : on y broda des kéroubim.
###### 36
On le fixa à quatre colonnes en acacia, plaquées d’or et munies de crochets en or. On coula pour elles quatre socles en argent.
###### 37
Pour l’entrée de la tente, on fit un voile en pourpre violette, pourpre rouge, cramoisi éclatant et lin retors : c’est une œuvre d’artisan brocheur.
###### 38
On fit pour le voile cinq colonnes avec leurs crochets ; leurs chapiteaux et leurs tringles furent plaqués d’or ; leurs cinq socles étaient en bronze.
