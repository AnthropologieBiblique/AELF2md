---
aliases : 
- Exode 37
- Exode 37
- Ex 37
- Exodus 37
tags : 
- Bible/Ex/37
- français
cssclass : français
---

# Exode 37

###### 01
Beçalel fit l’arche en bois d’acacia de deux coudées et demie de long sur une coudée et demie de large et une coudée et demie de haut.
###### 02
Il la plaqua d’or pur à l’intérieur et à l’extérieur, et il l’entoura d’une moulure en or.
###### 03
Il coula quatre anneaux d’or, qu’il attacha aux quatre pieds de l’arche : deux anneaux sur un côté, deux anneaux sur l’autre.
###### 04
Il fit des barres en bois d’acacia, il les plaqua d’or
###### 05
et il les introduisit dans les anneaux des côtés de l’arche pour qu’on puisse la porter.
###### 06
Il fit un propitiatoire en or pur, long de deux coudées et demie et large d’une coudée et demie.
###### 07
Et il forgea deux kéroubim en or, qu’il plaça aux deux extrémités du propitiatoire,
###### 08
un kéroub à une extrémité, et l’autre kéroub à l’autre extrémité ; il fit donc les kéroubim aux deux extrémités du propitiatoire.
###### 09
Les kéroubim avaient les ailes déployées vers le haut et protégeaient le propitiatoire de leurs ailes ; ils se faisaient face, le regard tourné vers le propitiatoire.
###### 10
Il fit la table en bois d’acacia, longue de deux coudées, large d’une coudée et haute d’une coudée et demie.
###### 11
Il la plaqua d’or pur et il l’entoura d’une moulure en or.
###### 12
Il lui fit des entretoises d’un palme et il les entoura d’une moulure en or.
###### 13
Il coula quatre anneaux d’or qu’il mit aux quatre angles formés par les quatre pieds.
###### 14
Ces anneaux furent placés près des entretoises, pour loger les barres servant à porter la table.
###### 15
Il fit les barres en bois d’acacia et il les plaqua d’or : elles servaient à porter la table.
###### 16
Il fit les accessoires de la table : plats, gobelets, timbales et aiguières pour les libations ; il les fit en or pur.
###### 17
Il fit le chandelier en or pur ; il forgea le chandelier : base, tige, coupes, boutons et fleurs faisaient corps avec lui.
###### 18
Six branches s’en détachaient sur les côtés : trois d’un côté et trois de l’autre.
###### 19
Sur une branche, trois coupes en forme d’amande avec boutons et fleurs et, sur une autre branche, trois coupes en forme d’amande avec boutons et fleurs ; de même pour les six branches sortant du chandelier.
###### 20
Le chandelier lui-même portait quatre coupes en forme d’amande avec boutons et fleurs :
###### 21
un bouton sous les deux premières branches issues du chandelier, un bouton sous les deux suivantes, et un bouton sous les deux dernières ; ainsi donc pour les six branches qui en sortaient.
###### 22
Boutons et branches faisaient corps avec le chandelier qui était tout entier forgé d’une seule pièce, en or pur.
###### 23
Il lui fit des lampes au nombre de sept, des pincettes et des porte-lampes en or pur.
###### 24
Il lui fallut un lingot d’or pur pour le chandelier et tous ses accessoires.
###### 25
Il fit l’autel de l’encens en bois d’acacia. L’autel avait une coudée de long, une coudée de large – sa base était donc carrée – et deux coudées et demie de haut. Ses cornes faisaient corps avec lui.
###### 26
Il le plaqua d’or pur : le dessus, les parois tout autour et les cornes ; et il l’entoura d’une moulure en or.
###### 27
Sous la moulure, sur les deux côtés, il plaça des anneaux d’or pour loger les barres servant à le porter.
###### 28
Il fit les barres en bois d’acacia et les plaqua d’or.
###### 29
Il fit l’huile d’onction sainte et l’encens aromatique pur : c’est une œuvre de parfumeur.
