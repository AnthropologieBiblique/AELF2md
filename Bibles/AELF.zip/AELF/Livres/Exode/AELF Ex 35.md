---
aliases : 
- Exode 35
- Exode 35
- Ex 35
- Exodus 35
tags : 
- Bible/Ex/35
- français
cssclass : français
---

# Exode 35

###### 01
Moïse rassembla toute la communauté des fils d’Israël. Il leur dit : « Voici ce que le Seigneur a ordonné :
###### 02
Pendant six jours, on travaillera, mais le septième jour sera pour vous un jour saint, un sabbat, un sabbat solennel pour le Seigneur. Quiconque travaillera ce jour-là sera mis à mort.
###### 03
Vous n’allumerez aucun feu dans vos maisons, le jour du sabbat. »
###### 04
Moïse s’adressa à toute la communauté des fils d’Israël. Il dit : « Voici ce que le Seigneur a ordonné :
###### 05
Prélevez parmi vous une contribution pour le Seigneur. Tous les hommes que leur cœur y incitera apporteront cette contribution : de l’or, de l’argent et du bronze,
###### 06
de la pourpre violette et de la pourpre rouge, du cramoisi éclatant, du lin fin et du poil de chèvre,
###### 07
des peaux de bélier teintes en rouge, du cuir fin et du bois d’acacia,
###### 08
de l’huile pour le luminaire, du baume pour l’huile de l’onction et pour l’encens aromatique,
###### 09
des pierres de cornaline et des pierres pour orner l’éphod et le pectoral.
###### 10
Et que, parmi vous, tous les artisans habiles viennent et exécutent tout ce que le Seigneur a ordonné :
###### 11
la Demeure avec sa tente, sa couverture, ses agrafes, ses cadres, ses traverses, ses colonnes et ses socles ;
###### 12
l’arche avec ses barres, le propitiatoire, le rideau ;
###### 13
la table avec ses barres, tous ses accessoires et le pain de l’offrande ;
###### 14
le chandelier du luminaire avec ses accessoires et ses lampes ; l’huile du luminaire ;
###### 15
l’autel de l’encens avec ses barres, l’huile de l’onction, l’encens aromatique et le voile de l’entrée de la Demeure ;
###### 16
l’autel de l’holocauste avec sa grille de bronze, ses barres et tous ses accessoires ; la cuve avec son support ;
###### 17
les toiles du parvis, ses colonnes, ses socles et le voile de la porte du parvis ;
###### 18
les piquets de la Demeure, les piquets du parvis et leurs cordes ;
###### 19
les vêtements liturgiques pour officier dans le sanctuaire, les vêtements sacrés pour Aaron, le prêtre, et les vêtements que porteront ses fils pour exercer le sacerdoce. »
###### 20
Toute la communauté des fils d’Israël se retira de devant Moïse.
###### 21
Alors tous les hommes que leur cœur y portait et que leur esprit y incitait vinrent apporter la contribution du Seigneur, pour les travaux de la tente de la Rencontre, pour tout son service et pour les vêtements sacrés.
###### 22
Les hommes vinrent aussi bien que les femmes ; tous ceux que leur cœur y incitait apportèrent broches, boucles, anneaux, breloques – tous objets d’or que chacun offrait au Seigneur avec le geste d’élévation.
###### 23
Tous ceux qui possédaient de la pourpre violette, de la pourpre rouge, du cramoisi éclatant, du lin, du poil de chèvre, des peaux de béliers teintes en rouge ou du cuir fin, tous ceux-là en apportèrent.
###### 24
Tous ceux qui offraient une contribution d’argent et de bronze apportèrent la contribution du Seigneur. Tous ceux qui possédaient du bois d’acacia l’apportèrent pour les travaux du service.
###### 25
Toutes les femmes habiles filèrent de leurs mains et apportèrent ce qu’elles avaient filé : la pourpre violette et la pourpre rouge, le cramoisi éclatant et le lin ;
###### 26
toutes les femmes que leur cœur y portait et qui étaient habiles filèrent le poil de chèvre.
###### 27
Les chefs de la communauté apportèrent les pierres de cornaline et les pierres pour orner l’éphod et le pectoral,
###### 28
ainsi que le baume et l’huile pour le luminaire, l’huile de l’onction et l’encens aromatique.
###### 29
Hommes et femmes, tous ceux que leur cœur y incitait apportèrent leur part à tout l’ouvrage que le Seigneur avait commandé par l’intermédiaire de Moïse ; ainsi, les fils d’Israël apportèrent une offrande volontaire au Seigneur.
###### 30
Moïse dit aux fils d’Israël : « Voyez : Le Seigneur a appelé par son nom Beçalel, fils d’Ouri, fils de Hour, de la tribu de Juda.
###### 31
Il l’a rempli de l’esprit de Dieu : sagesse, intelligence, savoir, en toute sorte d’ouvrages,
###### 32
pour concevoir des œuvres d’art et les réaliser avec l’or, l’argent, le bronze,
###### 33
pour tailler les pierres à sertir, sculpter sur bois et pour exécuter toute œuvre d’art.
###### 34
Il a mis en son cœur le don de transmettre le savoir, comme en celui d’Oholiab, fils d’Ahisamak, de la tribu de Dane.
###### 35
Il a rempli leur cœur de sagesse pour exécuter tout le travail du ciseleur, du brodeur, du brocheur de pourpre violette et pourpre rouge, cramoisi éclatant et lin, ainsi que le travail du tisserand. Ce sont des artisans de toute sorte, de véritables artistes.
