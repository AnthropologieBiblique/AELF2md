---
aliases : 
- Exode 27
- Exode 27
- Ex 27
- Exodus 27
tags : 
- Bible/Ex/27
- français
cssclass : français
---

# Exode 27

###### 01
« Puis tu feras l’autel en bois d’acacia. L’autel aura cinq coudées de long, cinq coudées de large, – sa base sera donc carrée – et trois coudées de haut.
###### 02
Tu feras des cornes aux quatre angles de l’autel, et ses cornes feront corps avec lui. Tu le plaqueras de bronze.
###### 03
Tu feras les vases pour recueillir les cendres grasses, les pelles, les bols pour l’aspersion, les fourchettes et les brûle-parfums : tous ces accessoires, tu les feras en bronze.
###### 04
Tu lui feras une grille de bronze en forme de filet, munie de quatre anneaux de bronze aux quatre extrémités.
###### 05
Tu la mettras sous la bordure de l’autel, en bas ; la grille sera à mi-hauteur de l’autel.
###### 06
Tu feras pour l’autel des barres en bois d’acacia et tu les plaqueras de bronze.
###### 07
On les engagera dans les anneaux et elles seront placées sur les deux côtés de l’autel pour le porter.
###### 08
Tu le feras creux, en planches. Comme il te fut montré sur la montagne, c’est ainsi que l’on fera.
###### 09
« Tu feras le parvis de la Demeure. Du côté du Néguev, au sud, le parvis aura des toiles en lin retors, sur une longueur de cent coudées pour un seul côté.
###### 10
Ses vingt colonnes et leurs vingt socles seront en bronze ; les crochets des colonnes et leurs tringles, en argent.
###### 11
De même, du côté nord, sur toute sa longueur, le parvis aura des toiles longues de cent coudées, vingt colonnes et leurs vingt socles en bronze ; les crochets des colonnes et leurs tringles seront en argent.
###### 12
En largeur, du côté ouest, le parvis aura des toiles sur cinquante coudées, avec leurs dix colonnes et leurs dix socles.
###### 13
La largeur du parvis du côté de l’est, vers le levant, sera de cinquante coudées ;
###### 14
il y aura quinze coudées de toiles sur une aile, avec leurs trois colonnes et leurs trois socles,
###### 15
et, sur la deuxième aile, quinze coudées de toiles, avec leurs trois colonnes et leurs trois socles.
###### 16
Pour la porte du parvis, il y aura un voile de vingt coudées, en pourpre violette, pourpre rouge, cramoisi éclatant et lin retors – œuvre d’artisan brocheur –, avec leurs quatre colonnes et leurs quatre socles.
###### 17
Toutes les colonnes du parvis seront réunies par des tringles en argent ; leurs crochets seront en argent et leurs socles en bronze.
###### 18
La longueur du parvis sera de cent coudées, sa largeur de cinquante, et sa hauteur de cinq – les socles seront en bronze.
###### 19
Tous les accessoires utilisés pour le service de la Demeure, tous ses piquets et les piquets du parvis seront en bronze.
###### 20
« Tu ordonneras également aux fils d’Israël de te procurer, pour le luminaire, de l’huile d’olive limpide et vierge, pour que, perpétuellement, monte la flamme d’une lampe.
###### 21
C’est dans la tente de la Rencontre, à l’extérieur du rideau qui abrite le Témoignage, que la disposeront Aaron et ses fils, pour qu’elle soit du soir au matin devant le Seigneur : c’est un décret perpétuel, de génération en génération, pour les fils d’Israël.
