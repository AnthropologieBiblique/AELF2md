---
aliases : 
- Exode 15
- Exode 15
- Ex 15
- Exodus 15
tags : 
- Bible/Ex/15
- français
cssclass : français
---

# Exode 15

###### 01
Alors Moïse et les fils d’Israël chantèrent ce cantique au Seigneur :
« Je chanterai pour le Seigneur ! Éclatante est sa gloire :
il a jeté dans la mer cheval et cavalier !
###### 02
Ma force et mon chant, c’est le Seigneur :
il est pour moi le salut.
Il est mon Dieu, je le célèbre ;
j’exalte le Dieu de mon père.
###### 03
Le Seigneur est le guerrier des combats ;
son nom est « Le Seigneur ».
###### 04
Les chars du Pharaon et ses armées, il les lance dans la mer.
[L’élite de leurs chefs a sombré dans la mer Rouge.
###### 05
L’abîme les recouvre :
ils descendent, comme la pierre, au fond des eaux.
###### 06
Ta droite, Seigneur, magnifique en sa force,
ta droite, Seigneur, écrase l’ennemi.
###### 07
La grandeur de ta majesté brise tes adversaires :
tu envoies ta colère qui les brûle comme un chaume.]
###### 08
Au souffle de tes narines, les eaux s’amoncellent :
comme une digue, se dressent les flots ;
les abîmes se figent au cœur de la mer.
###### 09
L’ennemi disait : “Je poursuis, je domine,
je partage le butin, je m’en repais ;
je tire mon épée : je prends les dépouilles !”
###### 10
Tu souffles ton haleine : la mer les recouvre ;
comme du plomb, ils s’abîment dans les eaux redoutables.
###### 11
Qui est comme toi parmi les dieux, Seigneur ?
Qui est comme toi, magnifique en sainteté,
terrible en ses exploits, auteur de prodiges ?
###### 12
Tu étends ta main droite : la terre les avale.
###### 13
Par ta fidélité tu conduis ce peuple que tu as racheté ;
tu les guides par ta force vers ta sainte demeure.
###### 14
[Les peuples ont entendu : ils tremblent ;
les douleurs ont saisi les habitants de Philistie.
###### 15
Les princes d’Édom sont pris d’effroi.
Un tremblement a saisi les puissants de Moab ;
tous les habitants de Canaan sont terrifiés,
###### 16
la peur et la terreur tombent sur eux.
Sous la vigueur de ton bras, ils se taisent, pétrifiés,
pendant que ton peuple passe, Seigneur,
que passe le peuple acquis par toi.]
###### 17
Tu les amènes, tu les plantes sur la montagne, ton héritage,
le lieu que tu as fait, Seigneur, pour l’habiter,
le sanctuaire, Seigneur, fondé par tes mains.
###### 18
Le Seigneur régnera pour les siècles des siècles. »
###### 19
Le cheval de Pharaon, ses chars et ses guerriers étaient entrés dans la mer, et le Seigneur avait fait revenir sur eux les eaux de la mer. Mais les fils d’Israël, eux, avaient marché à pied sec au milieu de la mer.
###### 20
La prophétesse Miryam, sœur d’Aaron, saisit un tambourin, et toutes les femmes la suivirent, dansant et jouant du tambourin.
###### 21
Et Miryam leur entonna :
« Chantez pour le Seigneur ! Éclatante est sa gloire :
il a jeté dans la mer cheval et cavalier ! »
###### 22
Moïse fit partir les fils d’Israël de la mer des Roseaux, et ils sortirent en direction du désert de Shour. Ils marchèrent trois jours à travers le désert sans trouver d’eau.
###### 23
Ils arrivèrent à Mara mais ne purent boire l’eau de Mara car elle était amère ; d’où son nom de « Mara ».
###### 24
Et le peuple récrimina contre Moïse en disant : « Que boirons-nous ? »
###### 25
Alors Moïse cria vers le Seigneur, et le Seigneur lui montra un morceau de bois. Moïse le jeta dans l’eau, et l’eau devint douce. C’est là que le Seigneur leur fixa un statut et un droit, là où il les mit à l’épreuve.
###### 26
Il dit : « Si tu écoutes bien la voix du Seigneur ton Dieu, si tu fais ce qui est droit à ses yeux, si tu prêtes l’oreille à ses commandements, si tu observes tous ses décrets, je ne t’infligerai aucune des maladies que j’ai infligées aux Égyptiens, car je suis le Seigneur, celui qui te guérit. »
###### 27
Les fils d’Israël atteignirent ensuite Élim, où il y a douze sources et soixante-dix palmiers. Et là, ils campèrent près de l’eau.
