---
aliases : 
- Exode 24
- Exode 24
- Ex 24
- Exodus 24
tags : 
- Bible/Ex/24
- français
cssclass : français
---

# Exode 24

###### 01
Le Seigneur avait dit à Moïse : « Monte vers le Seigneur et prends avec toi Aaron, ses deux fils Nadab et Abihou, et soixante-dix des anciens d’Israël. Vous vous prosternerez à distance.
###### 02
Moïse, seul, s’approchera du Seigneur. Les autres ne s’approcheront pas et le peuple ne montera pas avec lui. »
###### 03
Moïse vint rapporter au peuple toutes les paroles du Seigneur et toutes ses ordonnances. Tout le peuple répondit d’une seule voix : « Toutes ces paroles que le Seigneur a dites, nous les mettrons en pratique. »
###### 04
Moïse écrivit toutes les paroles du Seigneur. Il se leva de bon matin et il bâtit un autel au pied de la montagne, et il dressa douze pierres pour les douze tribus d’Israël.
###### 05
Puis il chargea quelques jeunes garçons parmi les fils d’Israël d’offrir des holocaustes, et d’immoler au Seigneur des taureaux en sacrifice de paix.
###### 06
Moïse prit la moitié du sang et le mit dans des coupes ; puis il aspergea l’autel avec le reste du sang.
###### 07
Il prit le livre de l’Alliance et en fit la lecture au peuple. Celui-ci répondit : « Tout ce que le Seigneur a dit, nous le mettrons en pratique, nous y obéirons. »
###### 08
Moïse prit le sang, en aspergea le peuple, et dit : « Voici le sang de l’Alliance que, sur la base de toutes ces paroles, le Seigneur a conclue avec vous. »
###### 09
Et Moïse gravit la montagne avec Aaron, Nadab et Abihou, et soixante-dix des anciens d’Israël.
###### 10
Ils virent le Dieu d’Israël : il avait sous les pieds comme un pavement de saphir, limpide comme le fond du ciel.
###### 11
Sur ces privilégiés parmi les fils d’Israël, il ne porta pas la main. Ils contemplèrent Dieu, puis ils mangèrent et ils burent.
###### 12
Le Seigneur dit à Moïse : « Monte vers moi sur la montagne et reste là ; je vais te donner les tables de pierre, la loi et les commandements que j’ai écrits pour qu’on les enseigne. »
###### 13
Moïse se leva avec Josué, son auxiliaire, et il gravit la montagne de Dieu.
###### 14
Auparavant il avait dit aux anciens : « Attendez-nous ici jusqu’à notre retour. Aaron et Hour sont avec vous : celui qui a une affaire à régler, qu’il s’adresse à eux. »
###### 15
Moïse gravit donc la montagne, et la nuée recouvrit la montagne,
###### 16
la gloire du Seigneur demeura sur la montagne du Sinaï, que la nuée recouvrit pendant six jours. Le septième jour, le Seigneur appela Moïse du milieu de la nuée.
###### 17
La gloire du Seigneur apparaissait aux fils d’Israël comme un feu dévorant, au sommet de la montagne.
###### 18
Moïse entra dans la nuée et gravit la montagne. Moïse resta sur la montagne quarante jours et quarante nuits.
