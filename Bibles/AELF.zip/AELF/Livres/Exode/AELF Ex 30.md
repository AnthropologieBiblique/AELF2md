---
aliases : 
- Exode 30
- Exode 30
- Ex 30
- Exodus 30
tags : 
- Bible/Ex/30
- français
cssclass : français
---

# Exode 30

###### 01
« Tu feras encore un autel en bois d’acacia pour brûler de l’encens.
###### 02
Il aura une coudée de long, une coudée de large – sa base sera donc carrée – et de deux coudées et demie de haut. Ses cornes feront corps avec lui.
###### 03
Tu le plaqueras d’or pur : le dessus, les parois tout autour et les cornes ; tu l’entoureras d’une moulure en or.
###### 04
Sous la moulure, sur les deux côtés, tu placeras des anneaux d’or pour loger les barres servant à le porter.
###### 05
Tu feras les barres en acacia et tu les plaqueras d’or.
###### 06
Tu placeras l’autel devant le rideau qui abrite l’arche du Témoignage, au lieu où tu pourras me rencontrer.
###### 07
Quand, chaque matin, Aaron viendra entretenir les lampes, il y brûlera de l’encens aromatique.
###### 08
Et quand, au coucher du soleil, il viendra allumer les lampes, il y brûlera à nouveau de l’encens. De génération en génération, l’encens montera perpétuellement devant le Seigneur.
###### 09
Sur cet autel, vous n’offrirez pas d’encens profane, ni d’holocauste, ni d’offrande de céréales ; vous n’y verserez pas de libation.
###### 10
Aaron accomplira le rite d’expiation sur les cornes de l’autel, une fois par an. Il le fera avec le sang du sacrifice pour la faute, une fois par an, lors de la fête du Grand Pardon, de génération en génération. Ce sera une chose très sainte pour le Seigneur. »
###### 11
Le Seigneur parla à Moïse. Il dit :
###### 12
« Quand tu dénombreras les fils d’Israël pour le recensement, chacun d’eux donnera au Seigneur le prix de la rançon pour sa vie : ainsi, aucun fléau ne les frappera lors du recensement.
###### 13
Voici ce que donnera tout homme soumis au recensement : un demi-sicle, selon le sicle du sanctuaire à vingt guéras par sicle, comme contribution pour le Seigneur.
###### 14
Tout homme de vingt ans et plus qui viendra se faire recenser s’acquittera de la contribution pour le Seigneur.
###### 15
Pour la payer, en rançon pour sa vie, le riche ne versera pas plus d’un demi-sicle et l’indigent, pas moins.
###### 16
Tu recevras, des fils d’Israël, l’argent de la rançon, et tu le donneras pour le service de la tente de la Rencontre. Pour les fils d’Israël, ce sera, en présence du Seigneur, un mémorial de la rançon pour vos vies. »
###### 17
Le Seigneur parla à Moïse. Il dit :
###### 18
« Pour les ablutions, tu feras une cuve en bronze sur un support en bronze. Tu placeras la cuve entre la tente de la Rencontre et l’autel, et tu y verseras de l’eau.
###### 19
Aaron et ses fils s’y laveront les mains et les pieds.
###### 20
Quand ils entreront dans la tente de la Rencontre, ils se laveront avec l’eau, et ainsi ils ne mourront pas ; quand ils s’approcheront de l’autel pour officier, faire fumer une nourriture offerte pour le Seigneur,
###### 21
ils se laveront les mains et les pieds, et ainsi ils ne mourront pas. C’est là un décret perpétuel pour Aaron et sa descendance, de génération en génération. »
###### 22
Le Seigneur parla à Moïse. Il dit :
###### 23
« Procure-toi aussi du baume de première qualité ; de la myrrhe fluide, cinq cents sicles ; du cinnamome aromatique, la moitié, soit deux cent cinquante ; du roseau aromatique, deux cent cinquante ;
###### 24
de la casse, cinq cents sicles – en sicles du sanctuaire –, et un setier d’huile d’olive.
###### 25
Tu en feras une huile d’onction sainte, un mélange parfumé, œuvre de parfumeur : ce sera l’huile d’onction sainte.
###### 26
Avec ce mélange, tu feras une onction sur la tente de la Rencontre, l’arche du Témoignage,
###### 27
la table et les accessoires, le chandelier et ses accessoires, l’autel de l’encens,
###### 28
l’autel de l’holocauste et ses accessoires, la cuve et son support.
###### 29
Tu les consacreras et ils seront très saints ; tout ce qui les touchera sera sanctifié.
###### 30
Tu donneras l’onction à Aaron et à ses fils, et tu les consacreras afin qu’ils exercent pour moi le sacerdoce.
###### 31
Puis tu t’adresseras aux fils d’Israël et tu leur diras : “Ceci est, pour moi, l’huile d’onction sainte, de génération en génération.
###### 32
On n’en répandra sur le corps d’aucune autre personne ; vous n’imiterez pas sa recette, car cette huile est sainte et elle restera sainte pour vous.
###### 33
Celui qui copiera ce mélange et en mettra sur un profane sera retranché de sa parenté.” »
###### 34
Le Seigneur dit à Moïse : « Procure-toi des aromates : storax, ambre, galbanum aromatique et encens pur, en parties égales.
###### 35
Tu en feras un encens parfumé qui soit salé, pur et saint. C’est une œuvre de parfumeur.
###### 36
Tu en réduiras une partie en poudre que tu mettras devant l’arche du Témoignage, dans la tente de la Rencontre ; là je te laisserai me rencontrer. Pour vous, ce sera chose très sainte.
###### 37
L’encens composé selon cette recette, vous ne l’utiliserez pas pour votre propre usage : il sera saint, réservé au Seigneur.
###### 38
Celui qui en fera une imitation pour jouir de son odeur sera retranché de sa parenté. »
