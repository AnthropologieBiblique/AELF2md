---
aliases : 
- Exode 11
- Exode 11
- Ex 11
- Exodus 11
tags : 
- Bible/Ex/11
- français
cssclass : français
---

# Exode 11

###### 01
Le Seigneur dit à Moïse : « Pour la dernière fois, je vais frapper Pharaon et l’Égypte. Après cela, non seulement il vous laissera partir, mais il vous renverra définitivement, il vous chassera d’ici.
###### 02
Parle donc au peuple : que chaque homme demande à son voisin, et chaque femme à sa voisine, des objets d’argent et des objets d’or. »
###### 03
Le Seigneur fit que son peuple trouve grâce aux yeux des Égyptiens. D’ailleurs, en Égypte, Moïse lui-même était un très grand personnage, aux yeux des serviteurs de Pharaon comme aux yeux du peuple.
###### 04
Alors Moïse dit : « Ainsi parle le Seigneur : Au milieu de la nuit, en plein cœur de l’Égypte, je sortirai
###### 05
et, chez les Égyptiens, tous les premiers-nés mourront, aussi bien le premier-né de Pharaon qui siège sur le trône, que le premier-né de la servante qui est derrière la meule, et que tous les premiers-nés du bétail.
###### 06
Alors s’élèvera, dans tout le pays d’Égypte, une immense clameur, comme il n’y en eut jamais auparavant, et comme il n’y en aura plus jamais.
###### 07
Cependant, chez les fils d’Israël, pas un seul chien ne devra grogner contre qui que ce soit, homme ou bête ; ainsi, vous reconnaîtrez que le Seigneur fait la distinction entre l’Égypte et Israël.
###### 08
Alors tous tes serviteurs que voici viendront me trouver et se prosterneront devant moi, en disant : “Sors, toi et tout le peuple qui marche à ta suite !” Après cela, je sortirai. » Et Moïse, enflammé de colère, sortit de chez Pharaon.
###### 09
Le Seigneur avait dit à Moïse : « Pharaon ne vous écoutera pas, tant et si bien que mes prodiges se multiplieront au pays d’Égypte. »
###### 10
Moïse et Aaron avaient accompli toutes sortes de prodiges devant Pharaon ; mais le Seigneur avait fait en sorte que Pharaon s’obstine ; et celui-ci ne laissa pas les fils d’Israël sortir de son pays.
