---
aliases : 
- Exode 2
- Exode 2
- Ex 2
- Exodus 2
tags : 
- Bible/Ex/2
- français
cssclass : français
---

# Exode 2

###### 01
Un homme de la tribu de Lévi avait épousé une femme de la même tribu.
###### 02
Elle devint enceinte, et elle enfanta un fils. Voyant qu’il était beau, elle le cacha durant trois mois.
###### 03
Lorsqu’il lui fut impossible de le tenir caché plus longtemps, elle prit une corbeille de jonc, qu’elle enduisit de bitume et de goudron. Elle y plaça l’enfant, et déposa la corbeille au bord du Nil, au milieu des roseaux.
###### 04
La sœur de l’enfant se tenait à distance pour voir ce qui allait arriver.
###### 05
La fille de Pharaon descendit au fleuve pour s’y baigner, tandis que ses suivantes se promenaient sur la rive. Elle aperçut la corbeille parmi les roseaux et envoya sa servante pour la prendre.
###### 06
Elle l’ouvrit et elle vit l’enfant. C’était un petit garçon, il pleurait. Elle en eut pitié et dit : « C’est un enfant des Hébreux. »
###### 07
La sœur de l’enfant dit alors à la fille de Pharaon : « Veux-tu que j’aille te chercher, parmi les femmes des Hébreux, une nourrice qui, pour toi, nourrira l’enfant ? »
###### 08
La fille de Pharaon lui répondit : « Va. » La jeune fille alla donc chercher la mère de l’enfant.
###### 09
La fille de Pharaon dit à celle-ci : « Emmène cet enfant et nourris-le pour moi. C’est moi qui te donnerai ton salaire. » Alors la femme emporta l’enfant et le nourrit.
###### 10
Lorsque l’enfant eut grandi, elle le ramena à la fille de Pharaon qui le traita comme son propre fils ; elle lui donna le nom de Moïse, en disant : « Je l’ai tiré des eaux. »
###### 11
Or vint le jour où Moïse, qui avait grandi, se rendit auprès de ses frères et les vit accablés de corvées. Il vit un Égyptien qui frappait un Hébreu, l’un de ses frères.
###### 12
Regardant autour de lui et ne voyant personne, il frappa à mort l’Égyptien et l’enfouit dans le sable.
###### 13
Le lendemain, il sortit de nouveau : voici que deux Hébreux se battaient. Il dit à l’agresseur : « Pourquoi frappes-tu ton compagnon ? »
###### 14
L’homme lui répliqua : « Qui t’a institué chef et juge sur nous ? Veux-tu me tuer comme tu as tué l’Égyptien ? » Moïse eut peur et se dit : « Pas de doute, la chose est connue. »
###### 15
Pharaon en fut informé et chercha à faire tuer Moïse. Celui-ci s’enfuit loin de Pharaon et habita au pays de Madiane.
Il vint s’asseoir près du puits.
###### 16
Le prêtre de Madiane avait sept filles. Elles allèrent puiser de l’eau et remplir les auges pour abreuver le troupeau de leur père.
###### 17
Des bergers survinrent et voulurent les chasser. Alors Moïse se leva pour leur porter secours et il abreuva leur troupeau.
###### 18
Elles retournèrent chez Réouël, leur père, qui leur dit : « Pourquoi êtes-vous revenues si tôt, aujourd’hui ? »
###### 19
Elles répondirent : « Un Égyptien nous a délivrées de la main des bergers, il a même puisé l’eau pour nous et abreuvé le troupeau ! –
###### 20
Mais où est-il, demanda Réouël, pourquoi l’avez-vous laissé là-bas ? Appelez-le ! Invitez-le à manger ! »
###### 21
Et Moïse accepta de s’établir chez cet homme qui lui donna comme épouse sa fille Cippora.
###### 22
Elle enfanta un fils à qui Moïse donna le nom de Guershom (ce qui signifie : Immigré en ce lieu) car, dit-il, « Je suis devenu un immigré en terre étrangère. »
###### 23
Au cours de cette longue période, le roi d’Égypte mourut. Du fond de leur esclavage, les fils d’Israël gémirent et crièrent. Du fond de leur esclavage, leur appel monta vers Dieu.
###### 24
Dieu entendit leur plainte ; Dieu se souvint de son alliance avec Abraham, Isaac et Jacob.
###### 25
Dieu regarda les fils d’Israël, et Dieu les reconnut.
