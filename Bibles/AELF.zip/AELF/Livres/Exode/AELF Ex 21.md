---
aliases : 
- Exode 21
- Exode 21
- Ex 21
- Exodus 21
tags : 
- Bible/Ex/21
- français
cssclass : français
---

# Exode 21

###### 01
« Voici les règles que tu leur exposeras.
###### 02
Quand tu achèteras un esclave hébreu, il servira durant six ans ; la septième année, il pourra s’en aller, libre, sans rien payer.
###### 03
S’il est arrivé seul, il s’en ira seul. S’il est déjà marié, sa femme s’en ira avec lui.
###### 04
Si son maître lui donne une femme et qu’elle lui enfante des fils ou des filles, la femme et les enfants appartiendront au maître, et lui s’en ira seul.
###### 05
Mais si l’esclave déclare : “J’aime mon maître, ma femme et mes fils, je ne veux pas être libéré”,
###### 06
son maître le fera approcher de Dieu, il le fera approcher du battant ou du montant de la porte, et lui percera l’oreille au poinçon. Alors l’esclave le servira pour toujours.
###### 07
Et quand un homme vendra sa fille comme servante, elle ne s’en ira pas comme s’en vont les esclaves.
###### 08
Si elle déplaît à son maître, qui se l’était destinée, et qu’il la fasse racheter, il n’aura pas le droit de la vendre à un peuple étranger, car ce serait la trahir.
###### 09
S’il la destine à son fils, il agira pour elle selon la règle concernant les filles.
###### 10
S’il prend pour lui une autre femme, il ne diminuera en rien la nourriture, le vêtement, le logement de la première.
###### 11
Et s’il ne lui procure pas ces trois choses, elle pourra s’en aller, sans rien payer, sans verser d’argent.
###### 12
« Qui frappe un homme à mort sera mis à mort.
###### 13
Mais s’il n’a pas traqué sa victime, si Dieu l’a mise à portée de sa main, je te fixerai un lieu où il pourra se réfugier.
###### 14
Mais quand un homme est en rage contre son prochain au point de le tuer par ruse, tu l’arracheras même de mon autel pour qu’il meure.
###### 15
Celui qui frappe son père ou sa mère sera mis à mort.
###### 16
Celui qui commet un rapt – qu’il ait vendu l’homme ou qu’on le trouve entre ses mains – sera mis à mort.
###### 17
Celui qui maudit son père ou sa mère sera mis à mort.
###### 18
« Quand des hommes se querellent et que l’un d’eux frappe son prochain avec une pierre ou avec le poing, sans le tuer mais en l’obligeant à garder le lit,
###### 19
si la victime peut se lever et se promener au dehors avec sa canne, l’agresseur sera acquitté. Il devra seulement l’indemniser pour son arrêt de travail, jusqu’à complète guérison.
###### 20
Si quelqu’un frappe avec un bâton et fait mourir de sa main son serviteur ou sa servante, la victime devra être vengée.
###### 21
Mais si elle survit un jour ou deux, elle ne sera pas vengée, car elle a été achetée avec l’argent du maître.
###### 22
Si des hommes, en se battant, heurtent une femme enceinte et que celle-ci accouche prématurément sans qu’un autre malheur n’arrive, le coupable paiera l’indemnité imposée par le mari, avec l’accord des juges.
###### 23
Mais s’il arrive malheur, tu paieras vie pour vie,
###### 24
œil pour œil, dent pour dent, main pour main, pied pour pied,
###### 25
brûlure pour brûlure, blessure pour blessure, meurtrissure pour meurtrissure.
###### 26
Si un homme blesse l’œil de son serviteur ou de sa servante, et que l’œil soit perdu, il rendra la liberté à la victime en compensation.
###### 27
Et s’il fait tomber une dent de son serviteur ou de sa servante, il rendra la liberté à la victime en compensation.
###### 28
Si un bœuf tue d’un coup de corne un homme ou une femme, il sera lapidé et on ne mangera pas la viande. Mais le propriétaire sera tenu pour innocent.
###### 29
Par contre, quand le bœuf a déjà, plus d’une fois, donné des coups de corne et que son propriétaire, averti, l’a laissé sans surveillance, si l’animal a causé la mort d’un homme ou d’une femme, il sera lapidé, et le propriétaire lui-même sera mis à mort.
###### 30
Et si on lui impose une rançon, il donnera, pour racheter sa vie, tout ce qu’on lui imposera.
###### 31
Si c’est un fils que le bœuf frappe d’un coup de corne, ou si c’est une fille, on appliquera cette règle-là.
###### 32
Si c’est un serviteur que le bœuf frappe, ou si c’est une servante, on donnera au maître trente pièces d’argent, et le bœuf sera lapidé.
###### 33
Si un homme laisse une citerne ouverte ou qu’il creuse une citerne sans la recouvrir, et qu’un bœuf ou un âne y tombe,
###### 34
le propriétaire de la citerne indemnisera le propriétaire de la bête morte ; celui-ci recevra une certaine somme d’argent et celui-là, le cadavre de la bête.
###### 35
Si le bœuf d’un homme blesse le bœuf de son prochain et cause sa mort, les propriétaires vendront le bœuf vivant et se partageront l’argent ; quant à la bête morte, ils se la partageront également.
###### 36
Mais s’il est notoire que ce bœuf a déjà, plus d’une fois, donné des coups de corne et que son propriétaire l’ait laissé sans surveillance, celui-ci fournira un bœuf en compensation de la bête morte qui, elle, lui reviendra.
###### 37
« Si un homme vole un bœuf ou un mouton, et qu’il abatte ou vende la bête, il fournira en compensation cinq têtes de gros bétail pour un bœuf ou quatre têtes de petit bétail pour un mouton.
