---
aliases : 
- Exode 33
- Exode 33
- Ex 33
- Exodus 33
tags : 
- Bible/Ex/33
- français
cssclass : français
---

# Exode 33

###### 01
Le Seigneur parla à Moïse : « Va, toi et le peuple que tu as fait monter du pays d’Égypte, monte d’ici vers la terre que j’ai juré de donner à Abraham, à Isaac et à Jacob, en leur disant : “C’est à ta descendance que je la donnerai.”
###### 02
J’enverrai devant toi un ange et je chasserai le Cananéen, l’Amorite, le Hittite, le Perizzite, le Hivvite et le Jébuséen.
###### 03
Monte vers une terre ruisselant de lait et de miel. Quant à moi, je ne monterai pas au milieu de toi, car tu es un peuple à la nuque raide, et je t’exterminerais en chemin. »
###### 04
À cette parole de malheur, le peuple prit le deuil, et personne ne porta plus ses habits de fête.
###### 05
Le Seigneur dit à Moïse : « Répète aux fils d’Israël : Vous êtes un peuple à la nuque raide. Si je montais un seul instant au milieu de toi, je t’exterminerais. Maintenant débarrasse-toi de tes habits de fête, et je saurai comment te traiter. »
###### 06
À partir de la montagne de l’Horeb, les fils d’Israël se défirent de leurs habits de fête.
###### 07
Moïse prenait la Tente et la plantait hors du camp, à bonne distance. On l’appelait : tente de la Rencontre, et quiconque voulait consulter le Seigneur devait sortir hors du camp pour gagner la tente de la Rencontre.
###### 08
Quand Moïse sortait pour aller à la Tente, tout le peuple se levait. Chacun se tenait à l’entrée de sa tente et suivait Moïse du regard jusqu’à ce qu’il soit entré.
###### 09
Au moment où Moïse entrait dans la Tente, la colonne de nuée descendait, se tenait à l’entrée de la Tente, et Dieu parlait avec Moïse.
###### 10
Tout le peuple voyait la colonne de nuée qui se tenait à l’entrée de la Tente, tous se levaient et se prosternaient, chacun devant sa tente.
###### 11
Le Seigneur parlait avec Moïse face à face, comme on parle d’homme à homme. Puis Moïse retournait dans le camp, mais son auxiliaire, le jeune Josué, fils de Noun, ne quittait pas l’intérieur de la Tente.
###### 12
Moïse dit au Seigneur : « Vois ! Tu me dis toi-même : “Fais monter ce peuple”, mais tu ne m’as pas fait connaître celui que tu enverras avec moi. Pourtant, c’est toi qui avais dit : “Je te connais par ton nom ; tu as trouvé grâce à mes yeux.”
###### 13
Maintenant, si j’ai vraiment trouvé grâce à tes yeux, fais-moi connaître ton chemin, et je te connaîtrai, je saurai que j’ai trouvé grâce à tes yeux. Considère aussi que cette nation est ton peuple. »
###### 14
Le Seigneur dit : « J’irai en personne te donner le repos. »
###### 15
Et Moïse répondit : « Si tu ne viens pas en personne, ne nous fais pas monter d’ici.
###### 16
À quoi donc reconnaître que moi j’ai trouvé grâce à tes yeux – et ton peuple également ? N’est-ce pas au fait que tu marcheras avec nous ? Ainsi, moi et ton peuple, nous serons différents de tous les peuples de la terre. »
###### 17
Le Seigneur dit à Moïse : « Même ce que tu viens de dire, je le ferai, car tu as trouvé grâce à mes yeux et je te connais par ton nom. »
###### 18
Moïse dit : « Je t’en prie, laisse-moi contempler ta gloire. »
###### 19
Le Seigneur dit : « Je vais passer devant toi avec toute ma splendeur, et je proclamerai devant toi mon nom qui est : LE SEIGNEUR. Je fais grâce à qui je veux, je montre ma tendresse à qui je veux. »
###### 20
Il dit encore : « Tu ne pourras pas voir mon visage, car un être humain ne peut pas me voir et rester en vie. »
###### 21
Le Seigneur dit enfin : « Voici une place près de moi, tu te tiendras sur le rocher ;
###### 22
quand passera ma gloire, je te mettrai dans le creux du rocher et je t’abriterai de ma main jusqu’à ce que j’aie passé.
###### 23
Puis je retirerai ma main, et tu me verras de dos, mais mon visage, personne ne peut le voir. »
