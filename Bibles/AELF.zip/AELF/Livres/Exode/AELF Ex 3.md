---
aliases : 
- Exode 3
- Exode 3
- Ex 3
- Exodus 3
tags : 
- Bible/Ex/3
- français
cssclass : français
---

# Exode 3

###### 01
Moïse était berger du troupeau de son beau-père Jéthro, prêtre de Madiane. Il mena le troupeau au-delà du désert et parvint à la montagne de Dieu, à l’Horeb.
###### 02
L’ange du Seigneur lui apparut dans la flamme d’un buisson en feu. Moïse regarda : le buisson brûlait sans se consumer.
###### 03
Moïse se dit alors : « Je vais faire un détour pour voir cette chose extraordinaire : pourquoi le buisson ne se consume-t-il pas ? »
###### 04
Le Seigneur vit qu’il avait fait un détour pour voir, et Dieu l’appela du milieu du buisson : « Moïse ! Moïse ! » Il dit : « Me voici ! »
###### 05
Dieu dit alors : « N’approche pas d’ici ! Retire les sandales de tes pieds, car le lieu où tu te tiens est une terre sainte ! »
###### 06
Et il déclara : « Je suis le Dieu de ton père, le Dieu d’Abraham, le Dieu d’Isaac, le Dieu de Jacob. » Moïse se voila le visage car il craignait de porter son regard sur Dieu.
###### 07
Le Seigneur dit : « J’ai vu, oui, j’ai vu la misère de mon peuple qui est en Égypte, et j’ai entendu ses cris sous les coups des surveillants. Oui, je connais ses souffrances.
###### 08
Je suis descendu pour le délivrer de la main des Égyptiens et le faire monter de ce pays vers un beau et vaste pays, vers un pays, ruisselant de lait et de miel, vers le lieu où vivent le Cananéen, le Hittite, l’Amorite, le Perizzite, le Hivvite et le Jébuséen.
###### 09
Maintenant, le cri des fils d’Israël est parvenu jusqu’à moi, et j’ai vu l’oppression que leur font subir les Égyptiens.
###### 10
Maintenant donc, va ! Je t’envoie chez Pharaon : tu feras sortir d’Égypte mon peuple, les fils d’Israël. »
###### 11
Moïse dit à Dieu : « Qui suis-je pour aller trouver Pharaon, et pour faire sortir d’Égypte les fils d’Israël ? »
###### 12
Dieu lui répondit : « Je suis avec toi. Et tel est le signe que c’est moi qui t’ai envoyé : quand tu auras fait sortir d’Égypte mon peuple, vous rendrez un culte à Dieu sur cette montagne. »
###### 13
Moïse répondit à Dieu : « J’irai donc trouver les fils d’Israël, et je leur dirai : “Le Dieu de vos pères m’a envoyé vers vous.” Ils vont me demander quel est son nom ; que leur répondrai-je ? »
###### 14
Dieu dit à Moïse : « Je suis qui je suis. Tu parleras ainsi aux fils d’Israël : “Celui qui m’a envoyé vers vous, c’est : JE-SUIS”. »
###### 15
Dieu dit encore à Moïse : « Tu parleras ainsi aux fils d’Israël : “Celui qui m’a envoyé vers vous, c’est LE SEIGNEUR, le Dieu de vos pères, le Dieu d’Abraham, le Dieu d’Isaac, le Dieu de Jacob”. C’est là mon nom pour toujours, c’est par lui que vous ferez mémoire de moi, d’âge en âge.
###### 16
Va, rassemble les anciens d’Israël. Tu leur diras : “Le Seigneur, le Dieu de vos pères, le Dieu d’Abraham, d’Isaac et de Jacob, m’est apparu. Il m’a dit : Je vous ai visités et ainsi j’ai vu comment on vous traite en Égypte.
###### 17
J’ai dit : Je vous ferai monter de la misère qui vous accable en Égypte vers le pays du Cananéen, du Hittite, de l’Amorite, du Perizzite, du Hivvite et du Jébuséen, le pays ruisselant de lait et de miel.”
###### 18
Ils écouteront ta voix ; alors tu iras, avec les anciens d’Israël, auprès du roi d’Égypte, et vous lui direz : “Le Seigneur, le Dieu des Hébreux, est venu nous trouver. Et maintenant, laisse-nous aller dans le désert, à trois jours de marche, pour y offrir un sacrifice au Seigneur notre Dieu.”
###### 19
Or, je sais, moi, que le roi d’Égypte ne vous laissera pas partir s’il n’y est pas forcé.
###### 20
Aussi j’étendrai la main, je frapperai l’Égypte par toutes sortes de prodiges que j’accomplirai au milieu d’elle. Après cela, il vous permettra de partir.
###### 21
Je ferai que ce peuple trouve grâce aux yeux des Égyptiens. Aussi, quand vous partirez, vous n’aurez pas les mains vides.
###### 22
Chaque femme demandera à sa voisine et à l’étrangère qui réside en sa maison des objets d’argent, des objets d’or et des manteaux : vous les ferez porter par vos fils et vos filles. Ainsi vous dépouillerez les Égyptiens. »
