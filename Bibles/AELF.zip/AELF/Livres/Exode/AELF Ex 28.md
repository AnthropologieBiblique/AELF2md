---
aliases : 
- Exode 28
- Exode 28
- Ex 28
- Exodus 28
tags : 
- Bible/Ex/28
- français
cssclass : français
---

# Exode 28

###### 01
« Et toi, fais approcher, du milieu des fils d’Israël, ton frère Aaron avec ses fils, afin qu’il exerce pour moi le sacerdoce. Il y avait donc : Aaron et ses fils Nadab et Abihou, Éléazar et Itamar.
###### 02
Tu feras pour Aaron ton frère des vêtements sacrés, en signe de gloire et de majesté.
###### 03
Toi, tu t’adresseras à tous les artisans habiles, ceux que j’ai remplis d’un esprit de sagesse : ils feront les vêtements d’Aaron, afin que celui-ci soit consacré et qu’il exerce pour moi le sacerdoce.
###### 04
Voici les vêtements qu’ils feront : un pectoral, un éphod, un manteau, une tunique brodée, un turban et une ceinture. Ils feront donc des vêtements sacrés pour Aaron ton frère – et pour ses fils – afin qu’il exerce pour moi le sacerdoce.
###### 05
Ils utiliseront l’or, la pourpre violette, la pourpre rouge, le cramoisi éclatant et le lin.
###### 06
Ils feront l’éphod en or, pourpre violette et pourpre rouge, cramoisi éclatant et lin retors. Ce sera une œuvre d’artiste.
###### 07
L’éphod sera fixé aux deux extrémités par deux brides.
###### 08
L’écharpe portée au-dessus de l’éphod et faisant corps avec lui sera travaillée de la même manière : en or, pourpre violette, pourpre rouge, cramoisi éclatant, lin retors.
###### 09
Tu prendras ensuite deux pierres de cornaline et tu y graveras les noms des fils d’Israël :
###### 10
six sur la première pierre, six sur la seconde, selon l’ordre de naissance.
###### 11
On taillera les deux pierres et tu les graveras aux noms des fils d’Israël, comme on grave un sceau ; et tu les enchâsseras dans des chatons en or.
###### 12
Tu placeras les deux pierres sur les brides de l’éphod. Ces pierres seront un mémorial pour les fils d’Israël. Ainsi, devant le Seigneur, Aaron portera leurs noms sur ses deux épaules, en mémorial.
###### 13
Tu feras des chatons en or
###### 14
et deux chaînettes torsadées, en or pur, que tu placeras sur les chatons.
###### 15
Ensuite, tu feras le pectoral du jugement. Ce sera une œuvre d’artiste. Tu le feras de la même manière que l’éphod, en or, pourpre violette, pourpre rouge, cramoisi éclatant et lin retors.
###### 16
Il sera carré. On le doublera. Il aura un empan de côté.
###### 17
Tu le garniras de quatre rangées de pierres : la première, de sardoine, topaze et émeraude ;
###### 18
la deuxième, d’escarboucle, saphir et jaspe ;
###### 19
la troisième, de béryl, agate, et améthyste ;
###### 20
et la quatrième, de chrysolithe, cornaline et onyx. Elles seront serties dans l’or.
###### 21
Les pierres seront aux noms des fils d’Israël ; comme leurs noms, elles seront douze, gravées à la manière d’un sceau ; chacune portera le nom de l’une des douze tribus.
###### 22
Tu feras au pectoral des chaînettes tressées et torsadées, en or pur.
###### 23
Tu feras au pectoral deux anneaux d’or et tu fixeras les deux anneaux à deux extrémités du pectoral.
###### 24
Tu fixeras les deux torsades d’or aux deux anneaux, aux extrémités du pectoral,
###### 25
tandis que tu fixeras les deux extrémités des deux torsades aux deux chatons ; tu les fixeras aux brides de l’éphod par-devant.
###### 26
Tu feras deux anneaux d’or et tu les mettras à deux des extrémités du pectoral, du côté tourné vers l’éphod, en dedans.
###### 27
Tu feras deux anneaux d’or et tu les fixeras aux deux brides de l’éphod, à leur base, par-devant, près de leur point d’attache, au-dessus de l’écharpe de l’éphod.
###### 28
On reliera le pectoral par ses anneaux aux anneaux de l’éphod avec un cordon de pourpre violette : le pectoral sera sur l’écharpe de l’éphod et ne pourra pas s’en détacher.
###### 29
Ainsi, quand Aaron entrera dans le sanctuaire, il portera sur son cœur, avec le pectoral du jugement, les noms des fils d’Israël, en mémorial devant le Seigneur, perpétuellement.
###### 30
Tu placeras dans le pectoral du jugement les Ourim et les Toummim. Ces objets seront sur le cœur d’Aaron quand il se présentera devant le Seigneur. Aaron portera sur son cœur le jugement des fils d’Israël, devant le Seigneur, perpétuellement.
###### 31
Puis tu feras le manteau de l’éphod, tout entier de pourpre violette.
###### 32
Il aura en son milieu une ouverture pour la tête, bordée comme celle d’une cuirasse, et donc indéchirable. Ce sera l’œuvre d’un ouvrier tisserand.
###### 33
Sur les pans du manteau, tout autour, tu feras des grenades de pourpre violette, de pourpre rouge et de cramoisi éclatant, alternant avec des clochettes d’or, tout autour :
###### 34
clochette d’or et grenade, clochette d’or et grenade, sur les pans du manteau, tout autour.
###### 35
Aaron portera ce manteau quand il officiera. On entendra le son des clochettes, quand il entrera dans le sanctuaire, devant le Seigneur, ou qu’il en sortira. Et ainsi, il ne mourra pas.
###### 36
Puis tu feras un fleuron d’or pur. Comme sur un sceau, tu y graveras l’inscription : “Consacré au Seigneur”.
###### 37
Tu attacheras le fleuron à un cordon de pourpre violette et tu le placeras sur le devant du turban.
###### 38
Il se trouvera sur le front d’Aaron, et Aaron portera ainsi les fautes commises envers les choses saintes que consacreront les fils d’Israël, quelles que soient les choses saintes qu’ils donnent. Le fleuron restera toujours sur son front, pour que ces dons trouvent grâce devant le Seigneur.
###### 39
Enfin, tu broderas une tunique de lin, tu feras un turban de lin et une ceinture. Ce sera l’œuvre d’un artisan brocheur.
###### 40
Pour les fils d’Aaron, tu feras des tuniques, des ceintures et des tiares, en signe de gloire et de majesté.
###### 41
Tu en revêtiras ton frère Aaron ainsi que ses fils ; tu leur donneras l’onction, tu leur conféreras l’investiture, tu les consacreras, et ils exerceront pour moi le sacerdoce.
###### 42
Fais-leur aussi des caleçons de lin pour couvrir leur nudité, des reins jusqu’aux cuisses.
###### 43
Aaron et ses fils les porteront quand ils entreront dans la tente de la Rencontre ou s’approcheront de l’autel pour officier dans le sanctuaire ; ainsi, ils ne se chargeront pas d’une faute qui entraînerait leur mort. C’est là un décret perpétuel pour Aaron et pour sa descendance.
