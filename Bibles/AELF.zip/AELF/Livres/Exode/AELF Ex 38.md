---
aliases : 
- Exode 38
- Exode 38
- Ex 38
- Exodus 38
tags : 
- Bible/Ex/38
- français
cssclass : français
---

# Exode 38

###### 01
Il fit l’autel de l’holocauste en bois d’acacia. L’autel avait cinq coudées de long, cinq coudées de large – sa base était donc carrée – et trois coudées de haut.
###### 02
Il fit, aux quatre angles de l’autel, des cornes qui faisaient corps avec lui. Il le plaqua de bronze.
###### 03
Il fit tous les accessoires de l’autel : les vases, les pelles, les bols pour l’aspersion, les fourchettes et les brûle-parfums, le tout en bronze.
###### 04
Il fit pour l’autel une grille de bronze en forme de filet et il la mit sous la bordure de l’autel, en bas, à mi-hauteur.
###### 05
Il coula quatre anneaux aux quatre extrémités de la grille de bronze, pour loger les barres.
###### 06
Il fit les barres en bois d’acacia et il les plaqua de bronze.
###### 07
Il les engagea dans les anneaux placés sur les côtés de l’autel pour qu’elles servent à le porter. L’autel était creux, en planches.
###### 08
Il fit la cuve en bronze sur un support en bronze, avec les miroirs des femmes qui étaient de service à l’entrée de la tente de la Rencontre.
###### 09
Il fit le parvis. Du côté du Néguev, au sud, le parvis avait des toiles en lin retors, sur une longueur de cent coudées.
###### 10
Leurs vingt colonnes et leurs vingt socles étaient en bronze ; les crochets des colonnes et leurs tringles, en argent.
###### 11
De même, du côté nord, cent coudées, avec leurs vingt colonnes et leurs vingt socles en bronze ; les crochets des colonnes et leurs tringles étaient en argent.
###### 12
Du côté ouest, des toiles sur cinquante coudées, avec leurs dix colonnes et leurs dix socles ; les crochets des colonnes et leurs tringles étaient en argent.
###### 13
Du côté de l’est, vers le levant, cinquante coudées ;
###### 14
quinze coudées de toiles sur une aile, avec leurs trois colonnes et leurs trois socles,
###### 15
et, sur la deuxième aile, de part et d’autre de la porte du parvis, quinze coudées de toiles, avec leurs trois colonnes et leurs trois socles.
###### 16
Toutes les toiles de l’enceinte du parvis étaient en lin retors.
###### 17
Les socles des colonnes étaient en bronze ; leurs crochets et leurs tringles, en argent ; leurs chapiteaux étaient plaqués d’argent. Toutes les colonnes de l’enceinte du parvis étaient réunies par des tringles en argent.
###### 18
Œuvre d’artisan brocheur, le rideau de la porte du parvis était en pourpre violette, pourpre rouge, cramoisi éclatant et lin retors ; il avait vingt coudées de long et cinq coudées de haut – prises dans la largeur –, comme les toiles du parvis.
###### 19
Les quatre colonnes et leurs quatre socles étaient en bronze, leurs crochets étaient en argent, leurs chapiteaux et leurs tringles étaient plaqués d’argent.
###### 20
Tous les piquets pour la Demeure et l’enceinte du parvis étaient en bronze.
###### 21
Voici l’état des comptes de la Demeure – la Demeure du Témoignage – qui fut établi sur l’ordre de Moïse ; ce fut le service des Lévites, accompli par l’intermédiaire d’Itamar, fils d’Aaron, le prêtre.
###### 22
Beçalel, fils d’Ouri, fils de Hour, de la tribu de Juda, avait exécuté tout ce que le Seigneur avait ordonné à Moïse.
###### 23
Avec lui, Oholiab, fils d’Ahisamak, de la tribu de Dane : ciseleur et artiste, brocheur sur pourpre violette, pourpre rouge, cramoisi éclatant et lin.
###### 24
Total de l’or utilisé pour les travaux, tous les travaux du sanctuaire – et c’était l’or provenant de l’offrande – : vingt-neuf talents et sept cent trente sicles, en sicles du sanctuaire.
###### 25
Argent provenant des personnes recensées de la communauté : cent talents et mille sept cent soixante-quinze sicles, en sicles du sanctuaire,
###### 26
soit un béqua par tête ou un demi-sicle, en sicles du sanctuaire, pour tout homme passant au recensement, âgé de vingt ans et plus, soit six cent trois mille cinq cent cinquante hommes.
###### 27
Cent talents d’argent furent utilisés pour couler les socles du sanctuaire et les socles du rideau : cent socles avec les cent talents, un talent par socle.
###### 28
Avec les mille sept cent soixante-quinze sicles, on avait fait les crochets des colonnes, on avait plaqué leurs chapiteaux et on les avait reliées par des tringles.
###### 29
Bronze provenant de l’offrande : soixante-dix talents et deux mille quatre cents sicles.
###### 30
On en avait fait les socles de l’entrée de la tente de la Rencontre, l’autel de bronze et sa grille de bronze, tous les accessoires de l’autel,
###### 31
les socles de l’enceinte du parvis, les socles de la porte du parvis, tous les piquets de la Demeure et tous les piquets de l’enceinte du parvis.
