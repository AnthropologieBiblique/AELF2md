---
aliases : 
- Exode 39
- Exode 39
- Ex 39
- Exodus 39
tags : 
- Bible/Ex/39
- français
cssclass : français
---

# Exode 39

###### 01
Avec la pourpre violette, la pourpre rouge et le cramoisi éclatant, on fit les vêtements liturgiques pour officier dans le sanctuaire, et les vêtements sacrés destinés à Aaron, comme le Seigneur l’avait ordonné à Moïse.
###### 02
On fit l’éphod en or, pourpre violette, pourpre rouge, cramoisi éclatant et lin retors.
###### 03
On lamina des plaques d’or et on y découpa des rubans pour les entrelacer avec la pourpre violette, la pourpre rouge, le cramoisi éclatant et le lin : c’était une œuvre d’artiste.
###### 04
On attacha l’éphod par des brides fixées à ses deux extrémités.
###### 05
L’écharpe portée au-dessus de l’éphod et faisant corps avec lui fut travaillée de la même manière : en or, pourpre violette, pourpre rouge, cramoisi éclatant et lin retors, comme le Seigneur l’avait ordonné à Moïse.
###### 06
On apprêta ensuite les pierres de cornaline : elles étaient enchâssées dans des chatons en or, et on les grava aux noms des fils d’Israël, comme on grave un sceau.
###### 07
On plaça sur les brides de l’éphod ces pierres qui sont un mémorial pour les fils d’Israël, comme le Seigneur l’avait ordonné à Moïse.
###### 08
On fit le pectoral – œuvre d’artiste – de la même manière que l’éphod : en or, pourpre violette, pourpre rouge, cramoisi éclatant et lin retors.
###### 09
Il était carré. On lui fit une doublure. Il avait un empan de côté.
###### 10
On le garnit de quatre rangées de pierres : la première, de sardoine, topaze et émeraude ;
###### 11
la deuxième, d’escarboucle, saphir et jaspe ;
###### 12
la troisième, de béryl, agate et améthyste ;
###### 13
et la quatrième, de chrysolithe, cornaline et onyx. Elles étaient garnies de chatons d’or.
###### 14
Les pierres étaient aux noms des fils d’Israël ; comme leurs noms, elles étaient douze, gravées à la manière d’un sceau ; chacune portait le nom de l’une des douze tribus.
###### 15
On fit au pectoral des chaînettes tressées et torsadées, en or pur.
###### 16
On fit deux chatons d’or et deux anneaux d’or, et on fixa les deux anneaux à deux extrémités du pectoral.
###### 17
On fixa les deux torsades d’or aux deux anneaux, aux extrémités du pectoral ;
###### 18
on fixa les deux extrémités des deux torsades aux deux chatons ; on les fixa aux brides de l’éphod par-devant.
###### 19
On fit deux anneaux d’or et on les mit à deux extrémités du pectoral, du côté tourné vers l’éphod, en dedans.
###### 20
On fit deux anneaux d’or et on les fixa aux deux brides de l’éphod, à leur base, par-devant, près de leur point d’attache, au-dessus de l’écharpe de l’éphod.
###### 21
On relia le pectoral par ses anneaux aux anneaux de l’éphod avec un cordon de pourpre violette : le pectoral était sur l’écharpe de l’éphod et il ne pouvait s’en détacher. On exécuta cela comme le Seigneur l’avait ordonné à Moïse.
###### 22
On fit le manteau de l’éphod, tout entier de pourpre violette : c’était l’œuvre d’un ouvrier tisserand.
###### 23
Il avait en son milieu une ouverture, bordée comme celle d’une cuirasse, donc indéchirable.
###### 24
Sur les pans du manteau, on fit des grenades de pourpre violette, de pourpre rouge, de cramoisi éclatant et de lin retors,
###### 25
alternant avec des clochettes d’or pur, tout autour :
###### 26
clochette et grenade, clochette et grenade, sur les pans du manteau, tout autour, pour officier, comme le Seigneur l’avait ordonné à Moïse.
###### 27
On fit les tuniques de lin pour Aaron et pour ses fils : c’était l’œuvre d’un ouvrier tisserand.
###### 28
On fit aussi le turban de lin, les garnitures des tiares de lin, les caleçons de lin, en lin retors ;
###### 29
les ceintures en lin retors, pourpre violette, pourpre rouge et cramoisi éclatant : c’était l’œuvre d’un artisan brocheur. On exécuta cela comme le Seigneur l’avait ordonné à Moïse.
###### 30
On fit en or pur le fleuron, le saint diadème. Comme sur un sceau, on y grava l’inscription : « Consacré au Seigneur ».
###### 31
On attacha le fleuron à un cordon de pourpre violette et on le plaça sur le devant du turban, comme le Seigneur l’avait ordonné à Moïse.
###### 32
Ainsi fut achevé tout le service de la Demeure de la tente de la Rencontre. Les fils d’Israël s’étaient mis à l’œuvre : comme le Seigneur l’avait ordonné à Moïse, ainsi firent-ils.
###### 33
Alors ils présentèrent la Demeure à Moïse : la Tente et tous ses accessoires, ses agrafes, ses cadres, ses traverses, ses colonnes et ses socles,
###### 34
la couverture en peaux de béliers teintes en rouge et la couverture en cuir fin, le rideau de séparation ;
###### 35
l’arche du Témoignage, ses barres et le propitiatoire ;
###### 36
la table, tous ses accessoires et le pain de l’offrande ;
###### 37
le chandelier d’or pur, ses lampes, tous ses accessoires, l’huile du luminaire ;
###### 38
l’autel d’or, l’huile de l’onction, l’encens aromatique et le rideau pour l’entrée de la Tente ;
###### 39
l’autel de bronze, sa grille de bronze, ses barres et tous ses accessoires ; la cuve et son support ;
###### 40
les toiles du parvis, ses colonnes, ses socles, le rideau pour la porte du parvis, ses cordes, ses piquets et tous les accessoires du service de la Demeure, pour la tente de la Rencontre ;
###### 41
les vêtements liturgiques pour officier dans le sanctuaire, les vêtements sacrés pour Aaron, le prêtre, et les vêtements que portent ses fils pour exercer le sacerdoce.
###### 42
Les fils d’Israël avaient exécuté tout l’ouvrage, comme le Seigneur l’avait ordonné à Moïse.
###### 43
Moïse vit tout ce travail : voici qu’ils l’avaient fait ! Comme le Seigneur l’avait ordonné, ainsi avaient-ils fait. Alors Moïse les bénit.
