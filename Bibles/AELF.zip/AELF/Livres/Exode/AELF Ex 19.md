---
aliases : 
- Exode 19
- Exode 19
- Ex 19
- Exodus 19
tags : 
- Bible/Ex/19
- français
cssclass : français
---

# Exode 19

###### 01
Le troisième mois qui suivit la sortie d’Égypte, jour pour jour, les fils d’Israël arrivèrent dans le désert du Sinaï.
###### 02
C’est en partant de Rephidim qu’ils arrivèrent dans ce désert, et ils y établirent leur camp juste en face de la montagne.
###### 03
Moïse monta vers Dieu. Le Seigneur l’appela du haut de la montagne : « Tu diras à la maison de Jacob, et tu annonceras aux fils d’Israël :
###### 04
“Vous avez vu ce que j’ai fait à l’Égypte, comment je vous ai portés comme sur les ailes d’un aigle et vous ai amenés jusqu’à moi.
###### 05
Maintenant donc, si vous écoutez ma voix et gardez mon alliance, vous serez mon domaine particulier parmi tous les peuples, car toute la terre m’appartient ;
###### 06
mais vous, vous serez pour moi un royaume de prêtres, une nation sainte.” Voilà ce que tu diras aux fils d’Israël. »
###### 07
Moïse revint et convoqua les anciens du peuple, il leur exposa tout ce que le Seigneur avait ordonné.
###### 08
Le peuple tout entier répondit, unanime : « Tout ce que le Seigneur a dit, nous le mettrons en pratique. » Et Moïse rapporta au Seigneur les paroles du peuple.
###### 09
Le Seigneur dit à Moïse : « Je vais venir vers toi dans l’épaisseur de la nuée, pour que le peuple, qui m’entendra te parler, mette sa foi en toi, pour toujours. » Puis Moïse transmit au Seigneur les paroles du peuple.
###### 10
Le Seigneur dit encore à Moïse : « Va vers le peuple ; sanctifie-le, aujourd’hui et demain ; qu’ils lavent leurs vêtements,
###### 11
pour être prêts le troisième jour ; car, ce troisième jour, en présence de tout le peuple, le Seigneur descendra sur la montagne du Sinaï.
###### 12
Fixe des limites au peuple, en leur disant : Gardez-vous de gravir la montagne et d’en toucher le bord ! Quiconque touchera la montagne sera mis à mort !
###### 13
Le condamné, tu ne le toucheras pas de la main, il sera lapidé ou percé de flèches. Qu’il s’agisse d’un animal ou d’un homme, il ne vivra pas. Quand la trompe retentira, quelques-uns monteront sur la montagne. »
###### 14
Moïse descendit de la montagne vers le peuple. Il sanctifia le peuple ; tous lavèrent leurs vêtements,
###### 15
et Moïse dit au peuple : « Soyez prêts dans trois jours. N’approchez aucune femme. »
###### 16
Le troisième jour, dès le matin, il y eut des coups de tonnerre, des éclairs, une lourde nuée sur la montagne, et une puissante sonnerie de cor ; dans le camp, tout le peuple trembla.
###### 17
Moïse fit sortir le peuple hors du camp, à la rencontre de Dieu, et ils restèrent debout au pied de la montagne.
###### 18
La montagne du Sinaï était toute fumante, car le Seigneur y était descendu dans le feu ; la fumée montait, comme la fumée d’une fournaise, et toute la montagne tremblait violemment.
###### 19
La sonnerie du cor était de plus en plus puissante. Moïse parlait, et la voix de Dieu lui répondait.
###### 20
Le Seigneur descendit sur le sommet du Sinaï, il appela Moïse sur le sommet de la montagne, et Moïse monta vers lui.
###### 21
Le Seigneur dit à Moïse : « Descends et avertis le peuple de ne pas se précipiter pour voir le Seigneur, car beaucoup d’entre eux périraient.
###### 22
Même les prêtres qui s’approchent du Seigneur doivent se sanctifier, de peur que le Seigneur ne s’emporte contre eux. »
###### 23
Moïse répondit au Seigneur : « Le peuple ne peut pas monter sur la montagne du Sinaï, puisque, toi-même, tu nous as avertis en ces termes : “Délimite la montagne et sanctifie-la.” »
###### 24
Puis le Seigneur lui dit : « Va, descends. Ensuite, tu remonteras, toi et Aaron avec toi. Quant aux prêtres et au peuple, qu’ils ne se précipitent pas pour monter vers le Seigneur, de peur que le Seigneur ne s’emporte contre eux. »
###### 25
Moïse descendit vers le peuple et leur en fit part.
