---
aliases : 
- Exode 40
- Exode 40
- Ex 40
- Exodus 40
tags : 
- Bible/Ex/40
- français
cssclass : français
---

# Exode 40

###### 01
Le Seigneur parla à Moïse. Il dit :
###### 02
« Au premier mois, le premier jour du mois, tu dresseras la Demeure de la tente de la Rencontre.
###### 03
Tu y mettras l’arche du Témoignage et tu protégeras l’arche avec le rideau.
###### 04
Tu apporteras la table et tu la disposeras avec soin. Tu apporteras le chandelier et tu allumeras ses lampes.
###### 05
Tu placeras l’autel d’or pour l’encens devant l’arche du Témoignage et tu mettras le rideau à l’entrée de la Demeure.
###### 06
Tu placeras l’autel de l’holocauste devant l’entrée de la Demeure de la tente de la Rencontre.
###### 07
Tu placeras la cuve entre la tente de la Rencontre et l’autel, et tu y verseras de l’eau.
###### 08
Tu installeras l’enceinte du parvis et tu placeras le rideau de la porte du parvis.
###### 09
Tu prendras l’huile de l’onction, et tu feras l’onction sur la Demeure et tout ce qu’elle contient ; tu la consacreras, ainsi que tous ses accessoires, et elle sera sainte.
###### 10
Tu feras l’onction sur l’autel de l’holocauste et tous ses accessoires, tu le consacreras, et l’autel sera très saint.
###### 11
Tu feras l’onction sur la cuve et son support, et tu la consacreras.
###### 12
Tu feras approcher Aaron et ses fils de l’entrée de la tente de la Rencontre, tu les baigneras dans l’eau,
###### 13
tu revêtiras Aaron des vêtements sacrés, tu lui donneras l’onction et tu le consacreras afin qu’il exerce pour moi le sacerdoce.
###### 14
Tu feras approcher ses fils, tu les revêtiras de tuniques,
###### 15
tu leur donneras l’onction comme tu l’as donnée à leur père, afin qu’ils exercent pour moi le sacerdoce. Ainsi, l’onction reçue leur conférera un sacerdoce perpétuel, de génération en génération. »
###### 16
Moïse exécuta tout ce que le Seigneur lui avait ordonné.
###### 17
La demeure de Dieu fut érigée la deuxième année après la sortie d’Égypte, le premier jour du premier mois.
###### 18
Moïse érigea ainsi la Demeure : il en posa les bases, les poutres et les traverses, et il dressa les colonnes.
###### 19
Au-dessus de la Demeure, il déploya la Tente et la recouvrit comme le Seigneur le lui avait ordonné.
###### 20
Il prit le Témoignage et le déposa dans l’arche. Il mit à l’arche ses barres et la recouvrit de la plaque d’or appelée propitiatoire.
###### 21
Il introduisit l’arche dans la Demeure, et posa le rideau pour voiler l’arche du Témoignage comme le Seigneur le lui avait ordonné.
###### 22
Moïse plaça la table dans la tente de la Rencontre, sur le côté nord de la Demeure, à l’extérieur du rideau.
###### 23
Il y disposa une rangée de pains devant le Seigneur, comme le Seigneur le lui avait ordonné.
###### 24
Il mit le chandelier dans la tente de la Rencontre en face de la table, sur le côté sud de la Demeure.
###### 25
Il alluma les lampes devant le Seigneur, comme le Seigneur le lui avait ordonné.
###### 26
Il mit l’autel d’or dans la tente de la Rencontre, en face du rideau,
###### 27
et il y brûla de l’encens aromatique, comme le Seigneur le lui avait ordonné.
###### 28
Il mit le rideau à l’entrée de la Demeure.
###### 29
Il dressa l’autel de l’holocauste à l’entrée de la tente de la Rencontre et y présenta l’holocauste et l’offrande de céréales, comme le Seigneur le lui avait ordonné.
###### 30
Il posa la cuve entre la tente de la Rencontre et l’autel, et y versa de l’eau pour les ablutions.
###### 31
Moïse, Aaron et ses fils s’y lavaient les mains et les pieds ;
###### 32
quand ils entraient dans la tente de la Rencontre et qu’ils s’approchaient de l’autel, ils se lavaient, comme le Seigneur l’avait ordonné à Moïse.
###### 33
Moïse installa le parvis autour de la Demeure et de l’autel, et il plaça le voile de la porte du parvis. Ainsi Moïse acheva le travail.
###### 34
La nuée couvrit la tente de la Rencontre, et la gloire du Seigneur remplit la Demeure.
###### 35
Moïse ne pouvait pas entrer dans la tente de la Rencontre, car la nuée y demeurait et la gloire du Seigneur remplissait la Demeure.
###### 36
À chaque étape, lorsque la nuée s’élevait et quittait la Demeure, les fils d’Israël levaient le camp.
###### 37
Si la nuée ne s’élevait pas, ils campaient jusqu’au jour où elle s’élevait.
###### 38
Dans la journée, la nuée du Seigneur reposait sur la Demeure, et la nuit, un feu brillait dans la nuée aux yeux de tout Israël. Et il en fut ainsi à toutes leurs étapes.
