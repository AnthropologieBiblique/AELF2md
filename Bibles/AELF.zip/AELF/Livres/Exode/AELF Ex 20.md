---
aliases : 
- Exode 20
- Exode 20
- Ex 20
- Exodus 20
tags : 
- Bible/Ex/20
- français
cssclass : français
---

# Exode 20

###### 01
Alors Dieu prononça toutes les paroles que voici :
###### 02
« Je suis le Seigneur ton Dieu, qui t’ai fait sortir du pays d’Égypte, de la maison d’esclavage.
###### 03
Tu n’auras pas d’autres dieux en face de moi.
###### 04
Tu ne feras aucune idole, aucune image de ce qui est là-haut dans les cieux, ou en bas sur la terre, ou dans les eaux par-dessous la terre.
###### 05
Tu ne te prosterneras pas devant ces dieux, pour leur rendre un culte. Car moi, le Seigneur ton Dieu, je suis un Dieu jaloux : chez ceux qui me haïssent, je punis la faute des pères sur les fils, jusqu’à la troisième et la quatrième génération ;
###### 06
mais ceux qui m’aiment et observent mes commandements, je leur montre ma fidélité jusqu’à la millième génération.
###### 07
Tu n’invoqueras pas en vain le nom du Seigneur ton Dieu, car le Seigneur ne laissera pas impuni celui qui invoque en vain son nom.
###### 08
Souviens-toi du jour du sabbat pour le sanctifier.
###### 09
Pendant six jours tu travailleras et tu feras tout ton ouvrage ;
###### 10
mais le septième jour est le jour du repos, sabbat en l’honneur du Seigneur ton Dieu : tu ne feras aucun ouvrage, ni toi, ni ton fils, ni ta fille, ni ton serviteur, ni ta servante, ni tes bêtes, ni l’immigré qui est dans ta ville.
###### 11
Car en six jours le Seigneur a fait le ciel, la terre, la mer et tout ce qu’ils contiennent, mais il s’est reposé le septième jour. C’est pourquoi le Seigneur a béni le jour du sabbat et l’a sanctifié.
###### 12
Honore ton père et ta mère, afin d’avoir longue vie sur la terre que te donne le Seigneur ton Dieu.
###### 13
Tu ne commettras pas de meurtre.
###### 14
Tu ne commettras pas d’adultère.
###### 15
Tu ne commettras pas de vol.
###### 16
Tu ne porteras pas de faux témoignage contre ton prochain.
###### 17
Tu ne convoiteras pas la maison de ton prochain ; tu ne convoiteras pas la femme de ton prochain, ni son serviteur, ni sa servante, ni son bœuf, ni son âne : rien de ce qui lui appartient. »
###### 18
Tout le peuple voyait les éclairs, les coups de tonnerre, la sonnerie du cor et la montagne fumante. Le peuple voyait : ils frémirent et se tinrent à distance.
###### 19
Ils dirent à Moïse : « Toi, parle-nous, et nous écouterons ; mais que Dieu ne nous parle pas, car ce serait notre mort. »
###### 20
Moïse répondit au peuple : « N’ayez pas peur. Dieu est venu pour vous mettre à l’épreuve, pour que vous soyez saisis de crainte en face de lui, et que vous ne péchiez pas. »
###### 21
Le peuple se tint à distance, mais Moïse s’approcha de la nuée obscure où Dieu était.
###### 22
Le Seigneur dit à Moïse : « Tu parleras ainsi aux fils d’Israël : “Vous avez vu que je vous ai parlé du haut des cieux.
###### 23
Vous ne ferez pas, à côté de moi, des dieux d’argent ou d’or ; vous n’en ferez pas pour moi.
###### 24
Tu me feras un autel de terre pour offrir tes holocaustes et tes sacrifices de paix, ton petit et ton gros bétail ; en tout lieu où je ferai rappeler mon nom, je viendrai vers toi et je te bénirai.
###### 25
Mais si tu me fais un autel de pierres, tu ne le bâtiras pas en pierres de taille car, en y passant ton ciseau, tu les profanerais.
###### 26
Et tu ne monteras pas à mon autel par des marches, afin que ta nudité n’y soit pas découverte.” »
