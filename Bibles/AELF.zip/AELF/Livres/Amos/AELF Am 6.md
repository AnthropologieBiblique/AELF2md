---
aliases : 
- Amos 6
- Amos 6
- Am 6
tags : 
- Bible/Am/6
- français
cssclass : français
---

# Amos 6

###### 01
Malheur à ceux qui vivent bien tranquilles
dans Sion,
et à ceux qui se croient en sécurité
sur la montagne de Samarie,
ces notables de la première des nations,
vers qui se rend la maison d’Israël !
###### 02
Passez par Kalné, et voyez ;
de là, partez pour Hamath, la grande,
puis descendez à Gath des Philistins.
Ces villes sont-elles les meilleures des royaumes ?
Leur territoire, plus grand que votre territoire ?
###### 03
En croyant repousser le jour du malheur,
vous rapprochez le règne de la violence !
###### 04
Couchés sur des lits d’ivoire,
vautrés sur leurs divans,
ils mangent les agneaux du troupeau,
les veaux les plus tendres de l’étable ;
###### 05
ils improvisent au son de la harpe,
ils inventent, comme David, des instruments de musique ;
###### 06
ils boivent le vin à même les amphores,
ils se frottent avec des parfums de luxe,
mais ils ne se tourmentent guère du désastre d’Israël !
###### 07
C’est pourquoi maintenant ils vont être déportés,
ils seront les premiers des déportés ;
et la bande des vautrés n’existera plus.
###### 08
Le Seigneur Dieu le jure par lui-même
– oracle du Seigneur, Dieu de l’univers :
Moi, j’ai en horreur l’orgueil de Jacob,
et je déteste ses palais ;
aussi, je livrerai la ville et ce qu’elle renferme.
###### 09
Et s’il reste dix hommes dans une seule maison,
ils mourront.
###### 10
Un parent, celui qui sortira les ossements
hors de la maison, pour les brûler,
dira à celui qui est au fond de la maison :
« Y en a-t-il encore avec toi ? »
Celui-ci répondra : « Plus rien ! »
Il dira : « Silence !
Car on n’a plus à faire mémoire du nom du Seigneur ! »
###### 11
Voici que le Seigneur commande ;
il frappe la grande maison : elle s’écroule,
la petite maison : elle se fissure.
###### 12
Est-ce qu’on fait galoper des chevaux sur des rochers,
est-ce qu’on laboure la mer avec des bœufs,
pour que vous changiez le droit en venin
et le fruit de la justice en poison ?
###### 13
Il en est qui se réjouissent pour Lo-Debar
(c’est-à-dire Rien-du-tout),
et qui disent : « N’est-ce pas par notre force
que nous avons conquis Qarnaïm
(c’est-à-dire Les-Deux-Cornes) ? »
###### 14
Eh bien ! maison d’Israël, voici que moi
– oracle du Seigneur, Dieu de l’univers –,
je dresse contre vous une nation ;
elle vous opprimera depuis l’Entrée-de-Hamath
jusqu’au torrent de la Araba.
