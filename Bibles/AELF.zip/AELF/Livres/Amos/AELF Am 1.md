---
aliases : 
- Amos 1
- Amos 1
- Am 1
tags : 
- Bible/Am/1
- français
cssclass : français
---

# Amos 1

###### 01
PAROLES D’AMOS, qui fut l’un des éleveurs de troupeaux à Teqoa, – ce qu’il a vu sur Israël au temps d’Ozias, roi de Juda, et de Jéroboam, fils de Josias, roi d’Israël, deux ans avant le tremblement de terre.
###### 02
Il a dit :
Le Seigneur rugit depuis Sion,
depuis Jérusalem il donne de la voix ;
les pâturages des bergers sont désolés,
le sommet du Carmel est desséché.
###### 03
Ainsi parle le Seigneur :
À cause de trois crimes de Damas, et même de quatre,
je l’ai décidé sans retour !
Parce qu’ils ont broyé le Galaad
avec des herses de fer,
###### 04
j’enverrai un feu dans la maison d’Hazaël,
et il dévorera les palais de Ben-Hadad ;
###### 05
je briserai les verrous de Damas ;
je supprimerai de la Vallée-du-Mal tout habitant,
et de la Maison-d’Éden, celui qui tient le sceptre ;
et le peuple d’Aram sera déporté à Qir.
Le Seigneur a parlé.
###### 06
Ainsi parle le Seigneur :
À cause de trois crimes de Gaza, et même de quatre,
je l’ai décidé sans retour !
Parce qu’ils ont mené en déportation des masses de déportés,
pour les livrer à Édom,
###### 07
j’enverrai un feu dans la muraille de Gaza,
et il dévorera ses palais ;
###### 08
je supprimerai d’Ashdod tout habitant,
et d’Ascalon, celui qui tient le sceptre ;
je retournerai ma main contre Eqrone ;
le reste des Philistins périra.
Le Seigneur Dieu a parlé.
###### 09
Ainsi parle le Seigneur :
À cause de trois crimes de Tyr, et même de quatre,
je l’ai décidé sans retour !
Parce qu’ils ont livré à Édom
des masses de déportés,
sans garder mémoire de l’alliance entre frères,
###### 10
j’enverrai un feu dans la muraille de Tyr,
et il dévorera ses palais.
###### 11
Ainsi parle le Seigneur :
À cause de trois crimes d’Édom, et même de quatre,
je l’ai décidé sans retour !
Parce qu’il a poursuivi de l’épée son frère,
étouffant sa pitié,
et entretenu sans fin sa fureur,
gardant à jamais sa rancune,
###### 12
j’enverrai un feu dans Témane,
et il dévorera les palais de Bosra.
###### 13
Ainsi parle le Seigneur :
À cause de trois crimes des fils d’Ammone, et même de quatre,
je l’ai décidé sans retour !
Parce qu’ils ont éventré les femmes enceintes du Galaad,
pour élargir leur territoire,
###### 14
j’allumerai un feu dans la muraille de Rabba,
et il dévorera ses palais,
au cri de guerre, un jour de bataille,
dans la tempête, un jour d’ouragan ;
###### 15
son roi partira en déportation,
lui et ses princes, tous ensemble.
Le Seigneur a parlé.
