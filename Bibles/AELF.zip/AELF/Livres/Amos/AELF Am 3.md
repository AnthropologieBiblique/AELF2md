---
aliases : 
- Amos 3
- Amos 3
- Am 3
tags : 
- Bible/Am/3
- français
cssclass : français
---

# Amos 3

###### 01
Écoutez cette parole que le Seigneur prononce
contre vous, fils d’Israël,
contre tout le peuple qu’il a fait monter du pays d’Égypte :
###### 02
Je vous ai distingués, vous seuls,
parmi tous les peuples de la terre ;
aussi je vous demanderai compte
de tous vos crimes.
###### 03
Deux hommes font-ils route ensemble
sans s’être mis d’accord ?
###### 04
Est-ce que le lion rugit dans la forêt
sans avoir de proie ?
Le lionceau va-t-il crier du fond de sa tanière
sans avoir rien pris ?
###### 05
L’oiseau tombe-t-il dans le filet posé à terre
sans y être attiré par un appât ?
Le piège se relève-t-il du sol
sans avoir rien attrapé ?
###### 06
Va-t-on sonner du cor dans une ville
sans que le peuple tremble ?
Un malheur arrive-t-il dans une ville
sans qu’il soit l’œuvre du Seigneur ?
###### 07
– Car le Seigneur Dieu ne fait rien
sans en révéler le secret
à ses serviteurs les prophètes.
###### 08
Quand le lion a rugi,
qui peut échapper à la peur ?
Quand le Seigneur Dieu a parlé,
qui refuserait d’être prophète ?
###### 09
Proclamez près des palais d’Ashdod,
près des palais du pays d’Égypte.
Dites :
Assemblez-vous sur les montagnes de Samarie,
voyez les grands désordres au milieu d’elle ;
en elle, que d’oppressions !
###### 10
Ils n’ont pas su agir avec droiture
– oracle du Seigneur –,
ceux qui entassent dans leurs palais
violence et rapine.
###### 11
C’est pourquoi – ainsi parle le Seigneur Dieu –
l’ennemi encerclera le pays ;
il te dépouillera de ta force
et tes palais seront pillés.
###### 12
Ainsi parle le Seigneur :
Comme un berger sauve de la gueule du lion
deux pattes ou un bout d’oreille,
voilà comment seront sauvés les fils d’Israël,
ceux qui sont, dans Samarie, assis au bord de leur couche,
sur leur divan de Damas !
###### 13
Écoutez et témoignez dans la maison de Jacob
– oracle du Seigneur Dieu, le Dieu de l’univers :
###### 14
car au jour de mon intervention, les crimes d’Israël seront sur lui,
et j’interviendrai contre les autels de Béthel :
les cornes de l’autel seront brisées,
elles tomberont à terre ;
###### 15
je ferai crouler maison d’hiver sur maison d’été,
les maisons d’ivoire seront détruites
et les vastes maisons disparaîtront
