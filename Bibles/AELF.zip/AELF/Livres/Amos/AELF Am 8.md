---
aliases : 
- Amos 8
- Amos 8
- Am 8
tags : 
- Bible/Am/8
- français
cssclass : français
---

# Amos 8

###### 01
Le Seigneur Dieu me donna cette vision :
c’était une corbeille de fruits mûrs.
###### 02
Il dit : « Que vois-tu, Amos ? »
Je répondis : « Une corbeille de fruits mûrs. »
Le Seigneur me dit :
« Mon peuple Israël est mûr, sa fin est arrivée ;
j’en ai fini de passer outre en sa faveur.
###### 03
Ce jour-là, les chants du palais hurleront,
– oracle du Seigneur Dieu.
Nombreux seront les cadavres,
en tout lieu on les jettera. Silence ! »
###### 04
Écoutez ceci, vous qui écrasez le malheureux
pour anéantir les humbles du pays,
###### 05
car vous dites :
« Quand donc la fête de la nouvelle lune sera-t-elle passée,
pour que nous puissions vendre notre blé ?
Quand donc le sabbat sera-t-il fini,
pour que nous puissions écouler notre froment ?
Nous allons diminuer les mesures,
augmenter les prix et fausser les balances.
###### 06
Nous pourrons acheter le faible pour un peu d’argent,
le malheureux pour une paire de sandales.
Nous vendrons jusqu’aux déchets du froment ! »
###### 07
Le Seigneur le jure par la Fierté de Jacob :
Non, jamais je n’oublierai aucun de leurs méfaits.
###### 08
À cause de cela, la terre ne va-t-elle pas trembler,
et toute sa population, prendre le deuil ?
Ne va-t-elle pas monter, tout entière, comme le Nil,
déborder, inonder, comme le fleuve d’Égypte ?
###### 09
Ce jour-là
– oracle du Seigneur Dieu –,
je ferai disparaître le soleil en plein midi,
en plein jour, j’obscurcirai la lumière sur la terre.
###### 10
Je changerai vos fêtes en deuil,
tous vos chants en lamentations ;
je vous obligerai tous à vous vêtir de toile à sac,
à vous raser la tête.
Je mettrai ce pays en deuil comme pour un fils unique,
et, dans la suite des jours, il connaîtra l’amertume.
###### 11
Voici venir des jours – oracle du Seigneur Dieu –,
où j’enverrai la famine sur la terre ;
ce ne sera pas une faim de pain ni une soif d’eau,
mais la faim et la soif d’entendre les paroles du Seigneur.
###### 12
On se traînera d’une mer à l’autre,
marchant à l’aventure du nord au levant,
pour chercher en tout lieu la parole du Seigneur,
mais on ne la trouvera pas.
###### 13
Ce jour-là, les jeunes filles en leur beauté se faneront
et les jeunes hommes souffriront de la soif.
###### 14
Ceux qui juraient par l’idole sacrilège de Samarie,
et qui disaient : « Vive ton dieu, Dane ! »
et : « Vive ton chemin, Bershéba ! »,
ils tomberont et ne se lèveront plus.
