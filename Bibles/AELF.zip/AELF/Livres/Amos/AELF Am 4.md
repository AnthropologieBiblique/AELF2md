---
aliases : 
- Amos 4
- Amos 4
- Am 4
tags : 
- Bible/Am/4
- français
cssclass : français
---

# Amos 4

###### 0
– oracle du Seigneur.
###### 01
Écoutez cette parole, vaches du Bashane,
sur la montagne de Samarie,
vous qui exploitez les faibles,
qui maltraitez les malheureux,
qui dites à vos seigneurs :
« Apportez-nous à boire ! »
###### 02
Le Seigneur Dieu le jure par sa sainteté :
Oui, voici venir sur vous des jours
où l’on vous enlèvera avec des crocs,
où votre progéniture sera prise au harpon ;
###### 03
vous sortirez par les brèches,
l’une devant l’autre,
et vous serez poussées vers l’Hermon
– oracle du Seigneur.
###### 04
Allez à Béthel et commettez vos crimes ;
à Guilgal, multipliez-les !
Apportez dès le matin vos sacrifices,
et le troisième jour, vos dîmes ;
###### 05
faites fumer en action de grâce du pain sans levain,
proclamez en public des offrandes volontaires,
car c’est cela que vous aimez, fils d’Israël !
– oracle du Seigneur Dieu.
###### 06
Quant à moi, voici ce que je vous ai donné :
rien à vous mettre sous la dent en toutes vos villes,
plus de pain en aucun lieu.
Et vous n’êtes pas revenus à moi !
– oracle du Seigneur.
###### 07
C’est moi aussi qui vous ai refusé la pluie
à trois mois de la récolte :
j’ai fait pleuvoir sur une ville,
et sur une autre ville je n’ai pas fait pleuvoir ;
une parcelle a reçu la pluie,
et une autre, sans pluie, s’est desséchée ;
###### 08
deux ou trois villes se traînaient vers une autre ville
pour boire de l’eau,
mais sans être désaltérées.
Et vous n’êtes pas revenus à moi !
– oracle du Seigneur.
###### 09
J’ai frappé votre blé de rouille et de nielle ;
et tous vos jardins et vos vignes,
vos figuiers et vos oliviers,
la chenille les a dévorés.
Et vous n’êtes pas revenus à moi !
– oracle du Seigneur.
###### 10
J’ai jeté la peste chez vous, comme en Égypte ;
j’ai tué par l’épée vos jeunes gens
quand on a capturé vos chevaux ;
la puanteur de votre camp,
je l’ai fait monter à vos narines.
Et vous n’êtes pas revenus à moi !
– oracle du Seigneur.
###### 11
J’ai tout détruit chez vous,
comme Dieu a détruit Sodome et Gomorrhe ;
vous étiez comme un tison
sauvé de l’incendie.
Et vous n’êtes pas revenus à moi !
– oracle du Seigneur.
###### 12
C’est pourquoi, voici comment je vais te traiter, Israël !
Et puisque c’est ainsi que je vais te traiter,
prépare-toi, Israël, à rencontrer ton Dieu.
###### 13
Car c’est lui qui façonne les montagnes
et crée le vent ;
il révèle aux hommes sa pensée,
il fait l’aurore et les ténèbres,
il marche sur les hauteurs de la terre :
son nom est « Le Seigneur, Dieu de l’univers ».
