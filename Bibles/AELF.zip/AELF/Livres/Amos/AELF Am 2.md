---
aliases : 
- Amos 2
- Amos 2
- Am 2
tags : 
- Bible/Am/2
- français
cssclass : français
---

# Amos 2

###### 01
Ainsi parle le Seigneur :
À cause de trois crimes de Moab, et même de quatre,
je l’ai décidé sans retour !
Parce qu’il a brûlé à la chaux vive
les os du roi d’Édom,
###### 02
j’enverrai un feu dans Moab,
et il dévorera les palais de Qeriyoth ;
Moab mourra dans le vacarme,
au cri de guerre, au son du cor ;
###### 03
de chez lui je supprimerai le juge,
et tuerai tous ses princes avec lui.
Le Seigneur a parlé.
###### 04
Ainsi parle le Seigneur :
À cause de trois crimes de Juda, et même de quatre,
je l’ai décidé sans retour !
Parce qu’ils ont rejeté la Loi du Seigneur,
et n’ont pas gardé ses décrets,
parce que leurs idoles les ont égarés,
celles que leurs pères avaient suivies,
###### 05
j’enverrai un feu en Juda,
et il dévorera les palais de Jérusalem.
###### 06
Ainsi parle le Seigneur :
À cause de trois crimes d’Israël, et même de quatre,
je l’ai décidé sans retour !
Ils vendent le juste pour de l’argent,
le malheureux pour une paire de sandales.
###### 07
Ils écrasent la tête des faibles dans la poussière,
aux humbles ils ferment la route.
Le fils et le père vont vers la même fille
et profanent ainsi mon saint nom.
###### 08
Auprès des autels, ils se couchent
sur les vêtements qu’ils ont pris en gage.
Dans la maison de leur Dieu,
ils boivent le vin de ceux qu’ils ont frappés d’amende.
###### 09
Moi, pourtant, j’avais détruit devant eux l’Amorite,
dont la stature égalait celle des cèdres
et la vigueur, celle des chênes !
Je l’avais anéanti de haut en bas,
depuis les fruits jusqu’aux racines.
###### 10
Moi, je vous avais fait monter du pays d’Égypte
et je vous avais, pendant quarante ans,
conduits à travers le désert,
pour vous donner en héritage le pays de l’Amorite.
###### 11
J’avais suscité des prophètes parmi vos fils
et, parmi vos jeunes gens, des naziréens (c’est-à-dire des hommes voués à Dieu).
Oui ou non, est-ce vrai, fils d’Israël ?
– oracle du Seigneur.
###### 12
Mais vous faites boire du vin aux naziréens,
et aux prophètes vous donnez cet ordre :
« Ne prophétisez pas ! »
###### 13
Eh bien, moi, maintenant, je vous écraserai sur place,
comme un char plein de gerbes
écrase tout sur son passage.
###### 14
L’homme le plus rapide ne pourra pas fuir,
le plus fort ne pourra pas montrer sa vigueur,
même le héros ne sauvera pas sa vie.
###### 15
L’archer ne tiendra pas,
le coureur n’échappera pas,
le cavalier ne sauvera pas sa vie.
###### 16
Le plus brave s’enfuira tout nu, ce jour-là,
– oracle du Seigneur.
