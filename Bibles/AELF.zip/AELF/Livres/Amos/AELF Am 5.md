---
aliases : 
- Amos 5
- Amos 5
- Am 5
tags : 
- Bible/Am/5
- français
cssclass : français
---

# Amos 5

###### 01
Écoutez cette parole que je profère contre vous,
une lamentation, maison d’Israël :
###### 02
Elle est tombée, la vierge d’Israël,
elle ne se relèvera plus ;
elle est abandonnée sur sa terre,
sans personne qui la relève.
###### 03
Car ainsi parle le Seigneur Dieu :
La ville d’où sortait un millier d’hommes
n’en aura plus qu’une centaine,
et celle d’où sortait une centaine
n’en aura plus que dix
pour la maison d’Israël.
###### 04
Car ainsi parle le Seigneur à la maison d’Israël :
Cherchez-moi et vous vivrez.
###### 05
Mais ne cherchez pas à Béthel,
n’entrez pas à Guilgal,
ne passez pas à Bershéba ;
car Guilgal sera entièrement déporté
et Béthel, réduit à néant.
###### 06
Cherchez le Seigneur et vous vivrez,
de peur qu’il ne tombe comme le feu sur la maison de Joseph,
un feu qui dévore,
et personne, à Béthel, pour l’éteindre !
###### 07
On change le droit en poison,
on jette à terre la justice.
###### 08
L’auteur des Pléiades et d’Orion,
qui change en matin l’ombre de la mort
et rend le jour obscur comme la nuit,
qui convoque les eaux de la mer
et les répand à la surface de la terre,
son nom est « Le Seigneur ».
###### 09
Sur le puissant il déchaîne la dévastation,
et la dévastation arrive sur la citadelle.
###### 10
Au tribunal, on déteste celui qui réprimande,
et l’homme intègre dans sa parole, on le hait.
###### 11
C’est pourquoi, vous qui avez pressuré le faible
et prélevé sur lui un tribut de blé,
les maisons que vous avez bâties en pierre de taille,
vous n’y habiterez pas,
les vignes exquises que vous avez plantées,
vous n’en boirez pas le vin.
###### 12
Oui, je connais vos nombreux crimes,
vos énormes péchés,
oppresseurs du juste, preneurs de pots-de-vin ;
au tribunal les malheureux sont écartés.
###### 13
C’est pourquoi, en ce temps-ci,
l’homme avisé se tait,
car c’est un temps de malheur.
###### 14
Cherchez le bien et non le mal,
afin de vivre.
Ainsi le Seigneur, Dieu de l’univers, sera avec vous,
comme vous le déclarez.
###### 15
Détestez le mal, aimez le bien,
faites régner le droit au tribunal ;
peut-être alors le Seigneur, Dieu de l’univers,
fera-t-il grâce à ce qui reste d’Israël.
###### 16
C’est pourquoi, ainsi parle le Seigneur,
le Dieu de l’univers, mon Seigneur :
Sur toutes les places, on fera des lamentations,
dans toutes les rues, on dira : « Hélas ! hélas ! »
On convoquera le paysan au deuil,
et aux lamentations, les pleureurs ;
###### 17
dans toutes les vignes, on fera des lamentations,
car je passerai au milieu de toi.
Le Seigneur a parlé.
###### 18
Malheur à ceux qui aspirent au jour du Seigneur !
Que sera-t-il pour vous, le jour du Seigneur ?
Jour de ténèbre et non de lumière !
###### 19
C’est comme un homme qui fuit devant un lion
et qui tombe sur un ours ;
il arrive à la maison, il pose la main sur le mur,
et le serpent le mord.
###### 20
Ainsi sera-t-il ténèbre, le jour du Seigneur,
et non lumière,
obscur, sans aucune clarté !
###### 21
Je déteste, je méprise vos fêtes,
je n’ai aucun goût pour vos assemblées.
###### 22
Quand vous me présentez des holocaustes et des offrandes,
je ne les accueille pas ;
vos sacrifices de bêtes grasses,
je ne les regarde même pas.
###### 23
Éloignez de moi le tapage de vos cantiques ;
que je n’entende pas la musique de vos harpes.
###### 24
Mais que le droit jaillisse comme une source ;
la justice, comme un torrent qui ne tarit jamais !
###### 25
Des sacrifices et des offrandes, m’en avez-vous apporté
pendant quarante ans au désert, maison d’Israël ?
###### 26
Vous portiez les statues de Sikkouth, votre roi, et de Kiyyoun,
avec l’étoile de vos dieux que vous aviez fabriqués.
###### 27
Je vous déporterai au-delà de Damas.
Le Seigneur a parlé.
Son nom est « Dieu de l’univers ».
