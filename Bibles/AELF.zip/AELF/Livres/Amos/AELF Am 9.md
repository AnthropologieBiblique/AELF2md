---
aliases : 
- Amos 9
- Amos 9
- Am 9
tags : 
- Bible/Am/9
- français
cssclass : français
---

# Amos 9

###### 01
Je vis le Seigneur debout près de l’autel.
Il dit : Frappe les chapiteaux,
et que tremblent les seuils !
Brise tous ceux qui sont en tête,
et les suivants, je les tuerai par l’épée ;
pas un d’entre eux ne pourra s’enfuir,
pas un d’entre eux ne pourra s’échapper.
###### 02
S’ils forcent le séjour des morts,
de là, ma main les extirpera ;
s’ils escaladent les cieux,
de là, je les ferai descendre ;
###### 03
s’ils se cachent au sommet du Carmel,
là, je les chercherai et les prendrai ;
s’ils se dérobent à mes yeux au fond de la mer,
là, je commanderai au Serpent de les mordre ;
###### 04
s’ils s’en vont en captivité, poussés par l’ennemi,
là-bas, je commanderai à l’épée de les tuer ;
j’aurai l’œil sur eux,
pour le malheur, non pour le bonheur.
###### 05
Le Seigneur, Dieu de l’univers,
qu’il touche la terre, elle s’effondre,
et tous ses habitants sont en deuil ;
elle monte, tout entière, comme le Nil,
elle baisse comme le fleuve d’Égypte.
###### 06
Lui qui bâtit son escalier dans le ciel
et fonde sa voûte sur la terre,
lui qui convoque les eaux de la mer
et les répand à la surface de la terre,
son nom est « Le Seigneur ».
###### 07
N’êtes-vous pas pour moi, fils d’Israël,
comme des fils d’Éthiopiens ?
– oracle du Seigneur.
N’ai-je pas fait monter Israël du pays d’Égypte ?
De Kaftor, les Philistins ? Et de Qir, les Araméens ?
###### 08
Voici les yeux du Seigneur Dieu sur le royaume pécheur :
je vais le supprimer de la surface de la terre ;
toutefois, je ne supprimerai pas entièrement la maison de Jacob
– oracle du Seigneur.
###### 09
Car voici que, moi, je commande ;
je vais secouer la maison d’Israël
parmi toutes les nations,
comme on secoue dans un crible,
et pas un caillou n’échappe.
###### 10
Tous les pécheurs de mon peuple
périront par l’épée,
eux qui disaient :
« Le malheur n’approchera pas,
il ne nous atteindra pas ! »
###### 11
Ce jour-là, je relèverai la hutte de David, qui s’écroule ;
je réparerai ses brèches, je relèverai ses ruines,
je la rebâtirai telle qu’aux jours d’autrefois,
###### 12
afin que ses habitants prennent possession
du reste d’Édom et de toutes les nations
sur lesquelles mon nom fut jadis invoqué,
– oracle du Seigneur, qui fera tout cela.
###### 13
Voici venir des jours
– oracle du Seigneur –
où se suivront de près laboureur et moissonneur,
le fouleur de raisins et celui qui jette la semence.
Les montagnes laisseront couler le vin nouveau,
toutes les collines en seront ruisselantes.
###### 14
Je ramènerai les captifs de mon peuple Israël ;
ils rebâtiront les villes dévastées et les habiteront ;
ils planteront des vignes et en boiront le vin ;
ils cultiveront des jardins et en mangeront les fruits.
###### 15
Je les planterai sur leur sol,
et jamais plus ils ne seront arrachés
du sol que je leur ai donné.
Le Seigneur ton Dieu a parlé.
