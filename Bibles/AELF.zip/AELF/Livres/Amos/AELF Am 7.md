---
aliases : 
- Amos 7
- Amos 7
- Am 7
tags : 
- Bible/Am/7
- français
cssclass : français
---

# Amos 7

###### 01
Le Seigneur Dieu me donna cette vision :
voici qu’il formait des sauterelles
au temps où le regain commence à pousser,
le regain après la fenaison pour le roi.
###### 02
Comme elles achevaient de dévorer l’herbe du pays,
je dis : « Seigneur Dieu, je t’en prie, pardonne !
Jacob est si petit ! Qui le relèverait ? »
###### 03
Le Seigneur s’en repentit.
« Cela n’arrivera pas », dit le Seigneur.
###### 04
Le Seigneur Dieu me donna cette vision :
voici que le Seigneur Dieu en appelait au procès par le feu ;
celui-ci avait dévoré les eaux profondes
et déjà il dévorait la campagne.
###### 05
Je dis : « Seigneur Dieu, je t’en prie, arrête !
Jacob est si petit ! Qui le relèverait ? »
###### 06
Le Seigneur s’en repentit.
« Cela non plus n’arrivera pas », dit le Seigneur.
###### 07
Il me donna cette vision :
voici que le Seigneur se tenait
sur un rempart monté d’aplomb,
il avait en main un fil à plomb.
###### 08
Le Seigneur me dit :
« Que vois-tu, Amos ? »
Je répondis : « Un fil à plomb ».
Le Seigneur me dit : « Voici que je tiens le fil à plomb
au milieu de mon peuple Israël ;
j’en ai fini de passer outre en sa faveur.
###### 09
Les lieux sacrés d’Isaac seront dévastés,
et les sanctuaires d’Israël, rasés ;
je me dresserai avec l’épée
contre la maison de Jéroboam. »
###### 10
Amazias, le prêtre de Béthel, envoya dire à Jéroboam, roi d’Israël : « Amos prêche la révolte contre toi, en plein royaume d’Israël ; le pays ne peut plus supporter tous ses discours,
###### 11
car voici ce que dit Amos : “Le roi Jéroboam périra par l’épée, et Israël sera déporté loin de sa terre.” »
###### 12
Puis Amazias dit à Amos : « Toi, le voyant, va-t’en d’ici, fuis au pays de Juda ; c’est là-bas que tu pourras gagner ta vie en faisant ton métier de prophète.
###### 13
Mais ici, à Béthel, arrête de prophétiser ; car c’est un sanctuaire royal, un temple du royaume. »
###### 14
Amos répondit à Amazias : « Je n’étais pas prophète ni fils de prophète ; j’étais bouvier, et je soignais les sycomores.
###### 15
Mais le Seigneur m’a saisi quand j’étais derrière le troupeau, et c’est lui qui m’a dit : “Va, tu seras prophète pour mon peuple Israël.”
###### 16
Écoute maintenant la parole du Seigneur, toi qui me dis : “Ne prophétise pas contre Israël, ne parle pas contre la maison d’Isaac.”
###### 17
Eh bien, voici ce que le Seigneur a dit :
Ta femme devra se prostituer en pleine ville,
tes fils et tes filles tomberont par l’épée,
la terre qui t’appartient sera partagée au cordeau,
toi, tu mourras sur une terre impure,
et Israël sera déporté loin de sa terre. »
